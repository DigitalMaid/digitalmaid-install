"""DigitalMaid Agentic OS core package."""

__version__ = "0.1.0"
