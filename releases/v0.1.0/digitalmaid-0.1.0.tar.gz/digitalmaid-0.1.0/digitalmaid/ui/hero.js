// Stage J hero: the Today readout (DESIGN.md C1). Wordmark + four-icon toolbar, a ring
// holding a canvas particle field whose four clusters are sized by the open items per
// PDCC phase, a rail of six node links with Doto badges (one may glow), and the "Next"
// strip fed by the server's next_action. The canvas is decoration only: it is
// aria-hidden and a visually-hidden sentence carries the same numbers.

import { el, icon, label, pillButton } from "./views.js";

const PHASES = [["plan", "Plan"], ["do", "Do"], ["check", "Check"], ["correction", "Correction"]];
// caption: the 9px Doto word under each node (D2); the glowing node's title is the Next reason.
const NODES = [
  { id: "plan", label: "Plan", caption: "Plan", href: "#/goals", icon: "plan" },
  { id: "do", label: "Do", caption: "Do", href: "#/goals", icon: "do" },
  { id: "check", label: "Check", caption: "Check", href: "#/review", icon: "check" },
  { id: "correction", label: "Correction", caption: "Fix", href: "#/review", icon: "correction" },
  { id: "automations", label: "Automations", caption: "Auto", href: "#/automations", icon: "automations" },
  { id: "inbox", label: "Inbox", caption: "Inbox", href: "#/capture", icon: "capture" },
];
const MIN_DOTS = 40;
const MAX_DOTS = 400;
const MAX_SPEED = 5; // px per second, brief: < 6
// Breathing tempo in rad/s per phase (full cycle ≈ 4–7 s). Plan is calm, Do is livelier,
// Check steady, Correction slowest — it should feel like something waiting, not racing.
const BREATH_TEMPO = { plan: 1.0, do: 1.5, check: 1.2, correction: 0.9 };
const HINT_KEY = "dm:hint:shortcuts";

export function summaryText(counts) {
  return PHASES.map(([id, name]) => `${name} ${counts?.[id] ?? 0}`).join(" · ");
}

function toolButton(id, name, title, onClick, extra = {}) {
  return el("button", { id, class: "hero-tool", type: "button", title, "aria-label": title, onclick: onClick, ...extra }, icon(name));
}

// Cluster dot counts: an empty phase still reads as a faint cluster.
export function dotCount(n) {
  return Math.max(MIN_DOTS, Math.min(MAX_DOTS, Number.isFinite(n) ? n : 0));
}

export function renderHero(today, { onCapture, onSearch, onLayout, onInfo, automationsDue = null, hintDismissed = null, onDismissHint } = {}) {
  const counts = today.pdcc_counts || {};
  const action = today.next_action || null;
  const editing = document.body.dataset.editing === "true";

  const toolbar = el("div", { class: "hero-toolbar", role: "toolbar", "aria-label": "Today tools" },
    toolButton("hero-capture", "pencil", "Quick capture (c)", onCapture),
    toolButton("hero-search", "search", "Search (/)", onSearch),
    toolButton("hero-layout", "layout", "Edit board layout", onLayout, { "aria-pressed": String(editing), dataset: { active: String(editing) } }),
    toolButton("hero-info", "info", "Keyboard shortcuts (?)", onInfo));

  const canvas = el("canvas", { id: "hero-canvas", class: "hero-canvas", "aria-hidden": "true" });
  const ring = el("div", { id: "hero-ring", class: "hero-ring" }, canvas,
    el("p", { id: "hero-summary", class: "visually-hidden" }, summaryText(counts)));

  const badges = { ...counts, automations: automationsDue, inbox: today.capture_inbox_count ?? 0 };
  const rail = el("ol", { id: "hero-rail", class: "hero-rail", "aria-label": "Areas by phase" }, NODES.map((node) => {
    const glow = action?.phase === node.id;
    const badge = badges[node.id];
    const badgeText = badge === null || badge === undefined ? "—" : String(badge);
    return el("li", { class: "hero-node-item" },
      el("a", { class: "hero-node", href: node.href, dataset: { node: node.id, glow: String(glow) },
        "aria-label": `${node.label}: ${badgeText}${glow ? ` — ${action.reason}` : ""}`, title: glow ? action.reason : node.label },
        el("span", { class: "hero-node-ring", "aria-hidden": "true" }, icon(node.icon)),
        el("span", { class: "badge num", "aria-hidden": "true" }, badgeText),
        el("span", { class: "hero-caption", "aria-hidden": "true" }, node.caption)));
  }));

  const next = el("div", { id: "next-strip", class: "next-strip" },
    label("Next", { class: "next-kicker" }),
    action
      ? [el("span", { class: "next-label" }, action.label),
        el("span", { class: "next-reason" }, action.reason),
        pillButton("Open", { href: action.href, class: "next-open" })]
      : [el("span", { class: "next-label is-clear" }, "Nothing is waiting on you right now."),
        el("span", { class: "next-reason" }, "Capture something or plan the next task."),
        pillButton("Capture", { onclick: onCapture, class: "next-open" })]);

  const showHint = hintDismissed === false || (hintDismissed === null && localStorage.getItem(HINT_KEY) !== "1");
  const hint = showHint
    ? el("div", { id: "shortcut-hint", class: "hint-pill" },
      el("span", {}, "Press ", el("kbd", {}, "?"), " for shortcuts"),
      el("button", { class: "hint-dismiss", type: "button", "aria-label": "Dismiss hint", onclick: (e) => {
        localStorage.setItem(HINT_KEY, "1");
        e.currentTarget.closest("#shortcut-hint")?.remove();
        onDismissHint?.();
      } }, icon("close")))
    : null;

  const hero = el("section", { id: "hero", class: "hero", "aria-label": "Today" },
    el("div", { class: "hero-mark wordmark", "aria-hidden": "true" }, el("span", { class: "wordmark-name" }, "DigitalMaid"), el("span", { class: "wordmark-sub" }, "Agentic OS")),
    toolbar,
    el("div", { class: "hero-stage" }, ring, rail),
    next, hint);

  startField(canvas, counts);
  return hero;
}

// --- particle field ---------------------------------------------------------------------
// A small star system in three dimensions. Layers, back to front by depth:
//   1. a dust shell of tiny faint stars, each twinkling on its own sine;
//   2. four orbital rings of stars, each in its own tilted plane, alternating direction (inner faster);
//   3. the four PDCC clusters (Plan, Do, Check, Correction), one colour each, sized by the live
//      counts, drifting inside their cluster and breathing (size + brightness + halo).
// The whole system rotates slowly on its own, and the user can grab it: dragging left/right
// spins it about the vertical axis, dragging up/down tilts it toward or away from the viewer.
// Release keeps the momentum, which eases back into the idle spin.

function token(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

const RINGS = [
  { r: 0.30, n: 30, speed: 0.11, tilt: [0.55, 0.20], alpha: 0.75 },
  { r: 0.50, n: 48, speed: -0.075, tilt: [-0.35, 0.45], alpha: 0.65 },
  { r: 0.72, n: 64, speed: 0.05, tilt: [0.25, -0.50], alpha: 0.55 },
  { r: 0.94, n: 84, speed: -0.032, tilt: [-0.15, 0.15], alpha: 0.45 },
];
const DUST = 220;
const IDLE_SPIN = 0.012;    // rad/s about the vertical axis when nobody is touching it
const DRAG_GAIN = 0.0075;   // rad per CSS pixel of drag
const FRICTION = 1.6;       // 1/s — how fast thrown momentum decays toward the idle spin
const CLUSTER_R = 0.52;     // cluster centres sit on this sphere (fraction of the field radius)
// Wind dust: free motes that ride a slowly turning breeze across the disc, independent of the
// 3D rotation. Shake dust: extra motes shed from the clusters while dragging, proportional to
// how hard the field is being shaken; they fade out and settle downward.
const WIND_MOTES = 140;
const WIND_SPEED = 0.028;   // fraction of R per second
const SHAKE_MAX = 700;      // cap on live shake motes
const SHAKE_GRAVITY = 0.09; // fraction of R per s² — a gentle settle, not a fall

// Rotation helpers: 3×3 matrices as flat arrays, row-major.
const I3 = [1, 0, 0, 0, 1, 0, 0, 0, 1];
function rotX(a) { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, c, -s, 0, s, c]; }
function rotY(a) { const c = Math.cos(a), s = Math.sin(a); return [c, 0, s, 0, 1, 0, -s, 0, c]; }
function mul(a, b) {
  const o = new Array(9);
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++)
    o[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
  return o;
}
function apply(m, x, y, z) {
  return [m[0] * x + m[1] * y + m[2] * z, m[3] * x + m[4] * y + m[5] * z, m[6] * x + m[7] * y + m[8] * z];
}

function makeParticles(counts, size) {
  const centre = size / 2;
  const R = size * 0.47;             // field radius in CSS px
  const spread = 0.30;               // cluster radius, fraction of R
  const ink = token("--ink-2") || "#c8c2b8";
  const colours = { plan: ink, do: token("--accent"), check: token("--phase-check"), correction: token("--phase-correction") };
  // Cluster centres: four directions on the sphere, two slightly toward the viewer, two away,
  // so a tilt drag visibly reorders them in depth.
  const dirs = {
    plan: [-0.62, -0.62, 0.48], do: [0.62, -0.62, -0.48],
    check: [0.62, 0.62, 0.48], correction: [-0.62, 0.62, -0.48],
  };
  const rnd = Math.random;

  const dust = [];
  for (let i = 0; i < DUST; i++) {
    // Uniform direction on the sphere, radius between 0.75 and 1.0.
    const u = rnd() * 2 - 1, t = rnd() * Math.PI * 2, s = Math.sqrt(1 - u * u), r = 0.75 + rnd() * 0.25;
    dust.push({ x: s * Math.cos(t) * r, y: s * Math.sin(t) * r, z: u * r, radius: 0.5 + rnd() * 0.8, alpha: 0.25 + rnd() * 0.4, tw: rnd() * Math.PI * 2, tempo: 0.4 + rnd() * 1.2 });
  }

  const rings = RINGS.map((ring) => ({
    ...ring, phase: rnd() * Math.PI * 2, plane: mul(rotX(ring.tilt[0]), rotY(ring.tilt[1])),
    stars: Array.from({ length: ring.n }, () => ({
      a: rnd() * Math.PI * 2, jitter: (rnd() - 0.5) * 0.02,
      radius: 0.7 + rnd() * 1.1, tw: rnd() * Math.PI * 2, tempo: 0.5 + rnd() * 1.0,
    })),
  }));

  const particles = [];
  for (const [id] of PHASES) {
    const [dx, dy, dz] = dirs[id];
    const n = Math.hypot(dx, dy, dz);
    const cx = (dx / n) * CLUSTER_R, cy = (dy / n) * CLUSTER_R, cz = (dz / n) * CLUSTER_R;
    for (let i = 0; i < dotCount(counts[id]); i++) {
      // Uniform direction, radius biased toward the cluster centre.
      const u = rnd() * 2 - 1, t = rnd() * Math.PI * 2, s = Math.sqrt(1 - u * u);
      const r = spread * rnd() * rnd() ** 0.35;
      const speed = (MAX_SPEED / R) * (0.3 + rnd() * 0.7);
      const du = rnd() * 2 - 1, dt = rnd() * Math.PI * 2, ds = Math.sqrt(1 - du * du);
      particles.push({ cx, cy, cz, ox: s * Math.cos(t) * r, oy: s * Math.sin(t) * r, oz: u * r,
        vx: ds * Math.cos(dt) * speed, vy: ds * Math.sin(dt) * speed, vz: du * speed,
        radius: 0.8 + rnd() * 1.0, colour: colours[id], alpha: 0.6 + rnd() * 0.4,
        breath: rnd() * Math.PI * 2, tempo: BREATH_TEMPO[id] * (0.85 + rnd() * 0.3), breathing: 0.5 });
    }
  }
  const wind = [];
  for (let i = 0; i < WIND_MOTES; i++) wind.push(newMote(rnd));
  return { centre, R, spread, ink, dust, rings, particles, wind, shake: [], windAngle: rnd() * Math.PI * 2,
    rot: I3, yawV: IDLE_SPIN, pitchV: 0, dragging: false, shakeEnergy: 0, shakeVx: 0, shakeVy: 0 };
}

// A wind mote somewhere on the disc (2D, screen space, fraction of R), with its own slow wobble.
function newMote(rnd, edge = false) {
  const a = rnd() * Math.PI * 2;
  const r = edge ? 1.0 : Math.sqrt(rnd());
  return { x: Math.cos(a) * r, y: Math.sin(a) * r, radius: 0.35 + rnd() * 0.6, alpha: 0.18 + rnd() * 0.3,
    wob: rnd() * Math.PI * 2, wobT: 0.6 + rnd() * 1.4, drift: 0.6 + rnd() * 0.8 };
}

function drawStar(ctx, x, y, radius, colour, alpha, glow) {
  ctx.globalAlpha = alpha;
  ctx.fillStyle = colour;
  ctx.shadowColor = colour;
  ctx.shadowBlur = glow;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
}

// Depth cue: things toward the viewer (z → +1) are a little larger and brighter.
function depthScale(z) { return 0.7 + 0.3 * (z + 1) / 2; }
function depthAlpha(z) { return 0.35 + 0.65 * (z + 1) / 2; }

function draw(ctx, size, f) {
  ctx.clearRect(0, 0, size, size);
  const c = f.centre, R = f.R, m = f.rot;
  // 0. wind dust — flat, behind the system
  for (const w of f.wind) {
    const tw = 0.6 + 0.4 * Math.sin(w.wob);
    drawStar(ctx, c + w.x * R, c + w.y * R, w.radius, f.ink, w.alpha * tw, 0);
  }
  // 1. dust
  for (const d of f.dust) {
    const [x, y, z] = apply(m, d.x, d.y, d.z);
    const tw = 0.5 + 0.5 * Math.sin(d.tw);
    drawStar(ctx, c + x * R, c + y * R, d.radius * depthScale(z), f.ink, d.alpha * (0.5 + 0.5 * tw) * depthAlpha(z), 0);
  }
  // 2. rings: stars on a circle in the ring's plane, then the faint orbit line as a polyline
  for (const ring of f.rings) {
    const pm = mul(m, ring.plane);
    for (const s of ring.stars) {
      const a = s.a + ring.phase, rr = ring.r + s.jitter;
      const [x, y, z] = apply(pm, Math.cos(a) * rr, Math.sin(a) * rr, 0);
      const tw = 0.5 + 0.5 * Math.sin(s.tw);
      drawStar(ctx, c + x * R, c + y * R, s.radius * (0.8 + 0.5 * tw) * depthScale(z), f.ink, ring.alpha * (0.5 + 0.5 * tw) * depthAlpha(z), 6 * tw);
    }
    ctx.globalAlpha = 0.14; ctx.strokeStyle = f.ink; ctx.lineWidth = 0.7; ctx.shadowBlur = 0;
    ctx.beginPath();
    for (let i = 0; i <= 72; i++) {
      const a = (i / 72) * Math.PI * 2;
      const [x, y] = apply(pm, Math.cos(a) * ring.r, Math.sin(a) * ring.r, 0);
      if (i === 0) ctx.moveTo(c + x * R, c + y * R); else ctx.lineTo(c + x * R, c + y * R);
    }
    ctx.stroke();
  }
  // 3. clusters, far to near so the front ones overdraw
  const projected = f.particles.map((p) => {
    const [x, y, z] = apply(m, p.cx + p.ox, p.cy + p.oy, p.cz + p.oz);
    return { p, x: c + x * R, y: c + y * R, z };
  });
  projected.sort((a, b) => a.z - b.z);
  for (const { p, x, y, z } of projected) {
    const b = p.breathing;
    const radius = p.radius * (0.6 + 1.6 * b) * depthScale(z);
    const alpha = p.alpha * depthAlpha(z);
    if (b > 0.45) drawStar(ctx, x, y, radius * 3.0, p.colour, alpha * (b - 0.45) * 0.22, 0); // halo on the inhale
    drawStar(ctx, x, y, radius, p.colour, alpha * (0.5 + 0.5 * b), 22 * b * b);
  }
  // 4. shake dust — shed motes in the cluster's colour, fading as they settle
  for (const s of f.shake) {
    const life = s.life / s.life0;
    drawStar(ctx, c + s.x * R, c + s.y * R, s.radius * (0.6 + 0.4 * life), s.colour, s.alpha * life, 3 * life);
  }
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 1;
}

function step(f, dt) {
  // Rotation: while dragging the pointer handler turns the system directly; when released the
  // thrown velocity eases back to the idle spin (yaw) and to rest (pitch).
  if (!f.dragging) {
    const k = Math.exp(-FRICTION * dt);
    f.yawV = IDLE_SPIN + (f.yawV - IDLE_SPIN) * k;
    f.pitchV *= k;
    f.rot = mul(mul(rotY(f.yawV * dt), rotX(f.pitchV * dt)), f.rot);
  }
  // Wind: the breeze direction turns slowly; motes drift with it plus a personal wobble, and
  // re-enter from the upwind edge when they leave the disc.
  f.windAngle += 0.05 * dt;
  const wx = Math.cos(f.windAngle), wy = Math.sin(f.windAngle);
  for (const w of f.wind) {
    w.wob += w.wobT * dt;
    const side = Math.sin(w.wob) * 0.35;
    w.x += (wx * w.drift + -wy * side) * WIND_SPEED * dt;
    w.y += (wy * w.drift + wx * side) * WIND_SPEED * dt;
    if (w.x * w.x + w.y * w.y > 1.02) {
      // Re-enter upwind, at a random point along the edge facing the wind.
      const spreadA = (Math.random() - 0.5) * Math.PI * 0.9;
      const a = Math.atan2(-wy, -wx) + spreadA;
      w.x = Math.cos(a) * 0.995; w.y = Math.sin(a) * 0.995;
    }
  }
  // Shake dust: shed while the field is being shaken, in proportion to the shake energy the
  // pointer handler accumulates; each mote inherits the cluster's colour and a kick outward.
  if (f.shakeEnergy > 0.02 && f.shake.length < SHAKE_MAX) {
    const budget = Math.min(60, Math.round(f.shakeEnergy * 90 * dt * 60));
    for (let i = 0; i < budget && f.shake.length < SHAKE_MAX; i++) {
      const p = f.particles[(Math.random() * f.particles.length) | 0];
      const [x, y, z] = apply(f.rot, p.cx + p.ox, p.cy + p.oy, p.cz + p.oz);
      const kick = 0.15 + Math.random() * 0.35 * Math.min(1, f.shakeEnergy);
      const ang = Math.random() * Math.PI * 2;
      f.shake.push({ x, y, vx: Math.cos(ang) * kick + f.shakeVx * 0.4, vy: Math.sin(ang) * kick + f.shakeVy * 0.4,
        colour: p.colour, radius: 0.5 + Math.random() * 0.9, alpha: 0.5 + Math.random() * 0.4 * depthAlpha(z),
        life0: 1.2 + Math.random() * 1.8, life: 0 });
      f.shake[f.shake.length - 1].life = f.shake[f.shake.length - 1].life0;
    }
  }
  f.shakeEnergy *= Math.exp(-3.5 * dt);
  for (let i = f.shake.length - 1; i >= 0; i--) {
    const s = f.shake[i];
    s.vx *= Math.exp(-1.4 * dt); s.vy = s.vy * Math.exp(-1.4 * dt) + SHAKE_GRAVITY * dt;
    s.x += s.vx * dt; s.y += s.vy * dt;
    s.life -= dt;
    if (s.life <= 0 || s.x * s.x + s.y * s.y > 1.1) { f.shake[i] = f.shake[f.shake.length - 1]; f.shake.pop(); }
  }
  for (const d of f.dust) d.tw += d.tempo * dt;
  for (const ring of f.rings) {
    ring.phase += ring.speed * dt;
    for (const s of ring.stars) s.tw += s.tempo * dt;
  }
  const limit = f.spread * 1.15;
  for (const p of f.particles) {
    p.ox += p.vx * dt; p.oy += p.vy * dt; p.oz += p.vz * dt;
    p.breath += p.tempo * dt;
    p.breathing = 0.5 + 0.5 * Math.sin(p.breath);
    // Drift is bounded: past the cluster edge the velocity turns back inward.
    if (p.ox * p.ox + p.oy * p.oy + p.oz * p.oz > limit * limit) {
      if (p.ox * p.vx > 0) p.vx = -p.vx;
      if (p.oy * p.vy > 0) p.vy = -p.vy;
      if (p.oz * p.vz > 0) p.vz = -p.vz;
    }
  }
}

// Grab-and-spin. Pointer events cover mouse, touch and pen; the canvas has touch-action: none
// so a phone drag rotates the system instead of scrolling the page.
function attachDrag(canvas, getField) {
  let lastX = 0, lastY = 0, lastT = 0;
  canvas.addEventListener("pointerdown", (e) => {
    const f = getField();
    if (!f || e.button !== 0 && e.pointerType === "mouse") return;
    f.dragging = true; f.yawV = 0; f.pitchV = 0; f.shakeVx = 0; f.shakeVy = 0;
    lastX = e.clientX; lastY = e.clientY; lastT = performance.now();
    canvas.setPointerCapture(e.pointerId);
    canvas.dataset.grabbing = "true";
    e.preventDefault();
  });
  canvas.addEventListener("pointermove", (e) => {
    const f = getField();
    if (!f || !f.dragging) return;
    const now = performance.now();
    const dx = e.clientX - lastX, dy = e.clientY - lastY, dt = Math.max((now - lastT) / 1000, 1 / 240);
    // Drag right → spin right (positive yaw); drag down → tilt the top toward the viewer.
    const yaw = dx * DRAG_GAIN, pitch = -dy * DRAG_GAIN;
    f.rot = mul(mul(rotY(yaw), rotX(pitch)), f.rot);
    // Remember the throw velocity (smoothed) for the release.
    f.yawV = f.yawV * 0.5 + (yaw / dt) * 0.5;
    f.pitchV = f.pitchV * 0.5 + (pitch / dt) * 0.5;
    // Shaking: energy grows with pointer speed and especially with direction reversals, so a
    // rapid back-and-forth sheds far more dust than a smooth slow turn.
    const sx = dx / dt / f.R, sy = dy / dt / f.R; // screen velocity in R/s
    const speed = Math.hypot(sx, sy);
    const reversal = (sx * f.shakeVx + sy * f.shakeVy) < 0 ? 2.5 : 1;
    f.shakeEnergy = Math.min(3, f.shakeEnergy + speed * reversal * dt * 1.6);
    f.shakeVx = sx; f.shakeVy = sy;
    lastX = e.clientX; lastY = e.clientY; lastT = now;
  });
  const release = (e) => {
    const f = getField();
    if (!f || !f.dragging) return;
    f.dragging = false;
    // Cap the throw so a flick never turns into a blur.
    f.yawV = Math.max(-4, Math.min(4, f.yawV));
    f.pitchV = Math.max(-4, Math.min(4, f.pitchV));
    delete canvas.dataset.grabbing;
    try { canvas.releasePointerCapture(e.pointerId); } catch { /* already released */ }
  };
  canvas.addEventListener("pointerup", release);
  canvas.addEventListener("pointercancel", release);
}

// Renders once (reduced motion) or animates until the canvas leaves the DOM for good.
// The hero is built before it is attached (the Today render awaits other data first), so the
// loop must wait for the canvas to be connected rather than give up on the first frame.
function startField(canvas, counts) {
  const ctx = canvas.getContext?.("2d");
  if (!ctx) return;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let size = 0, field = null, last = null, wasConnected = false;
  const fit = () => {
    const css = Math.round(canvas.clientWidth) || 0;
    if (!css) return false;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (css === size && canvas.width === Math.round(css * dpr)) return false;
    size = css;
    canvas.width = Math.round(css * dpr);
    canvas.height = Math.round(css * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const previous = field;
    field = makeParticles(counts, size);
    if (previous) field.rot = previous.rot; // keep the orientation across a resize
    return true;
  };
  attachDrag(canvas, () => field);
  const tick = (now) => {
    if (!canvas.isConnected) {
      if (wasConnected) { observer?.disconnect(); return; } // removed for good
      requestAnimationFrame(tick); // not attached yet — keep waiting
      return;
    }
    wasConnected = true;
    if (document.hidden) { last = null; requestAnimationFrame(tick); return; }
    fit();
    if (!field) { requestAnimationFrame(tick); return; }
    if (last !== null) step(field, Math.min((now - last) / 1000, 0.1));
    last = now;
    draw(ctx, size, field);
    if (reduced && !field.dragging && Math.abs(field.yawV - IDLE_SPIN) < 1e-3 && Math.abs(field.pitchV) < 1e-3) {
      // Reduced motion: hold still, but keep listening so a deliberate drag still works.
      requestAnimationFrame(tick); last = null; return;
    }
    requestAnimationFrame(tick);
  };
  const observer = typeof ResizeObserver === "function"
    ? new ResizeObserver(() => { if (fit() && field) draw(ctx, size, field); })
    : null;
  observer?.observe(canvas);
  requestAnimationFrame(tick);
}
