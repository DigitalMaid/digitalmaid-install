Bundled web fonts (self-hosted; the UI makes no external requests).
- Outfit (variable, weights 300–700) — SIL Open Font License 1.1 — https://github.com/Outfitio/Outfit-Fonts
- Doto (700, 900) — SIL Open Font License 1.1 — https://github.com/oliviersaidi/doto (via Google Fonts)
Files: outfit-latin.woff2, outfit-latin-ext.woff2, doto-latin.woff2, doto-latin-ext.woff2. Fetched 2026-09-06 from fonts.gstatic.com.
