# Third-party dependencies

Licenses below were read from the installed distributions' metadata on
2026-09-05 (`importlib.metadata`). Verify again against the lock used for any
release and preserve the packages' own notice files in the distribution.
No code from reference projects is used; only general-purpose libraries.

## Runtime (declared in `pyproject.toml`)

| Package | Version seen | License | Why |
|---|---|---|---|
| fastapi | 0.141.1 | MIT | HTTP API app factory, request-body validation, exception→status mapping |
| uvicorn | 0.52.4 | BSD-3-Clause | ASGI server for `digitalmaid serve`; loopback bind by default |
| pydantic | 2.13.5 | MIT | Strict request models (`StrictInt`/`StrictBool` keep floats out of money and flags) |

Transitive (pulled in by the above): starlette 1.6.0 BSD-3-Clause, pydantic-core
2.46.5 MIT, anyio 4.15.1 MIT, h11 0.16.0 MIT, click 8.5.0 BSD-3-Clause,
annotated-types 0.8.0 MIT, typing-extensions 4.16.0 PSF-2.0, typing-inspection
0.4.4 MIT, idna 3.19 BSD-3-Clause.

## Development only (`.[dev]`)

| Package | Version seen | License | Why |
|---|---|---|---|
| pytest | (existing) | MIT | Test runner |
| httpx2 | 2.12.0 | BSD-3-Clause | Transport for Starlette's `TestClient` (Starlette 1.6 deprecates `httpx` 0.x for this) |
| playwright | 1.62.0 | Apache-2.0 | Headless Chromium for `tests/test_ui_browser.py` (browser bundle lives outside the repo at `PLAYWRIGHT_BROWSERS_PATH`; the installed distribution's License metadata field is empty, licence read from the project's published terms) |

Transitive: httpcore2 2.12.0 BSD-3-Clause, certifi 2026.7.22 MPL-2.0,
truststore 0.10.4 MIT; playwright pulls pyee (MIT) and greenlet (MIT/PSF).
The Chromium build Playwright downloads is BSD-3-Clause and is not
redistributed by this repository.

## Bundled web fonts (`digitalmaid/ui/fonts/`, Stage I, 2026-09-06)

Self-hosted woff2 files served by the API at `/fonts/<name>` with `font/woff2` and a
one-year immutable cache header; the UI makes no external font requests and the
CSP stays `default-src 'self'`. Both are variable fonts (they carry `fvar` tables)
split into latin / latin-ext subsets with `unicode-range`.

| Font | Files | Licence | Source |
|---|---|---|---|
| Outfit (variable, weights 300–700) | outfit-latin.woff2, outfit-latin-ext.woff2 | SIL Open Font License 1.1 | https://github.com/Outfitio/Outfit-Fonts |
| Doto (variable, weights 700–900) | doto-latin.woff2, doto-latin-ext.woff2 | SIL Open Font License 1.1 | https://github.com/oliviersaidi/doto (via Google Fonts) |

The OFL permits bundling and redistribution with software; the fonts are not sold on
their own and keep their names. `digitalmaid/ui/fonts/README.md` restates this next to
the files and is served at `/fonts/README.md`.

## Not used

`python-multipart` (Apache-2.0) was permitted for the Capture Inbox upload route
(Stage H, 2026-09-06) but **not added**: installing it needed a network/approval
step unavailable in that session, and the stdlib `email.parser.BytesParser`
with `email.policy.HTTP` parses `multipart/form-data` (Python's documented
replacement for the removed `cgi.FieldStorage`). Binary round-trip is covered by
tests; FastAPI's `UploadFile`/`Form` helpers are therefore not used for that route.

No Node toolchain, bundler or front-end framework: the UI under
`digitalmaid/ui/` is hand-written HTML, CSS and ES modules served by the API.
SQLite comes from the Python standard library (public domain).
