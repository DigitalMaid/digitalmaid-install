// Stage F pages: Knowledge and Journal, Procedures (Stage K name for Skills and
// Workflows), Review Inbox, Deliverables (Stage K name for Outputs). Same rules as
// views.js: textContent only, every control does something real, keyboard reachable.

import { api } from "./api.js";
import { el, append, pill, phasePill, when, empty, emptyState, reasonsList, alertBox, field, form, runnerLabel, confirmDialog, pageHeader, techDetails, moreOptions, currentUser } from "./views.js";

const NOTE_KINDS = ["note", "journal", "research", "decision"];
const LINK_TARGETS = ["task", "project", "goal", "note", "output_version"];

function render(container, ...children) {
  container.replaceChildren();
  return append(container, children);
}

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function debounce(fn, ms) {
  let timer = null;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

function header(route, title, how, { meta = null, tools = [] } = {}) {
  return pageHeader(route, title, how, { meta, tools: tools.length ? el("div", { class: "form-actions" }, tools) : null });
}

// --- Knowledge and Journal ----------------------------------------------------------

const knowledge = { kind: "all", query: "" };

function decisionFields(decision) {
  const d = decision || {};
  return el("fieldset", { class: "decision-fields" }, el("legend", {}, "Decision record"),
    field("Options, one per line", "options", { required: true, rows: "3", value: (d.options || []).join("\n") }, "textarea"),
    el("div", { class: "form-row is-inline" },
      field("Chosen option", "chosen", { required: true, value: d.chosen || "" }),
      field("Confidence (1–5)", "confidence", { type: "number", min: "1", max: "5", step: "1", required: true, value: d.confidence ?? "3" }),
      field("Review date", "review_date", { type: "date", required: true, value: d.review_date || "" })),
    field("Reasoning", "reasoning", { required: true, rows: "2", value: d.reasoning || "" }, "textarea"),
    field("Expected result", "expected_result", { required: true, rows: "2", value: d.expected_result || "" }, "textarea"));
}

function readDecision(data) {
  return {
    options: data.options.split("\n").map((s) => s.trim()).filter(Boolean),
    chosen: data.chosen, reasoning: data.reasoning, expected_result: data.expected_result,
    confidence: Number.parseInt(data.confidence, 10), review_date: data.review_date,
  };
}

function noteItem(note, onOpen, selected) {
  return el("li", {},
    el("button", { class: `task-row${selected ? " is-selected" : ""}`, type: "button", dataset: { noteId: note.id }, "aria-current": selected ? "true" : null, onclick: () => onOpen(note.id) },
      el("span", {}, note.title, el("small", {}, note.kind === "journal" ? `journal · ${note.entry_date}` : note.kind, note.snippet ? ` · ${note.snippet}` : "", note.archived_at ? " · archived" : "")),
      pill(note.kind === "decision" && !note.outcome && note.decision && note.decision.review_date <= todayIso() ? "required" : "not_applicable", note.kind === "decision" && !note.outcome && note.decision && note.decision.review_date <= todayIso() ? "review due" : note.kind)));
}

export async function renderKnowledgePage(view, ctx, noteId) {
  const kind = knowledge.kind === "all" ? undefined : knowledge.kind;
  const [notes, searchHits] = await Promise.all([
    api.notes(kind),
    knowledge.query ? api.search(knowledge.query, 50).then((r) => r.notes) : Promise.resolve(null),
  ]);
  const shown = searchHits ? searchHits.filter((h) => !kind || h.kind === kind) : notes;
  const listNode = el("ul", { class: "list", id: "note-list" });
  const editorNode = el("section", { class: "panel", id: "note-editor", "aria-label": "Note editor" }, empty("Select a note or create one."));
  const status = el("div", { id: "note-search-status", class: "meta", role: "status", "aria-live": "polite" },
    knowledge.query ? `${shown.length} note${shown.length === 1 ? "" : "s"} match “${knowledge.query}”` : `${shown.length} note${shown.length === 1 ? "" : "s"}`);

  const openNote = async (id) => {
    location.hash = `#/knowledge/${id}`;
  };
  const openNewNote = () => { const d = document.getElementById("new-note"); if (d) { d.open = true; d.querySelector("[name=title]")?.focus(); } };
  render(listNode, shown.length ? shown.map((n) => noteItem(n, openNote, n.id === noteId))
    : el("li", {}, knowledge.query ? empty("No notes match.")
      : emptyState("knowledge", "Notes, daily journal entries, research and decision records live here; archiving hides, nothing is deleted.", "New note", openNewNote)));

  const tabs = el("div", { class: "tabs", role: "tablist", "aria-label": "Note kinds" },
    ["all", ...NOTE_KINDS].map((k) => el("button", {
      class: "tab", type: "button", role: "tab", dataset: { kindTab: k }, "aria-selected": String(knowledge.kind === k),
      onclick: () => { knowledge.kind = k; ctx.route(); },
    }, k === "all" ? "All" : k[0].toUpperCase() + k.slice(1))));

  const searchInput = el("input", { id: "note-search", type: "search", value: knowledge.query, placeholder: "Search title and body…", autocomplete: "off", "aria-describedby": "note-search-status" });
  searchInput.addEventListener("input", debounce(() => { knowledge.query = searchInput.value.trim(); ctx.route({ keepFocus: "#note-search" }); }, 250));

  let journalTools = null;
  if (knowledge.kind === "journal") {
    const today = todayIso();
    const existing = notes.find((n) => n.kind === "journal" && n.entry_date === today) || null;
    const button = el("button", { class: "btn is-primary", type: "button", id: "todays-entry", dataset: { written: String(Boolean(existing)) } },
      existing ? `Open today's entry (${today}, written)` : `Write today's entry (${today}, not yet written)`);
    button.addEventListener("click", async () => {
      button.disabled = true;
      try {
        let entry = existing;
        if (!entry) {
          try {
            entry = await api.createNote({ kind: "journal", title: `Journal ${today}`, body_md: "", actor: "ui", entry_date: today });
          } catch (error) {
            // Someone else wrote today's entry since the list loaded: open theirs.
            if (error.status !== 409) throw error;
            entry = await api.journalEntry(today);
          }
        }
        location.hash = `#/knowledge/${entry.id}`;
      } catch (error) {
        ctx.showGlobal(`Could not open today's entry: ${error.message}`, "error", error.reasons);
        button.disabled = false;
      }
    });
    journalTools = el("div", { class: "form-actions" }, button);
  }

  const newForm = newNoteForm(ctx);
  render(view,
    header("knowledge", "Knowledge and Journal", "Notes, daily journal, research and decisions. Nothing is deleted: archiving hides a note from lists and search."),
    el("div", { class: "knowledge-layout" },
      el("section", { class: "stack", "aria-label": "Notes" },
        tabs,
        el("div", { class: "form-row" }, el("label", { for: "note-search" }, "Search notes"), searchInput, status),
        journalTools,
        listNode,
        el("details", { class: "action", id: "new-note", open: noteId ? null : true }, el("summary", {}, "New note"), newForm)),
      editorNode));
  if (noteId) await renderNoteEditor(editorNode, noteId, ctx);
}

// Tier 1 is the title; the kind follows the current filter tab. Kind, author, entry date,
// the decision record and the body wait under More options, which opens itself when the
// preselected kind needs more than a title (a decision record).
function newNoteForm(ctx) {
  const preselected = knowledge.kind === "all" ? "note" : knowledge.kind;
  const kindSelect = field("Kind", "kind", { options: NOTE_KINDS, value: preselected }, "select");
  const entryRow = field("Entry date (journal)", "entry_date", { type: "date", value: todayIso() });
  const decisionRow = decisionFields(null);
  const more = moreOptions([
    el("div", { class: "form-row is-inline" }, kindSelect, field("Author", "actor", { required: true, value: currentUser() || "" })),
    entryRow, decisionRow,
    field("Body (Markdown)", "body_md", { rows: "4" }, "textarea"),
  ], { open: preselected === "decision" });
  const toggle = () => {
    const kind = kindSelect.querySelector("select").value;
    entryRow.hidden = kind !== "journal";
    decisionRow.hidden = kind !== "decision";
    if (kind === "decision") more.open = true;
  };
  kindSelect.querySelector("select").addEventListener("change", toggle);
  const node = form([
    field("Title", "title", { required: true }),
    more,
  ], "Create note", async (data) => {
    const body = { kind: data.kind, title: data.title, body_md: data.body_md || "", actor: data.actor };
    if (data.kind === "journal") body.entry_date = data.entry_date;
    if (data.kind === "decision") body.decision = readDecision(data);
    const note = await api.createNote(body);
    location.hash = `#/knowledge/${note.id}`;
  });
  node.id = "note-form";
  toggle();
  return node;
}

async function renderNoteEditor(container, noteId, ctx) {
  let note;
  try { note = await api.note(noteId); } catch (error) {
    render(container, alertBox("error", `Could not load note: ${error.message}`, error.reasons));
    return;
  }
  container.dataset.noteId = note.id;
  ctx.recordRecent?.({ type: "note", id: note.id, title: note.title });
  const refresh = () => ctx.route();
  const readOnly = Boolean(note.archived_at);
  const editForm = form([
    el("div", { class: "form-row is-inline" }, field("Title", "title", { required: true, value: note.title, disabled: readOnly }), field("Editor", "actor", { required: true, value: "ui", disabled: readOnly })),
    note.kind === "decision" ? decisionFields(note.decision) : null,
    field("Body (Markdown)", "body_md", { rows: "8", value: note.body_md, disabled: readOnly }, "textarea"),
  ], "Save", async (data) => {
    const body = { revision: note.revision, title: data.title, body_md: data.body_md, actor: data.actor };
    if (note.kind === "decision") body.decision = readDecision(data);
    await api.updateNote(note.id, body);
    refresh();
  });
  editForm.querySelector("button[type=submit]").disabled = readOnly;

  const archiveBox = el("div", { class: "form-actions" });
  const archiveButton = el("button", { class: "btn is-small", type: "button", disabled: readOnly }, "Archive…");
  archiveButton.addEventListener("click", () => {
    render(archiveBox,
      el("span", { class: "meta" }, "Archive this note? It leaves lists and search but is never deleted."),
      el("button", { class: "btn is-primary is-small", type: "button", onclick: async () => {
        try { await api.archiveNote(note.id, { revision: note.revision, actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(`Archive refused: ${error.message}`, "error", error.reasons); }
      } }, "Confirm archive"),
      el("button", { class: "btn is-small", type: "button", onclick: () => render(archiveBox, archiveButton) }, "Cancel"));
    archiveBox.querySelector("button").focus();
  });
  render(archiveBox, archiveButton);

  const linkPicker = linkPickerForm(note, refresh, ctx);
  const outcomeForm = note.kind === "decision" && !note.outcome
    ? form([field("Outcome (what actually happened)", "outcome", { required: true, rows: "2" }, "textarea"), field("Recorded by", "actor", { required: true })],
      "Record decision outcome", async (data) => { await api.decisionOutcome(note.id, data); refresh(); })
    : null;

  render(container,
    el("div", { class: "panel-header" },
      el("div", {}, el("h2", {}, note.title), el("div", { class: "meta" }, pill(note.kind), note.entry_date ? ` · ${note.entry_date}` : "", ` · revision ${note.revision} · updated ${when(note.updated_at)}`, note.archived_at ? ` · archived ${when(note.archived_at)}` : "")),
      archiveBox),
    readOnly ? alertBox("info", "Archived notes are read-only.") : null,
    note.kind === "decision" && note.decision ? el("dl", { class: "kv" },
      el("dt", {}, "Chosen"), el("dd", {}, `${note.decision.chosen} (confidence ${note.decision.confidence}/5)`),
      el("dt", {}, "Review"), el("dd", {}, note.decision.review_date, note.outcome ? ` · outcome recorded ${when(note.outcome_at)}: ${note.outcome}` : note.decision.review_date <= todayIso() ? " · review due" : "")) : null,
    outcomeForm ? el("details", { class: "action", open: true }, el("summary", {}, "Decision outcome"), outcomeForm) : null,
    editForm,
    el("section", { class: "drawer-section" }, el("h4", {}, "Links"),
      note.links.length ? el("ul", { class: "list" }, note.links.map((l) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" },
          el("span", {}, `${l.target_type.replace("_", " ")}: ${l.target_title ?? l.target_id}`),
          el("div", { class: "form-actions" },
            l.target_type === "task" ? el("button", { class: "btn is-small", type: "button", onclick: () => ctx.openTask(l.target_id) }, "Open task") : null,
            l.target_type === "note" ? el("button", { class: "btn is-small", type: "button", onclick: () => { location.hash = `#/knowledge/${l.target_id}`; } }, "Open note") : null,
            el("button", { class: "btn is-quiet is-small", type: "button", "aria-label": `Unlink ${l.target_type} ${l.target_title ?? ""}`, onclick: async () => {
              try { await api.unlinkNote(note.id, { target_type: l.target_type, target_id: l.target_id, actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(`Unlink refused: ${error.message}`, "error", error.reasons); }
            } }, "Unlink"))))))
        : empty("Not linked to anything yet."),
      el("details", { class: "action" }, el("summary", {}, "Link to a goal, project, task, output version or note"), linkPicker)));
  container.querySelector("h2")?.setAttribute("tabindex", "-1");
}

function linkPickerForm(note, refresh, ctx) {
  const typeField = field("Target type", "target_type", { options: LINK_TARGETS }, "select");
  const targetField = field("Target", "target_id", { options: [] }, "select");
  const targetSelect = targetField.querySelector("select");
  const load = async () => {
    const type = typeField.querySelector("select").value;
    targetSelect.replaceChildren(el("option", { value: "" }, "Loading…"));
    let options = [];
    try {
      if (type === "goal") options = (await api.goals()).map((g) => ({ value: g.id, label: g.title }));
      else if (type === "project") options = (await api.projects()).map((p) => ({ value: p.id, label: p.title }));
      else if (type === "task") options = (await api.get("/tasks")).map((t) => ({ value: t.id, label: `${t.title} (${t.status})` }));
      else if (type === "note") options = (await api.notes()).filter((n) => n.id !== note.id).map((n) => ({ value: n.id, label: `${n.title} (${n.kind})` }));
      else options = (await api.outputs()).map((v) => ({ value: v.id, label: `${v.task_title} v${v.version}` }));
    } catch (error) { ctx.showGlobal(`Could not load ${type}s: ${error.message}`); }
    targetSelect.replaceChildren(...(options.length ? options.map((o) => el("option", { value: o.value }, o.label)) : [el("option", { value: "" }, `No ${type.replace("_", " ")}s available`)]));
  };
  typeField.querySelector("select").addEventListener("change", load);
  const node = form([el("div", { class: "form-row is-inline" }, typeField, targetField)], "Link", async (data) => {
    if (!data.target_id) throw new Error("Choose a target first.");
    await api.linkNote(note.id, { target_type: data.target_type, target_id: data.target_id, actor: "ui" });
    refresh();
  });
  load();
  return node;
}

// --- Skills and Workflows (procedures) -----------------------------------------------

function stepsToText(steps) {
  return steps.map((s) => `${s.title} | ${s.instruction_md} | ${s.expected_evidence} | ${s.role}`).join("\n");
}

// A bare step title is enough: the evidence then defaults to the title itself, so a
// one-word-per-line list already publishes (the server refuses empty evidence).
function textToSteps(text) {
  return text.split("\n").map((s) => s.trim()).filter(Boolean).map((line) => {
    const [title = "", instruction_md = "", expected_evidence = "", role = "human"] = line.split("|").map((s) => s.trim());
    return { title, instruction_md, expected_evidence: expected_evidence || title, role: role || "human" };
  });
}

function stepsField(value) {
  return field("Steps, one per line (optionally: title | instruction | expected evidence | role)", "steps", { required: true, rows: "5", value, placeholder: "Sanitise the fermenter\nWeigh the sugar | 200 g | scale photo | human" }, "textarea");
}

function versionForm(procedure, { changelog = "", steps = null, onDone, proposalId = null }) {
  const current = procedure.current;
  const node = form([
    stepsField(stepsToText(steps || current.steps)),
    el("div", { class: "form-row is-inline" },
      field("Inputs, comma separated", "inputs", { value: current.inputs.join(", ") }),
      field("Outputs, comma separated", "outputs", { value: current.outputs.join(", ") }),
      field("Published by (human)", "created_by", { required: true })),
    field("Changelog", "changelog", { required: true, rows: "2", value: changelog }, "textarea"),
  ], proposalId ? "Publish new version applying this proposal" : `Publish version ${procedure.current_version + 1}`, async (data) => {
    const body = {
      revision: procedure.revision, steps: textToSteps(data.steps),
      inputs: data.inputs.split(",").map((s) => s.trim()).filter(Boolean),
      outputs: data.outputs.split(",").map((s) => s.trim()).filter(Boolean),
      changelog: data.changelog,
    };
    if (proposalId) await api.applyProposal(proposalId, { ...body, actor: data.created_by });
    else await api.publishProcedureVersion(procedure.id, { ...body, created_by: data.created_by });
    onDone();
  });
  node.id = proposalId ? "apply-proposal-form" : "new-version-form";
  return node;
}

export async function renderProceduresPage(view, ctx, procedureId) {
  const procedures = await api.procedures();
  const openNewProcedure = () => { const d = document.getElementById("new-procedure"); if (d) { d.open = true; d.querySelector("[name=title]")?.focus(); } };
  const list = el("ul", { class: "list" }, procedures.length
    ? procedures.map((p) => el("li", {}, el("button", { class: `task-row${p.id === procedureId ? " is-selected" : ""}`, type: "button", dataset: { procedure: p.id }, "aria-current": p.id === procedureId ? "true" : null, onclick: () => { location.hash = `#/procedures/${p.id}`; } },
      el("span", {}, p.title, el("small", {}, `${p.purpose} · v${p.current_version}`)), pill(p.status === "active" ? "available" : p.status === "retired" ? "missing" : "required", p.status))))
    : el("li", {}, emptyState("procedures", "Versioned procedures (SOPs) live here; running one creates a task per step, each waiting on the step before it.", "New procedure", openNewProcedure)));
  // Tier 1 (D3): a title and the steps — a procedure without steps cannot exist server-side.
  // Purpose falls back to the title; the author defaults to the signed-in user.
  const creator = form([
    field("Title", "title", { required: true }),
    stepsField(""),
    moreOptions([
      el("div", { class: "form-row is-inline" }, field("Purpose", "purpose", { placeholder: "defaults to the title" }), field("Created by", "created_by", { required: true, value: currentUser() || "" })),
      el("div", { class: "form-row is-inline" }, field("Inputs, comma separated", "inputs", {}), field("Outputs, comma separated", "outputs", {})),
    ]),
  ], "Create procedure (version 1, draft)", async (data) => {
    const created = await api.createProcedure({
      title: data.title, purpose: data.purpose.trim() || data.title, created_by: data.created_by, steps: textToSteps(data.steps),
      inputs: data.inputs.split(",").map((s) => s.trim()).filter(Boolean), outputs: data.outputs.split(",").map((s) => s.trim()).filter(Boolean),
      changelog: "initial version",
    });
    location.hash = `#/procedures/${created.id}`;
  });
  creator.id = "procedure-form";
  const detail = el("section", { class: "panel", id: "procedure-detail", "aria-label": "Procedure detail" }, empty("Select a procedure."));
  render(view,
    header("procedures", "Procedures", "Versioned procedures (SOPs). Publishing a new version never changes an old one; running a procedure creates one task per step, each waiting on the step before it."),
    el("div", { class: "knowledge-layout" },
      el("section", { class: "stack", "aria-label": "Procedures" }, list, el("details", { class: "action", id: "new-procedure", open: procedures.length ? null : true }, el("summary", {}, "New procedure"), creator)),
      detail));
  if (procedureId) await renderProcedureDetail(detail, procedureId, ctx);
}

async function renderProcedureDetail(container, procedureId, ctx, extra = null) {
  let procedure;
  try { procedure = await api.procedure(procedureId); } catch (error) {
    render(container, alertBox("error", `Could not load procedure: ${error.message}`, error.reasons));
    return;
  }
  const refresh = () => renderProcedureDetail(container, procedureId, ctx);
  const projects = await api.projects();
  const runResult = el("div", { class: "stack", id: "run-result" });
  const runForm = procedure.status === "retired" ? alertBox("info", "Retired procedures cannot be run.") : form([
    el("div", { class: "form-row is-inline" },
      field("Project", "project_id", { options: projects.map((p) => ({ value: p.id, label: p.title })) }, "select"),
      field("Version", "version", { options: procedure.versions.map((v) => ({ value: String(v.version), label: `v${v.version}` })).reverse() }, "select"),
      field("Task owner", "owner", { required: true })),
  ], "Run in project (creates the step tasks)", async (data) => {
    const run = await api.instantiateProcedure(procedure.id, { version: Number.parseInt(data.version, 10), project_id: data.project_id, owner: data.owner });
    render(runResult, alertBox("ok", `${run.tasks.length} step tasks created in Plan. Each step waits on the one before it.`),
      el("ol", { class: "list" }, run.tasks.map((t) => el("li", {}, el("button", { class: "task-row", type: "button", dataset: { stepTask: t.id }, onclick: () => ctx.openTask(t.id) }, el("span", {}, t.title, el("small", {}, `step ${t.step_index + 1} · next: ${t.next_action}`)), phasePill(t.status))))));
    runResult.querySelector("button")?.focus();
  });
  if (runForm.tagName === "FORM") runForm.id = "run-procedure-form";

  const statusTools = el("div", { class: "form-actions" },
    pill(procedure.status === "active" ? "available" : procedure.status === "retired" ? "missing" : "required", procedure.status),
    procedure.status === "draft" ? el("button", { class: "btn is-small", type: "button", onclick: async () => { try { await api.activateProcedure(procedure.id, { actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, "Activate") : null,
    procedure.status !== "retired" ? el("button", { class: "btn is-quiet is-small", type: "button", onclick: async () => { try { await api.retireProcedure(procedure.id, { actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, "Retire") : null);

  const proposalForm = form([
    field("From task (one created by this procedure)", "from_task_id", { options: (await api.get("/tasks")).filter((t) => t.procedure_id === procedure.id).map((t) => ({ value: t.id, label: `${t.title} (${t.status})` })) }, "select"),
    field("Learning", "text", { required: true, rows: "2" }, "textarea"),
    field("Proposed by", "actor", { required: true }),
  ], "Propose a learning", async (data) => { await api.proposeLearning(procedure.id, data); refresh(); });

  render(container,
    el("div", { class: "panel-header" }, el("div", {}, el("h2", {}, procedure.title), el("div", { class: "meta" }, `${procedure.purpose} · current v${procedure.current_version}`)), statusTools),
    extra,
    el("section", { class: "drawer-section" }, el("h4", {}, `Steps (v${procedure.current_version})`),
      el("ol", { class: "steps" }, procedure.current.steps.map((s) => el("li", {}, el("strong", {}, s.title), el("div", { class: "meta" }, s.instruction_md), el("div", { class: "meta" }, `evidence: ${s.expected_evidence} · role: ${s.role}`)))),
      el("div", { class: "meta" }, `inputs: ${procedure.current.inputs.join(", ") || "—"} · outputs: ${procedure.current.outputs.join(", ") || "—"}`)),
    el("section", { class: "drawer-section" }, el("h4", {}, "Run in project…"), runForm, runResult),
    el("section", { class: "drawer-section" }, el("h4", {}, "Version history (read-only)"),
      el("div", { class: "stack" }, procedure.versions.slice().reverse().map((v) => el("details", { class: "action", dataset: { version: v.version } },
        el("summary", {}, `v${v.version} · ${when(v.created_at)} · by ${v.created_by} · ${v.changelog}`),
        el("div", { class: "form" }, el("div", { class: "meta mono" }, `sha256 ${v.sha256}`),
          el("ol", { class: "steps" }, v.steps.map((s) => el("li", {}, s.title, el("div", { class: "meta" }, `${s.instruction_md} · evidence: ${s.expected_evidence} · role: ${s.role}`)))))))),
      procedure.status !== "retired" ? el("details", { class: "action" }, el("summary", {}, "Publish a new version"), versionForm(procedure, { onDone: refresh })) : null),
    el("section", { class: "drawer-section" }, el("h4", {}, "Learning proposals"),
      procedure.proposals.length ? el("ul", { class: "list" }, procedure.proposals.map((p) => el("li", { class: "list-item", dataset: { proposal: p.id } },
        el("div", { class: "list-item-title" }, el("span", {}, p.text), pill(p.status === "applied" ? "available" : p.status === "rejected" ? "missing" : "required", p.status)),
        el("div", { class: "meta" }, `by ${p.proposed_by} · ${when(p.created_at)}`, p.applied_version ? ` · applied in v${p.applied_version}` : "", p.decided_by && p.status !== "open" ? ` · decided by ${p.decided_by}` : ""),
        p.status === "open" && procedure.status !== "retired" ? el("div", { class: "form-actions" },
          el("button", { class: "btn is-small is-primary", type: "button", onclick: () => renderProcedureDetail(container, procedureId, ctx,
            el("section", { class: "panel", "aria-label": "Apply proposal" }, el("h3", {}, "Apply proposal as a new version"), el("p", { class: "meta" }, p.text),
              versionForm(procedure, { proposalId: p.id, changelog: `Applied proposal ${p.id}: `, onDone: refresh }))) }, "Apply…"),
          el("button", { class: "btn is-small", type: "button", onclick: async () => { try { await api.rejectProposal(p.id, { actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, "Reject")) : null)))
        : empty("No proposals yet."),
      el("details", { class: "action" }, el("summary", {}, "Propose a learning from a task"), proposalForm)),
    procedure.instantiations.length ? el("section", { class: "drawer-section" }, el("h4", {}, "Runs"),
      el("ul", { class: "list" }, procedure.instantiations.map((r) => el("li", { class: "list-item" }, `${r.project_title} · v${r.procedure_version} · ${r.done}/${r.steps} steps done · ${when(r.created_at)}`)))) : null);
  if (extra) container.querySelector("#apply-proposal-form textarea")?.focus();
}

// --- Review Inbox --------------------------------------------------------------------

function reviewItem(task, onOpen, ...extra) {
  return el("li", {}, el("button", { class: "task-row", type: "button", dataset: { taskId: task.id }, onclick: () => onOpen(task.id) },
    el("span", {}, task.title, el("small", {}, task.project_title ? `${task.project_title} · ` : "", ...extra)), phasePill(task.status)));
}

export async function renderReviewPage(view, ctx) {
  const inbox = await api.reviewInbox();
  render(view,
    header("review", "Review Inbox", "A finished process is not a checked output; a passed check is not acceptance.",
      { meta: el("p", { class: "meta" }, `${inbox.count} item${inbox.count === 1 ? "" : "s"} waiting for a human.`) }),
    el("div", { class: "grid is-thirds" },
      el("section", { class: "panel", "aria-labelledby": "review-check-title" }, el("h2", { id: "review-check-title" }, `Awaiting check (${inbox.awaiting_check.length})`),
        el("ul", { class: "list", id: "review-awaiting-check" }, inbox.awaiting_check.length
          ? inbox.awaiting_check.map((t) => reviewItem(t, (id) => ctx.openTask(id, { section: "check" }), `version ${t.latest_version.version} waiting for a check · ${when(t.latest_version.created_at)}`))
          : el("li", {}, emptyState("review", "Output versions without a check queue here; every latest version has one.", "Open Deliverables", "#/outputs")))),
      el("section", { class: "panel", "aria-labelledby": "review-revision-title" }, el("h2", { id: "review-revision-title" }, `Awaiting revised version (${inbox.awaiting_revision.length})`),
        el("ul", { class: "list", id: "review-awaiting-revision" }, inbox.awaiting_revision.length
          ? inbox.awaiting_revision.map((t) => reviewItem(t, (id) => ctx.openTask(id, { section: "output" }), `correction: ${t.correction.action} · owner ${t.correction.owner}`))
          : el("li", {}, emptyState("correction", "Open corrections wait here for a revised output version; none is open.")))),
      el("section", { class: "panel", "aria-labelledby": "review-decision-title" }, el("h2", { id: "review-decision-title" }, `Decision reviews due (${inbox.decision_reviews_due.length})`),
        el("ul", { class: "list", id: "review-decisions" }, inbox.decision_reviews_due.length
          ? inbox.decision_reviews_due.map((n) => el("li", {}, el("button", { class: "task-row", type: "button", onclick: () => { location.hash = `#/knowledge/${n.id}`; } },
            el("span", {}, n.title, el("small", {}, `chosen ${n.decision.chosen} · review date ${n.decision.review_date}`)), pill("required", "review due"))))
          : el("li", {}, emptyState("knowledge", "Decisions past their review date without an outcome surface here; none is due.", "New note", "#/knowledge"))))));
}

// --- Outputs -------------------------------------------------------------------------

const outputs = { accepted: "" };

export async function renderOutputsPage(view, ctx) {
  const versions = await api.outputs(outputs.accepted);
  const filter = el("select", { id: "outputs-filter", "aria-label": "Filter by acceptance" },
    el("option", { value: "" }, "All versions"), el("option", { value: "false" }, "Not accepted"), el("option", { value: "true" }, "Accepted"));
  filter.value = outputs.accepted;
  filter.addEventListener("change", () => { outputs.accepted = filter.value; ctx.route({ keepFocus: "#outputs-filter" }); });
  render(view,
    header("outputs", "Deliverables", "Every immutable output version in this scope, newest first. Acceptance is a human act recorded separately from any check.",
      { tools: [el("div", { class: "form-row" }, el("label", { for: "outputs-filter" }, "Show"), filter)] }),
    el("ul", { class: "list", id: "outputs-list" }, versions.length ? versions.map((v) => el("li", { class: "output-item" },
      el("button", { class: "task-row output-row", type: "button", dataset: { versionId: v.id }, onclick: () => ctx.openTask(v.task_id) },
        el("span", {}, `${v.task_title} — version ${v.version}`, v.superseded ? " (superseded)" : "",
          el("small", {}, `${when(v.created_at)} · check: ${v.check_status} · `, v.accepted ? `accepted by ${v.acceptance.accepted_by}` : "not accepted", v.execution ? ` · ${runnerLabel(v.execution)}` : "")),
        el("span", { class: "form-actions" }, phasePill(v.task_status), pill(v.accepted ? "available" : "required", v.accepted ? "accepted" : "not accepted"))),
      techDetails(`sha256 ${v.sha256}`, el("br"), `version ${v.id} · execution ${v.execution_id}`)))
      : el("li", {}, outputs.accepted ? empty("No output versions match this filter.")
        : emptyState("outputs", "Every immutable output version lands here once an execution submits one; acceptance is recorded separately.", "Open Goals", "#/goals"))));
}


// --- Settings and Connections ---------------------------------------------------------------

export async function renderSettingsPage(container, ctx) {
  const settings = await api.settings();
  const notice = el("div", { class: "stack", id: "settings-notice" });
  const agentPill = (a) => a.model_policy.kind === "fixture" ? pill("not_applicable", "test fixture")
    : pill(a.runner_status.configured ? "available" : "required", a.runner_status.configured ? "live, configured" : "live, unconfigured");
  const userRow = (u) => {
    const membership = u.memberships.find((m) => m.scope_id === settings.scope_id);
    const roleSelect = el("select", { "aria-label": `Role of ${u.username}`, disabled: Boolean(u.disabled_at) || null,
      onchange: async (e) => {
        const from = membership?.role ?? "none", to = e.target.value;
        const confirmed = await confirmDialog({
          title: "Change role?",
          message: `Change the role of ${u.username} in scope ${settings.scope_id} from ${from} to ${to}?${to !== "owner" && from === "owner" ? "\n\nThey will lose owner rights (user management, acceptance, decisions)." : ""}`,
          confirmLabel: `Change to ${to}`,
        });
        if (!confirmed) { e.target.value = from; return; }
        try { await api.setMembership(u.id, to); await ctx.route(); } catch (error) { e.target.value = from; notice.replaceChildren(alertBox("error", error.message, error.reasons)); } } },
      ["owner", "member", "viewer"].map((r) => el("option", { value: r, selected: membership?.role === r || null }, r)));
    return el("li", { class: "list-item", dataset: { username: u.username } },
      el("div", { class: "list-item-title" }, el("strong", {}, u.username), u.disabled_at ? pill("missing", "disabled") : pill("available", membership ? membership.role : "no membership here")),
      el("div", { class: "meta" }, `created ${when(u.created_at)} · memberships: ${u.memberships.map((m) => `${m.scope_id}=${m.role}`).join(", ") || "none"}`),
      u.disabled_at ? null : el("div", { class: "form-actions" }, roleSelect,
        el("button", { class: "btn is-small", type: "button", dataset: { write: "true" }, onclick: async () => {
          try { await api.disableUser(u.id); await ctx.route(); } catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); } } }, "Disable")));
  };
  const newUser = settings.users ? form([
    el("div", { class: "form-row is-inline" },
      field("Username", "new_username", { required: true, autocomplete: "off" }),
      field("Password (min 8 chars)", "new_password", { type: "password", required: true, autocomplete: "new-password" }),
      field("Role", "new_role", { options: ["viewer", "member", "owner"] }, "select")),
  ], "Add user", async (data) => { await api.createUser({ username: data.new_username, password: data.new_password, role: data.new_role }); await ctx.route(); }, { inline: false }) : null;
  const backup = settings.backup.last_backup_at
    ? `last backup ${when(settings.backup.last_backup_at)} → ${settings.backup.last_backup_path}`
    : "no backup yet — run: digitalmaid backup --root <root> --out <file.tar.gz>";
  // API tokens: owner only; the token value appears exactly once, in the response to create.
  const tokenOnce = el("div", { id: "token-once-box" });
  const tokenList = el("ul", { class: "list", id: "settings-tokens" });
  const renderTokens = (tokens) => tokenList.replaceChildren(...(tokens.length ? tokens.map((t) => el("li", { class: "list-item", dataset: { tokenId: t.id } },
    el("div", { class: "list-item-title" }, el("strong", {}, t.name), t.revoked_at ? pill("missing", "revoked") : pill("available", "active")),
    el("div", { class: "meta" }, `for ${t.username} · created ${when(t.created_at)} · last used ${t.last_used_at ? when(t.last_used_at) : "never"}`, t.revoked_at ? ` · revoked ${when(t.revoked_at)}` : ""),
    t.revoked_at ? null : el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", dataset: { write: "true" }, onclick: async () => {
      try { await api.revokeToken(t.id); renderTokens(await api.tokens()); } catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); } } }, "Revoke"))))
    : [el("li", {}, emptyState("settings", "Bearer tokens let Hermes post captures; a token reaches only /api/captures* and /api/healthz.", "Create a token",
      () => { const d = document.getElementById("token-details"); if (d) { d.open = true; d.querySelector("[name=name]")?.focus(); } }))]));
  const tokenForm = settings.api_tokens ? form([field("Token name (e.g. Hermes voice notes)", "name", { required: true })], "Create token (shown once)", async (data) => {
    const minted = await api.createToken({ name: data.name });
    tokenOnce.replaceChildren(el("div", { id: "token-once", class: "alert is-info", role: "status" },
      el("div", {}, `Token “${minted.name}” — copy it now, it is not shown again:`), el("code", { class: "mono token-value" }, minted.token)));
    renderTokens(await api.tokens());
  }) : null;
  if (tokenForm) tokenForm.id = "token-form";
  if (settings.api_tokens) renderTokens(settings.api_tokens);
  const passwordForm = form([
    field("Current password", "current_password", { type: "password", required: true, autocomplete: "current-password" }),
    field("New password (12+ characters)", "new_password", { type: "password", required: true, autocomplete: "new-password" }),
  ], "Change password", async (data) => {
    await api.changePassword(data.current_password, data.new_password);
    notice.replaceChildren(alertBox("info", "Password changed. Other signed-in sessions were signed out."));
  }, { inline: false });
  passwordForm.id = "password-form";
  const capture = settings.capture || {};
  // F9 — Uninstall: owners only. The app never gets root; it writes one flag file that the
  // installer's root path unit watches, so the button exists only where that unit exists.
  const uninstallPanel = settings.users ? renderUninstallPanel(settings, container) : null;
  // F10 — Hermes integration: owners only; status, the single-login trade-off, one-paste command.
  const hermesPanel = settings.users ? renderHermesPanel(settings) : null;
  const hermes = settings.hermes || {};
  const accountLine = hermes.session_trusted
    ? `Signed in via Hermes (trusted proxy) — all actions are recorded as ${ctx.currentUser() ?? "the owner"}.`
    : `Signed in as ${ctx.currentUser() ?? "you"}.`;
  container.replaceChildren(
    pageHeader("settings", "Settings and Connections",
      "Workspace identity, people and roles, agent configuration status, worker liveness, backups and declared external connections. Secrets are never shown — only whether a variable is set."),
    notice,
    el("div", { class: "grid" },
      el("section", { class: "panel", "aria-labelledby": "settings-workspace" }, el("h2", { id: "settings-workspace" }, "Workspace"),
        el("dl", { class: "kv" },
          el("dt", {}, "Workspace id"), el("dd", { class: "mono" }, settings.workspace_id),
          el("dt", {}, "Scope"), el("dd", {}, settings.scope_id),
          el("dt", {}, "Schema version"), el("dd", {}, String(settings.schema_version)),
          el("dt", {}, "Root path"), el("dd", { class: "mono" }, settings.root, el("span", { class: "meta" }, " (server-side, not editable)")),
          el("dt", {}, "Remote access"), el("dd", {}, settings.allow_remote ? "enabled (--allow-remote; HTTPS proxy required)" : "loopback only"),
          el("dt", {}, "Backup"), el("dd", {}, backup))),
      el("section", { class: "panel", "aria-labelledby": "settings-account-title" }, el("h2", { id: "settings-account-title" }, "Your account"),
        el("p", { class: "meta", id: "settings-account-line" }, accountLine), passwordForm),
      el("section", { class: "panel", "aria-labelledby": "settings-users-title" }, el("h2", { id: "settings-users-title" }, "Users and memberships"),
        settings.users
          ? el("div", { class: "stack" }, el("ul", { class: "list", id: "settings-users" }, settings.users.map(userRow)), el("details", { class: "action" }, el("summary", {}, "Add a user"), newUser))
          : el("div", { id: "settings-users" }, empty("Only owners can see and manage users."))),
      el("section", { class: "panel", "aria-labelledby": "settings-agents-title" }, el("h2", { id: "settings-agents-title" }, "Agent roles"),
        el("ul", { class: "list", id: "settings-agents" }, settings.agents.map((a) => el("li", { class: "list-item" },
          el("div", { class: "list-item-title" }, el("strong", {}, a.name), agentPill(a)),
          el("div", { class: "meta" }, a.credentials.length
            ? a.credentials.map((c) => `credential variable ${c.variable}: ${c.set ? "set" : "not set"}`).join(" · ")
            : "no credential needed"),
          a.runner_status.problems.length ? reasonsList(a.runner_status.problems.map((p) => `not configured: ${p}`)) : null)))),
      el("section", { class: "panel", "aria-labelledby": "settings-workers-title" }, el("h2", { id: "settings-workers-title" }, "Workers"),
        settings.workers.length
          ? el("ul", { class: "list" }, settings.workers.map((w) => el("li", { class: "list-item" },
            el("div", { class: "list-item-title" }, el("span", { class: "mono" }, w.worker_id), pill(w.alive ? "available" : "missing", w.alive ? "alive" : w.status)),
            el("div", { class: "meta" }, `last seen ${w.age_seconds}s ago${w.current_occurrence_id ? " · running an occurrence" : ""}`))))
          : empty("No worker heartbeat recorded. Start one with: digitalmaid worker --loop --root <root>")),
      el("section", { class: "panel", "aria-labelledby": "settings-capture-title" }, el("h2", { id: "settings-capture-title" }, "Capture Inbox"),
        el("dl", { class: "kv" },
          el("dt", {}, "Transcription"), el("dd", {}, "transcription: external — the app never transcribes audio; Hermes or a human supplies the text"),
          el("dt", {}, "Upload cap"), el("dd", {}, `${Math.round((capture.max_bytes || 0) / (1024 * 1024))} MB (capture_max_bytes in workspace.json)`),
          el("dt", {}, "Allowed types"), el("dd", {}, (capture.allowed_types || []).join(", ")))),
      el("section", { class: "panel", "aria-labelledby": "settings-tokens-title" }, el("h2", { id: "settings-tokens-title" }, "API tokens"),
        el("p", { class: "meta" }, "Bearer tokens for the Hermes seam (docs/HERMES-INTEGRATION.md). Scoped to /api/captures* and /api/healthz; everything else answers 403 “token scope”."),
        settings.api_tokens ? el("div", { class: "stack" }, tokenOnce, tokenList, el("details", { class: "action", id: "token-details" }, el("summary", {}, "Create a token"), tokenForm))
          : el("div", { id: "settings-tokens" }, empty("Only owners can mint and revoke API tokens."))),
      el("section", { class: "panel", "aria-labelledby": "settings-connections-title" }, el("h2", { id: "settings-connections-title" }, "Connections"),
        el("p", { class: "meta" }, "Declared in os-connections.json under the root. Read-only; no live integration runs yet (calendar/email/Hermes seams)."),
        el("ul", { class: "list", id: "settings-connections" }, settings.connections.length
          ? settings.connections.map((c) => el("li", { class: "list-item" },
            el("div", { class: "list-item-title" }, el("strong", {}, c.name), pill("not_applicable", c.status || "declared")),
            el("div", { class: "meta" }, `${c.kind} · owner ${c.owner}`)))
          : el("li", {}, emptyState("settings", "External connections are declared read-only in os-connections.json under the root; none is declared.")))),
      hermesPanel, uninstallPanel));
}

const HERMES_ONE_PASTE = "curl -fsSL https://raw.githubusercontent.com/DigitalMaid/digitalmaid-install/main/install.sh | bash -s -- --hermes";

function renderHermesPanel(settings) {
  const hermes = settings.hermes || {};
  const system = settings.install_mode === "system";
  const command = system ? HERMES_ONE_PASTE.replace("| bash -s --", "| sudo bash -s --") : HERMES_ONE_PASTE;
  return el("section", { class: "panel", id: "settings-hermes", "aria-labelledby": "settings-hermes-title" },
    el("h2", { id: "settings-hermes-title" }, "Hermes integration"),
    el("p", { class: "meta" }, "Show DigitalMaid as a tab inside the Hermes Agent dashboard on this machine (docs/HERMES-INTEGRATION.md, “Inside Hermes”)."),
    el("dl", { class: "kv" },
      el("dt", {}, "Trusted proxy"), el("dd", {}, hermes.trusted_proxy ? "trusted proxy: configured" : "trusted proxy: not configured"),
      el("dt", {}, "This session"), el("dd", {}, hermes.session_trusted ? "this session: signed in from Hermes" : "this session: signed in with a password")),
    el("p", { class: "meta" }, "Single login: inside the Hermes tab, whoever is signed in to Hermes acts as this workspace’s owner without a second password. The trade-off is a weaker per-user audit — every action taken from the tab is recorded as that owner. Keep individual DigitalMaid accounts if several people share the Hermes dashboard and you need to tell them apart."),
    el("p", { class: "meta" }, system ? "Install the tab: paste this on the server, as root (this is a system install)." : "Install the tab: paste this on the machine that runs Hermes."),
    el("code", { class: "mono token-value", id: "hermes-command" }, command),
    el("p", { class: "meta" }, "It copies the plugin into ~/.hermes/plugins/digitalmaid, creates the shared secret, enables the plugin in Hermes’s config.yaml and asks you to restart the Hermes dashboard. Nothing here restarts Hermes for you."));
}

function renderUninstallPanel(settings, view) {
  const available = Boolean(settings.uninstall?.available);
  const body = available
    ? el("div", { class: "stack" },
      el("p", { class: "meta" }, "Removes the app and its background services from this machine. Your workspace is kept unless you choose to erase it."),
      el("button", { class: "btn", type: "button", id: "uninstall-open", dataset: { write: "true" }, onclick: () => openUninstallDialog(settings, view) }, "Uninstall…"))
    : el("p", { class: "meta" }, "Uninstall from here is available for installs made by the one-command installer. Otherwise run digitalmaid-uninstall on the server.");
  return el("section", { class: "panel", id: "settings-uninstall", "aria-labelledby": "settings-uninstall-title" },
    el("h2", { id: "settings-uninstall-title" }, "Uninstall DigitalMaid"), body);
}

// The dialog is built per opening and removed on close, so the page never carries a
// half-filled password field. Same shell as #confirm-dialog (native modal, Esc/backdrop cancel).
function openUninstallDialog(settings, view) {
  const opener = document.activeElement;
  const notice = el("div", { id: "uninstall-notice" });
  const purge = el("input", { type: "checkbox", id: "uninstall-purge", name: "purge" });
  const password = el("input", { type: "password", id: "uninstall-password", name: "password", autocomplete: "current-password", required: true });
  const confirm = el("input", { type: "text", id: "uninstall-confirm", name: "confirm", autocomplete: "off", spellcheck: "false", required: true });
  const submit = el("button", { class: "btn is-danger", type: "submit", id: "uninstall-submit", disabled: true }, "Uninstall now");
  const cancel = el("button", { class: "btn", type: "button", id: "uninstall-cancel" }, "Cancel");
  const ready = () => { submit.disabled = !(confirm.value === "UNINSTALL" && password.value.length > 0); };
  password.addEventListener("input", ready);
  confirm.addEventListener("input", ready);
  const dialog = el("dialog", { id: "uninstall-dialog", class: "confirm-dialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "uninstall-title", "aria-describedby": "uninstall-message" },
    el("h2", { id: "uninstall-title" }, "Uninstall DigitalMaid?"),
    el("p", { id: "uninstall-message" }, "The app and its background services are removed from this machine. Signed-in sessions end. This cannot be cancelled once it starts."),
    el("form", { class: "form", id: "uninstall-form", novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      if (submit.disabled) return;
      submit.disabled = true;
      try {
        const result = await api.requestUninstall(password.value, confirm.value, purge.checked);
        close();
        renderUninstalling(view, settings, result);
      } catch (error) {
        notice.replaceChildren(alertBox("error", error.message, error.reasons));
        ready();
      } } },
      el("label", { class: "checkbox", for: "uninstall-purge" }, purge, "Also erase my data, backups and account (cannot be undone)"),
      el("div", { class: "form-row" }, el("label", { for: "uninstall-password", class: "is-required" }, "Your password"), password),
      el("div", { class: "form-row" }, el("label", { for: "uninstall-confirm", class: "is-required" }, "Type UNINSTALL to continue"), confirm),
      notice,
      el("div", { class: "form-actions" }, cancel, submit)));
  const close = () => { if (dialog.open) dialog.close(); dialog.remove(); opener?.focus?.(); };
  cancel.addEventListener("click", close);
  dialog.addEventListener("cancel", (e) => { e.preventDefault(); close(); });
  dialog.addEventListener("click", (e) => { if (e.target === dialog) close(); });
  document.body.append(dialog);
  dialog.showModal();
  password.focus();
}

// 202 accepted: the whole view becomes one quiet card and polls /api/healthz every 2 s; the
// first failure means the root unit has stopped the service, and the line becomes "Done."
function renderUninstalling(view, settings, result) {
  const meta = el("p", { class: "meta", id: "uninstalling-meta" }, "This page will stop responding in a few seconds. You can close this tab.");
  view.replaceChildren(el("div", { class: "uninstalling", id: "uninstalling", role: "status", "aria-live": "polite" },
    el("h1", {}, "Uninstalling DigitalMaid"),
    meta,
    el("p", { class: "meta" }, result.purge ? "Your data is being erased." : ["Your workspace was kept at ", el("span", { class: "mono" }, settings.root), "."])));
  const poll = async () => {
    if (!document.getElementById("uninstalling")) return;
    try { await api.healthz(); setTimeout(poll, 2000); } catch { meta.textContent = "Done."; }
  };
  setTimeout(poll, 2000);
}
