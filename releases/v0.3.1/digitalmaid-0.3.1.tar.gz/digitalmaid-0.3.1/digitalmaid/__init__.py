"""DigitalMaid Agentic OS core package."""

__version__ = "0.3.1"
