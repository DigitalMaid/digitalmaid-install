"""Command line: ``serve`` the API+UI for one root, or seed a ``demo`` root.

The demo data describes a fictional company, "Northwind Ferments", so the
example workspace never contains the owner's real goals.
"""

import argparse
import getpass
import json
import secrets
import signal
import struct
import sys
import threading
import time
import zlib
from datetime import timedelta
from pathlib import Path

from digitalmaid.backup import (BackupError, create_backup, pending_migrations,
                                restore_backup, verify_backup)
from digitalmaid.domain import Store
from digitalmaid.errors import ConflictError, InvariantError
from digitalmaid.worker import Worker

DEMO_SCOPE = "demo"
DEMO_USER = "demo"
_MONEY = {"amount_minor": 25000, "currency": "EUR"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="digitalmaid")
    commands = parser.add_subparsers(dest="command", required=True)

    serve = commands.add_parser("serve", help="serve the API and UI")
    serve.add_argument("--root", required=True, type=Path)
    serve.add_argument("--scope", default="personal")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", default=8765, type=int)
    serve.add_argument("--allow-remote", action="store_true",
                       help="required to bind anything but 127.0.0.1; needs an owner user"
                            " and an HTTPS reverse proxy in front (the app never terminates TLS)")

    demo = commands.add_parser(
        "demo", help="seed a synthetic example workspace (scope 'demo')")
    demo.add_argument("--root", required=True, type=Path)

    worker = commands.add_parser(
        "worker", help="plan, claim, run and complete due occurrences")
    worker.add_argument("--root", required=True, type=Path)
    worker.add_argument("--scope", default="personal")
    mode = worker.add_mutually_exclusive_group(required=True)
    mode.add_argument("--once", action="store_true",
                      help="run exactly one tick and exit")
    mode.add_argument("--loop", action="store_true",
                      help="tick every --interval-seconds until SIGTERM/SIGINT")
    worker.add_argument("--interval-seconds", default=15, type=int)
    worker.add_argument("--log-every-seconds", default=600, type=int,
                        help="with --loop: idle ticks print one heartbeat line this often"
                             " (ticks that did work always print)")
    worker.add_argument("--worker-id", default=None)
    worker.add_argument("--lease-seconds", default=120, type=int)
    worker.add_argument("--horizon-seconds", default=86400, type=int)

    user = commands.add_parser("user", help="manage users and scope memberships")
    user_cmd = user.add_subparsers(dest="user_command", required=True)
    create = user_cmd.add_parser("create")
    create.add_argument("--root", required=True, type=Path)
    create.add_argument("--username", required=True)
    create.add_argument("--scope", required=True)
    create.add_argument("--role", required=True, choices=("owner", "member", "viewer"))
    create.add_argument("--password-stdin", action="store_true",
                        help="read the password from stdin instead of prompting")
    listing = user_cmd.add_parser("list")
    listing.add_argument("--root", required=True, type=Path)
    disable = user_cmd.add_parser("disable")
    disable.add_argument("--root", required=True, type=Path)
    disable.add_argument("--username", required=True)
    disable.add_argument("--scope", default="personal")

    backup = commands.add_parser("backup", help="consistent snapshot of one root (ADR-007)")
    backup.add_argument("--root", type=Path)
    backup.add_argument("--out", type=Path)
    backup.add_argument("--verify", type=Path, metavar="FILE",
                        help="re-hash an existing archive without restoring")

    restore = commands.add_parser("restore", help="restore an archive into an EMPTY root")
    restore.add_argument("--archive", required=True, type=Path)
    restore.add_argument("--root", required=True, type=Path)

    migrate = commands.add_parser("migrate", help="apply or preview schema migrations")
    migrate.add_argument("--root", required=True, type=Path)
    migrate.add_argument("--preview", action="store_true",
                         help="list pending migrations without applying them")
    return parser


def _assess_all(store: Store, task_id: str, money_status: str = "available",
                skip: tuple[str, ...] = ()) -> None:
    for category in ("Man", "Method", "Machine", "Material", "Money"):
        if category in skip:
            continue
        if category == "Money":
            store.assess_resource(task_id, "Money", "Ingredient budget",
                                  money_status, **_MONEY)
        else:
            store.assess_resource(task_id, category,
                                  f"{category} for this batch", "available")


def _demo_png(size: int = 8) -> bytes:
    """A tiny valid PNG (solid amber square) generated in place; no asset files."""
    def chunk(kind: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + kind + data
                + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF))
    raw = b"".join(b"\x00" + b"\xd6\x9a\x5b\xff" * size for _ in range(size))
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def seed_demo(root: Path, demo_password: str | None = None) -> dict:
    """Populate ``root`` with Northwind Ferments; refuses a non-empty scope.

    Also creates the owner user ``demo``. The password is generated unless
    given, returned once under ``demo_password`` and stored nowhere in clear.
    """
    store = Store(root, scope_id=DEMO_SCOPE)
    try:
        if store.list_goals():
            sys.exit(f"{root} already contains demo data; choose an empty root")
        demo_password = demo_password or secrets.token_urlsafe(12)
        demo_user = store.create_user(DEMO_USER, demo_password, actor="demo")
        store.set_membership(demo_user["id"], DEMO_SCOPE, "owner", actor="demo")

        goal = store.create_goal(
            "Northwind Ferments: launch three shelf-stable kombucha flavours",
            "Ada Northwind", "3 flavours pass a 12-week stability panel")
        old_goal = store.create_goal(
            "Northwind Ferments: cut brewing water use by 20%",
            "Ada Northwind", "Metered litres per batch vs Q1 baseline")
        product = store.create_project(
            "Flavour development", "Bao Tran", goal["id"],
            "Each flavour has a signed-off recipe card")
        ops = store.create_project(
            "Water saving", "Ada Northwind", old_goal["id"],
            "Rinse cycle SOP revised and measured")

        # Blocked in Plan: two 5M categories never assessed, Money missing.
        blocked = store.create_task(
            product["id"], "Source organic ginger supplier", "Bao Tran",
            "Request samples from two suppliers",
            ["Two supplier quotes on file", "Sample batch tastes clean"], 2)
        _assess_all(store, blocked["id"], money_status="missing",
                    skip=("Machine", "Material"))

        # In Do with a running execution.
        brewing = store.create_task(
            product["id"], "Pilot brew: hibiscus lime", "Bao Tran",
            "Start 20 L pilot batch",
            ["pH between 2.8 and 3.2 at day 7", "Tasting panel score >= 4/5"],
            1, deadline="2026-09-19")
        _assess_all(store, brewing["id"])
        store.start_task(brewing["id"])
        store.record_execution(brewing["id"], "fixture-runner", "running",
                               model="fixture", provider="fixture",
                               log="Test fixture, not a live agent")

        # In Correction: first version failed one criterion.
        label = store.create_task(
            product["id"], "Draft back-label copy", "Cleo Marsh",
            "Write nutrition panel and story text",
            ["Allergen statement present", "Under 120 words"], 2)
        _assess_all(store, label["id"])
        store.start_task(label["id"])
        run = store.record_execution(label["id"], "fixture-runner", "succeeded",
                                     model="fixture", provider="fixture")
        v1 = store.submit_output(
            label["id"], run["id"],
            "# Hibiscus Lime\n\nBright, tart, alive. Brewed slowly in "
            "Northwind's cellar with organic hibiscus and fresh lime zest.\n")
        store.record_check(v1["id"], "Cleo Marsh", [
            {"criterion": "Allergen statement present", "passed": False,
             "evidence": "No allergen line in the draft"},
            {"criterion": "Under 120 words", "passed": True,
             "evidence": "38 words"}])

        # In Check, awaiting acceptance.
        sop = store.create_task(
            ops["id"], "Revise rinse cycle SOP", "Ada Northwind",
            "Rewrite step 4 with a metered rinse",
            ["Step 4 names the litre target", "Version number bumped"], 1)
        _assess_all(store, sop["id"])
        store.start_task(sop["id"])
        run = store.record_execution(sop["id"], "fixture-runner", "succeeded",
                                     model="fixture", provider="fixture")
        v = store.submit_output(
            sop["id"], run["id"],
            "# Rinse cycle SOP v3\n\n4. Rinse each fermenter with 12 L "
            "metered water, not to overflow.\n")
        store.record_check(v["id"], "Ada Northwind", [
            {"criterion": "Step 4 names the litre target", "passed": True,
             "evidence": "12 L stated"},
            {"criterion": "Version number bumped", "passed": True,
             "evidence": "v2 -> v3 in title"}])

        # Done, plus a decided goal.
        meter = store.create_task(
            ops["id"], "Install batch water meter", "Ada Northwind",
            "Fit meter on inlet", ["Meter reads within 2% of bucket test"], 1)
        _assess_all(store, meter["id"])
        store.start_task(meter["id"])
        run = store.record_execution(meter["id"], "fixture-runner",
                                     "succeeded", model="fixture",
                                     provider="fixture")
        v = store.submit_output(meter["id"], run["id"],
                                "Meter installed; bucket test 19.8 L vs "
                                "20.0 L read.\n")
        store.record_check(v["id"], "Bao Tran", [
            {"criterion": "Meter reads within 2% of bucket test",
             "passed": True, "evidence": "1% deviation"}])
        store.accept_output(v["id"], "Ada Northwind")
        store.add_learning(meter["id"],
                           "Calibrate with two bucket tests, not one.")
        store.record_goal_outcome(
            old_goal["id"], False,
            "Q2 metered use down 11%, short of the 20% target",
            "Ada Northwind")

        # Automation: one job the fixture runner executed on a manual occurrence
        # (task lands in Do with an unchecked output), one blocked by its template.
        template = {
            "title": "Daily pilot pH log", "owner": "Bao Tran",
            "next_action": "Read the pH meter at 09:00",
            "criteria": ["pH recorded with time", "Reading within 2.8-3.2 or flagged"],
            "priority": 2,
            "resources": {c: {"description": f"{c} for the daily log", "status": "available"}
                          for c in ("Man", "Method", "Machine", "Material")}
            | {"Money": {"description": "no spend", "status": "not_applicable",
                         "na_reason": "meter already owned"}}}
        daily = store.create_job(
            purpose="Daily pilot pH log", agent_id="fixture-runner",
            project_id=product["id"], task_template=template,
            schedule_kind="cron-lite", schedule_spec={"minute": 0, "hour": 9},
            timezone="Europe/Amsterdam", misfire_policy="skip")
        store.request_run_now(daily["id"], "demo-seed")
        weekly = store.create_job(
            purpose="Weekly supplier price check", agent_id="fixture-runner",
            project_id=product["id"],
            task_template={**template, "title": "Weekly supplier price check",
                           "resources": {k: v for k, v in template["resources"].items()
                                         if k not in ("Money", "Material")}},
            schedule_kind="cron-lite", schedule_spec={"minute": 30, "hour": 8, "dow": [0]},
            timezone="Europe/Amsterdam", misfire_policy="run_latest")
        store.request_run_now(weekly["id"], "demo-seed")
        seed_worker = Worker(store, worker_id="demo-seed", horizon=timedelta(days=7))
        seed_worker.tick()
        seed_worker.stop()

        # Knowledge (all fictional, labelled as demo content).
        starter = store.create_note(
            "note", "Demo: starter culture care",
            "Fictional Northwind note. Feed the SCOBY weekly; keep at 24 °C.",
            actor="Bao Tran")
        store.link_note(starter["id"], "task", brewing["id"], actor="Bao Tran")
        research = store.create_note(
            "research", "Demo: hibiscus supply notes",
            "Fictional research: two dried-hibiscus suppliers, both organic.",
            actor="Cleo Marsh")
        store.link_note(research["id"], "project", product["id"], actor="Cleo Marsh")
        store.create_note(
            "journal", "Demo journal: pilot day", "Fictional entry. Pilot batch "
            "started; pH meter calibrated.", actor="Bao Tran", entry_date="2026-09-05")
        store.create_note(
            "decision", "Demo decision: glass vs PET bottles", "Fictional decision.",
            actor="Ada Northwind",
            decision={"options": ["glass", "PET"], "chosen": "glass",
                      "reasoning": "Shelf-stable carbonation and brand fit",
                      "expected_result": "No off-flavours at week 12",
                      "confidence": 3, "review_date": "2026-09-01"})

        # One 3-step procedure, active, instantiated in the Flavour project.
        sop = store.create_procedure(
            "Demo SOP: pilot brew", "Run one 20 L pilot batch end to end",
            "Ada Northwind",
            [{"title": "Sanitise fermenter", "instruction_md": "Rinse with 12 L metered water.",
              "expected_evidence": "Rinse log line with litres", "role": "human"},
             {"title": "Pitch starter", "instruction_md": "Add 2 L starter at 24 °C.",
              "expected_evidence": "Temperature and volume noted", "role": "human"},
             {"title": "Log day-7 pH", "instruction_md": "Read the pH meter at 09:00.",
              "expected_evidence": "pH recorded with time", "role": "fixture-runner"}],
            inputs=["recipe card"], outputs=["pH log"], changelog="initial version")
        store.activate_procedure(sop["id"], "Ada Northwind")
        store.instantiate_procedure(sop["id"], 1, product["id"], "Bao Tran")

        # Calendar: two events and one recurring block (fictional, Europe/Amsterdam).
        store.create_event("Demo: tasting panel", "event", "2026-09-18T12:00:00Z",
                           end_utc="2026-09-18T13:30:00Z", timezone="Europe/Amsterdam",
                           actor="Ada Northwind", linked_type="project", linked_id=product["id"],
                           notes="Fictional Northwind panel; brings the three pilot flavours.")
        store.create_event("Demo: stability panel ends", "milestone", "2026-12-04T00:00:00Z",
                           all_day=True, timezone="Europe/Amsterdam", actor="Ada Northwind",
                           linked_type="goal", linked_id=goal["id"])
        store.create_event("Demo: weekly brew review", "block", "2026-09-07T07:00:00Z",
                           end_utc="2026-09-07T08:00:00Z", timezone="Europe/Amsterdam",
                           actor="Ada Northwind",
                           rrule={"freq": "weekly", "interval": 1, "byweekday": [0],
                                  "until": "2026-12-31"})

        # Capture Inbox: text, link and a generated PNG; the text one is converted.
        idea = store.create_capture(
            "text", captured_by=DEMO_USER, title="Demo capture: yuzu idea",
            body_text="Fictional idea: try a yuzu-ginger flavour for the winter panel.")
        store.add_capture_draft(idea["id"], "Yuzu-ginger candidate for the winter tasting panel.",
                                created_by=DEMO_USER)
        store.convert_capture(idea["id"], "note", {"kind": "research"}, actor=DEMO_USER)
        store.create_capture("link", captured_by=DEMO_USER, source="hermes",
                             url="https://example.org/demo-hibiscus-supplier",
                             title="Demo capture: supplier page (fictional link)")
        scan = store.create_capture("file", captured_by=DEMO_USER, title="Demo capture: label scan")
        store.attach_original(scan["id"], _demo_png(), "image/png", actor=DEMO_USER,
                              filename="label-scan.png")

        return {"root": str(root), "scope_id": DEMO_SCOPE,
                "workspace_id": store.workspace_id,
                "goals": len(store.list_goals()),
                "tasks": len(store.list_tasks()),
                "notes": len(store.list_notes()),
                "procedures": len(store.list_procedures()),
                "events": len(store.list_events()),
                "captures": len(store.list_captures()),
                "demo_user": DEMO_USER, "demo_password": demo_password}
    finally:
        store.close()


class TickLogger:
    """Loop log filter: a tick that did something prints at once; idle ticks print one
    heartbeat line per ``quiet_seconds`` (and the very first tick), so a service log is
    not one JSON line every 15 seconds forever."""

    COUNTERS = ("planned", "claimed", "succeeded", "blocked", "failed", "lost",
                "revised", "revision_blocked")

    def __init__(self, emit, quiet_seconds: int = 600, clock=None):
        self._emit, self._quiet, self._clock = emit, quiet_seconds, clock or time.monotonic
        self._last = None

    def __call__(self, summary: dict) -> None:
        now = self._clock()
        busy = any(summary.get(k) for k in self.COUNTERS) or summary.get("occurrences")
        if busy or self._last is None or now - self._last >= self._quiet:
            self._emit(json.dumps(summary))
            self._last = now


def run_worker(args) -> int:
    store = Store(args.root, scope_id=args.scope)
    worker = Worker(store, worker_id=args.worker_id,
                    lease_seconds=args.lease_seconds,
                    horizon=timedelta(seconds=args.horizon_seconds),
                    interval_seconds=args.interval_seconds)
    try:
        if args.once:
            summary = worker.tick()
            worker.stop()
            print(json.dumps(summary, indent=2))
            return 0
        stop = threading.Event()
        previous = {sig: signal.signal(sig, lambda *_: stop.set())
                    for sig in (signal.SIGTERM, signal.SIGINT)}
        try:
            worker.run_loop(stop_event=stop,
                            on_tick=TickLogger(lambda line: print(line, flush=True),
                                               quiet_seconds=args.log_every_seconds))
        finally:
            for sig, handler in previous.items():
                signal.signal(sig, handler)
        return 0
    finally:
        store.close()


def _read_password(args, stdin) -> str:
    if args.password_stdin:
        return (stdin or sys.stdin).readline().rstrip("\r\n")
    first = getpass.getpass("Password: ")
    if first != getpass.getpass("Repeat password: "):
        raise ValueError("passwords do not match")
    return first


def run_user(args, stdin=None) -> int:
    store = Store(args.root, scope_id=getattr(args, "scope", None) or "personal")
    try:
        if args.user_command == "create":
            user = store.create_user(args.username, _read_password(args, stdin), actor="cli")
            store.set_membership(user["id"], args.scope, args.role, actor="cli")
            print(json.dumps(store.get_user(user["id"]), indent=2))
        elif args.user_command == "list":
            print(json.dumps(store.list_users(), indent=2))
        else:
            user = store.get_user_by_username(args.username)
            if user is None:
                raise LookupError(f"no user {args.username!r}")
            print(json.dumps(store.disable_user(user["id"], actor="cli"), indent=2))
        return 0
    except (ValueError, ConflictError, InvariantError, LookupError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    finally:
        store.close()


def run_serve(args) -> int:
    loopback = args.host in ("127.0.0.1", "localhost", "::1")
    if not loopback and not args.allow_remote:
        print(f"error: binding {args.host} needs --allow-remote (and an HTTPS reverse proxy;"
              " see docs/INSTALL.md)", file=sys.stderr)
        return 2
    if args.allow_remote:
        store = Store(args.root, scope_id=args.scope)
        try:
            owners = store.count_owners(any_scope=True)
        finally:
            store.close()
        if owners == 0:
            print("error: --allow-remote refused: create an owner user first"
                  " (digitalmaid user create --role owner ...)", file=sys.stderr)
            return 2
    import uvicorn

    from digitalmaid.api import create_app

    app = create_app(args.root, scope_id=args.scope, allow_remote=args.allow_remote)
    uvicorn.run(app, host=args.host, port=args.port, log_level="info",
                proxy_headers=args.allow_remote, forwarded_allow_ips="127.0.0.1")
    return 0


def main(argv=None, stdin=None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "demo":
        summary = seed_demo(args.root)
        password = summary.pop("demo_password")
        print(json.dumps(summary, indent=2))
        print(f"Demo owner login: {summary['demo_user']} / {password}"
              " (shown once; stored only as a salted hash)")
        print(f"Next: digitalmaid serve --root {args.root} --scope {DEMO_SCOPE}")
        return 0
    if args.command == "worker":
        return run_worker(args)
    if args.command == "serve":
        return run_serve(args)
    if args.command == "user":
        return run_user(args, stdin)
    try:
        if args.command == "backup":
            if args.verify:
                print(json.dumps(verify_backup(args.verify), indent=2))
            elif args.root and args.out:
                print(json.dumps(create_backup(args.root, args.out), indent=2))
            else:
                print("error: backup needs --root and --out, or --verify FILE", file=sys.stderr)
                return 2
            return 0
        if args.command == "restore":
            print(json.dumps(restore_backup(args.archive, args.root), indent=2))
            return 0
        if args.command == "migrate":
            pending = pending_migrations(args.root)
            if args.preview:
                print(json.dumps({"root": str(args.root), "pending": pending}, indent=2))
                return 0
            Store(args.root).close()
            print(json.dumps({"root": str(args.root), "applied": pending}, indent=2))
            return 0
    except BackupError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    sys.exit(main())
