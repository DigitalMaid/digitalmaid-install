# Install profiles

**The supported way to install is the one-command installer** (repo `DigitalMaid/digitalmaid-install`):

```
curl -fsSL https://raw.githubusercontent.com/DigitalMaid/digitalmaid-install/main/install.sh | bash
```

Run it as yourself on a laptop (everything under `~/.digitalmaid`, user services) or **as root on a server** — it then creates a `digitalmaid` system user, installs to `/opt/digitalmaid`, registers system services running as that user, and with `--domain your.server.name` installs Caddy for automatic HTTPS and prints the public URL. The app never runs as root. The profiles below are the manual equivalents.

Two supported profiles. Both need only Python 3.12+ and `uv`; there is no Node toolchain and no build step. Linux is the tested platform (see docs/PROGRESS.md for what has actually been verified); macOS/Windows are untested.

`scripts/install.sh` performs every step below idempotently, prints each step with its check, and refuses to run as root unless `--allow-root` is passed. It never opens a network connection and never stores a password.

## Desktop (local)

```bash
git clone <your private remote> DigitalMaid-Agentic-OS && cd DigitalMaid-Agentic-OS
uv venv .venv && uv pip install --python .venv/bin/python -e .
.venv/bin/digitalmaid demo --root ./workspace          # fictional "Northwind Ferments"; prints the demo owner password ONCE
.venv/bin/digitalmaid serve --root ./workspace --scope demo
# open http://127.0.0.1:8765 and sign in as demo / <printed password>
```

Or `scripts/install.sh --profile desktop --root ~/digitalmaid-workspace --demo`.

For a real (empty) workspace, skip `demo` and create your owner user first:

```bash
.venv/bin/digitalmaid user create --root ./workspace --username you --scope personal --role owner   # password prompted
.venv/bin/digitalmaid serve --root ./workspace
```

Loopback (`127.0.0.1`) is the default and the only bind allowed without `--allow-remote`. Authentication is still enforced on loopback — every `/api/*` call needs a session — and is recommended even locally so `accepted_by`/`decided_by` records name a real person.

Start a worker in a second shell so automations actually run: `.venv/bin/digitalmaid worker --loop --root ./workspace`.

## VPS

1. Create a service user and install as that user (`scripts/install.sh --profile vps --root /srv/digitalmaid/workspace`).
2. Create the owner: `digitalmaid user create --root /srv/digitalmaid/workspace --username you --scope personal --role owner`. `serve --allow-remote` refuses to start while no enabled owner exists.
3. Serve on all interfaces **behind an HTTPS reverse proxy**. The app never terminates TLS; with `--allow-remote` the session cookie is `Secure` and would not work over plain HTTP anyway.

```bash
digitalmaid serve --root /srv/digitalmaid/workspace --allow-remote --host 0.0.0.0 --port 8765
```

Bind to `127.0.0.1` instead if the proxy runs on the same host — that is the safer default; `--allow-remote` is then still needed for `Secure` cookies and proxy header trust.

### Caddy (automatic HTTPS)

```
digitalmaid.example.com {
    reverse_proxy 127.0.0.1:8765
    header {
        Strict-Transport-Security "max-age=31536000"
    }
}
```

The app sets `Content-Security-Policy`, `X-Content-Type-Options`, `Referrer-Policy` and `X-Frame-Options` itself. Do not expose port 8765 directly to the internet.

### systemd units

`/etc/systemd/system/digitalmaid.service`:

```ini
[Unit]
Description=DigitalMaid Agentic OS API + UI
After=network.target

[Service]
User=digitalmaid
WorkingDirectory=/srv/digitalmaid/DigitalMaid-Agentic-OS
ExecStart=/srv/digitalmaid/DigitalMaid-Agentic-OS/.venv/bin/digitalmaid serve --root /srv/digitalmaid/workspace --allow-remote --host 127.0.0.1 --port 8765
Restart=on-failure
# The live model credential, if any, is set here or in an EnvironmentFile with mode 0600 — never in the workspace.
# Environment=DIGITALMAID_LLM_API_KEY=...
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/srv/digitalmaid/workspace

[Install]
WantedBy=multi-user.target
```

`/etc/systemd/system/digitalmaid-worker.service` is identical except `Description=DigitalMaid worker` and `ExecStart=... digitalmaid worker --loop --root /srv/digitalmaid/workspace`. Then `systemctl enable --now digitalmaid digitalmaid-worker`.

### s6 / plain nohup alternative (containers without systemd)

s6 run script `/etc/s6/digitalmaid/run`:

```sh
#!/bin/sh
exec s6-setuidgid digitalmaid /srv/digitalmaid/DigitalMaid-Agentic-OS/.venv/bin/digitalmaid serve --root /srv/digitalmaid/workspace --allow-remote --host 127.0.0.1 --port 8765
```

Without a supervisor:

```bash
nohup .venv/bin/digitalmaid serve --root /srv/digitalmaid/workspace --allow-remote --host 127.0.0.1 --port 8765 >> /var/log/digitalmaid/serve.log 2>&1 &
nohup .venv/bin/digitalmaid worker --loop --root /srv/digitalmaid/workspace >> /var/log/digitalmaid/worker.log 2>&1 &
```

Both processes exit cleanly on SIGTERM; the worker marks its heartbeat `stopped`.

### Backups via cron

```
17 3 * * * /srv/digitalmaid/DigitalMaid-Agentic-OS/.venv/bin/digitalmaid backup --root /srv/digitalmaid/workspace --out /srv/digitalmaid/backups/$(date +\%F).tar.gz
```

`backup --verify FILE` re-hashes an archive. The Settings page shows the last backup time and path (recorded in `workspace.json`).

### Health check

`scripts/healthcheck.sh https://digitalmaid.example.com` (or `http://127.0.0.1:8765` on the host) exits 0 when `GET /healthz` returns `{"status":"ok","schema_version":N}`. `/healthz` is the only unauthenticated API route and reveals nothing else.

### Restore drill (do this once after installing)

```bash
digitalmaid backup --root /srv/digitalmaid/workspace --out /tmp/drill.tar.gz
digitalmaid restore --archive /tmp/drill.tar.gz --root /tmp/drill-root     # must be empty
digitalmaid serve --root /tmp/drill-root --port 8799                        # sign in with your normal user
rm -rf /tmp/drill-root /tmp/drill.tar.gz
```

See docs/OPERATIONS.md for upgrades, logs and recovery.
