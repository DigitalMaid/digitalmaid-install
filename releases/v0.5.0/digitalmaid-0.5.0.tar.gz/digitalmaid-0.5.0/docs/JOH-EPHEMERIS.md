# JOH ephemeris file (`digitalmaid/joh/ephemeris.bin`)

Compact planetary ephemeris for the Journey of Humanity engine. Pure-stdlib readable; no Swiss
Ephemeris, no third-party code.

- **Source data**: JPL Horizons API (NASA/JPL, public domain), geocentric *apparent* ecliptic-of-date
  longitudes (`QUANTITIES=31`, `APPARENT=AIRLESS`) sampled 1900-01-01 … 2100-01-01 (JD 2415020.5 …
  2488069.5). `true_node` is the osculating ascending node of the Moon's orbit (Horizons ELEMENTS,
  ecliptic reference plane), sampled daily.
- **Fit**: per body, consecutive segments of `segment_days`; within each segment the longitude is
  unwrapped (no 360° jumps) and offset so the value at the segment start lies in [0, 360), then a
  least-squares Chebyshev polynomial of the stated degree is fitted. Residuals (worst sample) are recorded
  in the header as `fit_residual_deg`.
- **Layout** (little-endian):
  1. magic `DMEPH1` (6 bytes)
  2. `u32` header length `L`
  3. `L` bytes JSON: `{"format":"DMEPH1","jd_start":…,"jd_end":…,"source":…,"bodies":[{"name","segment_days","degree","n_segments","fit_residual_deg"},…]}`
  4. for each body in header order: `n_segments × (degree+1)` `float32` coefficients, segment-major.
- **Evaluate** longitude of body at `jd` (UT):
  `s = floor((jd − jd_start) / segment_days)` (clamp to `n_segments−1` at the exact end), `a = jd_start
  + s·segment_days`, `x = 2·(jd − a)/segment_days − 1`, Clenshaw: `b1=b2=0; for c in reversed(coef[1:]):
  b1, b2 = 2x·b1 − b2 + c, b1; value = x·b1 − b2 + coef[0]`, result `value mod 360`.
- Outside `[jd_start, jd_end]` raise a clear error (the UI says "JOH covers births from 1900 to 2099").
- Regeneration script (not shipped, network): `/opt/data/digitalmaid-preparation/joh/build_ephemeris.py`.
