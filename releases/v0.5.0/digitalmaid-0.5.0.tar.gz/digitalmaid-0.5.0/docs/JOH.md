# JOH — Journey of Humanity (0.5.0) — design and behaviour brief

Owner request (2026-09-15): keep every existing feature, look and interaction of DigitalMaid Agentic OS
unchanged; add one new area, **JOH — Journey of Humanity**, that turns a person's birth data into a
spiritual profile (sidereal astrology, Human Design, Gene Keys) plus an Enneagram type, and then lets the
agent give guidance — on replying to emails and on business decisions — filtered through that profile.

Owner decisions fixed on 2026-09-15:
1. **Everything sidereal (Lahiri ayanamsa)** — the astrology chart *and* the Human Design / Gene Keys
   gate mapping. The owner knows this differs from genekeys.com / official HD charts (which are tropical).
   The UI states this once, plainly, and offers a **tropical toggle** on every chart so a user can compare
   with an official reading. Default = sidereal, stored per profile.
2. **Birthplace → coordinates + timezone via one online OpenStreetMap Nominatim lookup at entry time**,
   result shown for the user to confirm (map-free: display name, lat/lon, detected IANA zone). Manual
   override of lat/lon/zone always available. No other network use in the feature.
3. **Guidance stays inside the app** (Compass panel + a profile block injected into the live agent's
   system prompt for tasks tagged as email/decision). No Hermes/Telegram reach in this version.
4. Built as **three paid Claude Code stages**, Pi verifies each.

## 1. Where it lives

- New rail group **JOURNEY** after KNOWLEDGE, one item **JOH** (`#/joh`, icon `i-joh`: a small
  constellation — three dots joined by two hairlines inside the usual 16-box). Hidden until the section is
  turned on; the switch is in **Settings → "Journey of Humanity"** (owner or member; per *user*, not per
  scope — a profile is personal). Turning it on navigates to `#/joh` and starts onboarding.
- ⌘K gains `Open JOH` and `Ask the Compass` (only when enabled). `g j` chord → JOH.
- Nothing else in the rail, Today, Goals, etc. changes. Existing tests must stay green except where a
  new item is *added* to a list assertion (list those changes).

## 2. Onboarding (first open, or "Edit birth data")

One glass card, serif title *"Where did your journey begin?"*, two-tier form:
- Date of birth (date input), time of birth (`HH:MM`, 24h) + checkbox **"I don't know the time"** →
  noon is used and every chart shows a quiet gold-dot notice *"Time unknown — Moon, houses, and any gate
  near a boundary are approximate."*
- City, Country (two text inputs) → button **Find place** → `POST /api/joh/geocode` → result row:
  display name · lat/lon (4 dp) · timezone (IANA, from the bundled `zone1970.tab` nearest-centroid lookup
  narrowed by country code, with `zoneinfo` for the historical UTC offset at that date/time) · **Use this**
  / **Enter coordinates manually** (lat, lon, timezone select from `zoneinfo.available_timezones()`).
- Save → `PUT /api/joh/profile` computes and stores the profile; navigates to the JOH overview.
- Rate-limit + privacy line under the form: *"Only the city and country you type are sent to
  OpenStreetMap; your date and time never leave this server."*

## 3. The engine (`digitalmaid/joh/`, pure stdlib, offline, deterministic)

### 3.1 Ephemeris
`digitalmaid/joh/ephemeris.bin` (Pi-supplied, ~1.6 MB) — Chebyshev segments fitted to JPL Horizons
geocentric apparent ecliptic-of-date longitudes, 1900–2100, for sun, moon, mercury, venus, mars, jupiter,
saturn, uranus, neptune, pluto, plus `true_node` (osculating lunar ascending node). File format is in
`docs/JOH-EPHEMERIS.md` (magic `DMEPH1`, u32 header length, JSON header with per-body
`segment_days/degree/n_segments`, then float32 coefficient blocks in header order). Evaluation: segment
index `s = floor((jd - jd_start)/segment_days)`, `x = 2*(jd - seg_start)/segment_days - 1`, Clenshaw sum,
result mod 360. Mean node = `125.0445479 - 1934.1362891*T + 0.0020754*T² + T³/467441 - T⁴/60616000` (T in
Julian centuries from J2000). Earth = Sun + 180°.
Accuracy target (tested against `tests/joh/fixtures.json`, 12 birth cases produced by an independent
oracle): Sun ±0.002°, Moon ±0.01°, planets ±0.01°, true node ±0.1° (the two oracles define the
osculating node slightly differently; a gate is 5.625° and a line 0.9375°, so this cannot move a line).

### 3.2 Time
UTC from local date/time + IANA zone via `zoneinfo` (historical offsets handled by tzdata; **tests must
cover a DST case** — London 1961-08-04 19:24 BST = 18:24 UT — and a half-hour zone, Asia/Kolkata).
`jd_ut = 367*Y - floor(7*(Y + floor((M+9)/12))/4) + floor(275*M/9) + D + 1721013.5 + hour/24` (valid
1900–2100). ΔT is ignored (< 0.002° on the Sun; note it in the docs).

### 3.3 Sidereal
Lahiri ayanamsa `A(T) = 23.85709235 + 1.39688796·T + 0.00030709·T²` (T Julian centuries from J2000 UT;
matches the reference implementation to < 1e-8° across 1900–2100). Sidereal longitude = tropical − A.
Every position is stored **both ways**; `zodiac: "sidereal" | "tropical"` selects the view.

### 3.4 Astrology chart (`astro.py`)
Positions for the 10 bodies + true node + south node (node + 180) + Earth: sign (12 × 30°), degree in
sign, minutes; retrograde flag (longitude decreasing over ±1 h). Houses: **whole-sign** from the
Ascendant (no Placidus). Ascendant/MC from the standard formulas (obliquity of date
`23.4392911 − 0.0130042·T`, local sidereal time from GMST `280.46061837 + 360.98564736629·(jd−2451545) +
0.000387933·T²` + longitude). Aspects: conjunction 0 (orb 8), sextile 60 (4), square 90 (6), trine 120
(6), opposition 180 (8); Sun/Moon get +2. Fixture tolerance for the Ascendant: ±0.3°.

### 3.5 Human Design (`humandesign.py`)
- **Design instant**: the moment the Sun's longitude was exactly 88.0° less than at birth (bisection
  between 82 and 95 days before; ±1e-6°; tested against fixture `design_jd_ut`, ±20 s).
- **Gate wheel**: 64 gates × 5.625°, 6 lines × 0.9375° each, colour 6 × 0.15625°, tone 6, base 5. The
  wheel starts with **Gate 41 at 302.0° (2° Aquarius 00')** and proceeds in this order (each 5.625°):
  41 19 13 49 30 55 37 63 22 36 25 17 21 51 42 3 27 24 2 23 8 20 16 35 45 12 15 52 39 53 62 56 31
  33 7 4 29 59 40 64 47 6 46 18 48 57 32 50 28 44 1 43 14 34 9 5 26 11 10 58 38 54 61 60.
  (Check: Gate 25 then spans 28°15′ Pisces → 3°52′30″ Aries and Gate 17 starts at 3°52′30″ Aries.)
  In **sidereal mode the same wheel is applied to sidereal longitudes** (owner decision) — the code path
  is one function `gate_line(longitude)`; the caller passes either longitude set.
- 13 activations per side (Sun, Earth, North Node, South Node, Moon, Mercury, Venus, Mars, Jupiter,
  Saturn, Uranus, Neptune, Pluto) → Personality (black, birth) and Design (red, 88° prior).
- 36 channels (gate pairs): 1-8 2-14 3-60 4-63 5-15 6-59 7-31 9-52 10-20 10-34 10-57 11-56 12-22 13-33
  16-48 17-62 18-58 19-49 20-34 20-57 21-45 23-43 24-61 25-51 26-44 27-50 28-38 29-46 30-41 32-54 34-57
  35-36 37-40 39-55 42-53 47-64. 9 centres with their gates:
  Head 64 61 63 · Ajna 47 24 4 17 43 11 · Throat 62 23 56 35 12 45 33 8 31 20 16 · G 1 13 25 46 2 15 10 7 ·
  Heart/Ego 21 40 26 51 · Sacral 5 14 29 59 9 3 42 27 34 · Spleen 48 57 44 50 32 28 18 · Solar Plexus 6 37 22
  36 30 55 49 · Root 53 60 52 19 39 41 58 38 54. A test asserts every channel joins two different centres and
  every gate appears in exactly one centre.
- Defined centre = at least one full channel (both gates activated, either colour). Type: Reflector (no
  defined centres) · Manifestor (a motor — Heart/Sacral/Solar Plexus/Root — connected to the Throat through
  any chain of defined channels, Sacral undefined) · Generator / Manifesting Generator (Sacral defined; MG
  if a motor reaches the Throat through a chain) · Projector (otherwise). Authority in order: Solar Plexus → Sacral → Spleen → Heart (Ego) → G (Self-
  projected, if G–Throat) → Mental/Environmental (Projector with none) → Lunar (Reflector). Strategy per
  type. Profile = Personality Sun line / Design Sun line. Definition: single/split/triple/quadruple by
  connected-component count over defined centres. Incarnation cross: gates of P-Sun/P-Earth | D-Sun/
  D-Earth with the Right/Left/Juxtaposition angle from the profile (1/3 1/4 2/4 2/5 3/5 4/6 right; 5/1 6/2
  6/3 left; 4/1 juxtaposition).
- Tests: the 12 fixture cases carry the expected tropical gate.line for every activation (Pi generated
  them from the wheel above — assert all); type/authority/profile for at least 4 cases spelled out.

### 3.6 Gene Keys (`genekeys.py`)
Hologenetic Profile spheres → activation (planet, side):
Life's Work = P-Sun · Evolution = P-Earth · Radiance = D-Sun · Purpose = D-Earth (Activation Sequence,
"the four Prime Gifts") · Attraction = D-Moon · IQ = P-Venus · EQ = P-Mars · SQ = D-Venus · Core Wound
(a.k.a. Core / Vocation) = D-Mars (Venus Sequence) · Vocation = D-Mars · Culture = D-Jupiter · Pearl =
P-Jupiter · Brand = P-Sun (Pearl Sequence) · plus Creativity = D-Uranus, Relating = P-Mercury, Stability =
D-Saturn as "further spheres". Each sphere = Gene Key number (= gate) + line (1–6) + the key's
**Shadow / Gift / Siddhi** keywords (table of 64 in `genekeys_data.py`, keywords only — these are single
words in public use; **no book text**). Line themes for the Activation Sequence (1 Creative/Self, 2
Dance/Relationship, 3 Energy/Experience, 4 Breath/Community, 5 Voice/Power, 6 Being/Wisdom) and short
original one-sentence prompts per frequency written by the worker in DigitalMaid's own plain voice.
Programming partner = gate + 32 in wheel order (opposite point) — show it.

### 3.7 Enneagram (`enneagram.py`)
- Direct entry: type 1–9, optional wing (adjacent only, validated), optional instinct (sp/so/sx).
- Test: **45 original statements** (5 per type, written by the worker — not copied from RHETI or any
  published instrument), 5-point agreement scale, randomised order with a fixed seed stored on the
  attempt so a reload keeps the order. Score = sum per type; result = top type, wing = higher-scoring
  adjacent type, and the full 9-bar score profile shown ("if this doesn't ring true, choose your type
  directly"). Stored with the answers so it can be retaken. Type data: name, core fear, core desire,
  basic proposition, growth/stress arrows, keywords (all short original phrasing).

### 3.8 Profile record
Table `joh_profiles` (migration 13): id, scope_id, user_id (unique per scope+user), birth_date,
birth_time (nullable), time_known, place_display, country_code, lat, lon, timezone, zodiac
('sidereal'|'tropical'), enneagram_type, enneagram_wing, enneagram_instinct, enneagram_source
('entered'|'test'), computed (JSON: the full engine output, both zodiacs), engine_version, created_at,
updated_at. Table `joh_enneagram_attempts` (id, profile_id, seed, answers JSON, scores JSON,
created_at). Table `joh_guidance` (id, profile_id, kind 'email'|'decision'|'question', input_text,
output_text, model, provider, cost_minor, currency, created_at) — every Compass answer is kept.
`computed` is recomputed whenever birth data changes or `engine_version` is older (on read).
Backup includes the tables automatically (same DB); `docs/OPERATIONS.md` gets one line.

## 4. Pages (all inside `#/joh`, tabs like Knowledge: **Overview · Astro · Bodygraph · Gene Keys ·
Enneagram · Compass**; `#/joh/<tab>`)

Design rules: everything from DESIGN.md F1–F10 stands (glass cards, Cormorant titles, gold accent,
labels with the tri-dot ornament, ghost pill buttons, 9 % hairlines). New drawings are SVG built in JS
(no canvas, no libraries), stroke-only, gold + ink + phase hues, dark background transparent so the sky
shows through. Every page has a D1 plain lead + `details.how`, and a footer line naming the zodiac in
force with the toggle (`Sidereal (Lahiri) · switch to tropical`).

- **Overview**: greeting-style serif line *"{Name}, born {date} at {time} in {place}"*; three summary
  cards — *Sun · Moon · Rising* (sidereal signs, degrees), *Human Design* (Type · Strategy · Authority ·
  Profile), *Enneagram* (type name + wing or "Find your type"); below, the four Prime Gifts as a
  horizontal constellation (four gold nodes on a hairline arc, each with key.line and the Gift word);
  "Edit birth data" ghost pill.
- **Astro**: SVG wheel 560px max — outer sign ring (12 sectors, sidereal glyph letters, thin), house
  ring (whole sign, numerals in Doto), planet glyphs as small serif letters on radii with degree ticks,
  aspect lines inside (gold conj/trine/sextile at .6, rose square/opposition at .5). Right/below: a
  positions table (Body · Sign · Degree · House · R). Toggle sidereal/tropical re-renders both.
- **Bodygraph**: SVG of the 9 centres in the standard layout (Head triangle top, Ajna, Throat square, G
  diamond, Heart small triangle right, Sacral square, Spleen triangle left, Solar Plexus triangle right,
  Root square bottom) with the 36 channels as hairlines; defined centres filled with a 14 % gold wash and
  a gold stroke, channels active in gold (personality) / rose (design) / both = gold with a rose inner
  line; gate numbers in Doto at each gate end. Legend and the "Foundation" facts card: Type, Strategy,
  Authority, Profile, Definition, Incarnation Cross, Not-self theme, Signature. Two columns of
  activations (Design red-rose left, Personality gold right) listing planet → gate.line.
- **Gene Keys**: the Hologenetic Profile as three sequences, each a card: *Activation* (Life's Work,
  Evolution, Radiance, Purpose), *Venus* (Attraction, IQ, EQ, SQ, Core Wound), *Pearl* (Vocation,
  Culture, Pearl, Brand). Each sphere is a row: sphere name (label), **key.line** in Doto gold, then a
  three-step spectrum `Shadow → Gift → Siddhi` (muted → ink → gold), and one original contemplation
  sentence. A small SVG "hologenetic" diagram at the top: the 11 spheres as nodes in the familiar
  triangle-over-diamond arrangement joined by hairlines, key numbers inside. Link out: "Contemplate this
  key at genekeys.com" (plain `<a target=_blank rel=noopener>`, no embedding).
- **Enneagram**: state machine — not set → two pills *"I know my type"* (inline select 1–9 + wing) /
  *"Take the test (about 8 minutes)"*; test → one statement per screen with the 5-dot scale, progress
  dots at the top (45), back/next, autosave to `localStorage` per attempt seed; result → the 9-bar score
  profile (thin gold bars, Doto numbers), the chosen type card (name, fear, desire, arrows), *"This is
  right"* / *"Choose differently"*. Set → the type card + "Retake".
- **Compass** (guidance): serif lead *"Ask with your whole chart in the room."* Three tabs of input —
  **Reply to an email** (textarea: paste the email; optional textarea: what you want to say / constraints),
  **Make a decision** (textarea: the decision, options, stakes; select: horizon — this week / this
  quarter / this year / life), **Ask anything**. Submit → `POST /api/joh/guidance` → answer rendered as
  Markdown-lite (the same renderer the outputs pages use) inside a card headed by a **"Chart in the
  room"** strip: the 4–6 profile facts the answer leans on (e.g. *Life's Work 25.3 Acceptance · Projector,
  Emotional authority · Type 9w1*). Below: history list of past answers (kind, first line, when). Money:
  every call goes through the existing `OpenAICompatibleTransport` using the **pi-chief-of-staff** agent's
  `model_policy`; the panel shows the cap and the last cost; when the credential is not configured the
  page explains that plainly (existing runner_status wording) instead of a dead button.

## 5. Guidance behaviour (`digitalmaid/joh/compass.py`)

`profile_brief(profile) -> str` — ≤ 60 lines, deterministic, plain text, the *whole* profile in the
zodiac the user chose: birth facts (no exact minutes — day and place only), Sun/Moon/Rising, HD type,
strategy, authority, profile, definition, cross, the 11 spheres with key.line and the three words each,
enneagram type/wing/instinct with fear/desire/arrows, and the ephemeris disclaimer when time is unknown.

`build_compass_messages(profile, kind, input_text, extra) -> list[dict]` — system prompt:
*You are the Compass inside DigitalMaid Agentic OS. You advise one person whose profile follows. Ground
every suggestion in that profile and say which part you are leaning on (name the sphere, the authority,
the enneagram pattern). Prefer the Gift frequency over the Shadow; name the Shadow only to help them
notice it. Give practical wording or steps, not horoscopes. Never predict events, health, or money
outcomes; never claim certainty; the person decides. Reply in Markdown with these sections:* — for
email: **Read** (what the email is really asking, seen through the profile) · **Reply** (a complete
draft in the person's voice, respecting their HD strategy/authority: e.g. a Projector is told to wait to
be invited before pushing, an emotional authority is told to sleep on heat) · **Watch for** (the Shadow
pattern most likely to hijack this) · **Chart in the room** (bullet list, exactly the facts used). For
decision: **Frame** · **Through your chart** (one paragraph per relevant sphere/authority/type) ·
**A way to decide** (a concrete step matching the authority: e.g. sacral yes/no questions, a 24-hour
emotional wave, a lunar cycle for reflectors) · **If you go ahead** · **If you don't** · **Chart in the
room**. For question: **Answer** · **Chart in the room**. The last section is parsed (bullets) to fill
the UI strip; if missing, the strip shows the four Prime Gifts.

**Live-agent injection**: `runners.build_messages` gains an optional `journey_brief: str | None`; when a
task's `inputs` contains `joh: "true"` (the create-task form gets a *"Consult my Journey profile"*
checkbox, shown only when the section is enabled) the owner-of-record's brief is appended to the system
prompt under *"The person you are working for — their Journey of Humanity profile:"*. Tests: brief present
⇒ in system message; absent ⇒ prompt byte-identical to today's.

## 6. API (all session-auth, CSRF as everywhere; API tokens stay 403 here)

- `GET /api/joh` → `{enabled, has_profile, zodiac, enneagram_set}` (per current user).
- `PUT /api/joh/enabled` `{enabled: bool}`.
- `POST /api/joh/geocode` `{city, country}` → `{display_name, lat, lon, country_code, timezone}` or 404
  `{"reasons": ["No place found for …"]}`; 502 when OSM is unreachable; **10/min per user** rate limit;
  User-Agent `DigitalMaid-Agentic-OS/<version> (joh)`; 8 s timeout; transport injectable for tests (no
  network in tests).
- `GET /api/joh/profile` → full profile (computed for the selected zodiac + `alternate_zodiac` summary)
  · `PUT /api/joh/profile` (birth data, coordinates, timezone, zodiac) → recompute
  · `PATCH /api/joh/profile` `{zodiac}` · `DELETE /api/joh/profile` (owner's own; confirm dialog).
- `GET /api/joh/enneagram/test` → the 45 statements in the attempt order (creates the attempt seed)
  · `POST /api/joh/enneagram/test` `{seed, answers: [45 ints 1..5]}` → scores + suggested type/wing
  · `PUT /api/joh/enneagram` `{type, wing?, instinct?, source}`.
- `POST /api/joh/guidance` `{kind, input_text, extra?}` → `{output_text, chart_in_the_room: [...],
  model, provider, cost_minor, currency}`; 409 with the runner's problems list when the credential is not
  configured; 422 for empty input or > 12,000 chars. `GET /api/joh/guidance?limit=20`.
- Errors follow the existing `{"detail": ..., "reasons": [...]}` shape.

## 7. Tests (target ≈ +120)

`tests/joh/test_ephemeris.py` (fixture accuracy, segment boundaries, out-of-range → clear error),
`test_time.py` (DST, half-hour zones, unknown time = noon), `test_astro.py` (signs, houses, ascendant
fixture, aspects), `test_humandesign.py` (wheel start, gate/line/colour boundaries, design instant, all
fixture activations, channels/centres integrity, type/authority/profile/cross on named cases, sidereal
vs tropical differ by the expected number of gates), `test_genekeys.py` (sphere mapping, 64-table
complete and unique words, programming partner), `test_enneagram.py` (45 statements, 5 per type,
scoring, wing rule, validation), `test_compass.py` (brief content, message shape, section parsing,
byte-identical prompt when absent), `tests/test_api_joh.py` (every route incl. auth/CSRF/token 403,
geocode via fake transport, rate limit, recompute on zodiac change, guidance 409 without credential and
200 with a fake transport, history), `tests/test_ui_browser.py` additions (enable in Settings → rail
item appears → onboarding → fake geocode → charts render with no console errors, SVGs present, toggle
changes the Sun sign, enneagram test end-to-end with 45 clicks, compass with fake transport shows the
strip; 360 px width: no horizontal overflow on any JOH tab), `test_ui.py` (new files allow-listed,
relative paths), `test_design_tokens.py` unchanged.

## 8. Must not change
Everything outside `digitalmaid/joh/`, the new UI file `joh.js`, the additive edits to `index.html`
(rail item + icon), `app.js` (route + nav visibility), `commands.js` (two entries), `pages.js`
(Settings panel), `api.js` (client calls), `app.css` (additive `.joh-*` rules only), `api.py` (routes
mounted from `digitalmaid/joh/api.py`), `db.py` (migration 13), `runners.py` (optional brief), and the
create-task form checkbox. No new Python dependencies. No third-party JS. No text copied from the Gene
Keys books, Human Design manuals or any enneagram test.
