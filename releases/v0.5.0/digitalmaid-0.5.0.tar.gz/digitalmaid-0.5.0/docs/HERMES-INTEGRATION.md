# Hermes → DigitalMaid: posting into the Capture Inbox

Hermes Agent can drop a voice-note transcript, a link or a file into the Capture
Inbox without a browser session. Nothing here is executed by DigitalMaid on
Hermes's behalf: a capture is raw material that a human drafts and converts.

## 1. Mint an API token (owner, once)

Settings and Connections → **API tokens** → *Create a token*. The value
(`dmt_<id>_<secret>`) is shown **once**; only a scrypt hash is stored. Keep it in
Hermes's own secret store, never in this repository or in `workspace.json`.

Tokens are scoped: they may call `POST/GET /api/captures*` and `GET /api/healthz`
only. Any other route answers `403 {"detail": "token scope: …"}`. Revoking a
token (Settings) or disabling its user stops it immediately. The token acts as
the user who minted it (`captured_by` = that username), with that user's role in
the served scope; viewers cannot post.

## 2. Post a transcript (text)

```bash
DM_URL="https://digitalmaid.example.internal"      # or http://127.0.0.1:8765 on the same host
DM_TOKEN="dmt_REPLACE_WITH_THE_TOKEN_SHOWN_ONCE"     # placeholder, not a real token

curl -sS -X POST "$DM_URL/api/captures" \
  -H "Authorization: Bearer $DM_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"kind": "transcript", "source": "hermes",
       "title": "Voice note 2026-09-06 09:12",
       "body_text": "Order more lime before the Friday tasting panel."}'
```

Response `201` with the capture record (`status: "inbox"`). No `X-Requested-With`
header is needed for bearer requests (that CSRF marker guards cookie sessions).

## 3. Post a link

```bash
curl -sS -X POST "$DM_URL/api/captures" \
  -H "Authorization: Bearer $DM_TOKEN" -H "Content-Type: application/json" \
  -d '{"kind": "link", "source": "hermes", "url": "https://example.org/article"}'
```

Only absolute `http://`/`https://` URLs are accepted.

## 4. Post the audio original (optional)

```bash
curl -sS -X POST "$DM_URL/api/captures/upload" \
  -H "Authorization: Bearer $DM_TOKEN" \
  -F "file=@voice-note.ogg;type=audio/ogg" \
  -F "title=Voice note 2026-09-06 09:12" \
  -F "body_text=Order more lime before the Friday tasting panel." \
  -F "source=hermes"
```

Allowed types: `text/plain, text/markdown, application/pdf, image/png, image/jpeg,
audio/ogg, audio/mpeg, application/json`; default cap 25 MB
(`capture_max_bytes` in `workspace.json`). Audio uploads become `transcript`
captures. **DigitalMaid never transcribes**: `body_text` is whatever Hermes (or a
human, later, as a draft) supplies — Settings shows `transcription: external`.
The original is stored once under `captures/<scope>/<id>/original.<ext>` (extension
from the allow-list, never from the file name) and is immutable.

## 5. Check health

`GET $DM_URL/api/healthz` → `{"status":"ok","schema_version":N}` (no token needed).

## What Hermes must not do

Do not store the DigitalMaid password, do not use the token for anything beyond
captures (it will be refused), do not attempt to convert captures — conversion
is a human step in the Capture Inbox that goes through the same PDCC gates as
everything else.

## 6. Inside Hermes: DigitalMaid as a dashboard tab (0.3.0)

The repository ships a Hermes dashboard plugin at `hermes-plugin/digitalmaid/`
(`plugin.yaml`, `__init__.py` with a no-op `register`, `dashboard/manifest.json`,
`dashboard/plugin_api.py`, `dashboard/dist/index.js`; see `hermes-plugin/README.md`).
Installed into `$HERMES_HOME/plugins/digitalmaid` and listed under `plugins.enabled`
in Hermes's `config.yaml`, it adds a **DigitalMaid** tab (icon *Sparkles*, after
*Skills*) whose content is the DigitalMaid web app in an iframe, proxied through
the authenticated Hermes dashboard at `/api/plugins/digitalmaid/ui/`.

### One-paste install

```bash
curl -fsSL https://raw.githubusercontent.com/DigitalMaid/digitalmaid-install/main/install.sh | bash -s -- --hermes
```

`sudo bash -s -- --hermes` on a server where DigitalMaid runs as a system service;
`--hermes-home DIR` when Hermes's home is not `~/.hermes` of the invoking user. The
installer: generates the shared secret into `PREFIX/hermes-secret` (0600), writes
`PREFIX/hermes.env` (`DIGITALMAID_TRUSTED_PROXY_SECRET=…`, 0600, read by both
`digitalmaid.service` variants through `EnvironmentFile=-`; secrets never sit in a
unit file), copies the plugin to `$HERMES_HOME/plugins/digitalmaid` with its own copy
of the secret (`secret`, 0600, owned by the Hermes home's owner) and a
`dashboard/config.json` (`upstream`, `secret_file`), appends `digitalmaid` to
`plugins.enabled` in `$HERMES_HOME/config.yaml` as a text edit (comments and other
keys survive; backup `config.yaml.before-digitalmaid`; idempotent on re-run), and
prints *restart the Hermes dashboard to see the DigitalMaid tab*. It never restarts
Hermes. Settings → **Hermes integration** shows the same command (owners only).

### Prefix-relocatable UI

The shell uses relative URLs (`href="app.css"`, `src="app.js"`, `url("fonts/…")`) and
`api.js` derives its API base from `document.baseURI`
(`BASE = new URL(".", document.baseURI).pathname` → `${BASE}/api/…`), so the same
files work at `/` and at `/api/plugins/digitalmaid/ui/`. Hash routes are unaffected.
The proxy redirects `/ui` → `/ui/` (307) because relative URLs resolve against the
document's directory.

### Trusted sign-in (owner decision: single login)

- Server: when `DIGITALMAID_TRUSTED_PROXY_SECRET` (≥ 32 chars) is set, a request from
  `127.0.0.1`/`::1` carrying `X-DigitalMaid-Proxy-Auth: <secret>` (constant-time
  compare) is *trusted*. `POST /api/auth/trusted` (CSRF header still required, no body)
  exists only for trusted requests — everyone else gets **404**. It signs in the
  scope's oldest enabled owner (`Store.first_enabled_owner`, deterministic), creates
  an ordinary session flagged `trusted` (migration 12: `sessions.trusted`), sets
  `dm_session`, returns `{username, trusted: true, role, scope_id}` and records the
  audit event `auth:trusted_login` on the workspace. `GET /api/auth/me` and
  `GET /api/settings` (`hermes: {trusted_proxy, session_trusted}`, `install_mode`)
  report it. No owner in the scope → 409.
- Headers: trusted requests get `Content-Security-Policy: … frame-ancestors 'self' …`
  and no `X-Frame-Options`; all other requests keep `frame-ancestors 'none'` /
  `X-Frame-Options: DENY`. When the variable is unset nothing changes at all.
- Proxy (`plugin_api.py`): strips hop headers and any client-supplied
  `X-DigitalMaid-Proxy-Auth`, forwards **only** the `dm_session` cookie (never
  Hermes's cookies), checks `Origin` against its own `Host` and then rewrites it to
  the upstream origin, adds its own auth header, rewrites `Set-Cookie … Path=/` to
  `Path=/api/plugins/digitalmaid/` so the DigitalMaid session never travels to the
  rest of Hermes, inserts `<meta name="dm-trusted" content="1">` after `<head>`
  when it has a secret, and answers with `frame-ancestors 'self'`. `GET /health` →
  upstream `/api/healthz` plus `trusted_proxy: bool`; upstream down → 502 JSON.
- UI (`app.js`): when the meta tag is present the app calls `POST /api/auth/trusted`
  once per page load before showing its login form; a refusal falls back to the
  normal form. Sign-out is honoured (no re-login until reload). Settings → *Your
  account* reads "Signed in via Hermes (trusted proxy) — all actions are recorded as
  `<owner>`" for such sessions.

**Trade-off, stated in the UI:** one login (Hermes's) instead of two, at the cost of a
weaker per-user audit — everyone who can open the Hermes dashboard acts as that one
owner inside the tab. Keep individual DigitalMaid accounts (leave the secret unset)
when several people share the dashboard and must be told apart.

### Tests

`tests/test_api_trusted.py` (server side), `tests/test_hermes_plugin.py` (the shipped
`plugin_api.py` mounted on a bare FastAPI app, pointed at a real `create_app` over an
in-process ASGI transport), `tests/test_hermes_plugin_browser.py` (headless Chromium
through two uvicorn servers — proxy and app — proving assets, trusted sign-in, Today
and Settings under the prefix, and the password fallback), and the F10 panel tests in
`tests/test_ui_browser.py`.
