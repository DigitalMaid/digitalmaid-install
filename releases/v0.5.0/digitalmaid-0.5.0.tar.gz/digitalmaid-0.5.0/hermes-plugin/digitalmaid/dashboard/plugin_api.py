"""DigitalMaid Agentic OS — Hermes dashboard plugin backend.

Mounted by the Hermes dashboard at /api/plugins/digitalmaid/ (behind Hermes's own login).
It reverse-proxies the DigitalMaid web app that runs on this host so the app appears as a
tab inside Hermes without opening its port to anyone else.

  GET  /api/plugins/digitalmaid/health          -> upstream /api/healthz (+ whether the
                                                   trusted-proxy secret is available here)
  GET  /api/plugins/digitalmaid/ui              -> 307 to /ui/
  ANY  /api/plugins/digitalmaid/ui/{path}       -> upstream /{path}

Trust (owner decision, single login): every proxied request carries
``X-DigitalMaid-Proxy-Auth: <secret>``; the browser can never supply that header itself
(it is stripped). DigitalMaid, seeing the secret from loopback, lets ``POST /api/auth/trusted``
sign the Hermes user in as the scope's owner. The HTML gets ``<meta name="dm-trusted">`` so the
app knows to try that before showing its login form.

Configuration, read at request time (no restart needed):
  dashboard/config.json   {"upstream": "http://127.0.0.1:8765", "secret_file": "/path"}
                          (written by the installer's --hermes step)
  DIGITALMAID_UPSTREAM            overrides the upstream base URL
  DIGITALMAID_PROXY_SECRET_FILE   overrides the secret file path
Defaults: upstream http://127.0.0.1:8765; secret from /opt/digitalmaid/hermes-secret, else
~/.digitalmaid/hermes-secret. The secret file should be mode 0600, owned by the Hermes user.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

import httpx
from fastapi import APIRouter, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse

router = APIRouter()

PLUGIN_NAME = "digitalmaid"
PREFIX = f"/api/plugins/{PLUGIN_NAME}"
UI_PREFIX = f"{PREFIX}/ui"
CONFIG_FILE = Path(__file__).resolve().parent / "config.json"
DEFAULT_UPSTREAM = "http://127.0.0.1:8765"
DEFAULT_SECRET_FILES = (Path("/opt/digitalmaid/hermes-secret"),
                        Path.home() / ".digitalmaid" / "hermes-secret")
PROXY_AUTH_HEADER = "X-DigitalMaid-Proxy-Auth"
SESSION_COOKIE = "dm_session"
TRUSTED_META = '<meta name="dm-trusted" content="1">'
# Tests inject an httpx transport (ASGI) here; None means real sockets to ``upstream()``.
TRANSPORT: Optional[httpx.AsyncBaseTransport] = None

_HOP = {"connection", "keep-alive", "transfer-encoding", "content-length", "content-encoding",
        "host", "upgrade", "proxy-authenticate", "proxy-authorization", "te", "trailers"}
_HEAD_RE = re.compile(r"<head(\s[^>]*)?>", re.IGNORECASE)


def _config() -> dict:
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def upstream() -> str:
    value = os.environ.get("DIGITALMAID_UPSTREAM") or _config().get("upstream") or DEFAULT_UPSTREAM
    return str(value).rstrip("/")


def secret_file() -> Path:
    value = os.environ.get("DIGITALMAID_PROXY_SECRET_FILE") or _config().get("secret_file")
    if value:
        return Path(str(value)).expanduser()
    for candidate in DEFAULT_SECRET_FILES:
        if candidate.is_file():
            return candidate
    return DEFAULT_SECRET_FILES[0]


def proxy_secret() -> Optional[str]:
    """The shared secret, or None when the file is missing/unreadable (then the tab still
    works, but the user sees DigitalMaid's own login form)."""
    try:
        value = secret_file().read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return value or None


def _client() -> httpx.AsyncClient:
    kwargs = {"timeout": httpx.Timeout(70.0), "follow_redirects": False}
    if TRANSPORT is not None:
        kwargs["transport"] = TRANSPORT
    return httpx.AsyncClient(**kwargs)


def _rewrite_html(body: bytes, trusted: bool) -> bytes:
    """The app's assets are relative, so under the prefix nothing needs rewriting except the
    marker that tells it a trusted sign-in is available."""
    if not trusted:
        return body
    text = body.decode("utf-8", "replace")
    match = _HEAD_RE.search(text)
    if match:
        text = text[:match.end()] + TRUSTED_META + text[match.end():]
    return text.encode("utf-8")


def _rewrite_set_cookie(value: str) -> str:
    """The upstream scopes its session cookie to Path=/; inside Hermes it must stay under the
    plugin prefix so it never travels with requests to the rest of the dashboard."""
    parts = [p.strip() for p in value.split(";")]
    out = []
    replaced = False
    for part in parts:
        if part.lower().startswith("path="):
            out.append(f"Path={PREFIX}/")
            replaced = True
        else:
            out.append(part)
    if not replaced:
        out.append(f"Path={PREFIX}/")
    return "; ".join(out)


def _forward_headers(request: Request, secret: Optional[str]) -> tuple[dict, Optional[Response]]:
    headers = {}
    for key, value in request.headers.items():
        lower = key.lower()
        if lower in _HOP or lower in ("cookie", "origin", PROXY_AUTH_HEADER.lower()):
            continue
        headers[key] = value
    # Only DigitalMaid's own cookie goes upstream; Hermes's cookies stay with Hermes.
    dm_cookie = request.cookies.get(SESSION_COOKIE)
    if dm_cookie is not None:
        headers["Cookie"] = f"{SESSION_COOKIE}={dm_cookie}"
    # The upstream compares Origin with its Host. We are the origin the browser sees, so we
    # do that check here and then present an Origin the upstream recognises.
    origin = request.headers.get("origin")
    if origin is not None:
        incoming_host = request.headers.get("host", "").lower()
        if origin == "null" or urlsplit(origin).netloc.lower() != incoming_host:
            return headers, JSONResponse({"detail": "Origin does not match Host"}, status_code=403)
        headers["Origin"] = upstream()
    if secret is not None:
        headers[PROXY_AUTH_HEADER] = secret
    return headers, None


async def _proxy(request: Request, path: str) -> Response:
    secret = proxy_secret()
    headers, refused = _forward_headers(request, secret)
    if refused is not None:
        return refused
    url = upstream() + "/" + path.lstrip("/")
    if request.url.query:
        url += "?" + request.url.query
    body = await request.body()
    try:
        async with _client() as client:
            r = await client.request(request.method, url, headers=headers, content=body)
    except httpx.HTTPError as exc:
        return JSONResponse({"error": f"DigitalMaid unreachable at {upstream()}: {exc}"},
                            status_code=502)
    ctype = r.headers.get("content-type", "")
    content = r.content
    if "text/html" in ctype:
        content = _rewrite_html(content, trusted=secret is not None)
    response = Response(content=content, status_code=r.status_code, media_type=ctype or None)
    for key, value in r.headers.multi_items():
        lower = key.lower()
        if lower in _HOP or lower in ("content-type", "set-cookie", "content-security-policy",
                                      "x-frame-options"):
            continue
        response.headers.append(key, value)
    for cookie in r.headers.get_list("set-cookie"):
        response.headers.append("set-cookie", _rewrite_set_cookie(cookie))
    # Framed by the Hermes dashboard (same origin) and by nothing else.
    response.headers["Content-Security-Policy"] = "frame-ancestors 'self'"
    return response


@router.get("/health")
async def health():
    try:
        async with _client() as client:
            r = await client.get(upstream() + "/api/healthz", timeout=5.0)
            return {"ok": r.status_code == 200, "upstream": upstream(), "server": r.json(),
                    "trusted_proxy": proxy_secret() is not None}
    except Exception as exc:  # noqa: BLE001 — surfaced to the status bar, never raised
        return {"ok": False, "upstream": upstream(), "error": str(exc),
                "trusted_proxy": proxy_secret() is not None}


@router.get("/ui", include_in_schema=False)
async def ui_root_redirect():
    # The SPA's relative asset URLs resolve against the directory of the document, so the
    # shell must live at exactly ".../ui/".
    return RedirectResponse(url=f"{UI_PREFIX}/", status_code=307)


@router.api_route("/ui/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS",
                                              "HEAD"])
async def ui_any(request: Request, path: str):
    return await _proxy(request, path)
