"""digitalmaid plugin: no agent tools or hooks. The dashboard/ folder provides the tab + proxy."""


def register(ctx) -> None:  # noqa: D401 — Hermes plugin entry point; nothing to register
    return None
