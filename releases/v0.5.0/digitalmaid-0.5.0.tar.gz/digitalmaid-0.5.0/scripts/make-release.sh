#!/usr/bin/env bash
# Build a release tarball of DigitalMaid Agentic OS from the committed tree.
# Usage: scripts/make-release.sh [OUT_DIR]   → OUT_DIR/digitalmaid.tar.gz + digitalmaid-<version>.tar.gz + SHA256SUMS
# Only what the app needs ships: package, UI, docs, install scripts, licences. No tests, no .git, no workspaces.
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$REPO/dist}"
VERSION="$(sed -n 's/^version = "\(.*\)"/\1/p' "$REPO/pyproject.toml")"
[ -n "$VERSION" ] || { echo "no version in pyproject.toml" >&2; exit 1; }
mkdir -p "$OUT"
cd "$REPO"
git diff --quiet || { echo "working tree is dirty; commit first" >&2; exit 1; }
PREFIX="digitalmaid-$VERSION/"
git archive --format=tar --prefix="$PREFIX" HEAD \
  pyproject.toml README.md AGENTS.md CLAUDE.md digitalmaid docs scripts hermes-plugin \
  | gzip -9 > "$OUT/digitalmaid-$VERSION.tar.gz"
cp "$OUT/digitalmaid-$VERSION.tar.gz" "$OUT/digitalmaid.tar.gz"
( cd "$OUT" && (command -v sha256sum >/dev/null && sha256sum digitalmaid-$VERSION.tar.gz digitalmaid.tar.gz || shasum -a 256 digitalmaid-$VERSION.tar.gz digitalmaid.tar.gz) > SHA256SUMS )
echo "built $OUT/digitalmaid-$VERSION.tar.gz ($(du -h "$OUT/digitalmaid.tar.gz" | cut -f1))"
tar -tzf "$OUT/digitalmaid.tar.gz" | grep -c . | xargs echo "files:"
