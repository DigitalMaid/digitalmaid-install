"""SQLite connection, versioned migrations, audit log and revision-checked writes."""

import json
import re
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from digitalmaid.errors import ConflictError

_IDENTIFIER = re.compile(r"^[a-z_][a-z0-9_]*$")
_ISO_TIMESTAMP = re.compile(r"^[0-9T:.+\-]+$")

MIGRATIONS = [
    # 1: goals, projects, audit log
    """
    CREATE TABLE goals (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        title TEXT NOT NULL,
        owner TEXT NOT NULL,
        success_measure TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE projects (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        title TEXT NOT NULL,
        owner TEXT NOT NULL,
        goal_id TEXT NOT NULL REFERENCES goals(id),
        success_criteria TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Plan',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE audit_events (
        id TEXT PRIMARY KEY,
        scope_id TEXT,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        action TEXT NOT NULL,
        actor TEXT NOT NULL,
        at TEXT NOT NULL,
        details TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX audit_events_entity ON audit_events (entity_type, entity_id);
    """,
    # 2: tasks, 5M assessments, waivers, spend authorizations, executions,
    #    outputs/versions, checks, corrections, learnings, goal outcomes
    """
    CREATE TABLE tasks (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        project_id TEXT NOT NULL REFERENCES projects(id),
        title TEXT NOT NULL,
        owner TEXT NOT NULL,
        next_action TEXT NOT NULL,
        criteria TEXT NOT NULL,
        priority INTEGER NOT NULL,
        deadline TEXT,
        status TEXT NOT NULL DEFAULT 'Plan',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE INDEX tasks_project ON tasks (scope_id, project_id);
    CREATE TABLE resource_assessments (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        status TEXT NOT NULL,
        na_reason TEXT,
        amount_minor INTEGER,
        currency TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1,
        UNIQUE (task_id, category)
    );
    CREATE TABLE waivers (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        category TEXT NOT NULL,
        reason TEXT NOT NULL,
        granted_by TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE spend_authorizations (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        amount_minor INTEGER NOT NULL,
        currency TEXT NOT NULL,
        authorized_by TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE executions (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        agent_id TEXT NOT NULL,
        status TEXT NOT NULL,
        model TEXT,
        provider TEXT,
        log TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE outputs (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL UNIQUE REFERENCES tasks(id),
        latest_version INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE output_versions (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        output_id TEXT NOT NULL REFERENCES outputs(id),
        execution_id TEXT NOT NULL REFERENCES executions(id),
        version INTEGER NOT NULL,
        content TEXT NOT NULL,
        sha256 TEXT NOT NULL,
        criteria_snapshot TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE (output_id, version)
    );
    CREATE TABLE checks (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        output_version_id TEXT NOT NULL REFERENCES output_versions(id),
        reviewer TEXT NOT NULL,
        passed INTEGER NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE check_results (
        id TEXT PRIMARY KEY,
        check_id TEXT NOT NULL REFERENCES checks(id),
        criterion TEXT NOT NULL,
        passed INTEGER NOT NULL,
        evidence TEXT NOT NULL
    );
    CREATE TABLE corrections (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        check_id TEXT NOT NULL UNIQUE REFERENCES checks(id),
        task_id TEXT NOT NULL REFERENCES tasks(id),
        owner TEXT NOT NULL,
        action TEXT NOT NULL,
        revised_output_version_id TEXT REFERENCES output_versions(id),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE acceptances (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        output_version_id TEXT NOT NULL UNIQUE REFERENCES output_versions(id),
        accepted_by TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE learnings (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        text TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    ALTER TABLE goals ADD COLUMN outcome_status TEXT NOT NULL DEFAULT 'open';
    CREATE TABLE goal_outcomes (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        goal_id TEXT NOT NULL UNIQUE REFERENCES goals(id),
        achieved INTEGER NOT NULL,
        evidence TEXT NOT NULL,
        decided_by TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    """,
    # 3: output content moves to immutable blobs under outputs/<scope>/...
    #    (ADR-002); the row keeps the relative path and hash only.
    """
    ALTER TABLE output_versions DROP COLUMN content;
    ALTER TABLE output_versions ADD COLUMN blob_path TEXT NOT NULL DEFAULT '';
    """,
    # 4: per-scope UI widget preferences (order + visibility)
    """
    CREATE TABLE widget_preferences (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        area TEXT NOT NULL,
        widgets TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1,
        UNIQUE (scope_id, area)
    );
    """,
    # 5: application-owned automation jobs and their database-backed
    #    occurrences (ADR-005). Timestamps in these tables use the fixed-width
    #    ``utc_iso`` form so string comparison equals instant comparison.
    """
    CREATE TABLE automation_jobs (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        purpose TEXT NOT NULL,
        agent_id TEXT NOT NULL,
        project_id TEXT NOT NULL REFERENCES projects(id),
        task_template TEXT NOT NULL,
        schedule_kind TEXT NOT NULL,
        schedule_spec TEXT NOT NULL,
        timezone TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        misfire_policy TEXT NOT NULL,
        schedule_version INTEGER NOT NULL DEFAULT 1,
        planned_until TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE job_occurrences (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        job_id TEXT NOT NULL REFERENCES automation_jobs(id),
        schedule_version INTEGER NOT NULL,
        occurrence_utc TEXT NOT NULL,
        kind TEXT NOT NULL,
        idempotency_key TEXT,
        status TEXT NOT NULL,
        lease_until TEXT,
        fencing_token INTEGER NOT NULL DEFAULT 0,
        worker_id TEXT,
        task_id TEXT REFERENCES tasks(id),
        execution_id TEXT REFERENCES executions(id),
        blocked_reasons TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1,
        UNIQUE (job_id, schedule_version, occurrence_utc)
    );
    CREATE UNIQUE INDEX job_occurrences_idempotency
        ON job_occurrences (job_id, idempotency_key)
        WHERE idempotency_key IS NOT NULL;
    CREATE INDEX job_occurrences_due
        ON job_occurrences (scope_id, status, occurrence_utc);
    """,
    # 6: live execution evidence (ADR-008): usage/cost/response id from the
    #    provider response, spend intents recorded before a paid call, and
    #    worker heartbeats for liveness.
    """
    ALTER TABLE executions ADD COLUMN usage_json TEXT;
    ALTER TABLE executions ADD COLUMN cost_minor INTEGER;
    ALTER TABLE executions ADD COLUMN cost_currency TEXT;
    ALTER TABLE executions ADD COLUMN provider_response_id TEXT;
    CREATE TABLE spend_intents (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        execution_id TEXT NOT NULL REFERENCES executions(id),
        amount_minor INTEGER NOT NULL,
        currency TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE worker_heartbeats (
        worker_id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        status TEXT NOT NULL,
        started_at_utc TEXT NOT NULL,
        last_seen_utc TEXT NOT NULL,
        expires_at_utc TEXT NOT NULL,
        current_occurrence_id TEXT
    );
    """,
    # 7: knowledge — notes/journal/research/decisions and typed links.
    #    The full-text index is a rebuildable derived table created outside
    #    the migration (FTS5 may be unavailable; see knowledge.py).
    """
    CREATE TABLE notes (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        kind TEXT NOT NULL,
        title TEXT NOT NULL,
        body_md TEXT NOT NULL,
        entry_date TEXT,
        decision_json TEXT,
        outcome TEXT,
        outcome_at TEXT,
        archived_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE INDEX notes_scope_kind ON notes (scope_id, kind, created_at);
    CREATE UNIQUE INDEX notes_journal_day ON notes (scope_id, entry_date)
        WHERE kind = 'journal';
    CREATE TABLE note_links (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        note_id TEXT NOT NULL REFERENCES notes(id),
        target_type TEXT NOT NULL,
        target_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE (note_id, target_type, target_id)
    );
    CREATE INDEX note_links_target ON note_links (scope_id, target_type, target_id);
    """,
    # 8: versioned procedures (SOPs), task dependencies, learning proposals
    #    and review comments on output versions.
    """
    CREATE TABLE procedures (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        title TEXT NOT NULL,
        purpose TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'draft',
        current_version INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE procedure_versions (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        procedure_id TEXT NOT NULL REFERENCES procedures(id),
        version INTEGER NOT NULL,
        steps_json TEXT NOT NULL,
        inputs_json TEXT NOT NULL,
        outputs_json TEXT NOT NULL,
        changelog TEXT NOT NULL,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        sha256 TEXT NOT NULL,
        UNIQUE (procedure_id, version)
    );
    ALTER TABLE tasks ADD COLUMN procedure_id TEXT REFERENCES procedures(id);
    ALTER TABLE tasks ADD COLUMN procedure_version INTEGER;
    ALTER TABLE tasks ADD COLUMN step_index INTEGER;
    CREATE TABLE task_dependencies (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        task_id TEXT NOT NULL REFERENCES tasks(id),
        depends_on_task_id TEXT NOT NULL REFERENCES tasks(id),
        created_at TEXT NOT NULL,
        UNIQUE (task_id, depends_on_task_id)
    );
    CREATE INDEX task_dependencies_task ON task_dependencies (scope_id, task_id);
    CREATE TABLE learning_proposals (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        procedure_id TEXT NOT NULL REFERENCES procedures(id),
        text TEXT NOT NULL,
        from_task_id TEXT NOT NULL REFERENCES tasks(id),
        proposed_by TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'open',
        decided_by TEXT,
        applied_version INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE review_comments (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        output_version_id TEXT NOT NULL REFERENCES output_versions(id),
        author TEXT NOT NULL,
        body_md TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE INDEX review_comments_version ON review_comments (scope_id, output_version_id);
    """,
    # 9: calendar events with recurrence (local wall time in an IANA zone)
    #    and per-occurrence exceptions. Rows with external_source are owned
    #    elsewhere and read-only here (ADR-002).
    """
    CREATE TABLE events (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        title TEXT NOT NULL,
        kind TEXT NOT NULL,
        start_utc TEXT NOT NULL,
        end_utc TEXT,
        all_day INTEGER NOT NULL DEFAULT 0,
        timezone TEXT NOT NULL,
        rrule_json TEXT,
        notes TEXT NOT NULL DEFAULT '',
        linked_type TEXT,
        linked_id TEXT,
        external_source TEXT,
        external_id TEXT,
        archived_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE INDEX events_scope_start ON events (scope_id, start_utc);
    CREATE TABLE event_exceptions (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        event_id TEXT NOT NULL REFERENCES events(id),
        occurrence_local_date TEXT NOT NULL,
        kind TEXT NOT NULL,
        new_start_utc TEXT,
        new_end_utc TEXT,
        created_at TEXT NOT NULL,
        UNIQUE (event_id, occurrence_local_date)
    );
    """,
    # 10: authentication (ADR-006): workspace-wide users with scrypt password
    #     hashes, per-scope memberships and opaque sessions.
    """
    CREATE TABLE users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        salt TEXT NOT NULL,
        created_at TEXT NOT NULL,
        disabled_at TEXT
    );
    CREATE TABLE memberships (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id),
        scope_id TEXT NOT NULL,
        role TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (user_id, scope_id)
    );
    CREATE TABLE sessions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL
    );
    CREATE INDEX sessions_user ON sessions (user_id);
    """,
    # 11: Capture Inbox — raw originals (immutable blobs under captures/),
    #     draft versions, links to what a capture became — and API tokens
    #     scoped to the capture routes (Hermes seam).
    """
    CREATE TABLE captures (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        kind TEXT NOT NULL,
        title TEXT,
        body_text TEXT,
        url TEXT,
        original_path TEXT,
        original_sha256 TEXT,
        mime TEXT,
        size_bytes INTEGER,
        source TEXT NOT NULL,
        captured_by TEXT NOT NULL,
        captured_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'inbox',
        converted_type TEXT,
        converted_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1
    );
    CREATE INDEX captures_scope_status ON captures (scope_id, status, captured_at);
    CREATE TABLE capture_drafts (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        capture_id TEXT NOT NULL REFERENCES captures(id),
        version INTEGER NOT NULL,
        body_md TEXT NOT NULL,
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE (capture_id, version)
    );
    CREATE TABLE capture_links (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        capture_id TEXT NOT NULL REFERENCES captures(id),
        target_type TEXT NOT NULL,
        target_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE (capture_id, target_type, target_id)
    );
    CREATE TABLE api_tokens (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id),
        name TEXT NOT NULL,
        token_hash TEXT NOT NULL,
        created_at TEXT NOT NULL,
        last_used_at TEXT,
        revoked_at TEXT
    );
    CREATE INDEX api_tokens_user ON api_tokens (user_id);
    """,
    # 12: trusted sign-in from the Hermes dashboard proxy (0.3.0): a session created by
    #     POST /api/auth/trusted is flagged so the UI can say so and audit can tell.
    """
    ALTER TABLE sessions ADD COLUMN trusted INTEGER NOT NULL DEFAULT 0;
    """,
    # 13: JOH — Journey of Humanity (0.5.0): one personal profile per scope+user with the
    #     full engine output as JSON (both zodiacs), enneagram test attempts, and every
    #     Compass answer. ``revision`` added to the brief's column list so writes follow
    #     the revision-checked pattern used everywhere else.
    """
    CREATE TABLE joh_profiles (
        id TEXT PRIMARY KEY,
        scope_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        birth_date TEXT NOT NULL,
        birth_time TEXT,
        time_known INTEGER NOT NULL DEFAULT 1,
        place_display TEXT,
        country_code TEXT,
        lat REAL NOT NULL,
        lon REAL NOT NULL,
        timezone TEXT NOT NULL,
        zodiac TEXT NOT NULL DEFAULT 'sidereal',
        enneagram_type INTEGER,
        enneagram_wing INTEGER,
        enneagram_instinct TEXT,
        enneagram_source TEXT,
        computed TEXT NOT NULL,
        engine_version INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        revision INTEGER NOT NULL DEFAULT 1,
        UNIQUE (scope_id, user_id)
    );
    CREATE TABLE joh_enneagram_attempts (
        id TEXT PRIMARY KEY,
        profile_id TEXT NOT NULL REFERENCES joh_profiles(id),
        seed INTEGER NOT NULL,
        answers TEXT NOT NULL,
        scores TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE INDEX joh_attempts_profile ON joh_enneagram_attempts (profile_id, created_at);
    CREATE TABLE joh_guidance (
        id TEXT PRIMARY KEY,
        profile_id TEXT NOT NULL REFERENCES joh_profiles(id),
        kind TEXT NOT NULL,
        input_text TEXT NOT NULL,
        output_text TEXT NOT NULL,
        model TEXT,
        provider TEXT,
        cost_minor INTEGER,
        currency TEXT,
        created_at TEXT NOT NULL
    );
    CREATE INDEX joh_guidance_profile ON joh_guidance (profile_id, created_at);
    """,
    # 14: task inputs (0.5.0, JOH-3): a small string→string JSON object on every task, the
    #     plain-task counterpart of a job template's ``inputs``; the live runner merges the
    #     task's over the template's, and ``{"joh": "true"}`` asks for the Journey brief.
    """
    ALTER TABLE tasks ADD COLUMN inputs TEXT NOT NULL DEFAULT '{}';
    """,
]

SCHEMA_VERSION = len(MIGRATIONS)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


class Database:
    """Owns one connection to ``root/state/state.sqlite``."""

    def __init__(self, root):
        state_dir = Path(root) / "state"
        state_dir.mkdir(parents=True, exist_ok=True)
        # One connection shared by whichever thread serves a request; the
        # re-entrant lock serialises transactions and the reads inside them.
        self._conn = sqlite3.connect(state_dir / "state.sqlite",
                                     isolation_level=None,
                                     check_same_thread=False)
        self._lock = threading.RLock()
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.execute("PRAGMA busy_timeout = 5000")
        self._columns: dict[str, set[str]] = {}
        self._migrate()

    def close(self) -> None:
        self._conn.close()

    # -- migrations ---------------------------------------------------------

    def _migrate(self) -> None:
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations ("
            " version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)")
        applied = {
            r["version"] for r in
            self._conn.execute("SELECT version FROM schema_migrations")
        }
        for version, script in enumerate(MIGRATIONS, start=1):
            if version in applied:
                continue
            # executescript commits any open transaction first, so the
            # migration and its journal row are wrapped inside the script.
            stamp = now()
            assert _ISO_TIMESTAMP.match(stamp)
            self._conn.executescript(
                f"BEGIN IMMEDIATE;\n{script}\n"
                "INSERT INTO schema_migrations (version, applied_at)"
                f" VALUES ({int(version)}, '{stamp}');\nCOMMIT;")

    # -- reads --------------------------------------------------------------

    def query(self, sql: str, params=()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    def query_one(self, sql: str, params=()):
        with self._lock:
            return self._conn.execute(sql, params).fetchone()

    # -- writes -------------------------------------------------------------

    @contextmanager
    def transaction(self):
        """Yield a cursor inside BEGIN IMMEDIATE; commit on success."""
        with self._lock:
            cur = self._conn.cursor()
            cur.execute("BEGIN IMMEDIATE")
            try:
                yield cur
            except BaseException:
                cur.execute("ROLLBACK")
                raise
            else:
                cur.execute("COMMIT")
            finally:
                cur.close()

    def audit(self, cur, entity_type: str, entity_id: str, action: str,
              actor: str, details: dict | None = None,
              scope_id: str | None = None) -> str:
        event_id = new_id()
        cur.execute(
            "INSERT INTO audit_events (id, scope_id, entity_type, entity_id,"
            " action, actor, at, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (event_id, scope_id, entity_type, entity_id, action, actor,
             now(), json.dumps(details or {}, sort_keys=True)))
        return event_id

    def update_with_revision(self, table: str, row_id: str, scope_id: str,
                             expected_revision: int, fields: dict,
                             actor: str, action: str,
                             details: dict | None = None, cur=None,
                             entity_type: str | None = None) -> int:
        """Apply ``fields`` only if the row still has ``expected_revision``.

        Bumps ``revision`` and ``updated_at`` and writes an audit row
        (``entity_type`` defaults to the table name). Returns the new
        revision. Raises ConflictError if the row is missing in this scope
        or has moved on.
        """
        if cur is None:
            with self.transaction() as own:
                return self.update_with_revision(
                    table, row_id, scope_id, expected_revision, fields,
                    actor, action, details, cur=own, entity_type=entity_type)
        self._check_columns(table, fields)
        assignments = ", ".join(f"{name} = ?" for name in fields)
        params = [*fields.values(), now(), row_id, scope_id,
                  expected_revision]
        cur.execute(
            f"UPDATE {table} SET {assignments}, updated_at = ?,"
            " revision = revision + 1"
            " WHERE id = ? AND scope_id = ? AND revision = ?", params)
        if cur.rowcount != 1:
            raise ConflictError(
                f"{table} {row_id!r} not at revision {expected_revision}"
                f" in scope {scope_id!r}")
        self.audit(cur, entity_type or table, row_id, action, actor,
                   {**(details or {}), "revision": expected_revision + 1},
                   scope_id=scope_id)
        return expected_revision + 1

    def _check_columns(self, table: str, fields: dict) -> None:
        if not _IDENTIFIER.match(table):
            raise ValueError(f"invalid table name {table!r}")
        if table not in self._columns:
            rows = self._conn.execute(f"PRAGMA table_info({table})").fetchall()
            if not rows:
                raise ValueError(f"unknown table {table!r}")
            self._columns[table] = {r["name"] for r in rows}
        allowed = self._columns[table] - {"id", "scope_id", "revision",
                                          "created_at", "updated_at"}
        bad = set(fields) - allowed
        if bad or not fields:
            raise ValueError(f"cannot update columns {sorted(bad)} of {table}")
