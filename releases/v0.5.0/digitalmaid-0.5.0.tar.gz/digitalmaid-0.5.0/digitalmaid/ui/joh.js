// JOH — Journey of Humanity (0.5.0, docs/JOH.md §2, §4; DESIGN.md F11). Six tabs under
// #/joh: Overview · Astro · Bodygraph · Gene Keys · Enneagram · Compass. Every drawing is
// SVG built here, stroke-only, in the Observatory tokens; text goes through textContent.

import { api } from "./api.js";
import { el, append, pill, when, empty, alertBox, reasonsList, field, form, pageHeader, LEADS, confirmDialog, isReadOnly, applyReadOnly } from "./views.js";

LEADS.joh = "Your birth chart, Human Design, Gene Keys and Enneagram in one place — and a Compass that advises through them.";

const TABS = [["overview", "Overview"], ["astro", "Astro"], ["bodygraph", "Bodygraph"], ["genekeys", "Gene Keys"], ["enneagram", "Enneagram"], ["compass", "Compass"]];
const SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"];
const SIGN_ABBR = ["Ar", "Ta", "Ge", "Cn", "Le", "Vi", "Li", "Sc", "Sg", "Cp", "Aq", "Pi"];
const BODIES = [["sun", "Sun", "Su"], ["moon", "Moon", "Mo"], ["mercury", "Mercury", "Me"], ["venus", "Venus", "Ve"], ["mars", "Mars", "Ma"], ["jupiter", "Jupiter", "Ju"], ["saturn", "Saturn", "Sa"], ["uranus", "Uranus", "Ur"], ["neptune", "Neptune", "Ne"], ["pluto", "Pluto", "Pl"], ["true_node", "North Node", "NN"], ["south_node", "South Node", "SN"]];
const HD_BODIES = [["sun", "Sun"], ["earth", "Earth"], ["north_node", "North Node"], ["south_node", "South Node"], ["moon", "Moon"], ["mercury", "Mercury"], ["venus", "Venus"], ["mars", "Mars"], ["jupiter", "Jupiter"], ["saturn", "Saturn"], ["uranus", "Uranus"], ["neptune", "Neptune"], ["pluto", "Pluto"]];
const GOLD_ASPECTS = new Set(["conjunction", "trine", "sextile"]);
// The nine centres (docs/JOH.md §3.5 tables): shape, anchor and the gates that sit in each.
const CENTRES = [
  { name: "Head", shape: "tri-up", x: 150, y: 38, gates: [64, 61, 63] },
  { name: "Ajna", shape: "tri-down", x: 150, y: 108, gates: [47, 24, 4, 17, 43, 11] },
  { name: "Throat", shape: "square", x: 150, y: 185, gates: [62, 23, 56, 35, 12, 45, 33, 8, 31, 20, 16] },
  { name: "G", shape: "diamond", x: 150, y: 270, gates: [1, 13, 25, 46, 2, 15, 10, 7] },
  { name: "Heart", shape: "tri-heart", x: 226, y: 262, gates: [21, 40, 26, 51] },
  { name: "Sacral", shape: "square", x: 150, y: 372, gates: [5, 14, 29, 59, 9, 3, 42, 27, 34] },
  { name: "Spleen", shape: "tri-left", x: 62, y: 340, gates: [48, 57, 44, 50, 32, 28, 18] },
  { name: "Solar Plexus", shape: "tri-right", x: 238, y: 340, gates: [6, 37, 22, 36, 30, 55, 49] },
  { name: "Root", shape: "square", x: 150, y: 470, gates: [53, 60, 52, 19, 39, 41, 58, 38, 54] },
];
const CHANNELS = [[1, 8], [2, 14], [3, 60], [4, 63], [5, 15], [6, 59], [7, 31], [9, 52], [10, 20], [10, 34], [10, 57], [11, 56], [12, 22], [13, 33], [16, 48], [17, 62], [18, 58], [19, 49], [20, 34], [20, 57], [21, 45], [23, 43], [24, 61], [25, 51], [26, 44], [27, 50], [28, 38], [29, 46], [30, 41], [32, 54], [34, 57], [35, 36], [37, 40], [39, 55], [42, 53], [47, 64]];
const SEQUENCES = [["activation", "Activation sequence", "The four Prime Gifts: what you are here to do and how it lands."], ["venus", "Venus sequence", "How you attract, think, feel and relate — and the wound underneath."], ["pearl", "Pearl sequence", "Your work in the world and the prosperity it can return."]];
const GK_NODES = { "Life's Work": [150, 34], Evolution: [96, 96], Radiance: [204, 96], Purpose: [150, 158], Attraction: [60, 214], IQ: [40, 276], EQ: [60, 338], SQ: [104, 384], "Core Wound": [150, 410], Vocation: [240, 214], Culture: [260, 276], Pearl: [240, 338], Brand: [196, 384] };
const GK_EDGES = [["Life's Work", "Evolution"], ["Life's Work", "Radiance"], ["Evolution", "Purpose"], ["Radiance", "Purpose"], ["Purpose", "Attraction"], ["Attraction", "IQ"], ["IQ", "EQ"], ["EQ", "SQ"], ["SQ", "Core Wound"], ["Purpose", "Vocation"], ["Vocation", "Culture"], ["Culture", "Pearl"], ["Pearl", "Brand"], ["Brand", "Core Wound"]];
const ENNEAGRAM_NAMES = { 1: "Improver", 2: "Helper", 3: "Achiever", 4: "Individualist", 5: "Investigator", 6: "Loyalist", 7: "Enthusiast", 8: "Protector", 9: "Peacemaker" };
const SCALE_LABELS = ["Not like me", "Slightly", "Somewhat", "Mostly", "Very like me"];
const COMPASS_KINDS = [["email", "Reply to an email"], ["decision", "Make a decision"], ["question", "Ask anything"]];
const HORIZONS = [["this week", "This week"], ["this quarter", "This quarter"], ["this year", "This year"], ["life", "Life"]];
const SVG_NS = "http://www.w3.org/2000/svg";
const TIME_UNKNOWN = "Time unknown — Moon, houses, and any gate near a boundary are approximate.";
const PRIVACY = "Only the city and country you type are sent to OpenStreetMap; your date and time never leave this server.";
const ATTRIBUTION = "Place data © OpenStreetMap contributors";

const state = { compassKind: "email", enneagramMode: null, enneagramResult: null, onboarding: false, geocode: null, manual: false };

function svg(tag, attrs = {}, ...children) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) if (value !== null && value !== undefined && value !== false) node.setAttribute(key, String(value));
  for (const child of children.flat()) if (child) node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  return node;
}

function polar(cx, cy, r, degrees) {
  // Zodiac wheel: 0° Aries on the left, counter-clockwise (the astrological convention).
  const a = Math.PI * (180 - degrees) / 180;
  return [cx + r * Math.cos(a), cy - r * Math.sin(a)];
}

function degText(p) { return `${p.degree}°${String(p.minute).padStart(2, "0")}′`; }
function label(text, cls = "") { return el("span", { class: `label${cls ? ` ${cls}` : ""}` }, text); }
function num(text, cls = "") { return el("span", { class: `num joh-num${cls ? ` ${cls}` : ""}` }, String(text)); }
function tabHash(tab) { return `#/joh${tab === "overview" ? "" : `/${tab}`}`; }

// Markdown-lite for Compass answers: headings, bullets, paragraphs and **bold**; DOM only.
function renderMarkdown(text) {
  const root = el("div", { class: "joh-md" });
  let list = null, para = [];
  const flush = () => { if (para.length) { root.append(el("p", {}, inline(para.join(" ")))); para = []; } };
  const inline = (line) => line.split(/(\*\*[^*]+\*\*)/).map((part) => part.startsWith("**") && part.endsWith("**") ? el("strong", {}, part.slice(2, -2)) : part);
  for (const raw of (text || "").split("\n")) {
    const line = raw.trimEnd();
    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    const bullet = line.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if (heading) { flush(); list = null; root.append(el(heading[1].length <= 2 ? "h3" : "h4", {}, heading[2].replace(/\*\*/g, ""))); }
    else if (bullet) { flush(); if (!list) { list = el("ul", {}); root.append(list); } list.append(el("li", {}, inline(bullet[1]))); }
    else if (!line.trim()) { flush(); list = null; }
    else { list = null; para.push(line.trim()); }
  }
  flush();
  return root;
}

// --- page ---------------------------------------------------------------------------------

export async function renderJohPage(view, ctx, tabParam) {
  const tab = TABS.some(([id]) => id === tabParam) ? tabParam : "overview";
  let status, profile = null;
  try { status = await api.johStatus(); } catch (error) { view.replaceChildren(alertBox("error", `Could not load JOH: ${error.message}`)); return; }
  if (status.has_profile) {
    try { profile = await api.johProfile(); } catch (error) { if (error.status !== 404) throw error; }
  }
  const head = pageHeader("joh", "Journey of Humanity",
    "Sidereal (Lahiri) positions drive the astrology chart and the Human Design and Gene Keys gate mapping — the owner's choice, and different from official HD and Gene Keys charts, which are tropical. Every chart tab has a toggle so you can compare. The engine is offline and deterministic: the same birth data always yields the same profile. The Compass sends your profile brief and your question to the configured model; only the typed city and country ever reach OpenStreetMap.",
    { meta: !status.enabled ? el("p", { class: "meta" }, "JOH is turned off in Settings; it is still yours to read here.") : null });
  const body = el("div", { class: "stack joh-page", id: "joh" });
  view.replaceChildren(head, body);
  if (!profile || state.onboarding) {
    body.append(renderOnboarding(profile, ctx, () => { state.onboarding = false; ctx.route(); }));
    return;
  }
  const tabs = el("div", { class: "tabs joh-tabs", role: "tablist", "aria-label": "Journey pages" },
    TABS.map(([id, text]) => el("button", { class: "tab", type: "button", role: "tab", id: `joh-tab-${id}`, dataset: { johTab: id }, "aria-selected": String(tab === id), "aria-controls": "joh-panel",
      onclick: () => { location.hash = tabHash(id); } }, text)));
  const panel = el("section", { id: "joh-panel", class: "stack joh-panel", role: "tabpanel", "aria-labelledby": `joh-tab-${tab}`, dataset: { tab } });
  body.append(tabs, panel);
  const render = { overview: renderOverview, astro: renderAstro, bodygraph: renderBodygraph, genekeys: renderGeneKeys, enneagram: renderEnneagram, compass: renderCompass }[tab];
  await render(panel, profile, ctx);
  if (tab !== "enneagram" && tab !== "compass") panel.append(zodiacFooter(profile, ctx));
  if (tab === "overview" || tab === "astro" || tab === "bodygraph" || tab === "genekeys") {
    if (!profile.birth.time_known) panel.prepend(el("p", { class: "gate-line joh-time-note" }, el("span", {}, TIME_UNKNOWN)));
  }
  applyReadOnly(body);
}

function zodiacFooter(profile, ctx) {
  const sidereal = profile.zodiac === "sidereal";
  const button = el("button", { class: "pill-btn", type: "button", id: "joh-zodiac-toggle", dataset: { write: "true" } }, sidereal ? "switch to tropical" : "switch to sidereal");
  button.addEventListener("click", async () => {
    button.disabled = true;
    try { await api.johSetZodiac(sidereal ? "tropical" : "sidereal"); await ctx.route(); }
    catch (error) { button.disabled = false; ctx.showGlobal(`Could not switch zodiac: ${error.message}`, "error", error.reasons); }
  });
  return el("p", { class: "meta joh-zodiac", id: "joh-zodiac" },
    el("span", { id: "joh-zodiac-name" }, sidereal ? "Sidereal (Lahiri)" : "Tropical"), " · ", button,
    el("span", {}, ` · the other zodiac reads Sun ${profile.alternate.sun_sign}, ${profile.alternate.hd_type} ${profile.alternate.profile}`));
}

// --- onboarding (§2) ------------------------------------------------------------------------

function renderOnboarding(existing, ctx, done) {
  const birth = existing?.birth || {};
  const notice = el("div", { class: "stack", id: "joh-onboarding-notice" });
  const result = el("div", { class: "stack", id: "joh-geocode-result" });
  const city = el("input", { type: "text", name: "city", id: "joh-city", autocomplete: "off", placeholder: "City or town" });
  const country = el("input", { type: "text", name: "country", id: "joh-country", autocomplete: "off", placeholder: "Country" });
  const findButton = el("button", { class: "btn", type: "button", id: "joh-find", dataset: { write: "true" } }, "Find place");
  const timeInput = el("input", { type: "time", name: "birth_time", id: "joh-time", value: birth.time || "", step: "60" });
  const unknown = el("input", { type: "checkbox", name: "time_unknown", id: "joh-time-unknown", checked: existing && !birth.time_known ? "" : null });
  unknown.addEventListener("change", () => { timeInput.disabled = unknown.checked; if (unknown.checked) timeInput.value = ""; });
  timeInput.disabled = unknown.checked;
  const lat = el("input", { type: "number", name: "lat", id: "joh-lat", step: "0.0001", min: "-90", max: "90", value: birth.lat ?? "" });
  const lon = el("input", { type: "number", name: "lon", id: "joh-lon", step: "0.0001", min: "-180", max: "180", value: birth.lon ?? "" });
  const zone = el("select", { name: "timezone", id: "joh-timezone" });
  const zones = typeof Intl.supportedValuesOf === "function" ? Intl.supportedValuesOf("timeZone") : [];
  const zoneOptions = new Set(zones);
  if (birth.timezone) zoneOptions.add(birth.timezone);
  if (!zoneOptions.size) zoneOptions.add("UTC");
  zone.append(...[...zoneOptions].sort().map((z) => el("option", { value: z, selected: z === birth.timezone || null }, z)));
  const place = el("input", { type: "hidden", name: "place_display", id: "joh-place", value: birth.place_display || "" });
  const code = el("input", { type: "hidden", name: "country_code", id: "joh-country-code", value: birth.country_code || "" });
  const manual = el("div", { class: "stack joh-manual", id: "joh-manual", hidden: !(state.manual || (existing && !state.geocode)) || null },
    el("div", { class: "form-row is-inline" },
      el("div", { class: "form-row" }, el("label", { for: "joh-lat" }, "Latitude"), lat),
      el("div", { class: "form-row" }, el("label", { for: "joh-lon" }, "Longitude"), lon)),
    el("div", { class: "form-row" }, el("label", { for: "joh-timezone" }, "Timezone (IANA)"), zone));
  const chosenLine = (name, hitLat, hitLon, tz) => el("p", { class: "gate-line", id: "joh-place-chosen" },
    el("span", {}, `${name} · ${Number(hitLat).toFixed(4)}, ${Number(hitLon).toFixed(4)} · ${tz}`));
  const useResult = (hit) => {
    lat.value = hit.lat; lon.value = hit.lon; place.value = hit.display_name; code.value = hit.country_code || "";
    if (![...zone.options].some((o) => o.value === hit.timezone)) zone.append(el("option", { value: hit.timezone }, hit.timezone));
    zone.value = hit.timezone;
    state.geocode = hit;
    result.replaceChildren(chosenLine(hit.display_name, hit.lat, hit.lon, hit.timezone));
  };
  // Editing: the saved place is shown as the chosen one; the coordinates stay editable below.
  if (existing && !state.geocode) result.append(chosenLine(birth.place_display || "Saved place", birth.lat, birth.lon, birth.timezone));
  findButton.addEventListener("click", async () => {
    notice.replaceChildren();
    if (!city.value.trim() || !country.value.trim()) { notice.replaceChildren(alertBox("error", "Type a city and a country first.")); return; }
    findButton.disabled = true;
    try {
      const hit = await api.johGeocode(city.value.trim(), country.value.trim());
      result.replaceChildren(el("div", { class: "list-item joh-geocode-hit", id: "joh-geocode-hit" },
        el("div", { class: "list-item-title" }, el("strong", {}, hit.display_name)),
        el("div", { class: "meta" }, `${hit.lat.toFixed(4)}, ${hit.lon.toFixed(4)} · ${hit.timezone}${hit.country_code ? ` · ${hit.country_code.toUpperCase()}` : ""}`),
        el("div", { class: "form-actions" },
          el("button", { class: "btn is-primary is-small", type: "button", id: "joh-use-place", dataset: { write: "true" }, onclick: () => { manual.hidden = true; useResult(hit); } }, "Use this"),
          el("button", { class: "btn is-small", type: "button", id: "joh-manual-toggle", onclick: () => { manual.hidden = false; state.manual = true; lat.focus(); } }, "Enter coordinates manually"))));
    } catch (error) {
      result.replaceChildren();
      notice.replaceChildren(alertBox("error", error.status === 404 ? "No place found — check the spelling, or enter the coordinates manually." : `Place lookup failed: ${error.message}`, error.reasons),
        el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", id: "joh-manual-toggle", onclick: () => { manual.hidden = false; state.manual = true; lat.focus(); } }, "Enter coordinates manually")));
    } finally { findButton.disabled = false; }
  });
  const save = form([
    el("div", { class: "form-row is-inline" },
      el("div", { class: "form-row" }, el("label", { for: "joh-date" }, "Date of birth"), el("input", { type: "date", name: "birth_date", id: "joh-date", required: true, value: birth.date || "", min: "1900-01-01", max: "2099-12-31" })),
      el("div", { class: "form-row" }, el("label", { for: "joh-time" }, "Time of birth (24h)"), timeInput)),
    el("div", { class: "form-row is-check" }, el("label", {}, unknown, " I don't know the time")),
    el("div", { class: "form-row is-inline joh-place-row" },
      el("div", { class: "form-row" }, el("label", { for: "joh-city" }, "City"), city),
      el("div", { class: "form-row" }, el("label", { for: "joh-country" }, "Country"), country),
      el("div", { class: "form-row joh-find-row" }, findButton)),
    result, manual, place, code,
    el("p", { class: "meta joh-privacy" }, PRIVACY),
    el("p", { class: "meta joh-attribution" }, ATTRIBUTION),
    notice,
  ], existing ? "Save birth data" : "Save and see my profile", async (data) => {
    if (!data.birth_date) throw new Error("Date of birth is required.");
    const body = {
      birth_date: data.birth_date, birth_time: unknown.checked || !data.birth_time ? null : data.birth_time.slice(0, 5),
      lat: Number.parseFloat(data.lat), lon: Number.parseFloat(data.lon), timezone: data.timezone,
      place_display: data.place_display || (city.value.trim() ? `${city.value.trim()}, ${country.value.trim()}` : null),
      country_code: data.country_code || null,
    };
    if (!Number.isFinite(body.lat) || !Number.isFinite(body.lon)) { manual.hidden = false; throw new Error("Find the place or enter latitude and longitude."); }
    await api.johSaveProfile(body);
    state.geocode = null; state.manual = false;
    location.hash = "#/joh";
    done();
  });
  save.id = "joh-onboarding-form";
  return el("section", { class: "panel joh-onboarding", id: "joh-onboarding", "aria-labelledby": "joh-onboarding-title" },
    el("h2", { id: "joh-onboarding-title", class: "joh-serif" }, existing ? "Edit your birth data" : "Where did your journey begin?"),
    el("p", { class: "meta" }, "Date, time and place of birth are enough. If the time is unknown, noon is used and the charts say so."),
    save,
    existing ? el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", id: "joh-onboarding-cancel", onclick: () => { state.onboarding = false; ctx.route(); } }, "Cancel"),
      el("button", { class: "btn is-small is-danger", type: "button", id: "joh-delete", dataset: { write: "true" }, onclick: async () => {
        const ok = await confirmDialog({ title: "Delete your Journey profile?", message: "Birth data, enneagram attempts and every Compass answer are removed. This cannot be undone.", confirmLabel: "Delete profile" });
        if (!ok) return;
        try { await api.johDeleteProfile(); state.onboarding = false; window.dispatchEvent(new CustomEvent("dm:joh-changed")); ctx.route(); }
        catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); }
      } }, "Delete profile")) : null);
}

// --- Overview -----------------------------------------------------------------------------

function card(title, ...children) {
  return el("section", { class: "panel joh-card" }, el("h2", { class: "joh-card-title" }, title), ...children);
}

function kv(rows) {
  return el("dl", { class: "kv joh-kv" }, rows.flatMap(([k, v]) => [el("dt", {}, k), el("dd", {}, v)]));
}

async function renderOverview(panel, profile, ctx) {
  const { astro, humandesign: hd, genekeys: gk } = profile.profile;
  const b = profile.birth;
  const who = ctx.currentUser() || "You";
  const timeText = b.time_known ? `at ${b.time}` : "at an unknown time";
  const enn = profile.enneagram;
  panel.append(
    el("p", { class: "joh-greeting", id: "joh-greeting" }, el("em", {}, who), `, born ${b.date} ${timeText} in ${b.place_display || `${b.lat}, ${b.lon}`}`),
    el("div", { class: "grid is-thirds joh-summary" },
      card("Sun · Moon · Rising", kv([
        ["Sun", el("span", { id: "joh-sun" }, `${astro.positions.sun.sign} ${degText(astro.positions.sun)}`)],
        ["Moon", el("span", { id: "joh-moon" }, `${astro.positions.moon.sign} ${degText(astro.positions.moon)}`)],
        ["Rising", el("span", { id: "joh-rising" }, `${astro.ascendant.sign} ${degText(astro.ascendant)}`)]])),
      card("Human Design", kv([["Type", el("span", { id: "joh-hd-type" }, hd.type)], ["Strategy", hd.strategy], ["Authority", hd.authority], ["Profile", el("span", { class: "num joh-num" }, hd.profile)]])),
      card("Enneagram", enn
        ? el("div", { class: "stack" }, el("p", { class: "joh-type-line", id: "joh-enneagram-summary" }, el("span", { class: "num joh-num" }, enn.card.label), ` · ${enn.card.name}`),
          el("p", { class: "meta" }, enn.card.keywords.join(" · ")), el("a", { class: "pill-btn", href: "#/joh/enneagram" }, "Open"))
        : el("div", { class: "stack" }, empty("Not set yet."), el("a", { class: "pill-btn gold", href: "#/joh/enneagram", id: "joh-find-type" }, "Find your type")))),
    card("The four Prime Gifts", primeGiftsArc(gk.prime_gifts), el("p", { class: "meta" }, "Life's Work · Evolution · Radiance · Purpose — the Activation sequence, key.line and the Gift word.")),
    el("div", { class: "form-actions" },
      el("button", { class: "pill-btn", type: "button", id: "joh-edit-birth", dataset: { write: "true" }, onclick: () => { state.onboarding = true; ctx.route(); } }, "Edit birth data"),
      el("a", { class: "pill-btn", href: "#/joh/compass" }, "Ask the Compass")));
}

function primeGiftsArc(gifts) {
  const width = 640, height = 150;
  const root = svg("svg", { class: "joh-arc", viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": `Prime Gifts: ${gifts.map((g) => `${g.sphere} ${g.key_line} ${g.gift}`).join(", ")}` });
  root.append(svg("path", { class: "joh-hair", d: `M 40 110 Q ${width / 2} -10 ${width - 40} 110`, fill: "none" }));
  gifts.forEach((g, i) => {
    const t = (i + 0.5) / gifts.length;
    const x = 40 + t * (width - 80);
    const y = (1 - t) * (1 - t) * 110 + 2 * (1 - t) * t * -10 + t * t * 110;
    root.append(svg("circle", { class: "joh-node", cx: x, cy: y, r: 5 }),
      svg("text", { class: "joh-svg-num", x, y: y + 24, "text-anchor": "middle" }, g.key_line),
      svg("text", { class: "joh-svg-serif", x, y: y + 42, "text-anchor": "middle" }, g.gift),
      svg("text", { class: "joh-svg-label", x, y: y - 14, "text-anchor": "middle" }, g.sphere.toUpperCase()));
  });
  return root;
}

// --- Astro (§4) ---------------------------------------------------------------------------

async function renderAstro(panel, profile) {
  const chart = profile.profile.astro;
  const rows = [...BODIES.map(([key, name]) => [name, chart.positions[key]]), ["Ascendant", chart.ascendant], ["Midheaven", chart.mc]];
  panel.append(
    el("p", { class: "meta" }, `Whole-sign houses from the Ascendant · aspects: conjunction, sextile, square, trine, opposition. ${profile.zodiac === "sidereal" ? "Sidereal (Lahiri) longitudes." : "Tropical longitudes."}`),
    el("div", { class: "joh-astro-layout" },
      el("div", { class: "joh-wheel-box" }, drawWheel(chart)),
      el("section", { class: "panel joh-card" }, el("h2", { class: "joh-card-title" }, "Positions"),
        el("table", { class: "joh-table", id: "joh-positions" },
          el("thead", {}, el("tr", {}, ["Body", "Sign", "Degree", "House", "R"].map((h) => el("th", {}, h)))),
          el("tbody", {}, rows.map(([name, p]) => el("tr", { dataset: { body: name } },
            el("td", {}, name), el("td", {}, p.sign), el("td", { class: "num joh-num" }, degText(p)),
            el("td", { class: "num joh-num" }, p.house ?? (name === "Ascendant" ? "1" : "—")), el("td", {}, p.retrograde ? "R" : ""))))))),
    el("details", { class: "how joh-how" }, el("summary", {}, "How to read the wheel"),
      el("div", { class: "how-body" }, "The outer ring is the twelve signs; the numbered ring is the whole-sign house each sign takes from your Ascendant. Planets sit at their degree with a small tick; gold lines inside are the easy aspects (conjunction, trine, sextile), rose lines the tense ones (square, opposition).")));
}

function drawWheel(chart) {
  const size = 560, c = size / 2, rOuter = 272, rSign = 236, rHouse = 206, rPlanet = 168, rAspect = 128;
  const root = svg("svg", { class: "joh-wheel", viewBox: `0 0 ${size} ${size}`, role: "img", "aria-label": "Birth chart wheel" });
  root.append(svg("circle", { class: "joh-hair", cx: c, cy: c, r: rOuter }), svg("circle", { class: "joh-hair", cx: c, cy: c, r: rSign }), svg("circle", { class: "joh-hair", cx: c, cy: c, r: rHouse }), svg("circle", { class: "joh-hair is-faint", cx: c, cy: c, r: rAspect }));
  const ascIndex = chart.ascendant.sign_index;
  for (let i = 0; i < 12; i += 1) {
    const start = i * 30;
    const [x1, y1] = polar(c, c, rHouse, start), [x2, y2] = polar(c, c, rOuter, start);
    root.append(svg("line", { class: "joh-hair", x1, y1, x2, y2 }));
    const [tx, ty] = polar(c, c, (rOuter + rSign) / 2, start + 15);
    const sector = svg("g", { class: "joh-sign", "data-sign": SIGNS[i] });
    sector.append(svg("text", { class: "joh-svg-serif", x: tx, y: ty + 5, "text-anchor": "middle" }, SIGN_ABBR[i]));
    const house = ((i - ascIndex + 12) % 12) + 1;
    const [hx, hy] = polar(c, c, (rSign + rHouse) / 2, start + 15);
    sector.append(svg("text", { class: "joh-svg-num", x: hx, y: hy + 4, "text-anchor": "middle" }, house));
    root.append(sector);
  }
  // Ascendant marker.
  const [ax1, ay1] = polar(c, c, rAspect, chart.ascendant.longitude), [ax2, ay2] = polar(c, c, rOuter, chart.ascendant.longitude);
  root.append(svg("line", { class: "joh-asc", x1: ax1, y1: ay1, x2: ax2, y2: ay2 }));
  for (const a of chart.aspects || []) {
    const pa = chart.positions[a.a], pb = chart.positions[a.b];
    if (!pa || !pb) continue;
    const [x1, y1] = polar(c, c, rAspect, pa.longitude), [x2, y2] = polar(c, c, rAspect, pb.longitude);
    root.append(svg("line", { class: `joh-aspect ${GOLD_ASPECTS.has(a.aspect) ? "is-gold" : "is-rose"}`, x1, y1, x2, y2, "data-aspect": a.aspect }));
  }
  // Planets: the tick always sits at the true longitude; labels closer than 6° of arc are
  // fanned out on alternating radii and joined to their tick by a leader hairline.
  for (const item of fanPlanets(chart.positions, rPlanet)) {
    const { key, name, glyph, p, angle, r, fanned } = item;
    const [x, y] = polar(c, c, r, angle);
    const [t1x, t1y] = polar(c, c, rHouse - 2, p.longitude), [t2x, t2y] = polar(c, c, rHouse - 10, p.longitude);
    const g = svg("g", { class: `joh-planet${fanned ? " is-fanned" : ""}`, "data-body": key });
    g.append(svg("line", { class: "joh-tick", x1: t1x, y1: t1y, x2: t2x, y2: t2y }));
    if (fanned) {
      const [lx, ly] = polar(c, c, r + 10, angle);
      g.append(svg("line", { class: "joh-leader", x1: t2x, y1: t2y, x2: lx, y2: ly }));
    }
    g.append(svg("text", { class: "joh-svg-serif is-planet joh-planet-label", x, y: y + 5, "text-anchor": "middle" }, glyph),
      svg("title", {}, `${name} ${p.sign} ${degText(p)}${p.retrograde ? " R" : ""}`));
    root.append(g);
  }
  return root;
}

const FAN_GAP = 6;        // bodies closer than this (degrees of arc) share a fan
const FAN_STEP = 6.5;     // angular spacing between fanned labels
const FAN_DROP = 24;      // radial step for every second label in a fan

function arcGap(from, to) { return ((to - from) % 360 + 360) % 360; }

function fanPlanets(positions, rPlanet) {
  const items = BODIES.filter(([key]) => positions[key]).map(([key, name, glyph]) => ({ key, name, glyph, p: positions[key] }));
  items.sort((a, b) => a.p.longitude - b.p.longitude);
  if (items.length > 1) {
    // Start the sweep after the widest empty arc so a fan never straddles the cut at 0° Aries.
    let cut = 0, widest = -1;
    items.forEach((item, i) => {
      const gap = arcGap(items[(i + items.length - 1) % items.length].p.longitude, item.p.longitude);
      if (gap > widest) { widest = gap; cut = i; }
    });
    items.push(...items.splice(0, cut));
  }
  let clusters = items.map((item) => [item]);
  const span = (cluster) => Math.max(arcGap(cluster[0].p.longitude, cluster[cluster.length - 1].p.longitude), (cluster.length - 1) * FAN_STEP);
  const mid = (cluster) => cluster[0].p.longitude + arcGap(cluster[0].p.longitude, cluster[cluster.length - 1].p.longitude) / 2;
  // Merge neighbours until every fan, at its spread width, clears the next by FAN_GAP.
  let merged = true;
  while (merged && clusters.length > 1) {
    merged = false;
    for (let i = 0; i < clusters.length; i += 1) {
      const a = clusters[i], b = clusters[(i + 1) % clusters.length];
      if (a === b) break;
      const gap = arcGap(mid(a) + span(a) / 2, mid(b) - span(b) / 2);
      const overlap = gap > 180 || gap < FAN_GAP;
      if (overlap) { clusters.splice(i, 1, [...a, ...b]); clusters.splice(clusters.indexOf(b), 1); merged = true; break; }
    }
  }
  const out = [];
  for (const cluster of clusters) {
    if (cluster.length === 1) { out.push({ ...cluster[0], angle: cluster[0].p.longitude, r: rPlanet, fanned: false }); continue; }
    const centre = mid(cluster);
    cluster.forEach((item, i) => out.push({ ...item, angle: centre + (i - (cluster.length - 1) / 2) * FAN_STEP, r: rPlanet - (i % 2) * FAN_DROP, fanned: true }));
  }
  return out;
}

// --- Bodygraph (§4) ---------------------------------------------------------------------

function centreShape(centre) {
  const { x, y, shape } = centre;
  const s = 28;
  const pts = {
    "tri-up": [[x, y - s], [x - s, y + s * 0.7], [x + s, y + s * 0.7]],
    "tri-down": [[x - s, y - s * 0.7], [x + s, y - s * 0.7], [x, y + s]],
    "tri-heart": [[x - 18, y - 16], [x + 22, y - 8], [x + 4, y + 20]],
    "tri-left": [[x + 26, y - 30], [x + 26, y + 30], [x - 32, y]],
    "tri-right": [[x - 26, y - 30], [x - 26, y + 30], [x + 32, y]],
    diamond: [[x, y - 34], [x + 34, y], [x, y + 34], [x - 34, y]],
    square: [[x - 30, y - 30], [x + 30, y - 30], [x + 30, y + 30], [x - 30, y + 30]],
  }[shape];
  return svg("polygon", { points: pts.map((p) => p.join(",")).join(" ") });
}

const GATE_FONT = 10;   // SVG units; the 300-wide graph is drawn at 340 px, so ≈ 11.3 px on screen

function gateNumeral(gate, x, y, cls) {
  // A solid backing under every numeral so the channel line never strikes through it.
  const w = String(gate).length * GATE_FONT * 0.62 + 4, h = GATE_FONT + 2;
  return [
    svg("rect", { class: "joh-gate-bg", x: x - w / 2, y: y - h / 2, width: w, height: h, rx: 2 }),
    svg("text", { class: `joh-svg-num is-gate joh-gate ${cls}`, x, y: y + GATE_FONT * 0.36, "text-anchor": "middle", "data-gate": gate }, gate),
  ];
}

function drawBodygraph(hd) {
  const root = svg("svg", { class: "joh-bodygraph", viewBox: "0 0 300 520", role: "img", "aria-label": `Bodygraph: ${hd.type}, ${hd.authority} authority, profile ${hd.profile}` });
  const byGate = Object.fromEntries(CENTRES.flatMap((c) => c.gates.map((g) => [g, c])));
  const sides = hd.gates || {};
  const active = new Map((hd.channels || []).map((ch) => [ch.gates.join("-"), ch]));
  const pairKey = ([a, b]) => [byGate[a].name, byGate[b].name].sort().join("|");
  const pairTotal = {};
  for (const ch of CHANNELS) pairTotal[pairKey(ch)] = (pairTotal[pairKey(ch)] || 0) + 1;
  const pairIndex = {};
  for (const [a, b] of CHANNELS) {
    const ca = byGate[a], cb = byGate[b];
    const pair = pairKey([a, b]);
    const k = pairIndex[pair] = (pairIndex[pair] || 0) + 1;
    const offset = (k - (pairTotal[pair] + 1) / 2) * 15;   // parallel channels fan out symmetrically
    const dx = cb.x - ca.x, dy = cb.y - ca.y, len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len * offset, ny = dx / len * offset;
    const x1 = ca.x + nx, y1 = ca.y + ny, x2 = cb.x + nx, y2 = cb.y + ny;
    const ch = active.get(`${a}-${b}`);
    const sideOf = (gate) => sides[String(gate)] || [];
    const gateClass = (gate) => { const s = sideOf(gate); return s.length === 2 ? "is-both" : s[0] === "design" ? "is-design" : s[0] === "personality" ? "is-personality" : ""; };
    const g = svg("g", { class: `joh-channel${ch ? " is-active" : ""}`, "data-channel": `${a}-${b}` });
    // Each half is coloured by its own gate's activation, so a half-channel shows as a hanging gate.
    const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
    g.append(svg("line", { class: `joh-half ${gateClass(a)}`, x1, y1, x2: mx, y2: my }), svg("line", { class: `joh-half ${gateClass(b)}`, x1: mx, y1: my, x2, y2 }));
    if (ch) g.append(svg("line", { class: "joh-channel-core", x1, y1, x2, y2 }));
    // Numerals sit a fixed way out from each centre (just past its edge on the long channels),
    // and parallel channels stagger theirs along the line so neighbours never share a row.
    const reach = Math.min(36, 0.3 * len) + (k - (pairTotal[pair] + 1) / 2) * 8;
    const ux = (x2 - x1) / len, uy = (y2 - y1) / len;
    g.append(...gateNumeral(a, x1 + ux * reach, y1 + uy * reach, gateClass(a)),
      ...gateNumeral(b, x2 - ux * reach, y2 - uy * reach, gateClass(b)));
    root.append(g);
  }
  const defined = new Set(hd.defined_centres || []);
  for (const centre of CENTRES) {
    const g = svg("g", { class: `joh-centre${defined.has(centre.name) ? " is-defined" : ""}`, "data-centre": centre.name });
    g.append(centreShape(centre), svg("title", {}, `${centre.name}: ${defined.has(centre.name) ? "defined" : "open"}`));
    root.append(g);
  }
  return root;
}

async function renderBodygraph(panel, profile) {
  const hd = profile.profile.humandesign;
  const activationList = (side) => el("ul", { class: "list joh-activations", dataset: { side } }, HD_BODIES.map(([key, name]) => {
    const a = hd[side][key];
    return el("li", { class: "list-item" }, el("div", { class: "list-item-title" }, el("span", {}, name), el("span", { class: "num joh-num" }, a.key)));
  }));
  panel.append(
    el("p", { class: "meta" }, "Defined centres are washed gold; gold channels come from your birth (personality), rose from the design moment 88° of Sun before it, both together gold with a rose core. Gate numbers sit at each channel end."),
    el("div", { class: "joh-body-layout" },
      el("div", { class: "joh-body-box" }, drawBodygraph(hd),
        el("ul", { class: "joh-legend", "aria-label": "Legend" },
          el("li", { class: "is-personality" }, "Personality (birth)"), el("li", { class: "is-design" }, "Design (88° before)"), el("li", { class: "is-both" }, "Both"), el("li", { class: "is-defined" }, "Defined centre"))),
      el("div", { class: "stack" },
        card("Foundation", kv([["Type", el("span", { id: "joh-body-type" }, hd.type)], ["Strategy", hd.strategy], ["Authority", hd.authority], ["Profile", el("span", { class: "num joh-num" }, hd.profile)],
          ["Definition", hd.definition], ["Incarnation cross", hd.incarnation_cross.label], ["Not-self theme", hd.not_self_theme], ["Signature", hd.signature]])),
        el("div", { class: "grid joh-two" },
          card("Design", activationList("design")), card("Personality", activationList("personality"))))));
}

// --- Gene Keys (§4) --------------------------------------------------------------------------

function drawHologenetic(spheres) {
  const by = Object.fromEntries(spheres.map((s) => [s.sphere, s]));
  const root = svg("svg", { class: "joh-hologenetic", viewBox: "0 0 300 440", role: "img", "aria-label": "Hologenetic profile diagram" });
  for (const [a, b] of GK_EDGES) {
    const [x1, y1] = GK_NODES[a], [x2, y2] = GK_NODES[b];
    root.append(svg("line", { class: "joh-hair", x1, y1, x2, y2 }));
  }
  for (const [name, [x, y]] of Object.entries(GK_NODES)) {
    const s = by[name];
    if (!s) continue;
    const g = svg("g", { class: "joh-gk-node", "data-sphere": name });
    g.append(svg("circle", { class: "joh-node is-ring", cx: x, cy: y, r: 17 }),
      svg("text", { class: "joh-svg-num", x, y: y + 4, "text-anchor": "middle" }, s.key),
      svg("text", { class: "joh-svg-label", x, y: y + 32, "text-anchor": "middle" }, name.toUpperCase()),
      svg("title", {}, `${name} ${s.key_line} — ${s.shadow} → ${s.gift} → ${s.siddhi}`));
    root.append(g);
  }
  return root;
}

function sphereRow(s) {
  return el("li", { class: "joh-sphere", dataset: { sphere: s.sphere } },
    el("div", { class: "joh-sphere-head" }, label(s.sphere), el("span", { class: "num joh-num is-gold", dataset: { keyLine: s.key_line } }, s.key_line),
      el("span", { class: "meta" }, `line ${s.line} · ${s.line_theme} · partner ${s.programming_partner}`)),
    el("div", { class: "joh-spectrum", "aria-label": `Shadow ${s.shadow}, Gift ${s.gift}, Siddhi ${s.siddhi}` },
      el("span", { class: "is-shadow" }, s.shadow), el("span", { class: "joh-arrow", "aria-hidden": "true" }, "→"), el("span", { class: "is-gift" }, s.gift), el("span", { class: "joh-arrow", "aria-hidden": "true" }, "→"), el("span", { class: "is-siddhi" }, s.siddhi)),
    el("p", { class: "joh-contemplation" }, s.contemplation));
}

async function renderGeneKeys(panel, profile) {
  const gk = profile.profile.genekeys;
  panel.append(
    el("p", { class: "meta" }, "Each sphere is one activation of your bodygraph read as a Gene Key: the key number, its line, and the Shadow → Gift → Siddhi spectrum. Contemplate rather than conclude."),
    el("div", { class: "joh-gk-layout" },
      el("div", { class: "joh-gk-diagram" }, drawHologenetic(gk.spheres)),
      el("div", { class: "stack" },
        SEQUENCES.map(([id, title, lead]) => card(title, el("p", { class: "meta" }, lead), el("ul", { class: "joh-spheres" }, gk.sequences[id].map(sphereRow)))),
        card("Further spheres", el("ul", { class: "joh-spheres" }, gk.sequences.further.map(sphereRow))),
        el("p", { class: "meta" }, el("a", { href: "https://genekeys.com/", target: "_blank", rel: "noopener" }, "Contemplate this key at genekeys.com"), " — the official charts there are tropical; use the zodiac toggle below to compare."))));
}

// --- Enneagram (§4) -----------------------------------------------------------------------------

function typeCardNode(cardData, extra) {
  return el("section", { class: "panel joh-card joh-type-card", id: "joh-type-card" },
    el("h2", { class: "joh-card-title" }, el("span", { class: "num joh-num is-gold" }, cardData.label), ` · ${cardData.name}`),
    kv([["Core fear", cardData.core_fear], ["Core desire", cardData.core_desire], ["Basic proposition", cardData.basic_proposition],
      ["Arrows", `growth → ${cardData.growth_arrow} ${ENNEAGRAM_NAMES[cardData.growth_arrow]} · stress → ${cardData.stress_arrow} ${ENNEAGRAM_NAMES[cardData.stress_arrow]}`],
      ["Keywords", cardData.keywords.join(" · ")]]), extra);
}

function scoreBars(scores) {
  const max = Math.max(1, ...Object.values(scores));
  return el("ol", { class: "joh-bars", "aria-label": "Score per type" }, Object.entries(scores).map(([t, v]) => el("li", { class: "joh-bar", dataset: { type: t } },
    el("span", { class: "num joh-num" }, t), el("span", { class: "joh-bar-track" }, el("span", { class: "joh-bar-fill", "data-pct": Math.round(100 * v / max) })), el("span", { class: "num joh-num" }, v))));
}

function testKey(seed) { return `dm:joh:enneagram:${seed}`; }

async function renderEnneagram(panel, profile, ctx) {
  const enn = profile.enneagram;
  const notice = el("div", { class: "stack", id: "joh-enneagram-notice" });
  panel.append(el("p", { class: "meta" }, "Nine patterns of attention. Choose your type directly, or answer 45 short statements — the result is a suggestion, and you decide."), notice);
  if (state.enneagramResult) { renderResult(panel, state.enneagramResult, ctx, notice); return; }
  if (state.enneagramMode === "test") { await renderTest(panel, ctx, notice); return; }
  if (state.enneagramMode === null) {
    // A half-finished attempt (autosaved under its seed) resumes on reload instead of restarting.
    let pending = null;
    try { pending = await api.johEnneagramTest(); } catch { pending = null; }
    if (pending && localStorage.getItem(testKey(pending.seed))) { state.enneagramMode = "test"; await renderTest(panel, ctx, notice, pending); return; }
  }
  if (state.enneagramMode === "choose" || (!enn && state.enneagramMode === null)) {
    panel.append(el("div", { class: "form-actions joh-enn-start" },
      el("button", { class: "pill-btn gold", type: "button", id: "joh-enn-know", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "know"; ctx.route(); } }, "I know my type"),
      el("button", { class: "pill-btn", type: "button", id: "joh-enn-test", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "test"; ctx.route(); } }, "Take the test (about 8 minutes)")));
    if (enn) panel.append(typeCardNode(enn.card));
    return;
  }
  if (state.enneagramMode === "know") {
    const typeSelect = field("Type", "type", { options: Object.entries(ENNEAGRAM_NAMES).map(([n, name]) => ({ value: n, label: `${n} — ${name}` })) }, "select");
    const wingSelect = field("Wing (optional)", "wing", { options: [{ value: "", label: "none" }] }, "select");
    const instinct = field("Instinct (optional)", "instinct", { options: [{ value: "", label: "not sure" }, { value: "sp", label: "sp — self-preservation" }, { value: "so", label: "so — social" }, { value: "sx", label: "sx — one-to-one" }] }, "select");
    const refreshWings = () => {
      const n = Number.parseInt(typeSelect.querySelector("select").value, 10);
      const low = ((n - 2) % 9 + 9) % 9 + 1, high = n % 9 + 1;
      wingSelect.querySelector("select").replaceChildren(el("option", { value: "" }, "none"), el("option", { value: String(low) }, `${n}w${low}`), el("option", { value: String(high) }, `${n}w${high}`));
    };
    typeSelect.querySelector("select").addEventListener("change", refreshWings);
    refreshWings();
    const chooser = form([el("div", { class: "form-row is-inline" }, typeSelect, wingSelect, instinct)], "Save my type", async (data) => {
      await api.johSetEnneagram({ type: Number.parseInt(data.type, 10), wing: data.wing ? Number.parseInt(data.wing, 10) : null, instinct: data.instinct || null, source: "entered" });
      state.enneagramMode = null;
      window.dispatchEvent(new CustomEvent("dm:joh-changed"));
      await ctx.route();
    });
    chooser.id = "joh-enn-form";
    panel.append(chooser, el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", onclick: () => { state.enneagramMode = null; ctx.route(); } }, "Cancel")));
    return;
  }
  // Set: the type card + Retake / Choose differently.
  panel.append(typeCardNode(enn.card, el("div", { class: "form-actions" },
    el("button", { class: "pill-btn", type: "button", id: "joh-enn-retake", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "test"; ctx.route(); } }, "Retake the test"),
    el("button", { class: "pill-btn", type: "button", id: "joh-enn-change", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "choose"; ctx.route(); } }, "Choose differently"))),
    el("p", { class: "meta" }, `Source: ${enn.source === "test" ? "the 45-statement test, confirmed by you" : "entered by you"}.`));
}

async function renderTest(panel, ctx, notice, loaded = null) {
  let test = loaded;
  try { if (!test) test = await api.johEnneagramTest(); } catch (error) { notice.replaceChildren(alertBox("error", `Could not load the test: ${error.message}`)); return; }
  const key = testKey(test.seed);
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(key) || "{}"); } catch { saved = {}; }
  const answers = Array.isArray(saved.answers) && saved.answers.length === 45 ? saved.answers : Array(45).fill(null);
  let index = Number.isInteger(saved.index) ? Math.min(44, Math.max(0, saved.index)) : answers.findIndex((a) => a === null);
  if (index < 0) index = 44;
  const box = el("section", { class: "panel joh-card joh-test", id: "joh-test", dataset: { seed: String(test.seed) } });
  const remember = () => { try { localStorage.setItem(key, JSON.stringify({ answers, index })); } catch { /* autosave is a convenience */ } };
  const draw = () => {
    const statement = test.statements[index];
    const answered = answers.filter((a) => a !== null).length;
    box.replaceChildren(
      el("ol", { class: "joh-progress", "aria-label": `${answered} of 45 answered` }, test.statements.map((s, i) => el("li", { class: `joh-progress-dot${answers[i] !== null ? " is-done" : ""}${i === index ? " is-current" : ""}`, "aria-current": i === index ? "step" : null }))),
      el("p", { class: "meta" }, el("span", { class: "num joh-num" }, index + 1), " of 45"),
      el("p", { class: "joh-statement", id: "joh-statement", dataset: { statementId: statement.id } }, statement.text),
      el("div", { class: "joh-scale", role: "radiogroup", "aria-label": "How much is this like you?" }, test.scale.map((v, i) => el("button", {
        class: `joh-scale-dot${answers[index] === v ? " is-chosen" : ""}`, type: "button", role: "radio", "aria-checked": String(answers[index] === v), dataset: { value: String(v), write: "true" }, title: SCALE_LABELS[i], "aria-label": `${v} — ${SCALE_LABELS[i]}`,
        onclick: () => { answers[index] = v; if (index < 44) index += 1; remember(); draw(); },
      }, el("span", { class: "joh-dot-mark", "aria-hidden": "true" }), el("span", { class: "joh-dot-text" }, String(v))))),
      el("div", { class: "joh-scale-ends meta", "aria-hidden": "true" }, el("span", {}, SCALE_LABELS[0]), el("span", {}, SCALE_LABELS[4])),
      el("div", { class: "form-actions" },
        el("button", { class: "btn is-small", type: "button", id: "joh-test-back", disabled: index === 0 || null, onclick: () => { index = Math.max(0, index - 1); remember(); draw(); } }, "Back"),
        el("button", { class: "btn is-small", type: "button", id: "joh-test-next", disabled: answers[index] === null || index === 44 || null, onclick: () => { index = Math.min(44, index + 1); remember(); draw(); } }, "Next"),
        answers.every((a) => a !== null) ? el("button", { class: "btn is-primary is-small", type: "button", id: "joh-test-submit", dataset: { write: "true" }, onclick: async () => {
          try {
            state.enneagramResult = await api.johSubmitEnneagramTest(test.seed, answers);
            try { localStorage.removeItem(key); } catch { /* fine */ }
            state.enneagramMode = null;
            await ctx.route();
          } catch (error) { notice.replaceChildren(alertBox("error", `Could not score the test: ${error.message}`, error.reasons)); }
        } }, "See my result") : null,
        el("button", { class: "btn is-quiet is-small", type: "button", id: "joh-test-cancel", onclick: () => { state.enneagramMode = null; ctx.route(); } }, "Stop for now")));
    applyReadOnly(box);
  };
  draw();
  panel.append(box);
}

function renderResult(panel, result, ctx, notice) {
  const chosen = { type: result.type, wing: result.wing };
  const chooser = el("div", { class: "form-actions" },
    el("button", { class: "pill-btn gold", type: "button", id: "joh-result-confirm", dataset: { write: "true" }, onclick: async () => {
      try {
        await api.johSetEnneagram({ type: chosen.type, wing: chosen.wing, instinct: null, source: "test" });
        state.enneagramResult = null;
        window.dispatchEvent(new CustomEvent("dm:joh-changed"));
        await ctx.route();
      } catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); }
    } }, "This is right"),
    el("button", { class: "pill-btn", type: "button", id: "joh-result-choose", dataset: { write: "true" }, onclick: () => { state.enneagramResult = null; state.enneagramMode = "know"; ctx.route(); } }, "Choose differently"),
    el("button", { class: "pill-btn", type: "button", id: "joh-result-retake", dataset: { write: "true" }, onclick: () => { state.enneagramResult = null; state.enneagramMode = "test"; ctx.route(); } }, "Retake"));
  panel.append(card("Your scores", scoreBars(result.scores), el("p", { class: "meta" }, "The highest total is the suggested type; its higher-scoring neighbour is the wing. If this doesn't ring true, choose your type directly.")),
    typeCardNode(result.card, chooser));
  for (const fill of panel.querySelectorAll(".joh-bar-fill")) fill.style.width = `${fill.dataset.pct}%`;
}

// --- Compass (§4, §5) -------------------------------------------------------------------------

async function renderCompass(panel, profile, ctx) {
  const [agents, history] = await Promise.all([api.agents().catch(() => []), api.johGuidanceHistory(20).catch(() => [])]);
  const agent = agents.find((a) => a.id === "pi-chief-of-staff") || null;
  const configured = Boolean(agent && agent.runner_status && agent.runner_status.configured);
  const policy = agent?.model_policy || {};
  const last = history[0] || null;
  const notice = el("div", { class: "stack", id: "joh-compass-notice" });
  const answer = el("div", { class: "stack", id: "joh-compass-answer" });
  panel.append(el("p", { class: "joh-greeting joh-compass-lead" }, "Ask with your whole chart in the room."));
  if (!configured) {
    panel.append(el("section", { class: "panel joh-card", id: "joh-compass-unconfigured" },
      el("h2", { class: "joh-card-title" }, "The Compass is not configured on this server"),
      el("p", { class: "meta" }, `It answers through the ${agent ? agent.name : "pi-chief-of-staff"} role's model policy. Until the items below are set, there is nothing to send to; your profile pages still work.`),
      reasonsList((agent?.runner_status?.problems || ["agent definition pi-chief-of-staff not found"]).map((p) => `not configured: ${p}`))));
  } else {
    const kindTabs = el("div", { class: "tabs joh-kind-tabs", role: "tablist", "aria-label": "What to ask" }, COMPASS_KINDS.map(([id, text]) => el("button", {
      class: "tab", type: "button", role: "tab", dataset: { kind: id }, "aria-selected": String(state.compassKind === id), onclick: () => { state.compassKind = id; ctx.route(); } }, text)));
    const kind = state.compassKind;
    const fields = kind === "email"
      ? [field("The email (paste it here)", "input_text", { required: true, rows: "7" }, "textarea"), field("What you want to say, and any constraints (optional)", "intent", { rows: "2" }, "textarea")]
      : kind === "decision"
        ? [field("The decision, the options and the stakes", "input_text", { required: true, rows: "7" }, "textarea"), field("Horizon", "horizon", { options: HORIZONS.map(([v, l]) => ({ value: v, label: l })) }, "select")]
        : [field("Your question", "input_text", { required: true, rows: "5" }, "textarea")];
    const ask = form(fields, "Ask the Compass", async (data) => {
      answer.replaceChildren(el("p", { class: "empty" }, "Asking…"));
      const extra = kind === "email" ? { intent: data.intent || "" } : kind === "decision" ? { horizon: data.horizon } : {};
      try {
        const reply = await api.johGuidance({ kind, input_text: data.input_text, extra });
        answer.replaceChildren(answerCard(reply));
        ctx.route();
      } catch (error) {
        answer.replaceChildren();
        throw error;
      }
    });
    ask.id = "joh-compass-form";
    panel.append(kindTabs, el("section", { class: "panel joh-card" }, ask),
      el("p", { class: "meta joh-money", id: "joh-compass-money" },
        `Cap per call ${policy.max_cost_minor ?? "—"} ${policy.currency || "USD"} minor units (${agent.name}, ${policy.model}) · last cost ${last && last.cost_minor !== null && last.cost_minor !== undefined ? `${last.cost_minor} ${last.currency || ""}` : "—"}`));
  }
  panel.append(notice, answer);
  if (last && configured) answer.append(answerCard(last));
  panel.append(card("Past answers", history.length
    ? el("ul", { class: "list", id: "joh-history" }, history.map((g) => el("li", { class: "list-item joh-history-item", dataset: { kind: g.kind } },
      el("div", { class: "list-item-title" }, el("span", {}, (g.output_text || "").split("\n").map((l) => l.replace(/^#+\s*/, "").trim()).find(Boolean) || "(empty answer)"), pill("not_applicable", g.kind)),
      el("div", { class: "meta" }, `${when(g.created_at)}${g.model ? ` · ${g.model}` : ""}${g.cost_minor !== null && g.cost_minor !== undefined ? ` · ${g.cost_minor} ${g.currency || ""}` : ""}`))))
    : empty("No answers yet. Every answer is kept here.")));
}

function answerCard(reply) {
  return el("section", { class: "panel joh-card joh-answer", id: "joh-answer", dataset: { kind: reply.kind } },
    el("ul", { class: "joh-strip", "aria-label": "Chart in the room" }, el("li", { class: "label" }, "Chart in the room"), (reply.chart_in_the_room || []).map((fact) => el("li", { class: "joh-strip-item" }, fact))),
    renderMarkdown(reply.output_text),
    el("p", { class: "meta" }, `${when(reply.created_at)}${reply.provider ? ` · ${reply.provider}` : ""}${reply.model ? ` / ${reply.model}` : ""}${reply.cost_minor !== null && reply.cost_minor !== undefined ? ` · cost ${reply.cost_minor} ${reply.currency || ""}` : ""}`));
}
