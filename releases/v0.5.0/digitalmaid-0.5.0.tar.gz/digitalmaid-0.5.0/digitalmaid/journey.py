"""JOH — Journey of Humanity profile records (migration 13).

One profile per (scope, user): birth data + the full engine output (both zodiacs) as
JSON, the enneagram choice, the test attempts and every Compass answer. ``computed`` is
recomputed when birth data changes or when a stored ``engine_version`` is older than the
engine on read. Nothing here talks to the network.
"""

import json

from digitalmaid.db import new_id, now
from digitalmaid.joh import ENGINE_VERSION, compute_profile
from digitalmaid.joh.enneagram import score, validate_entry
from digitalmaid.joh.sidereal import check_zodiac

ENNEAGRAM_SOURCES = ("entered", "test")
GUIDANCE_KINDS = ("email", "decision", "question")
_JOH_PREF_SCOPE = "user:"
_JOH_PREF_AREA = "joh"
_PROFILE_COLUMNS = ("id, scope_id, user_id, birth_date, birth_time, time_known, place_display,"
                    " country_code, lat, lon, timezone, zodiac, enneagram_type, enneagram_wing,"
                    " enneagram_instinct, enneagram_source, computed, engine_version,"
                    " created_at, updated_at, revision")


def _text_or_none(value, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{name} must be a string")
    value = value.strip()
    return value or None


class Journey:
    """Mixin; expects ``self._db`` and ``self.scope_id``."""

    # -- the per-user switch --------------------------------------------------------------
    # Kept in the existing preferences table (no migration): one row per *user*, not per
    # scope — the section is personal — under scope_id "user:<id>", area "joh".

    def get_joh_enabled(self, user_id: str) -> bool:
        row = self._db.query_one(
            "SELECT widgets FROM widget_preferences WHERE scope_id = ? AND area = ?",
            (_JOH_PREF_SCOPE + user_id, _JOH_PREF_AREA))
        if row is None:
            return False
        try:
            return bool(json.loads(row["widgets"]).get("enabled"))
        except (ValueError, AttributeError):
            return False

    def set_joh_enabled(self, user_id: str, enabled: bool, actor: str) -> bool:
        if not isinstance(user_id, str) or not user_id.strip():
            raise ValueError("user_id required")
        if type(enabled) is not bool:
            raise ValueError("enabled must be true or false")
        key, stamp = _JOH_PREF_SCOPE + user_id, now()
        payload = json.dumps({"enabled": enabled})
        with self._db.transaction() as cur:
            existing = cur.execute(
                "SELECT id, revision FROM widget_preferences WHERE scope_id = ? AND area = ?",
                (key, _JOH_PREF_AREA)).fetchone()
            if existing is None:
                pref_id = new_id()
                cur.execute(
                    "INSERT INTO widget_preferences (id, scope_id, area, widgets, created_at,"
                    " updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (pref_id, key, _JOH_PREF_AREA, payload, stamp, stamp))
                self._db.audit(cur, "joh_setting", pref_id, "create", actor,
                               {"enabled": enabled, "user_id": user_id}, scope_id=self.scope_id)
            else:
                self._db.update_with_revision(
                    "widget_preferences", existing["id"], key, existing["revision"],
                    {"widgets": payload}, actor=actor, action="set_enabled",
                    details={"enabled": enabled, "user_id": user_id}, cur=cur,
                    entity_type="joh_setting")
        return enabled

    def record_joh_task_request(self, task_id: str, actor: str) -> str:
        """Audit that a task was created with "Consult my Journey profile" ticked."""
        with self._db.transaction() as cur:
            return self._db.audit(cur, "task", task_id, "joh_requested", actor,
                                  {"inputs": {"joh": "true"}}, scope_id=self.scope_id)

    # -- profile ------------------------------------------------------------------------

    def _joh_row(self, row) -> dict:
        record = dict(row)
        record["time_known"] = bool(record["time_known"])
        record["computed"] = json.loads(record["computed"])
        return record

    def _joh_profile_row(self, user_id: str):
        return self._db.query_one(
            f"SELECT {_PROFILE_COLUMNS} FROM joh_profiles WHERE scope_id = ? AND user_id = ?",
            (self.scope_id, user_id))

    def _require_joh_profile_id(self, profile_id: str) -> dict:
        row = self._db.query_one(
            f"SELECT {_PROFILE_COLUMNS} FROM joh_profiles WHERE id = ? AND scope_id = ?",
            (profile_id, self.scope_id))
        if row is None:
            raise LookupError(f"JOH profile {profile_id!r} not found in scope {self.scope_id!r}")
        return self._joh_row(row)

    def _require_joh_profile(self, user_id: str) -> dict:
        row = self._joh_profile_row(user_id)
        if row is None:
            raise LookupError(f"no JOH profile for user {user_id!r} in scope {self.scope_id!r}")
        return self._joh_row(row)

    def save_joh_profile(self, user_id: str, birth: dict, zodiac: str | None = None,
                         actor: str = "") -> dict:
        """Create or replace the birth data of the user's profile; recomputes everything."""
        if not isinstance(user_id, str) or not user_id.strip():
            raise ValueError("user_id required")
        if zodiac is not None:
            check_zodiac(zodiac)
        place = _text_or_none(birth.get("place_display"), "place_display")
        country = _text_or_none(birth.get("country_code"), "country_code")
        computed = compute_profile(birth)          # validates date/time/zone/lat/lon
        info = computed["birth"]
        fields = {
            "birth_date": info["date"], "birth_time": info["time"],
            "time_known": int(info["time_known"]), "place_display": place,
            "country_code": country.lower() if country else None,
            "lat": info["lat"], "lon": info["lon"], "timezone": info["timezone"],
            "computed": json.dumps(computed, sort_keys=True), "engine_version": ENGINE_VERSION,
        }
        with self._db.transaction() as cur:
            existing = self._joh_profile_row(user_id)
            if existing is None:
                profile_id, stamp = new_id(), now()
                cur.execute(
                    "INSERT INTO joh_profiles (id, scope_id, user_id, birth_date, birth_time,"
                    " time_known, place_display, country_code, lat, lon, timezone, zodiac,"
                    " computed, engine_version, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (profile_id, self.scope_id, user_id, fields["birth_date"], fields["birth_time"],
                     fields["time_known"], place, fields["country_code"], fields["lat"],
                     fields["lon"], fields["timezone"], zodiac or "sidereal", fields["computed"],
                     ENGINE_VERSION, stamp, stamp))
                self._db.audit(cur, "joh_profile", profile_id, "create", actor,
                               {"zodiac": zodiac or "sidereal", "time_known": info["time_known"]},
                               scope_id=self.scope_id)
            else:
                if zodiac is not None:
                    fields["zodiac"] = zodiac
                self._db.update_with_revision(
                    "joh_profiles", existing["id"], self.scope_id, existing["revision"], fields,
                    actor=actor, action="update_birth",
                    details={"time_known": info["time_known"], "engine_version": ENGINE_VERSION},
                    cur=cur, entity_type="joh_profile")
        return self.get_joh_profile(user_id)

    def get_joh_profile(self, user_id: str) -> dict | None:
        """The user's profile, recomputed first when it was stored by an older engine."""
        row = self._joh_profile_row(user_id)
        if row is None:
            return None
        profile = self._joh_row(row)
        if profile["engine_version"] < ENGINE_VERSION:
            computed = compute_profile({
                "birth_date": profile["birth_date"], "birth_time": profile["birth_time"],
                "timezone": profile["timezone"], "lat": profile["lat"], "lon": profile["lon"]})
            self._db.update_with_revision(
                "joh_profiles", profile["id"], self.scope_id, profile["revision"],
                {"computed": json.dumps(computed, sort_keys=True), "engine_version": ENGINE_VERSION},
                actor="engine", action="recompute",
                details={"from": profile["engine_version"], "to": ENGINE_VERSION},
                entity_type="joh_profile")
            profile = self._joh_row(self._joh_profile_row(user_id))
        return profile

    def set_joh_zodiac(self, user_id: str, zodiac: str, actor: str) -> dict:
        check_zodiac(zodiac)
        profile = self._require_joh_profile(user_id)
        self._db.update_with_revision(
            "joh_profiles", profile["id"], self.scope_id, profile["revision"], {"zodiac": zodiac},
            actor=actor, action="set_zodiac", details={"zodiac": zodiac}, entity_type="joh_profile")
        return self.get_joh_profile(user_id)

    def set_joh_enneagram(self, user_id: str, number: int, wing: int | None, instinct: str | None,
                          source: str, actor: str) -> dict:
        entry = validate_entry(number, wing, instinct)
        if source not in ENNEAGRAM_SOURCES:
            raise ValueError(f"source must be one of {ENNEAGRAM_SOURCES}, got {source!r}")
        profile = self._require_joh_profile(user_id)
        self._db.update_with_revision(
            "joh_profiles", profile["id"], self.scope_id, profile["revision"],
            {"enneagram_type": entry["type"], "enneagram_wing": entry["wing"],
             "enneagram_instinct": entry["instinct"], "enneagram_source": source},
            actor=actor, action="set_enneagram", details={**entry, "source": source},
            entity_type="joh_profile")
        return self.get_joh_profile(user_id)

    def delete_joh_profile(self, user_id: str, actor: str) -> bool:
        """Remove the profile with its attempts and guidance; False when there was none."""
        row = self._joh_profile_row(user_id)
        if row is None:
            return False
        profile_id = row["id"]
        with self._db.transaction() as cur:
            cur.execute("DELETE FROM joh_guidance WHERE profile_id = ?", (profile_id,))
            cur.execute("DELETE FROM joh_enneagram_attempts WHERE profile_id = ?", (profile_id,))
            cur.execute("DELETE FROM joh_profiles WHERE id = ? AND scope_id = ?",
                        (profile_id, self.scope_id))
            self._db.audit(cur, "joh_profile", profile_id, "delete", actor, scope_id=self.scope_id)
        return True

    # -- enneagram attempts ---------------------------------------------------------------

    def record_joh_enneagram_attempt(self, profile_id: str, seed: int, answers: list) -> dict:
        self._require_joh_profile_id(profile_id)
        result = score(answers, seed)             # validates seed and the 45 answers
        attempt_id, stamp = new_id(), now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO joh_enneagram_attempts (id, profile_id, seed, answers, scores, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (attempt_id, profile_id, seed, json.dumps(result["answers"]),
                 json.dumps(result["scores"], sort_keys=True), stamp))
            self._db.audit(cur, "joh_profile", profile_id, "enneagram_attempt", "user",
                           {"attempt_id": attempt_id, "type": result["type"],
                            "wing": result["wing"]}, scope_id=self.scope_id)
        return {"id": attempt_id, "profile_id": profile_id, "created_at": stamp, **result}

    def list_joh_enneagram_attempts(self, profile_id: str) -> list[dict]:
        self._require_joh_profile_id(profile_id)
        rows = self._db.query(
            "SELECT id, profile_id, seed, answers, scores, created_at FROM joh_enneagram_attempts"
            " WHERE profile_id = ? ORDER BY created_at DESC, rowid DESC", (profile_id,))
        out = []
        for row in rows:
            record = dict(row)
            record["answers"] = json.loads(record["answers"])
            record["scores"] = json.loads(record["scores"])
            out.append(record)
        return out

    # -- guidance -------------------------------------------------------------------------

    def add_joh_guidance(self, profile_id: str, kind: str, input_text: str, output_text: str,
                         model: str | None, provider: str | None, cost_minor: int | None,
                         currency: str | None) -> dict:
        if kind not in GUIDANCE_KINDS:
            raise ValueError(f"kind must be one of {GUIDANCE_KINDS}, got {kind!r}")
        if not isinstance(input_text, str) or not input_text.strip():
            raise ValueError("input_text must be a non-empty string")
        if not isinstance(output_text, str):
            raise ValueError("output_text must be a string")
        if cost_minor is not None and (type(cost_minor) is not int or cost_minor < 0):
            raise ValueError("cost_minor must be a non-negative integer or None")
        self._require_joh_profile_id(profile_id)
        row_id, stamp = new_id(), now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO joh_guidance (id, profile_id, kind, input_text, output_text, model,"
                " provider, cost_minor, currency, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (row_id, profile_id, kind, input_text, output_text, model, provider, cost_minor,
                 currency, stamp))
            self._db.audit(cur, "joh_profile", profile_id, "guidance", "user",
                           {"guidance_id": row_id, "kind": kind, "model": model,
                            "provider": provider, "cost_minor": cost_minor},
                           scope_id=self.scope_id)
        return dict(self._db.query_one("SELECT * FROM joh_guidance WHERE id = ?", (row_id,)))

    def list_joh_guidance(self, profile_id: str, limit: int = 20) -> list[dict]:
        self._require_joh_profile_id(profile_id)
        if type(limit) is not int or not (1 <= limit <= 200):
            raise ValueError("limit must be an integer 1..200")
        return [dict(r) for r in self._db.query(
            "SELECT * FROM joh_guidance WHERE profile_id = ?"
            " ORDER BY created_at DESC, rowid DESC LIMIT ?", (profile_id, limit))]
