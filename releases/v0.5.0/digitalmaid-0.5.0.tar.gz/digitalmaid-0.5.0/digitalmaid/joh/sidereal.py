"""Lahiri ayanamsa and the tropical -> sidereal shift (owner decision: sidereal by default).

Sidereal longitudes refer to the *mean* ecliptic of date, as the oracle used for the
fixtures does: apparent (tropical) longitude - nutation in longitude - ayanamsa.
Without the nutation term the Sun misses the oracle by up to ~0.005°, more than the
±0.002° the brief allows.
"""

import math

from digitalmaid.joh.timeutil import julian_centuries

ZODIACS = ("sidereal", "tropical")


def ayanamsa_lahiri(jd_ut: float) -> float:
    """Lahiri (Chitrapaksha) ayanamsa in degrees at ``jd_ut``."""
    t = julian_centuries(jd_ut)
    return 23.85709235 + 1.39688796 * t + 0.00030709 * t * t


def nutation_longitude(jd_ut: float) -> float:
    """Nutation in longitude Δψ in degrees (four-term IAU 1980 abridgement, ~0.5″)."""
    t = julian_centuries(jd_ut)
    omega = math.radians((125.04452 - 1934.136261 * t) % 360.0)
    sun = math.radians((280.4665 + 36000.7698 * t) % 360.0)
    moon = math.radians((218.3165 + 481267.8813 * t) % 360.0)
    arcsec = (-17.20 * math.sin(omega) - 1.32 * math.sin(2 * sun)
              - 0.23 * math.sin(2 * moon) + 0.21 * math.sin(2 * omega))
    return arcsec / 3600.0


def to_sidereal(tropical_longitude: float, jd_ut: float) -> float:
    return (tropical_longitude - nutation_longitude(jd_ut) - ayanamsa_lahiri(jd_ut)) % 360.0


def check_zodiac(value: str) -> str:
    if value not in ZODIACS:
        raise ValueError(f"zodiac must be one of {ZODIACS}, got {value!r}")
    return value
