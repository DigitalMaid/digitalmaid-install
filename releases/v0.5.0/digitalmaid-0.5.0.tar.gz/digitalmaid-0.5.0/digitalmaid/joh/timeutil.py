"""Birth date/time in an IANA zone -> UTC instant -> Julian day (UT).

ΔT is ignored (well under 0.002° on the Sun for 1900-2100). Valid 1900-2099.
"""

import math
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

J2000 = 2451545.0
YEAR_MIN, YEAR_MAX = 1900, 2099
_TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$")


@dataclass(frozen=True)
class BirthInstant:
    local: datetime
    utc: datetime
    jd_ut: float
    time_known: bool
    timezone: str


def julian_day(year: int, month: int, day: int, hour_decimal: float) -> float:
    """Julian day (UT) from a calendar date and decimal hours; valid 1900-2100."""
    return (367 * year - math.floor(7 * (year + math.floor((month + 9) / 12)) / 4)
            + math.floor(275 * month / 9) + day + 1721013.5 + hour_decimal / 24.0)


def julian_centuries(jd: float) -> float:
    """Julian centuries from J2000.0."""
    return (jd - J2000) / 36525.0


def jd_from_utc(moment: datetime) -> float:
    moment = moment.astimezone(timezone.utc)
    hours = moment.hour + moment.minute / 60.0 + (moment.second + moment.microsecond / 1e6) / 3600.0
    return julian_day(moment.year, moment.month, moment.day, hours)


def parse_birth_date(value: str) -> date:
    try:
        parsed = date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ValueError(f"birth_date must be YYYY-MM-DD, got {value!r}") from None
    if not (YEAR_MIN <= parsed.year <= YEAR_MAX):
        raise ValueError(f"JOH covers births from 1900 to 2099; got {parsed.year}")
    return parsed


def parse_birth_time(value: str | None) -> time | None:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    match = _TIME_RE.match(value.strip()) if isinstance(value, str) else None
    if match is None:
        raise ValueError(f"birth_time must be HH:MM (24 h), got {value!r}")
    hour, minute, second = int(match[1]), int(match[2]), int(match[3] or 0)
    if not (0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= second <= 59):
        raise ValueError(f"birth_time must be HH:MM (24 h), got {value!r}")
    return time(hour, minute, second)


def zone(name: str) -> ZoneInfo:
    if not isinstance(name, str) or not name.strip():
        raise ValueError("timezone must be an IANA zone name")
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise ValueError(f"unknown timezone {name!r}") from None


def birth_instant(birth_date: str, birth_time: str | None, tz_name: str) -> BirthInstant:
    """Local wall time in ``tz_name`` -> UTC. Unknown time means local noon (flagged)."""
    day = parse_birth_date(birth_date)
    clock = parse_birth_time(birth_time)
    tz = zone(tz_name)
    time_known = clock is not None
    local = datetime.combine(day, clock or time(12, 0), tzinfo=tz)
    utc = local.astimezone(timezone.utc)
    return BirthInstant(local=local, utc=utc, jd_ut=jd_from_utc(utc),
                        time_known=time_known, timezone=tz_name)
