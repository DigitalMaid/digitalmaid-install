"""Gene Keys Hologenetic Profile: spheres mapped onto Human Design activations."""

from digitalmaid.joh.genekeys_data import CONTEMPLATIONS, KEYS
from digitalmaid.joh.humandesign import opposite_gate

# (sphere, side, body, sequence) in display order. Core Wound and Vocation share D-Mars;
# Brand shares P-Sun with Life's Work — sixteen rows, eleven distinct positions plus three
# further spheres.
SPHERES = (
    ("Life's Work", "personality", "sun", "activation"),
    ("Evolution", "personality", "earth", "activation"),
    ("Radiance", "design", "sun", "activation"),
    ("Purpose", "design", "earth", "activation"),
    ("Attraction", "design", "moon", "venus"),
    ("IQ", "personality", "venus", "venus"),
    ("EQ", "personality", "mars", "venus"),
    ("SQ", "design", "venus", "venus"),
    ("Core Wound", "design", "mars", "venus"),
    ("Vocation", "design", "mars", "pearl"),
    ("Culture", "design", "jupiter", "pearl"),
    ("Pearl", "personality", "jupiter", "pearl"),
    ("Brand", "personality", "sun", "pearl"),
    ("Creativity", "design", "uranus", "further"),
    ("Relating", "personality", "mercury", "further"),
    ("Stability", "design", "saturn", "further"),
)
SEQUENCES = ("activation", "venus", "pearl", "further")
PRIME_GIFTS = ("Life's Work", "Evolution", "Radiance", "Purpose")

LINE_THEMES = {1: "Creative / Self", 2: "Dance / Relationship", 3: "Energy / Experience",
               4: "Breath / Community", 5: "Voice / Power", 6: "Being / Wisdom"}

FREQUENCY_PROMPTS = {
    "shadow": "Where does this pattern show up when you are tired, rushed or afraid this week.",
    "gift": "What would it look like to lead with this quality in one conversation today.",
    "siddhi": "Hold this word lightly; it is a direction to face, not a standard to meet.",
}


def key_summary(key: int) -> dict:
    words = KEYS[key]
    return {"key": key, "shadow": words["shadow"], "gift": words["gift"],
            "siddhi": words["siddhi"], "programming_partner": opposite_gate(key),
            "contemplation": CONTEMPLATIONS[key]}


def sphere(name: str, side: str, body: str, sequence: str, activation: dict) -> dict:
    key, line = activation["gate"], activation["line"]
    return {"sphere": name, "side": side, "body": body, "sequence": sequence,
            "key": key, "line": line, "key_line": f"{key}.{line}",
            "line_theme": LINE_THEMES[line], **key_summary(key)}


def hologenetic_profile(bodygraph: dict) -> dict:
    """Spheres from a ``humandesign.compute`` result (``personality``/``design`` activations)."""
    spheres = [sphere(name, side, body, sequence, bodygraph[side][body])
               for name, side, body, sequence in SPHERES]
    sequences = {seq: [s for s in spheres if s["sequence"] == seq] for seq in SEQUENCES}
    return {"spheres": spheres, "sequences": sequences,
            "prime_gifts": [s for s in spheres if s["sphere"] in PRIME_GIFTS],
            "line_themes": {str(k): v for k, v in LINE_THEMES.items()},
            "frequency_prompts": FREQUENCY_PROMPTS}
