"""Astrology chart: positions, Ascendant/MC, whole-sign houses, aspects (both zodiacs)."""

import math

from digitalmaid.joh import ephemeris
from digitalmaid.joh.sidereal import check_zodiac, to_sidereal
from digitalmaid.joh.timeutil import J2000, julian_centuries

SIGNS = ("Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra",
         "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces")

PLANETS = ("sun", "moon", "mercury", "venus", "mars", "jupiter", "saturn",
           "uranus", "neptune", "pluto")
CHART_BODIES = PLANETS + ("true_node", "south_node", "earth", "mean_node")
# Bodies that take part in aspects: the ten planets and the north node.
ASPECT_BODIES = PLANETS + ("true_node",)

# name -> (angle, base orb); Sun or Moon in the pair adds 2°.
ASPECTS = (("conjunction", 0.0, 8.0), ("sextile", 60.0, 4.0), ("square", 90.0, 6.0),
           ("trine", 120.0, 6.0), ("opposition", 180.0, 8.0))
LUMINARIES = ("sun", "moon")


def sign_position(longitude: float) -> dict:
    lon = longitude % 360.0
    index = int(lon // 30.0)
    within = lon - 30.0 * index
    degree = int(within)
    minute = int(round((within - degree) * 60.0))
    if minute == 60:
        minute = 59
    return {"sign": SIGNS[index], "sign_index": index, "degree": degree, "minute": minute}


def mean_node(jd_ut: float) -> float:
    t = julian_centuries(jd_ut)
    return (125.0445479 - 1934.1362891 * t + 0.0020754 * t * t
            + t ** 3 / 467441.0 - t ** 4 / 60616000.0) % 360.0


def tropical_longitudes(jd_ut: float) -> dict:
    """Tropical longitudes of every chart body at ``jd_ut``."""
    values = {body: ephemeris.longitude(body, jd_ut) for body in PLANETS + ("true_node",)}
    values["south_node"] = (values["true_node"] + 180.0) % 360.0
    values["earth"] = (values["sun"] + 180.0) % 360.0
    values["mean_node"] = mean_node(jd_ut)
    return values


def longitudes(jd_ut: float, zodiac: str) -> dict:
    check_zodiac(zodiac)
    values = tropical_longitudes(jd_ut)
    if zodiac == "sidereal":
        values = {body: to_sidereal(lon, jd_ut) for body, lon in values.items()}
    return values


def _is_retrograde(body: str, jd_ut: float) -> bool:
    if body in ("sun", "moon", "earth"):
        return False
    source = {"south_node": "true_node"}.get(body, body)
    if source == "mean_node":
        before, after = mean_node(jd_ut - 1 / 24), mean_node(jd_ut + 1 / 24)
    else:
        lo = max(jd_ut - 1 / 24, ephemeris.JD_START)
        hi = min(jd_ut + 1 / 24, ephemeris.JD_END)
        before, after = ephemeris.longitude(source, lo), ephemeris.longitude(source, hi)
    return ((after - before + 180.0) % 360.0 - 180.0) < 0.0


def positions(jd_ut: float, zodiac: str) -> dict:
    """``{body: {longitude, sign, sign_index, degree, minute, retrograde}}`` in ``zodiac``."""
    out = {}
    for body, lon in longitudes(jd_ut, zodiac).items():
        out[body] = {"longitude": lon, **sign_position(lon),
                     "retrograde": _is_retrograde(body, jd_ut)}
    return out


def obliquity(jd_ut: float) -> float:
    return 23.4392911 - 0.0130042 * julian_centuries(jd_ut)


def gmst(jd_ut: float) -> float:
    t = julian_centuries(jd_ut)
    return (280.46061837 + 360.98564736629 * (jd_ut - J2000) + 0.000387933 * t * t) % 360.0


def ascendant_mc(jd_ut: float, lat: float, lon: float) -> tuple[float, float]:
    """Tropical Ascendant and Midheaven longitudes for the geographic ``lat``/``lon`` (east positive)."""
    theta = math.radians((gmst(jd_ut) + lon) % 360.0)
    eps = math.radians(obliquity(jd_ut))
    phi = math.radians(lat)
    mc = math.degrees(math.atan2(math.sin(theta), math.cos(theta) * math.cos(eps))) % 360.0
    asc = math.degrees(math.atan2(
        math.cos(theta),
        -(math.sin(theta) * math.cos(eps) + math.tan(phi) * math.sin(eps)))) % 360.0
    return asc, mc


def whole_sign_cusps(ascendant: float) -> list[float]:
    first = 30.0 * int((ascendant % 360.0) // 30.0)
    return [(first + 30.0 * i) % 360.0 for i in range(12)]


def house_of(longitude: float, ascendant: float) -> int:
    return (int((longitude % 360.0) // 30.0) - int((ascendant % 360.0) // 30.0)) % 12 + 1


def aspects(longitude_by_body: dict) -> list[dict]:
    """Aspects between every pair (in dict order) within the orbs of ``ASPECTS``."""
    bodies = [b for b in longitude_by_body if b in ASPECT_BODIES or b not in CHART_BODIES]
    found = []
    for i, a in enumerate(bodies):
        for b in bodies[i + 1:]:
            separation = abs((longitude_by_body[a] - longitude_by_body[b] + 180.0) % 360.0 - 180.0)
            bonus = 2.0 if (a in LUMINARIES or b in LUMINARIES) else 0.0
            for name, angle, orb in ASPECTS:
                if abs(separation - angle) <= orb + bonus:
                    found.append({"a": a, "b": b, "aspect": name, "angle": angle,
                                  "orb": round(abs(separation - angle), 4)})
                    break
    return found


def chart(jd_ut: float, lat: float, lon: float, zodiac: str) -> dict:
    """Full chart in ``zodiac``: positions with houses, Ascendant/MC, whole-sign houses, aspects."""
    check_zodiac(zodiac)
    asc_t, mc_t = ascendant_mc(jd_ut, lat, lon)
    if zodiac == "sidereal":
        asc, mc = to_sidereal(asc_t, jd_ut), to_sidereal(mc_t, jd_ut)
    else:
        asc, mc = asc_t, mc_t
    body_positions = positions(jd_ut, zodiac)
    for record in body_positions.values():
        record["house"] = house_of(record["longitude"], asc)
    houses = [{"house": i + 1, "cusp": cusp, **sign_position(cusp)}
              for i, cusp in enumerate(whole_sign_cusps(asc))]
    return {
        "zodiac": zodiac,
        "house_system": "whole_sign",
        "ascendant": {"longitude": asc, **sign_position(asc)},
        "mc": {"longitude": mc, **sign_position(mc), "house": house_of(mc, asc)},
        "positions": body_positions,
        "houses": houses,
        "aspects": aspects({b: body_positions[b]["longitude"] for b in ASPECT_BODIES}),
    }
