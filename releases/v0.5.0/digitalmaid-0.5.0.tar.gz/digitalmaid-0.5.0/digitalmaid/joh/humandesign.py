"""Human Design bodygraph facts from birth (Personality) and design (88° of Sun earlier) longitudes.

One wheel, one ``gate_line`` function; the caller chooses tropical or sidereal longitudes
(owner decision: the same wheel is applied to sidereal longitudes in sidereal mode).
"""

import math

from digitalmaid.joh import astro, ephemeris
from digitalmaid.joh.sidereal import check_zodiac

WHEEL_START = 302.0                      # Gate 41 begins at 2° Aquarius
GATE_SPAN = 360.0 / 64                   # 5.625°
LINE_SPAN = GATE_SPAN / 6                # 0.9375°
COLOUR_SPAN = LINE_SPAN / 6              # 0.15625°
TONE_SPAN = COLOUR_SPAN / 6
BASE_SPAN = TONE_SPAN / 5

WHEEL = (41, 19, 13, 49, 30, 55, 37, 63, 22, 36, 25, 17, 21, 51, 42, 3, 27, 24, 2, 23, 8, 20,
         16, 35, 45, 12, 15, 52, 39, 53, 62, 56, 31, 33, 7, 4, 29, 59, 40, 64, 47, 6, 46, 18,
         48, 57, 32, 50, 28, 44, 1, 43, 14, 34, 9, 5, 26, 11, 10, 58, 38, 54, 61, 60)
_WHEEL_INDEX = {gate: i for i, gate in enumerate(WHEEL)}

ACTIVATION_BODIES = ("sun", "earth", "north_node", "south_node", "moon", "mercury", "venus",
                     "mars", "jupiter", "saturn", "uranus", "neptune", "pluto")
_CHART_NAME = {"north_node": "true_node"}

CHANNELS = ((1, 8), (2, 14), (3, 60), (4, 63), (5, 15), (6, 59), (7, 31), (9, 52), (10, 20),
            (10, 34), (10, 57), (11, 56), (12, 22), (13, 33), (16, 48), (17, 62), (18, 58),
            (19, 49), (20, 34), (20, 57), (21, 45), (23, 43), (24, 61), (25, 51), (26, 44),
            (27, 50), (28, 38), (29, 46), (30, 41), (32, 54), (34, 57), (35, 36), (37, 40),
            (39, 55), (42, 53), (47, 64))

CENTRES = {
    "Head": (64, 61, 63),
    "Ajna": (47, 24, 4, 17, 43, 11),
    "Throat": (62, 23, 56, 35, 12, 45, 33, 8, 31, 20, 16),
    "G": (1, 13, 25, 46, 2, 15, 10, 7),
    "Heart": (21, 40, 26, 51),
    "Sacral": (5, 14, 29, 59, 9, 3, 42, 27, 34),
    "Spleen": (48, 57, 44, 50, 32, 28, 18),
    "Solar Plexus": (6, 37, 22, 36, 30, 55, 49),
    "Root": (53, 60, 52, 19, 39, 41, 58, 38, 54),
}
_CENTRE_OF = {gate: centre for centre, gates in CENTRES.items() for gate in gates}
MOTOR_CENTRES = ("Heart", "Sacral", "Solar Plexus", "Root")

TYPES = {
    "Manifestor": {"strategy": "Inform the people affected before you act",
                   "not_self_theme": "anger", "signature": "peace"},
    "Generator": {"strategy": "Wait to respond to what shows up, then follow your gut",
                  "not_self_theme": "frustration", "signature": "satisfaction"},
    "Manifesting Generator": {"strategy": "Wait to respond, then inform before you move",
                              "not_self_theme": "frustration and anger",
                              "signature": "satisfaction"},
    "Projector": {"strategy": "Wait for the invitation; offer your view when it is asked for",
                  "not_self_theme": "bitterness", "signature": "success"},
    "Reflector": {"strategy": "Wait a full lunar cycle before deciding anything big",
                  "not_self_theme": "disappointment", "signature": "surprise"},
}

RIGHT_ANGLE_PROFILES = ("1/3", "1/4", "2/4", "2/5", "3/5", "4/6")
LEFT_ANGLE_PROFILES = ("5/1", "6/2", "6/3")
JUXTAPOSITION_PROFILES = ("4/1",)


# -- wheel ---------------------------------------------------------------------------

def gate_start(gate: int) -> float:
    return (WHEEL_START + _WHEEL_INDEX[gate] * GATE_SPAN) % 360.0


def opposite_gate(gate: int) -> int:
    """Programming partner: the gate 180° across the wheel (32 positions on)."""
    return WHEEL[(_WHEEL_INDEX[gate] + 32) % 64]


def gate_line(longitude: float) -> dict:
    """Gate, line, colour, tone and base for an ecliptic longitude on the 64-gate wheel."""
    offset = (longitude - WHEEL_START) % 360.0
    gate_index = min(int(offset // GATE_SPAN), 63)
    within = offset - gate_index * GATE_SPAN
    line = min(int(within // LINE_SPAN), 5)
    within -= line * LINE_SPAN
    colour = min(int(within // COLOUR_SPAN), 5)
    within -= colour * COLOUR_SPAN
    tone = min(int(within // TONE_SPAN), 5)
    within -= tone * TONE_SPAN
    base = min(int(within // BASE_SPAN), 4)
    gate = WHEEL[gate_index]
    return {"gate": gate, "line": line + 1, "colour": colour + 1, "tone": tone + 1,
            "base": base + 1, "key": f"{gate}.{line + 1}"}


def centre_of(gate: int) -> str:
    return _CENTRE_OF[gate]


# -- design instant ------------------------------------------------------------------

def design_instant(jd_birth: float) -> float:
    """Instant when the Sun stood exactly 88° behind its birth longitude (bisection, ±1e-6°)."""
    target = (ephemeris.longitude("sun", jd_birth) - 88.0) % 360.0

    def offset(jd: float) -> float:
        return (ephemeris.longitude("sun", jd) - target + 180.0) % 360.0 - 180.0

    lo, hi = jd_birth - 95.0, jd_birth - 82.0
    if lo < ephemeris.JD_START:
        raise ephemeris.EphemerisRangeError(
            "JOH covers births from 1900 to 2099; the design instant falls before the ephemeris")
    f_lo, f_hi = offset(lo), offset(hi)
    if not (f_lo < 0.0 < f_hi):
        raise ValueError("design instant bracket failed")
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        f_mid = offset(mid)
        if abs(f_mid) < 1e-6:
            return mid
        if f_mid < 0.0:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# -- activations ---------------------------------------------------------------------

def activations(jd_ut: float, zodiac: str) -> dict:
    """The 13 activations at ``jd_ut`` in ``zodiac``: ``{body: {gate, line, colour, tone, base, key, longitude}}``."""
    check_zodiac(zodiac)
    lons = astro.longitudes(jd_ut, zodiac)
    out = {}
    for body in ACTIVATION_BODIES:
        lon = lons[_CHART_NAME.get(body, body)]
        out[body] = {**gate_line(lon), "longitude": lon}
    return out


# -- bodygraph -----------------------------------------------------------------------

def cross_angle(profile: str) -> str:
    if profile in RIGHT_ANGLE_PROFILES:
        return "Right Angle"
    if profile in LEFT_ANGLE_PROFILES:
        return "Left Angle"
    if profile in JUXTAPOSITION_PROFILES:
        return "Juxtaposition"
    raise ValueError(f"{profile!r} is not one of the twelve profiles")


def _components(centres: set[str], edges: list[tuple[str, str]]) -> list[set[str]]:
    remaining, groups = set(centres), []
    while remaining:
        seed = remaining.pop()
        group, frontier = {seed}, [seed]
        while frontier:
            node = frontier.pop()
            for a, b in edges:
                other = b if a == node else a if b == node else None
                if other is not None and other not in group:
                    group.add(other)
                    frontier.append(other)
        remaining -= group
        groups.append(group)
    return groups


def bodygraph(personality: dict, design: dict) -> dict:
    """Channels, centres, type, strategy, authority, profile, definition and cross."""
    sides = {}
    for side, table in (("personality", personality), ("design", design)):
        for record in table.values():
            sides.setdefault(record["gate"], set()).add(side)
    channels = []
    for a, b in CHANNELS:
        if a in sides and b in sides:
            channels.append({"gates": [a, b], "centres": [centre_of(a), centre_of(b)],
                             "sides": {str(a): sorted(sides[a]), str(b): sorted(sides[b])}})
    edges = [(c["centres"][0], c["centres"][1]) for c in channels]
    defined = [centre for centre in CENTRES if any(centre in e for e in edges)]
    defined_set = set(defined)
    groups = _components(defined_set, edges)
    throat_group = next((g for g in groups if "Throat" in g), set())
    motor_to_throat = any(m in throat_group for m in MOTOR_CENTRES)

    if not defined:
        kind = "Reflector"
    elif "Sacral" in defined_set:
        kind = "Manifesting Generator" if motor_to_throat else "Generator"
    elif motor_to_throat:
        kind = "Manifestor"
    else:
        kind = "Projector"

    if "Solar Plexus" in defined_set:
        authority = "Emotional"
    elif "Sacral" in defined_set:
        authority = "Sacral"
    elif "Spleen" in defined_set:
        authority = "Splenic"
    elif "Heart" in defined_set:
        authority = "Ego"
    elif "G" in defined_set and ("G", "Throat") in [tuple(sorted(e)) for e in edges]:
        authority = "Self-projected"
    elif defined:
        authority = "Mental"
    else:
        authority = "Lunar"

    profile = f"{personality['sun']['line']}/{design['sun']['line']}"
    definition = {0: "none", 1: "single", 2: "split", 3: "triple", 4: "quadruple"}.get(
        len(groups), f"{len(groups)}-way")
    cross_gates = [personality["sun"]["gate"], personality["earth"]["gate"],
                   design["sun"]["gate"], design["earth"]["gate"]]
    angle = cross_angle(profile)
    cross = {"gates": cross_gates, "angle": angle,
             "label": f"{angle} Cross {cross_gates[0]}/{cross_gates[1]} | {cross_gates[2]}/{cross_gates[3]}"}
    facts = TYPES[kind]
    return {
        "type": kind,
        "strategy": facts["strategy"],
        "authority": authority,
        "profile": profile,
        "definition": definition,
        "incarnation_cross": cross,
        "not_self_theme": facts["not_self_theme"],
        "signature": facts["signature"],
        "defined_centres": defined,
        "channels": channels,
        "gates": {str(g): sorted(s) for g, s in sorted(sides.items())},
    }


def compute(jd_birth: float, zodiac: str) -> dict:
    """Personality + Design activations and the bodygraph facts for one birth instant."""
    design_jd = design_instant(jd_birth)
    personality = activations(jd_birth, zodiac)
    design = activations(design_jd, zodiac)
    return {"zodiac": zodiac, "design_jd_ut": design_jd,
            "personality": personality, "design": design,
            **bodygraph(personality, design)}
