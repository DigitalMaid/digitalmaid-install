"""JOH — Journey of Humanity engine (offline, deterministic, stdlib only).

``compute_profile(birth)`` turns birth data into the astrology chart, the Human Design
bodygraph and the Gene Keys profile in both zodiacs. Bump ``ENGINE_VERSION`` whenever the
output shape or any table changes so stored profiles are recomputed on read.
"""

from digitalmaid.joh import astro, genekeys, humandesign
from digitalmaid.joh.sidereal import ZODIACS, ayanamsa_lahiri
from digitalmaid.joh.timeutil import birth_instant

ENGINE_VERSION = 1


def _coordinate(value, name: str, limit: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number")
    if not (-limit <= float(value) <= limit):
        raise ValueError(f"{name} must be within ±{limit:g}")
    return float(value)


def compute_profile(birth: dict) -> dict:
    """Full engine output for ``birth`` = {birth_date, birth_time|None, timezone, lat, lon}."""
    lat = _coordinate(birth.get("lat"), "lat", 90.0)
    lon = _coordinate(birth.get("lon"), "lon", 180.0)
    instant = birth_instant(birth.get("birth_date"), birth.get("birth_time"), birth.get("timezone"))
    jd = instant.jd_ut
    design_jd = humandesign.design_instant(jd)
    out = {
        "engine_version": ENGINE_VERSION,
        "birth": {
            "date": instant.local.date().isoformat(),
            "time": instant.local.strftime("%H:%M") if instant.time_known else None,
            "time_known": instant.time_known,
            "timezone": instant.timezone,
            "utc": instant.utc.isoformat(),
            "jd_ut": jd,
            "design_jd_ut": design_jd,
            "ayanamsa_lahiri": ayanamsa_lahiri(jd),
            "lat": lat,
            "lon": lon,
        },
    }
    for zodiac in ZODIACS:
        body = humandesign.compute(jd, zodiac)
        out[zodiac] = {
            "astro": astro.chart(jd, lat, lon, zodiac),
            "humandesign": body,
            "genekeys": genekeys.hologenetic_profile(body),
        }
    return out
