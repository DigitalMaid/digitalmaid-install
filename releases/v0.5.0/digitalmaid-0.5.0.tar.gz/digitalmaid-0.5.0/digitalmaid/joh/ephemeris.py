"""Reader for ``ephemeris.bin`` (format DMEPH1, see docs/JOH-EPHEMERIS.md).

Chebyshev segments fitted to JPL Horizons geocentric apparent ecliptic-of-date
longitudes, 1900-2100. Pure stdlib; the whole file (~2 MB) is read once and
kept as a flat float32 array per body.
"""

import array
import json
import math
import struct
from pathlib import Path

MAGIC = b"DMEPH1"
FILE = Path(__file__).with_name("ephemeris.bin")

BODIES = ("sun", "moon", "mercury", "venus", "mars", "jupiter", "saturn",
          "uranus", "neptune", "pluto", "true_node")


class EphemerisRangeError(ValueError):
    """The instant lies outside the years the bundled ephemeris covers."""


class _Body:
    __slots__ = ("name", "segment_days", "degree", "n_segments", "coefficients")

    def __init__(self, info: dict, coefficients):
        self.name = info["name"]
        self.segment_days = float(info["segment_days"])
        self.degree = int(info["degree"])
        self.n_segments = int(info["n_segments"])
        self.coefficients = coefficients


def _load() -> tuple[dict, dict]:
    raw = FILE.read_bytes()
    if raw[:6] != MAGIC:
        raise ValueError("ephemeris.bin: bad magic")
    (length,) = struct.unpack_from("<I", raw, 6)
    header = json.loads(raw[10:10 + length].decode("utf-8"))
    if header.get("format") != "DMEPH1":
        raise ValueError("ephemeris.bin: unsupported format")
    offset = 10 + length
    bodies = {}
    for info in header["bodies"]:
        count = int(info["n_segments"]) * (int(info["degree"]) + 1)
        block = array.array("f")
        block.frombytes(raw[offset:offset + 4 * count])
        if len(block) != count:
            raise ValueError(f"ephemeris.bin: truncated block for {info['name']}")
        offset += 4 * count
        bodies[info["name"]] = _Body(info, block)
    return header, bodies


_HEADER, _BODIES = _load()
JD_START: float = float(_HEADER["jd_start"])
JD_END: float = float(_HEADER["jd_end"])


def header() -> dict:
    """The JSON header of the bundled file (copy)."""
    return json.loads(json.dumps(_HEADER))


def longitude(body: str, jd: float) -> float:
    """Apparent geocentric ecliptic longitude of ``body`` at Julian day ``jd`` (UT), in [0, 360)."""
    record = _BODIES.get(body)
    if record is None:
        raise ValueError(f"unknown body {body!r}; expected one of {BODIES}")
    if not (JD_START <= jd <= JD_END) or math.isnan(jd):
        raise EphemerisRangeError(
            f"JOH covers births from 1900 to 2099; jd {jd} is outside the ephemeris")
    segment = int((jd - JD_START) // record.segment_days)
    segment = min(segment, record.n_segments - 1)
    start = JD_START + segment * record.segment_days
    x = 2.0 * (jd - start) / record.segment_days - 1.0
    width = record.degree + 1
    base = segment * width
    coef = record.coefficients[base:base + width]
    b1 = b2 = 0.0
    two_x = 2.0 * x
    for c in reversed(coef[1:]):
        b1, b2 = two_x * b1 - b2 + c, b1
    value = x * b1 - b2 + coef[0]
    return value % 360.0
