"""Birthplace lookup (docs/JOH.md §2, §6): one Nominatim query, one bundled timezone table.

The only network call in the whole JOH feature. Only the city and country the user typed
are sent; the birth date and time never leave the server. The HTTP fetch is a plain
callable ``fetch(url, headers, timeout_seconds) -> str`` so tests inject a fake and the
default is stdlib ``urllib``. The IANA zone comes from ``zone1970.tab`` shipped with the
system tz database: the nearest principal location among zones listed for the result's
country code, else the nearest overall.
"""

import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from digitalmaid import __version__

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
USER_AGENT = f"DigitalMaid-Agentic-OS/{__version__} (joh)"
TIMEOUT_SECONDS = 8
RATE_LIMIT = 10                 # lookups per user ...
RATE_WINDOW_SECONDS = 60.0      # ... per minute
ZONE_TABLE = Path("/usr/share/zoneinfo/zone1970.tab")
_COORD_RE = re.compile(r"^([+-])(\d{2})(\d{2})(\d{2})?([+-])(\d{3})(\d{2})(\d{2})?$")


class GeocodeError(Exception):
    """OpenStreetMap could not be reached or answered something unusable (HTTP 502)."""


class NoPlaceFound(LookupError):
    """Nominatim returned no match for the typed place (HTTP 404)."""


def urllib_fetch(url: str, headers: dict, timeout_seconds: float) -> str:
    request = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        return response.read().decode("utf-8", "replace")


def _clean(value, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} is required")
    return " ".join(value.split())


def geocode(city, country, fetch=None) -> dict:
    """``{display_name, lat, lon, country_code, timezone}`` for a typed city + country."""
    city, country = _clean(city, "city"), _clean(country, "country")
    query = urllib.parse.urlencode({"q": f"{city}, {country}", "format": "jsonv2", "limit": "1",
                                    "addressdetails": "1"})
    url = f"{NOMINATIM_URL}?{query}"
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    try:
        raw = (fetch or urllib_fetch)(url, headers, TIMEOUT_SECONDS)
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise GeocodeError(f"OpenStreetMap could not be reached: {exc}") from None
    try:
        hits = json.loads(raw)
        if not isinstance(hits, list):
            raise TypeError("not a list")
    except (ValueError, TypeError) as exc:
        raise GeocodeError(f"OpenStreetMap answered something unexpected: {exc}") from None
    if not hits or not isinstance(hits[0], dict):
        raise NoPlaceFound(f"No place found for {city}, {country}")
    hit = hits[0]
    try:
        lat, lon = float(hit["lat"]), float(hit["lon"])
    except (KeyError, TypeError, ValueError):
        raise GeocodeError("OpenStreetMap answered without coordinates") from None
    address = hit.get("address") if isinstance(hit.get("address"), dict) else {}
    code = address.get("country_code")
    code = code.lower() if isinstance(code, str) and len(code) == 2 else None
    return {"display_name": str(hit.get("display_name") or f"{city}, {country}"),
            "lat": round(lat, 4), "lon": round(lon, 4), "country_code": code,
            "timezone": nearest_timezone(lat, lon, code)}


# -- zone1970.tab ---------------------------------------------------------------------------

_zones: list[tuple] | None = None


def _parse_coordinate(text: str) -> tuple[float, float]:
    match = _COORD_RE.match(text)
    if match is None:
        raise ValueError(f"bad coordinate {text!r}")
    lat_sign, lat_d, lat_m, lat_s, lon_sign, lon_d, lon_m, lon_s = match.groups()
    lat = int(lat_d) + int(lat_m) / 60 + int(lat_s or 0) / 3600
    lon = int(lon_d) + int(lon_m) / 60 + int(lon_s or 0) / 3600
    return (-lat if lat_sign == "-" else lat), (-lon if lon_sign == "-" else lon)


def load_zone_table(path: Path = ZONE_TABLE) -> list[tuple]:
    """``(country codes, lat, lon, zone, first code)`` rows, parsed once per process."""
    global _zones
    if _zones is None or path != ZONE_TABLE:
        rows = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 3:
                continue
            try:
                lat, lon = _parse_coordinate(parts[1])
            except ValueError:
                continue
            codes = [c.lower() for c in parts[0].split(",")]
            rows.append((frozenset(codes), lat, lon, parts[2], codes[0]))
        if not rows:
            raise GeocodeError(f"no timezone rows in {path}")
        if path == ZONE_TABLE:
            _zones = rows
        return rows
    return _zones


def _distance(lat1, lon1, lat2, lon2) -> float:
    """Great-circle angle in radians (unit sphere)."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    d = math.radians(lon2 - lon1)
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(d / 2) ** 2
    return 2 * math.asin(min(1.0, math.sqrt(h)))


def nearest_timezone(lat: float, lon: float, country_code: str | None) -> str:
    """Nearest principal location, narrowed by country.

    Rows whose *first* code is the country (the zone is that country's own) win over rows
    that merely list it — Hanoi is nearer Bangkok's centroid, yet ``Asia/Ho_Chi_Minh`` is
    the zone a Vietnamese birth expects (and the right one before 1970). Then any row
    containing the code, then every row."""
    rows = load_zone_table()
    code = country_code.lower() if isinstance(country_code, str) else None
    own = [r for r in rows if code and r[4] == code]
    listed = [r for r in rows if code and code in r[0]]
    candidates = own or listed or rows
    return min(candidates, key=lambda r: _distance(lat, lon, r[1], r[2]))[3]


# -- rate limit -----------------------------------------------------------------------------

class GeocodeRateLimiter:
    """At most ``limit`` lookups per user in any rolling ``window`` seconds."""

    def __init__(self, limit: int = RATE_LIMIT, window: float = RATE_WINDOW_SECONDS, clock=None):
        self.limit, self.window, self.clock = limit, window, clock or time.monotonic
        self._hits: dict[str, list[float]] = {}

    def allow(self, key: str) -> bool:
        now = self.clock()
        recent = [t for t in self._hits.get(key, []) if now - t < self.window]
        if len(recent) >= self.limit:
            self._hits[key] = recent
            return False
        recent.append(now)
        self._hits[key] = recent
        return True
