"""Enneagram: nine type records, a 45-statement self-report and its scoring.

Every sentence here was written for DigitalMaid; nothing is taken from a published
instrument. The statements are deliberately plain: everyday situations, no jargon.
"""

import random

INSTINCTS = ("sp", "so", "sx")
SCALE = (1, 2, 3, 4, 5)

TYPES: dict[int, dict] = {
    1: {"name": "The Improver",
        "core_fear": "Being wrong, careless or morally off track",
        "core_desire": "To be good, correct and beyond reproach",
        "basic_proposition": "If I get things right and hold the line, the world will be fair and I will be worthy.",
        "growth_arrow": 7, "stress_arrow": 4,
        "keywords": ["principled", "orderly", "self-critical", "responsible", "exacting"]},
    2: {"name": "The Helper",
        "core_fear": "Being unwanted or unworthy of love",
        "core_desire": "To be needed and appreciated",
        "basic_proposition": "If I take care of everyone, I will be loved and never left out.",
        "growth_arrow": 4, "stress_arrow": 8,
        "keywords": ["warm", "generous", "attentive", "people-focused", "self-forgetting"]},
    3: {"name": "The Achiever",
        "core_fear": "Being worthless apart from what I accomplish",
        "core_desire": "To be valued and admired for what I do",
        "basic_proposition": "If I succeed and look successful, I will matter.",
        "growth_arrow": 6, "stress_arrow": 9,
        "keywords": ["driven", "adaptable", "efficient", "image-aware", "goal-oriented"]},
    4: {"name": "The Individualist",
        "core_fear": "Having no identity or personal significance",
        "core_desire": "To be understood as the person I really am",
        "basic_proposition": "If I stay true to my feelings and my difference, I will finally be seen.",
        "growth_arrow": 1, "stress_arrow": 2,
        "keywords": ["expressive", "introspective", "sensitive", "authentic", "moody"]},
    5: {"name": "The Investigator",
        "core_fear": "Being overwhelmed, depleted or incapable",
        "core_desire": "To understand and to be competent",
        "basic_proposition": "If I know enough and keep my needs small, I will be safe.",
        "growth_arrow": 8, "stress_arrow": 7,
        "keywords": ["curious", "private", "analytical", "self-sufficient", "detached"]},
    6: {"name": "The Loyalist",
        "core_fear": "Being without support, guidance or security",
        "core_desire": "To feel safe and backed up",
        "basic_proposition": "If I stay alert and keep faith with trusted people, I will not be caught out.",
        "growth_arrow": 9, "stress_arrow": 3,
        "keywords": ["vigilant", "committed", "questioning", "responsible", "anxious"]},
    7: {"name": "The Enthusiast",
        "core_fear": "Being trapped in pain or deprivation",
        "core_desire": "To be free, satisfied and fully alive",
        "basic_proposition": "If I keep my options open and my spirits up, nothing can pin me down.",
        "growth_arrow": 5, "stress_arrow": 1,
        "keywords": ["upbeat", "spontaneous", "versatile", "restless", "optimistic"]},
    8: {"name": "The Protector",
        "core_fear": "Being controlled, harmed or at someone's mercy",
        "core_desire": "To be strong and in charge of my own life",
        "basic_proposition": "If I am strong and direct, nobody can take advantage of me or mine.",
        "growth_arrow": 2, "stress_arrow": 5,
        "keywords": ["decisive", "protective", "blunt", "self-confident", "confrontational"]},
    9: {"name": "The Peacemaker",
        "core_fear": "Loss of connection, conflict, being pushed aside",
        "core_desire": "Inner and outer peace",
        "basic_proposition": "If I keep the peace and go along, everything will stay comfortable.",
        "growth_arrow": 3, "stress_arrow": 6,
        "keywords": ["easygoing", "steady", "accommodating", "receptive", "conflict-avoidant"]},
}

# 45 statements, five per type, id 1..45. Rated 1 (not like me) .. 5 (very like me).
_RAW_STATEMENTS = (
    (1, "I notice small mistakes in a document that other people read straight past."),
    (1, "I find it hard to relax while something at home or work is still not done properly."),
    (1, "I have a clear sense of how things should be done and it bothers me when they are not."),
    (1, "My inner critic is louder than any criticism I get from other people."),
    (1, "I would rather be right and unpopular than liked and careless."),
    (2, "I usually notice what someone needs before they have said anything."),
    (2, "It is much easier for me to give help than to ask for it."),
    (2, "I feel hurt when my efforts for other people go unnoticed."),
    (2, "I tend to say yes to requests and work out afterwards how I will manage."),
    (2, "Being needed by the people around me is a big part of how I feel worthwhile."),
    (3, "I measure my week by what I got done and how it looked to others."),
    (3, "I adapt how I come across depending on who I am with, usually without planning to."),
    (3, "Slowing down feels like falling behind."),
    (3, "I want the things I make to be admired, not just useful."),
    (3, "Failure in front of other people worries me more than failure in private."),
    (4, "I often feel that something essential is missing from my life that other people seem to have."),
    (4, "My moods run deep and I do not want them talked out of me."),
    (4, "Being ordinary feels worse to me than being misunderstood."),
    (4, "I express myself best through a personal style, a craft or a way of speaking that is mine."),
    (4, "I go back over painful moments long after other people have moved on."),
    (5, "I need a good deal of time alone to recharge and to think."),
    (5, "I would rather understand a thing fully before I speak about it."),
    (5, "Other people's demands on my time and energy can feel like more than I have to give."),
    (5, "I collect knowledge on the subjects I care about far beyond what is practical."),
    (5, "I keep my feelings to myself and work them out privately later."),
    (6, "I tend to imagine what could go wrong so that I am ready for it."),
    (6, "I look for people and systems I can rely on, and I am loyal once I trust them."),
    (6, "I question authority, yet I also want someone reliable to check with."),
    (6, "Making a decision alone leaves me second-guessing it for a long time."),
    (6, "I feel most at ease when the plan is clear and someone has my back."),
    (7, "I get excited by new possibilities and lose interest once something becomes routine."),
    (7, "I keep several options open so that I never feel stuck."),
    (7, "When something painful comes up, I reach for a distraction or a bright side."),
    (7, "I would rather have too much on my plate than a dull, empty week."),
    (7, "People say I bring energy into a room."),
    (8, "I say what I think directly and I expect other people to do the same."),
    (8, "I step in to protect people I care about, even when nobody asked me to."),
    (8, "Being told what to do makes me want to do the opposite."),
    (8, "I make decisions quickly and take responsibility for how they turn out."),
    (8, "Showing weakness in front of others is uncomfortable for me."),
    (9, "I go along with what other people want to keep things pleasant."),
    (9, "I can see every side of a disagreement and find it hard to take one."),
    (9, "I put off tasks that matter to me while I stay busy with small comfortable ones."),
    (9, "I calm other people down just by being around them."),
    (9, "It takes me a while to know what I actually want."),
)

STATEMENTS: list[dict] = [{"id": i, "type": t, "text": text}
                          for i, (t, text) in enumerate(_RAW_STATEMENTS, start=1)]
_TYPE_OF = {s["id"]: s["type"] for s in STATEMENTS}
_TEXT_OF = {s["id"]: s["text"] for s in STATEMENTS}


def _check_seed(seed) -> int:
    if type(seed) is not int:
        raise ValueError("seed must be an integer")
    return seed


def attempt_order(seed: int) -> list[int]:
    """Statement ids in the presentation order for ``seed`` (same seed, same order)."""
    order = [s["id"] for s in STATEMENTS]
    random.Random(_check_seed(seed)).shuffle(order)
    return order


def statements_for(seed: int) -> list[dict]:
    """Statements in attempt order without their type tag."""
    return [{"id": i, "text": _TEXT_OF[i]} for i in attempt_order(seed)]


def adjacent(number: int) -> tuple[int, int]:
    return ((number - 2) % 9 + 1, number % 9 + 1)


def suggest_wing(number: int, scores: dict) -> int:
    """The adjacent type with the higher score; ties break to the lower number (9 counts as low next to 1)."""
    low, high = adjacent(number)
    return high if scores[high] > scores[low] else low


def score(answers: list, seed: int) -> dict:
    """Sum agreement per type for ``answers`` given in the attempt order of ``seed``."""
    order = attempt_order(seed)
    if not isinstance(answers, list) or len(answers) != 45:
        raise ValueError("answers must be a list of 45 ratings")
    if any(type(a) is not int or a not in SCALE for a in answers):
        raise ValueError("every answer must be an integer 1..5")
    totals = {t: 0 for t in range(1, 10)}
    for statement_id, answer in zip(order, answers):
        totals[_TYPE_OF[statement_id]] += answer
    best = max(range(1, 10), key=lambda t: (totals[t], -t))
    return {"seed": seed, "answers": list(answers),
            "scores": {str(t): totals[t] for t in range(1, 10)},
            "type": best, "wing": suggest_wing(best, totals)}


def validate_entry(number, wing, instinct) -> dict:
    if type(number) is not int or number not in range(1, 10):
        raise ValueError("type must be an integer 1..9")
    if wing is not None and (type(wing) is not int or wing not in adjacent(number)):
        raise ValueError(f"wing must be one of {adjacent(number)} for type {number}")
    if instinct is not None and instinct not in INSTINCTS:
        raise ValueError(f"instinct must be one of {INSTINCTS}")
    return {"type": number, "wing": wing, "instinct": instinct}


def type_card(number: int, wing: int | None, instinct: str | None) -> dict:
    entry = validate_entry(number, wing, instinct)
    label = f"Type {number}" + (f"w{wing}" if wing else "")
    return {**entry, "label": label, **TYPES[number]}
