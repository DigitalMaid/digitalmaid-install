# Operations

## Health
- `GET /healthz` → `{"status":"ok","schema_version":N}`; unauthenticated, nothing else disclosed. `scripts/healthcheck.sh [BASE_URL]` wraps it for cron/systemd/uptime monitors.
- Settings and Connections (UI) shows worker heartbeats (`alive` uses `2 × interval` / `2 × lease/3` + 5 s staleness), agent configuration status, last backup and declared connections.
- `GET /api/workers` (authenticated) exposes the same heartbeat rows.

## Logs
- `serve` logs to stdout (uvicorn). With systemd: `journalctl -u digitalmaid -f`; with nohup, the redirected file.
- `worker --loop` prints one JSON summary per tick: `planned, claimed, succeeded, blocked, failed, lost`.
- Audit trail per record: `audit_events` (`Store.audit_trail(entity_type, id)`), actors are usernames, `worker:<id>` or `scheduler`.
- Nothing logs credentials; transport errors are redacted before they reach an execution record.

## Backup and restore (ADR-007)
- Backup: `digitalmaid backup --root ROOT --out FILE.tar.gz`. Uses the SQLite online backup API into a temp copy (never a raw copy of the live DB), tars it with `outputs/`, `captures/`, `definitions/`, `knowledge/`, `attachments/`, `workspace.json` and `MANIFEST.json` (sha256 per file, schema and app version). Records `last_backup_at`/`last_backup_path` in `workspace.json`. A backup **must** include `captures/` — capture rows reference those blobs by path and hash; the restore round-trip with an uploaded file is tested (`test_backup_cli.py`).
- Disk growth: `captures/<scope>/<id>/original.<ext>` holds every uploaded original, immutable and never deleted by the app (archiving a capture hides it, nothing more). Growth is bounded only by `capture_max_bytes` per upload (default 25 MB, `workspace.json`) times the number of uploads; watch the directory with `du -sh ROOT/captures` and size the backup target accordingly. Interrupted uploads can leave `*.staging` files or a blob without a row; they are never removed automatically.
- Verify: `digitalmaid backup --verify FILE` re-hashes without restoring.
- JOH (0.5.0): the Journey of Humanity tables (`joh_profiles`, `joh_enneagram_attempts`, `joh_guidance`, migration 13) live in the same `state.sqlite`, so every backup carries them and a restore brings the profile back unchanged (`tests/test_joh_store.py::test_profile_survives_backup_and_restore`). The profile holds a birth date, place and coordinates — personal data; treat backup archives accordingly.
- Restore: `digitalmaid restore --archive FILE --root NEWROOT`. Refuses a non-empty root, verifies every hash, refuses a manifest `schema_version` newer than the app, extracts with the `data` tar filter, then applies pending migrations. Switch authority to the restored root only after the old `serve` and `worker` have stopped; never run two live servers on copies of the same workspace.
- Secrets are not in backups by design (credentials are environment variables). After restoring on a new host, set the variable again ("explicit reconnect").

## Upgrade
1. Stop `worker`, then `serve`.
2. Backup (above).
3. `git pull` / install the new version into `.venv` (`uv pip install -e .`).
4. `digitalmaid migrate --root ROOT --preview` lists pending migrations with a summary; nothing is applied.
5. `digitalmaid migrate --root ROOT` applies them (or simply start `serve`, which migrates on open). Migrations are journaled in `schema_migrations`.
6. Start `serve`, check `/healthz` reports the new `schema_version`, start `worker`.
Rollback = restore the pre-upgrade backup into a fresh root with the previous app version.

## Recovery when a worker dies mid-lease
- A claimed occurrence holds `lease_until` and a fencing token. If the worker dies, its heartbeat goes stale (Settings/Automations show "no worker running") and the lease expires after `--lease-seconds` (default 120).
- The next `worker --loop` tick (or `worker --once`) re-claims the due occurrence with a higher fencing token; the dead worker's late completion, if it ever arrives, is refused (`ConflictError`) and counted as `lost`.
- Any execution left `running` belongs to the interrupted attempt; the task stays in Do with no output version. Review it in the task drawer and record an execution status of `interrupted` or `uncertain` if a side effect may have happened. Non-idempotent external actions are never retried blindly.
- Orphaned blobs (a file under `outputs/` with no row) are listed by `Store.orphaned_blobs()`; they are never deleted automatically.

## Users
- `digitalmaid user create --root ROOT --username U --scope S --role owner|member|viewer` (password prompted, or `--password-stdin`), `user list`, `user disable --username U`.
- The last enabled owner of a scope cannot be disabled. Disabling a user deletes their sessions immediately.
- Login is rate-limited to 10 failures per username per 15 minutes (in memory, per process).

## Uninstall (0.3.0)
Two ways, same script. Both keep the workspace unless purge is chosen.
- **From the app** (owner only): Settings → "Uninstall DigitalMaid" → "Uninstall…", re-enter the password,
  type `UNINSTALL`, optionally tick "Also erase my data, backups and account". The app never gets root: on
  202 it only writes `$DIGITALMAID_UNINSTALL_DIR/request.json` (atomic tmp + rename; `{"purge", "requested_by",
  "at", "version"}`) and records an audit event `uninstall:request` on the workspace. The installer sets
  `Environment=DIGITALMAID_UNINSTALL_DIR=PREFIX/uninstall` in `digitalmaid.service` and adds that directory to
  `ReadWritePaths`; without the variable (or a non-writable directory) `GET /api/settings` reports
  `uninstall.available=false`, `POST /api/uninstall` answers 409 and the button is not shown.
- **The watcher**: `digitalmaid-uninstall.path` (`PathExists=PREFIX/uninstall/request.json`) starts the oneshot
  `digitalmaid-uninstall.service`, which runs `PREFIX/bin/digitalmaid-uninstall --from-request FILE` — as root
  in system installs (no `User=`), as the user in `systemd --user` installs. macOS (launchd) has no watcher, so
  the variable is not set there and the button stays hidden; use the command line.
- **From the shell**: `digitalmaid-uninstall` (system) or `PREFIX/bin/digitalmaid-uninstall` (user); `--purge`
  also removes the workspace (and, as root, the `digitalmaid` user and the Caddy block).
- `--from-request FILE` reads `purge` from the file with the venv's Python *before* the venv is deleted
  (unreadable → keep data). The script first copies itself to a temp file and re-executes from there
  (`DIGITALMAID_UNINSTALL_RELAUNCHED=1` guards recursion) because it deletes its own directory. It stops and
  disables the two app services and the `.path` unit, removes all four unit files, restores the Caddyfile,
  removes the `/usr/local/bin` symlinks and `PREFIX/{app,venv,bin,uninstall,uv,python,cache,home,scope}`.
- Brute force: password re-entry uses the login limiter (10 failures / 15 min per username → 429 on both
  `/api/uninstall` and `/api/auth/login`).

## Inside Hermes (0.3.0, `--hermes`)
- Environment the installer sets: `DIGITALMAID_INSTALL_MODE=system|user` (unit `Environment=`; Settings uses it for
  the one-paste command) and `DIGITALMAID_TRUSTED_PROXY_SECRET` from `EnvironmentFile=-PREFIX/hermes.env` (0600,
  owned by the service user; never inside a unit file). `PREFIX/hermes-secret` is the canonical copy;
  `HERMES_HOME/plugins/digitalmaid/secret` is the Hermes-side copy (0600, owned by the Hermes home's owner).
- Rotate the secret: delete `PREFIX/hermes-secret` and re-run the installer with `--hermes`; restart
  `digitalmaid.service` and the Hermes dashboard. Disable trusted sign-in: remove `PREFIX/hermes.env` (or the
  variable) and restart `digitalmaid.service` — the tab then shows DigitalMaid's own login form.
- Audit: every trusted sign-in is `auth:trusted_login` on the workspace with the owner as actor; sessions carry
  `trusted=1` (migration 12). `GET /api/settings → hermes` tells whether the proxy is configured and whether the
  current session came through it.
- The uninstaller removes `HERMES_HOME/plugins/digitalmaid` and both secret files but leaves `config.yaml` alone
  (it prints a reminder to drop `digitalmaid` from `plugins.enabled`). Nothing here ever restarts Hermes.

## Journey of Humanity (0.5.0)
JOH is off by default and per user (Settings → Journey of Humanity). The only network egress in the feature is the birthplace lookup: `POST /api/joh/geocode` sends the typed city and country (nothing else) to `https://nominatim.openstreetmap.org` with User-Agent `DigitalMaid-Agentic-OS/<version> (joh)`, 8 s timeout, 10 requests per minute per user; users may enter latitude/longitude/timezone by hand instead. Charts are computed offline from the bundled ephemeris (`digitalmaid/joh/ephemeris.bin`, 1900–2099). Compass answers go through the same provider transport, Money gate and cost recording as live agents (agent `pi-chief-of-staff`); with no credential configured the page says so and makes no call. Profiles, enneagram attempts and guidance history live in the workspace database and are included in `backup`.

## Languages (0.5.1) — how to add one
1. `digitalmaid/i18n.py`: add the code to `LANGUAGES` and its native name to `LANGUAGE_NAMES`; `negotiate()` needs nothing else.
2. UI catalogue: copy `digitalmaid/ui/locales/en.json` to `<code>.json` and translate every value (same keys, same `{placeholders}`, plural objects keep `one`/`other`). `UI_FILES` picks the file up from `LANGUAGES`.
3. JOH catalogue: copy `digitalmaid/joh/locales/en.json` to `<code>.json` and translate (lists keep their length).
4. Compass: add the language's "Chart in the room" heading to `joh/i18n.py` `CHART_HEADINGS` and the nine section titles to `compass.py` `SECTION_TITLES`.
5. `digitalmaid/ui/i18n.js`: add the BCP-47 tag to `INTL_TAGS`; if the script needs its own font, add the files under `fonts/`, the `@font-face` rules (a separate sheet if large), an `html[lang=<code>]` block in `app.css`, and the code to the `CJK` set (or a new set) in `i18n.js`.
6. Run `pytest tests/test_i18n.py tests/test_i18n_catalogue.py tests/test_joh_i18n.py tests/test_ui_browser_i18n.py` — they refuse an incomplete catalogue — and add the language to the screenshot test. Users pick the language in Settings; no server restart is needed beyond deploying the files.
