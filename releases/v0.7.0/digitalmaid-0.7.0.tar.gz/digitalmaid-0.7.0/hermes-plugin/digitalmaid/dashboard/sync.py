"""Hermes → DigitalMaid sync, stage 1 (0.7.0): the readers that run inside Hermes.

Everything here is stdlib only and read-only. It reads the Hermes home (``cron/jobs.json``,
``kanban.db``, ``memories/``, ``skills/``, the workspace) and asks the Composio CLI — with
Hermes's own login — for the next 60 days of calendar and the last 7 days of mail. It never
opens ``.env``, ``config.yaml``, ``auth.json``, sessions or chat history, and never sees a
DigitalMaid credential: the plugin API forwards the collected payload upstream with the proxy
secret (``plugin_api.py``).

Every reader returns one *source*::

    {"key", "label", "available", "reason", "count",
     "items": [{"external_id", "id", "title", "subtitle", "ticked", "payload"}]}

``payload`` is the exact item DigitalMaid's ``POST /api/hermes-sync`` validates. A source that
cannot be read (missing CLI, missing file, timeout) is *unavailable*: count 0 plus a reason —
never an exception to the caller.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import quote

SOURCES = ("cron", "kanban", "calendar", "email", "memory", "skills", "files")
LABELS = {"cron": "Cron jobs", "kanban": "Kanban tasks", "calendar": "Calendar (60 days)",
          "email": "Emails (7 days)", "memory": "Memory", "skills": "Skills", "files": "Files"}
COMPOSIO_TIMEOUT = 30.0
CALENDAR_DAYS = 60
EMAIL_QUERY = "newer_than:7d -category:promotions"
EMAIL_MAX = 100
FILES_MAX_DEPTH = 3
FILES_MAX = 500
MEMORY_SEPARATOR = "§"
MEMORY_FILES = ("MEMORY.md", "USER.md")
_URGENT = re.compile(r"\b(urgent|asap|deadline)\b", re.IGNORECASE)
_ACTION = re.compile(r"\?|\b(please|can you|could you|need)\b", re.IGNORECASE)
_FRONTMATTER_KEY = re.compile(r"^([A-Za-z_][\w-]*)\s*:\s*(.*)$")


class SourceUnavailable(Exception):
    """A reader could not reach its source; the message is shown as the reason."""


# -- home and config ---------------------------------------------------------------------------

def hermes_home(config: dict) -> Path:
    """``hermes_home`` from the plugin config, else ``$HERMES_HOME``, else the directory that
    holds ``plugins/`` (this file lives at ``<home>/plugins/digitalmaid/dashboard/sync.py``)."""
    value = config.get("hermes_home") or os.environ.get("HERMES_HOME")
    if value:
        return Path(str(value)).expanduser()
    return Path(__file__).resolve().parents[3]


def workspace_dir(config: dict, home: Path) -> Path:
    value = config.get("workspace_dir")
    return Path(str(value)).expanduser() if value else home / "workspace"


def composio_account(config: dict) -> Optional[str]:
    value = config.get("composio_account")
    return str(value) if value else None


# -- Composio runner (injectable; tests never reach the real CLI) -------------------------------------

def run_composio(tool: str, args: dict, account: Optional[str] = None,
                 timeout: float = COMPOSIO_TIMEOUT) -> dict:
    argv = ["composio", "execute", tool]
    if account:
        argv += ["--account", account]
    argv += ["-d", json.dumps(args)]
    try:
        done = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
    except FileNotFoundError:
        raise SourceUnavailable("composio CLI not found on this machine") from None
    except subprocess.TimeoutExpired:
        raise SourceUnavailable(f"composio {tool} timed out after {int(timeout)} s") from None
    if done.returncode != 0:
        detail = (done.stderr or done.stdout or "").strip().splitlines()
        raise SourceUnavailable(f"composio {tool} failed ({done.returncode}): "
                                + (detail[-1] if detail else "no output"))
    try:
        data = json.loads(done.stdout)
    except ValueError:
        raise SourceUnavailable(f"composio {tool} returned no JSON") from None
    return data if isinstance(data, dict) else {"data": data}


RUNNER: Callable[..., dict] = run_composio


def _source(key: str, items: list[dict], available: bool = True, reason: Optional[str] = None) -> dict:
    return {"key": key, "label": LABELS[key], "available": available, "reason": reason,
            "count": len(items), "items": items}


def _unavailable(key: str, reason: str) -> dict:
    return _source(key, [], available=False, reason=reason)


def _item(source: str, item_id: str, title: str, subtitle: str, payload: dict, ticked: bool = True) -> dict:
    return {"external_id": f"hermes:{source}:{item_id}", "id": item_id, "title": title,
            "subtitle": subtitle, "ticked": ticked, "payload": payload}


def _text(value) -> Optional[str]:
    if value is None:
        return None
    return value if isinstance(value, str) else str(value)


def _iso(value) -> Optional[str]:
    """Hermes stores mixed timestamps (ISO strings, epoch seconds); normalise to ISO text."""
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return datetime.fromtimestamp(float(value), tz=timezone.utc).isoformat()
    return str(value)


# -- file-based readers -----------------------------------------------------------------------------------

def read_cron(home: Path) -> dict:
    path = home / "cron" / "jobs.json"
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except OSError:
        return _unavailable("cron", f"{path} not found")
    except ValueError:
        return _unavailable("cron", f"{path} is not valid JSON")
    if isinstance(raw, dict) and isinstance(raw.get("jobs"), (dict, list)):
        raw = raw["jobs"]
    if isinstance(raw, dict):
        entries = [(str(k), v) for k, v in raw.items() if isinstance(v, dict)]
    elif isinstance(raw, list):
        entries = [(str(v.get("id", i)), v) for i, v in enumerate(raw) if isinstance(v, dict)]
    else:
        return _unavailable("cron", f"{path} has an unexpected shape")
    items = []
    for job_id, job in entries:
        name = _text(job.get("name")) or f"Job {job_id}"
        payload = {"id": job_id, "name": name, "prompt": _text(job.get("prompt")),
                   "schedule": _text(job.get("schedule")) or "",
                   "schedule_display": _text(job.get("schedule_display")),
                   "enabled": bool(job.get("enabled", True)),
                   "next_run_at": _iso(job.get("next_run_at")), "last_run_at": _iso(job.get("last_run_at")),
                   "last_status": _text(job.get("last_status"))}
        subtitle = payload["schedule_display"] or payload["schedule"]
        if not payload["enabled"]:
            subtitle = (subtitle + " · " if subtitle else "") + "disabled"
        items.append(_item("cron", job_id, name, subtitle, payload))
    return _source("cron", items)


def read_kanban(home: Path) -> dict:
    path = home / "kanban.db"
    if not path.is_file():
        return _unavailable("kanban", f"{path} not found")
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except sqlite3.Error as exc:
        return _unavailable("kanban", f"cannot open {path}: {exc}")
    try:
        conn.row_factory = sqlite3.Row
        columns = {r["name"] for r in conn.execute("PRAGMA table_info(tasks)")}
        if not columns:
            return _unavailable("kanban", f"{path} has no tasks table")
        wanted = ["id", "title", "body", "status", "priority", "project_id", "created_at", "completed_at"]
        select = ", ".join(c if c in columns else f"NULL AS {c}" for c in wanted)
        rows = conn.execute(f"SELECT {select} FROM tasks ORDER BY created_at, id").fetchall()
        projects = {}
        try:
            for r in conn.execute("SELECT id, name FROM projects"):
                projects[str(r["id"])] = _text(r["name"])
        except sqlite3.Error:
            pass
    except sqlite3.Error as exc:
        return _unavailable("kanban", f"cannot read {path}: {exc}")
    finally:
        conn.close()
    items = []
    for r in rows:
        task_id = str(r["id"])
        project_id = _text(r["project_id"])
        priority = r["priority"]
        payload = {"id": task_id, "title": _text(r["title"]) or f"Task {task_id}", "body": _text(r["body"]),
                   "status": _text(r["status"]) or "todo",
                   "priority": priority if isinstance(priority, int) else _text(priority),
                   "project_id": project_id, "project_title": projects.get(project_id) if project_id else None,
                   "created_at": _iso(r["created_at"]), "completed_at": _iso(r["completed_at"])}
        subtitle = payload["status"] + (f" · {payload['project_title']}" if payload["project_title"] else "")
        items.append(_item("kanban", task_id, payload["title"], subtitle, payload))
    return _source("kanban", items)


def read_memory(home: Path) -> dict:
    items = []
    seen_any = False
    for name in MEMORY_FILES:
        path = home / "memories" / name
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        seen_any = True
        for entry in text.split(MEMORY_SEPARATOR):
            entry = entry.strip()
            if not entry:
                continue
            digest = hashlib.sha1(entry.encode("utf-8")).hexdigest()[:10]
            entry_id = f"{path.stem.lower()}-{digest}"
            first = next((line.strip() for line in entry.splitlines() if line.strip()), entry)
            payload = {"id": entry_id, "text": entry, "source": name}
            items.append(_item("memory", entry_id, first[:120], name, payload))
    if not seen_any:
        return _unavailable("memory", f"{home / 'memories'} has no MEMORY.md or USER.md")
    return _source("memory", items)


def parse_frontmatter(text: str) -> dict:
    """``key: value`` lines between the leading ``---`` fences; no YAML library needed for the two
    keys we read (name, description). Quoted values lose their quotes."""
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}
    fields = {}
    for line in lines[1:]:
        if line.strip() == "---":
            break
        match = _FRONTMATTER_KEY.match(line)
        if match:
            value = match.group(2).strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            fields[match.group(1)] = value
    return fields


def read_skills(home: Path) -> dict:
    root = home / "skills"
    if not root.is_dir():
        return _unavailable("skills", f"{root} not found")
    items = []
    for path in sorted(root.rglob("SKILL.md")):
        if any(part.startswith(".") for part in path.relative_to(root).parts):
            continue
        try:
            front = parse_frontmatter(path.read_text(encoding="utf-8"))
        except OSError:
            continue
        name = front.get("name") or path.parent.name
        payload = {"id": name, "name": name, "description": front.get("description") or None}
        items.append(_item("skills", name, name, payload["description"] or "", payload))
    return _source("skills", items)


def read_files(home: Path, config: dict, base_url: str) -> dict:
    root = workspace_dir(config, home)
    if not root.is_dir():
        return _unavailable("files", f"{root} not found")
    items = []
    truncated = False
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if len(relative.parts) > FILES_MAX_DEPTH or any(p.startswith(".") for p in relative.parts):
            continue
        if not path.is_file() or path.is_symlink():
            continue
        if len(items) >= FILES_MAX:
            truncated = True
            break
        stat = path.stat()
        rel = relative.as_posix()
        payload = {"id": rel, "path": rel, "size": stat.st_size,
                   "mtime": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
                   "url": base_url.rstrip("/") + "/api/files/download?path=" + quote(rel, safe="")}
        items.append(_item("files", rel, path.name, f"{rel} · {stat.st_size} bytes", payload))
    source = _source("files", items)
    if truncated:
        source["reason"] = f"only the first {FILES_MAX} files are listed"
    return source


# -- Composio readers ----------------------------------------------------------------------------------------

def _records(response: dict) -> list[dict]:
    """Composio wraps results differently per tool version; take the first list of records."""
    def walk(node, depth=0):
        if isinstance(node, list):
            if node and all(isinstance(n, dict) for n in node):
                return node
            return []
        if isinstance(node, dict) and depth < 4:
            for value in node.values():
                found = walk(value, depth + 1)
                if found:
                    return found
        return []
    return walk(response.get("data", response))


def _when(node) -> tuple[Optional[str], bool]:
    if isinstance(node, dict):
        if node.get("dateTime"):
            return str(node["dateTime"]), False
        if node.get("date"):
            return str(node["date"]), True
        return None, False
    return (_text(node), False) if node else (None, False)


def read_calendar(runner: Callable[..., dict], account: Optional[str], now: Optional[datetime] = None) -> dict:
    now = now or datetime.now(timezone.utc)
    args = {"calendarId": "primary", "timeMin": now.isoformat(), "singleEvents": True,
            "timeMax": (now + timedelta(days=CALENDAR_DAYS)).isoformat(), "maxResults": 250}
    try:
        response = runner("GOOGLECALENDAR_EVENTS_LIST", args, account)
    except SourceUnavailable as exc:
        return _unavailable("calendar", str(exc))
    items = []
    for record in _records(response):
        event_id = _text(record.get("id"))
        start, all_day = _when(record.get("start"))
        if not event_id or not start:
            continue
        end, _ = _when(record.get("end"))
        title = _text(record.get("summary")) or "(untitled event)"
        payload = {"id": event_id, "title": title, "start": start, "end": end,
                   "location": _text(record.get("location")), "all_day": all_day}
        items.append(_item("calendar", event_id, title, start[:16].replace("T", " "), payload))
    return _source("calendar", items)


def email_tier(subject: str, snippet: str, starred: bool) -> str:
    if starred or _URGENT.search(subject or ""):
        return "urgent"
    if _ACTION.search(subject or "") or _ACTION.search(snippet or ""):
        return "action"
    return "info"


def read_email(runner: Callable[..., dict], account: Optional[str]) -> dict:
    args = {"query": EMAIL_QUERY, "max_results": EMAIL_MAX}
    try:
        response = runner("GMAIL_FETCH_EMAILS", args, account)
    except SourceUnavailable as exc:
        return _unavailable("email", str(exc))
    items = []
    for record in _records(response)[:EMAIL_MAX]:
        message_id = _text(record.get("messageId") or record.get("id") or record.get("threadId"))
        if not message_id:
            continue
        subject = _text(record.get("subject")) or "(no subject)"
        snippet = _text(record.get("snippet") or record.get("preview") or record.get("messageText")) or ""
        sender = _text(record.get("sender") or record.get("from"))
        labels = record.get("labelIds") or []
        starred = isinstance(labels, list) and "STARRED" in labels
        tier = email_tier(subject, snippet, starred)
        payload = {"id": message_id, "subject": subject, "snippet": snippet[:500], "sender": sender,
                   "date": _iso(record.get("messageTimestamp") or record.get("date")), "tier": tier}
        subtitle = tier.capitalize() + (f" · {sender}" if sender else "")
        items.append(_item("email", message_id, subject, subtitle, payload, ticked=tier != "info"))
    return _source("email", items)


# -- assembling --------------------------------------------------------------------------------------------

def collect(config: dict, base_url: str, runner: Optional[Callable[..., dict]] = None) -> dict:
    """Every source, in the fixed order; ``collected_at`` is now."""
    home = hermes_home(config)
    run = runner or RUNNER
    account = composio_account(config)
    sources = [read_cron(home), read_kanban(home), read_calendar(run, account), read_email(run, account),
               read_memory(home), read_skills(home), read_files(home, config, base_url)]
    return {"sources": sources, "collected_at": datetime.now(timezone.utc).isoformat(),
            "hermes_home": str(home)}


def preview(collected: dict) -> dict:
    """The preview shape of H1 — the payloads stay behind."""
    return {"collected_at": collected["collected_at"], "hermes_home": collected["hermes_home"],
            "sources": [{"key": s["key"], "label": s["label"], "available": s["available"],
                         "reason": s["reason"], "count": s["count"],
                         "items": [{k: i[k] for k in ("external_id", "title", "subtitle", "ticked")}
                                   for i in s["items"]]} for s in collected["sources"]]}


def build_payload(collected: dict, selected) -> dict:
    """``selected`` is ``"all"`` or ``{source_key: [external_id, …]}``. Unavailable sources are left
    out entirely (so DigitalMaid never tags their items gone); available ones always contribute
    their full inventory, selected or not."""
    sources: dict[str, list] = {}
    inventory: dict[str, list] = {}
    for source in collected["sources"]:
        if not source["available"]:
            continue
        key = source["key"]
        inventory[key] = [i["id"] for i in source["items"]]
        if selected == "all":
            chosen = source["items"]
        else:
            wanted = set((selected or {}).get(key) or [])
            chosen = [i for i in source["items"] if i["external_id"] in wanted]
        sources[key] = [i["payload"] for i in chosen]
    return {"collected_at": collected["collected_at"], "sources": sources, "inventory": inventory}
