# DigitalMaid as a Hermes dashboard tab

`hermes-plugin/digitalmaid/` is a [Hermes Agent](https://hermes-agent.nousresearch.com/docs)
dashboard plugin. Installed, it adds a **DigitalMaid** tab (after *Skills*) to the Hermes
dashboard that shows the DigitalMaid web app running on the same machine, proxied through
Hermes's own login. The DigitalMaid port stays on loopback.

## The easy way

Run the one-command installer with `--hermes` on the machine that runs Hermes:

```bash
curl -fsSL https://raw.githubusercontent.com/DigitalMaid/digitalmaid-install/main/install.sh | bash -s -- --hermes
```

(as `root` on a server where DigitalMaid runs as a system service; add `--hermes-home DIR` if
Hermes's home is not `~/.hermes`). It installs the app, copies this folder to
`$HERMES_HOME/plugins/digitalmaid`, generates the shared secret, enables the plugin in Hermes's
`config.yaml`, and tells you to restart the Hermes dashboard. It never restarts Hermes itself.

## Manual install

1. Copy this folder: `cp -r hermes-plugin/digitalmaid ~/.hermes/plugins/digitalmaid`
2. Create a secret (≥ 32 characters) readable by the Hermes user only:
   `openssl rand -hex 32 > ~/.hermes/plugins/digitalmaid/secret && chmod 600 ~/.hermes/plugins/digitalmaid/secret`
3. Tell the plugin where the app is and where the secret lives —
   `~/.hermes/plugins/digitalmaid/dashboard/config.json`:
   ```json
   {"upstream": "http://127.0.0.1:8765", "secret_file": "/home/you/.hermes/plugins/digitalmaid/secret"}
   ```
   Optional keys for *Sync from Hermes* (0.7.0, `dashboard/sync.py`): `hermes_home` (default: the
   directory holding `plugins/`, or `$HERMES_HOME`), `workspace_dir` (default
   `<hermes_home>/workspace`) and `composio_account` (default: none — `--account` is omitted when
   the plugin calls `composio execute …`). See docs/HERMES-INTEGRATION.md §7.
4. Give DigitalMaid the same secret: put `DIGITALMAID_TRUSTED_PROXY_SECRET=<the value>` in a
   file the service reads (`EnvironmentFile=` in `digitalmaid.service`, mode 0600) and restart
   `digitalmaid.service`. Without it the tab still works, but shows DigitalMaid's own login form.
5. Enable the plugin in Hermes's `config.yaml`:
   ```yaml
   plugins:
     enabled: [digitalmaid]
   ```
6. Restart the Hermes dashboard. The tab appears at `/digitalmaid`.

## How sign-in works (and its trade-off)

Inside the tab you are signed in automatically as the DigitalMaid **owner** (the oldest enabled
owner of the served scope): one login — Hermes's — instead of two. Every proxied request carries
`X-DigitalMaid-Proxy-Auth: <secret>`; the browser can never supply that header (the proxy
strips it), and DigitalMaid honours it only from 127.0.0.1. `POST /api/auth/trusted` then mints
an ordinary session flagged *trusted* and records `auth:trusted_login` in the audit log.

The trade-off: everyone who can open your Hermes dashboard acts as that owner, and
DigitalMaid's per-user audit trail collapses to one name inside the tab. If several people
share the Hermes dashboard and you need per-person accountability, leave the secret unset
and sign in with individual DigitalMaid accounts.

## What the proxy does

- `GET /api/plugins/digitalmaid/health` → upstream `/api/healthz` plus `trusted_proxy: bool`.
- `GET /api/plugins/digitalmaid/ui` → 307 to `/ui/` (the app's asset URLs are relative).
- `ANY /api/plugins/digitalmaid/ui/{path}` → upstream `/{path}`: hop headers dropped, only the
  `dm_session` cookie forwarded (never Hermes's cookies), `Origin` checked here and rewritten,
  `Set-Cookie` re-scoped to `Path=/api/plugins/digitalmaid/`, HTML gets
  `<meta name="dm-trusted" content="1">` when a secret is available, and the response is
  framed by `frame-ancestors 'self'` only.
