"""DigitalMaid Agentic OS core package."""

__version__ = "0.7.0"
