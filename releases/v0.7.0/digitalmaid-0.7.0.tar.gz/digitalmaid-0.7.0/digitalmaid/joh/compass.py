"""The Compass: a profile brief for prompts, the guidance message contracts, strip parsing."""

import re

from digitalmaid.i18n import LANGUAGE_NAMES
from digitalmaid.joh.enneagram import TYPES, type_card
from digitalmaid.joh.genekeys import PRIME_GIFTS
from digitalmaid.joh.i18n import CHART_HEADINGS
from digitalmaid.joh.sidereal import check_zodiac

KINDS = ("email", "decision", "question")
MAX_BRIEF_LINES = 60
TIME_UNKNOWN_NOTE = ("Time unknown — Moon, houses, and any gate near a boundary are approximate;"
                     " lean on the Sun, the Earth and the Human Design type, not on the Rising sign.")

SYSTEM_LEAD = (
    "You are the Compass inside DigitalMaid Agentic OS. You advise one person whose profile"
    " follows. Ground every suggestion in that profile and say which part you are leaning on"
    " (name the sphere, the authority, the enneagram pattern). Prefer the Gift frequency over"
    " the Shadow; name the Shadow only to help them notice it. Give practical wording or steps,"
    " not horoscopes. Never predict events, health, or money outcomes; never claim certainty;"
    " the person decides. Reply in Markdown with these sections:")

SECTIONS = {
    "email": (
        ("Read", "what the email is really asking, seen through the profile"),
        ("Reply", "a complete draft in the person's voice that respects their Human Design"
                  " strategy and authority — a Projector waits to be invited before pushing, an"
                  " emotional authority sleeps on anything heated, a sacral authority answers"
                  " from a plain yes or no, a Manifestor informs before acting"),
        ("Watch for", "the Shadow pattern most likely to hijack this exchange"),
        ("Chart in the room", "a bullet list of exactly the profile facts you used"),
    ),
    "decision": (
        ("Frame", "the decision in one plain paragraph, stakes included"),
        ("Through your chart", "one paragraph per relevant sphere, authority or type"),
        ("A way to decide", "one concrete step that matches the authority — sacral yes/no"
                            " questions, a 24-hour emotional wave, a lunar cycle for a Reflector,"
                            " speaking it aloud for a self-projected authority"),
        ("If you go ahead", "what to protect and what to watch"),
        ("If you don't", "what to protect and what to watch"),
        ("Chart in the room", "a bullet list of exactly the profile facts you used"),
    ),
    "question": (
        ("Answer", "the answer, grounded in the profile"),
        ("Chart in the room", "a bullet list of exactly the profile facts you used"),
    ),
}

# Section titles in the user's language (0.5.1). The strip heading is the last row of each
# contract and must be parseable, so the parser accepts every language's heading below.
SECTION_TITLES = {
    "vi": {"Read": "Đọc", "Reply": "Trả lời", "Watch for": "Cần để ý", "Frame": "Khung",
           "Through your chart": "Qua biểu đồ của bạn", "A way to decide": "Một cách để quyết định",
           "If you go ahead": "Nếu bạn tiến hành", "If you don't": "Nếu bạn không", "Answer": "Trả lời"},
    "zh": {"Read": "解读", "Reply": "回复", "Watch for": "留意", "Frame": "框定",
           "Through your chart": "透过你的星盘", "A way to decide": "一种决定的方法",
           "If you go ahead": "如果你继续", "If you don't": "如果你不", "Answer": "回答"},
    "fr": {"Read": "Lecture", "Reply": "Réponse", "Watch for": "À surveiller", "Frame": "Cadre",
           "Through your chart": "À travers votre carte", "A way to decide": "Une façon de décider",
           "If you go ahead": "Si vous y allez", "If you don't": "Si vous n'y allez pas", "Answer": "Réponse"},
    "ja": {"Read": "読み解き", "Reply": "返信", "Watch for": "注意点", "Frame": "枠組み",
           "Through your chart": "あなたのチャートを通して", "A way to decide": "決め方のひとつ",
           "If you go ahead": "進める場合", "If you don't": "進めない場合", "Answer": "答え"},
}
LANGUAGE_INSTRUCTION = ("Reply in {name}; keep Gene Keys / Human Design / Enneagram terms bilingual:"
                        " <local> (<English>) on first mention.")


def section_title(title: str, language: str = "en") -> str:
    if title == "Chart in the room":
        return CHART_HEADINGS.get(language, CHART_HEADINGS["en"])
    return SECTION_TITLES.get(language, {}).get(title, title)


_HEADINGS_ALT = "|".join(re.escape(h) for h in CHART_HEADINGS.values())
_HEADING_RE = re.compile(r"^\s*(?:#{1,6}\s*|\*\*)\s*(?:" + _HEADINGS_ALT + r")\s*[:：]?\s*(?:\*\*)?\s*$", re.I)
_BULLET_RE = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+(.*\S)\s*$")
_ANY_HEADING_RE = re.compile(r"^\s*#{1,6}\s+\S")


def _degrees(record: dict) -> str:
    return f"{record['sign']} {record['degree']}°{record['minute']:02d}′"


def _zodiac_label(zodiac: str) -> str:
    return "Sidereal (Lahiri)" if zodiac == "sidereal" else "Tropical"


def _enneagram_lines(profile: dict) -> list[str]:
    number = profile.get("enneagram_type")
    if not number:
        return ["Enneagram: not set."]
    card = type_card(number, profile.get("enneagram_wing"), profile.get("enneagram_instinct"))
    label = card["label"] + (f" ({card['instinct']})" if card["instinct"] else "")
    return [
        f"Enneagram: {label} — {card['name']}. Fear: {card['core_fear']}."
        f" Desire: {card['core_desire']}.",
        f"  Proposition: {card['basic_proposition']}",
        f"  Arrows: growth {card['growth_arrow']} ({TYPES[card['growth_arrow']]['name']}),"
        f" stress {card['stress_arrow']} ({TYPES[card['stress_arrow']]['name']})."
        f" Keywords: {', '.join(card['keywords'])}.",
    ]


def profile_brief(profile: dict) -> str:
    """≤ 60 plain-text lines: the whole profile in the chosen zodiac; day and place, never the minute."""
    zodiac = check_zodiac(profile.get("zodiac") or "sidereal")
    computed = profile["computed"]
    block = computed[zodiac]
    chart, body, keys = block["astro"], block["humandesign"], block["genekeys"]
    time_known = bool(profile.get("time_known", computed["birth"]["time_known"]))
    place = profile.get("place_display") or "an unrecorded place"
    lines = [
        f"Journey of Humanity profile — zodiac: {_zodiac_label(zodiac)}"
        + (" (the owner's choice; official Human Design and Gene Keys charts are tropical)."
           if zodiac == "sidereal" else "."),
        f"Born {profile.get('birth_date') or computed['birth']['date']} in {place}.",
    ]
    if not time_known:
        lines.append(TIME_UNKNOWN_NOTE)
    positions = chart["positions"]
    lines += [
        f"Sun {_degrees(positions['sun'])} · Moon {_degrees(positions['moon'])}"
        f" · Rising {_degrees(chart['ascendant'])}.",
        f"Human Design: {body['type']} · Profile {body['profile']} · Authority: {body['authority']}"
        f" · Definition: {body['definition']}.",
        f"  Strategy: {body['strategy']}. Not-self theme: {body['not_self_theme']};"
        f" signature: {body['signature']}.",
        f"  Incarnation cross: {body['incarnation_cross']['label']}."
        f" Defined centres: {', '.join(body['defined_centres']) or 'none'}.",
        "Gene Keys (Hologenetic Profile) — Shadow → Gift → Siddhi:",
    ]
    for sphere in keys["spheres"]:
        if sphere["sequence"] == "further":
            continue
        lines.append(f"  {sphere['sphere']} {sphere['key_line']} — {sphere['shadow']}"
                     f" → {sphere['gift']} → {sphere['siddhi']} (line: {sphere['line_theme']})")
    lines += _enneagram_lines(profile)
    if len(lines) > MAX_BRIEF_LINES:
        lines = lines[:MAX_BRIEF_LINES]
    return "\n".join(lines)


def _section_contract(kind: str, language: str = "en") -> str:
    return "\n".join(f"## {section_title(title, language)} — {rule}." for title, rule in SECTIONS[kind])


def build_compass_messages(profile: dict, kind: str, input_text: str, extra: dict | None,
                           language: str = "en") -> list[dict]:
    """System + user messages for one Compass request; English is byte-identical to 0.5.0."""
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {KINDS}, got {kind!r}")
    if not isinstance(input_text, str) or not input_text.strip():
        raise ValueError("input_text must be a non-empty string")
    extra = dict(extra or {})
    parts = [SYSTEM_LEAD, "", _section_contract(kind, language), ""]
    if language != "en":
        parts += [LANGUAGE_INSTRUCTION.format(name=LANGUAGE_NAMES.get(language, language)), ""]
    system = "\n".join(parts + ["The person's profile:", profile_brief(profile)])
    if kind == "email":
        user = ["The email to reply to:", "---", input_text.strip(), "---"]
        intent = str(extra.get("intent") or "").strip()
        if intent:
            user += ["", "What they want to say, and any constraints:", intent]
    elif kind == "decision":
        user = ["The decision, the options and the stakes:", "---", input_text.strip(), "---",
                f"Horizon: {str(extra.get('horizon') or 'not stated').strip()}"]
    else:
        user = ["The question:", "---", input_text.strip(), "---"]
    return [{"role": "system", "content": system},
            {"role": "user", "content": "\n".join(user)}]


def prime_gift_facts(profile: dict) -> list[str]:
    zodiac = check_zodiac(profile.get("zodiac") or "sidereal")
    by_name = {s["sphere"]: s for s in profile["computed"][zodiac]["genekeys"]["spheres"]}
    return [f"{name} {by_name[name]['key_line']} {by_name[name]['gift']}" for name in PRIME_GIFTS]


def parse_chart_in_the_room(markdown: str, profile: dict | None = None) -> list[str]:
    """Bullets under the *Chart in the room* heading; the four Prime Gifts when absent and a profile is given."""
    facts: list[str] = []
    lines = (markdown or "").splitlines()
    for index, line in enumerate(lines):
        if not _HEADING_RE.match(line):
            continue
        for rest in lines[index + 1:]:
            if not rest.strip():
                continue
            bullet = _BULLET_RE.match(rest)
            if bullet is None or _ANY_HEADING_RE.match(rest):
                break
            text = re.sub(r"\*\*|__|`", "", bullet.group(1)).strip()
            if text:
                facts.append(text)
        break
    if not facts and profile is not None:
        return prime_gift_facts(profile)
    return facts
