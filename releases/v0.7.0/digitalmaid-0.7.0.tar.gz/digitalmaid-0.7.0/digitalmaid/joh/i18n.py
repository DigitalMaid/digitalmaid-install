"""JOH vocabulary in the user's language (0.5.1, ADR-010).

English stays where it lives today (``genekeys_data``, ``enneagram``, ``humandesign``, ``astro``);
``english_catalogue()`` flattens it into keys, and ``joh/locales/<code>.json`` carries the same
keys in the other four languages (``en.json`` is a reference copy the tests keep equal to the
Python source). Lookups fall back to English. API views are localised *after* computation and
keep the English alongside as ``*_en`` for the spiritual vocabulary so the UI can show
"Tự do (Freedom)" on first mention. Nothing here touches the stored profile.
"""

import json
from functools import lru_cache
from pathlib import Path

from digitalmaid.i18n import LANGUAGES
from digitalmaid.joh.astro import ASPECTS, CHART_BODIES, SIGNS
from digitalmaid.joh.enneagram import STATEMENTS, TYPES
from digitalmaid.joh.genekeys import FREQUENCY_PROMPTS, LINE_THEMES, SEQUENCES, SPHERES
from digitalmaid.joh.genekeys_data import CONTEMPLATIONS, KEYS
from digitalmaid.joh.humandesign import CENTRES, TYPES as HD_TYPES

LOCALES_DIR = Path(__file__).parent / "locales"
AUTHORITIES = ("Emotional", "Sacral", "Splenic", "Ego", "Self-projected", "Mental", "Lunar")
DEFINITIONS = ("none", "single", "split", "triple", "quadruple")
ANGLES = ("Right Angle", "Left Angle", "Juxtaposition")
FREQUENCIES = {"shadow": "Shadow", "gift": "Gift", "siddhi": "Siddhi"}
SEQUENCE_NAMES = {"activation": "Activation Sequence", "venus": "Venus Sequence",
                  "pearl": "Pearl Sequence", "further": "Further spheres"}
ZODIACS = {"sidereal": "Sidereal (Lahiri)", "tropical": "Tropical"}
BODY_NAMES = {"sun": "Sun", "moon": "Moon", "mercury": "Mercury", "venus": "Venus", "mars": "Mars",
              "jupiter": "Jupiter", "saturn": "Saturn", "uranus": "Uranus", "neptune": "Neptune",
              "pluto": "Pluto", "true_node": "North Node", "south_node": "South Node", "earth": "Earth",
              "mean_node": "Mean Node", "north_node": "North Node"}
# The Compass strip heading per language; the parser accepts all five (compass.py).
CHART_HEADINGS = {"en": "Chart in the room", "vi": "Biểu đồ trong phòng", "zh": "在场的星盘",
                  "fr": "La carte dans la pièce", "ja": "この場にあるチャート"}


def english_catalogue() -> dict:
    """Every JOH string a user sees, keyed; built from the Python source of truth."""
    out: dict = {}
    for number, words in KEYS.items():
        for part in ("shadow", "gift", "siddhi"):
            out[f"key.{number}.{part}"] = words[part]
        out[f"key.{number}.contemplation"] = CONTEMPLATIONS[number]
    for statement in STATEMENTS:
        out[f"statement.{statement['id']}"] = statement["text"]
    for number, card in TYPES.items():
        for part in ("name", "core_fear", "core_desire", "basic_proposition"):
            out[f"type.{number}.{part}"] = card[part]
        out[f"type.{number}.keywords"] = list(card["keywords"])
    for name, *_ in SPHERES:
        out[f"sphere.{name}"] = name
    for seq in SEQUENCES:
        out[f"sequence.{seq}"] = SEQUENCE_NAMES[seq]
    for line, theme in LINE_THEMES.items():
        out[f"line_theme.{line}"] = theme
    for freq, word in FREQUENCIES.items():
        out[f"frequency.{freq}"] = word
        out[f"frequency_prompt.{freq}"] = FREQUENCY_PROMPTS[freq]
    for kind, facts in HD_TYPES.items():
        out[f"hd.type.{kind}"] = kind
        out[f"hd.strategy.{kind}"] = facts["strategy"]
        out[f"hd.not_self.{kind}"] = facts["not_self_theme"]
        out[f"hd.signature.{kind}"] = facts["signature"]
    for authority in AUTHORITIES:
        out[f"hd.authority.{authority}"] = authority
    for centre in CENTRES:
        out[f"hd.centre.{centre}"] = centre
    for definition in DEFINITIONS:
        out[f"hd.definition.{definition}"] = definition
    for angle in ANGLES:
        out[f"hd.angle.{angle}"] = angle
    out["hd.cross"] = "Cross"
    for sign in SIGNS:
        out[f"sign.{sign}"] = sign
    for body in CHART_BODIES + ("north_node",):
        out[f"body.{body}"] = BODY_NAMES[body]
    for name, _angle, _orb in ASPECTS:
        out[f"aspect.{name}"] = name
    for zodiac, label in ZODIACS.items():
        out[f"zodiac.{zodiac}"] = label
    return out


@lru_cache(maxsize=None)
def load_catalogue(code: str) -> dict:
    if code == "en":
        return english_catalogue()
    if code not in LANGUAGES:
        raise ValueError(f"language must be one of {LANGUAGES}")
    path = LOCALES_DIR / f"{code}.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def lookup(key: str, language: str, default=None):
    """The localised value, else English, else ``default``."""
    value = load_catalogue(language).get(key) if language != "en" else None
    if value is None:
        value = english_catalogue().get(key)
    return default if value is None else value


def _set(record: dict, field: str, key: str, language: str, keep_english: bool = True) -> None:
    """Replace ``record[field]`` with its translation; keep the English as ``<field>_en``."""
    original = record.get(field)
    if original is None:
        return
    translated = lookup(key, language, original)
    if keep_english:
        record[f"{field}_en"] = original
    record[field] = translated


def _localise_sphere(sphere: dict, language: str) -> None:
    key = sphere["key"]
    _set(sphere, "sphere", f"sphere.{sphere['sphere']}", language)
    for part in ("shadow", "gift", "siddhi"):
        _set(sphere, part, f"key.{key}.{part}", language)
    _set(sphere, "contemplation", f"key.{key}.contemplation", language, keep_english=False)
    _set(sphere, "line_theme", f"line_theme.{sphere['line']}", language, keep_english=False)


def _localise_position(record: dict, language: str) -> None:
    _set(record, "sign", f"sign.{record['sign']}", language)


def localise_card(card: dict, language: str) -> dict:
    """An enneagram type card in ``language``; the label ("Type 9w1") stays as the UI rebuilds it."""
    if language == "en":
        return card
    number = card["type"]
    _set(card, "name", f"type.{number}.name", language)
    for part in ("core_fear", "core_desire", "basic_proposition"):
        _set(card, part, f"type.{number}.{part}", language, keep_english=False)
    words = lookup(f"type.{number}.keywords", language)
    if isinstance(words, list) and len(words) == len(card.get("keywords", [])):
        card["keywords_en"] = list(card["keywords"])
        card["keywords"] = list(words)
    return card


def localise_statements(rows: list, language: str) -> list:
    if language == "en":
        return rows
    for row in rows:
        _set(row, "text", f"statement.{row['id']}", language)
    return rows


def localise_profile(view: dict, language: str) -> dict:
    """The ``profile_view`` response in ``language`` (in place); English returns it untouched."""
    if language == "en":
        return view
    block = view.get("profile") or {}
    astro = block.get("astro") or {}
    for record in (astro.get("positions") or {}).values():
        _localise_position(record, language)
    for angle in ("ascendant", "mc"):
        if isinstance(astro.get(angle), dict):
            _localise_position(astro[angle], language)
    for aspect in astro.get("aspects") or []:
        _set(aspect, "aspect", f"aspect.{aspect['aspect']}", language)
    hd = block.get("humandesign") or {}
    if hd:
        kind = hd.get("type")
        _set(hd, "type", f"hd.type.{kind}", language)
        _set(hd, "strategy", f"hd.strategy.{kind}", language, keep_english=False)
        _set(hd, "not_self_theme", f"hd.not_self.{kind}", language, keep_english=False)
        _set(hd, "signature", f"hd.signature.{kind}", language, keep_english=False)
        _set(hd, "authority", f"hd.authority.{hd.get('authority')}", language)
        _set(hd, "definition", f"hd.definition.{hd.get('definition')}", language)
        if isinstance(hd.get("defined_centres"), list):
            hd["defined_centres_en"] = list(hd["defined_centres"])
            hd["defined_centres"] = [lookup(f"hd.centre.{c}", language, c) for c in hd["defined_centres"]]
        cross = hd.get("incarnation_cross")
        if isinstance(cross, dict) and cross.get("gates"):
            gates = cross["gates"]
            cross["label_en"] = cross.get("label")
            cross["angle_en"] = cross.get("angle")
            cross["angle"] = lookup(f"hd.angle.{cross.get('angle')}", language, cross.get("angle"))
            cross["label"] = (f"{cross['angle']} {lookup('hd.cross', language, 'Cross')}"
                              f" {gates[0]}/{gates[1]} | {gates[2]}/{gates[3]}")
    keys = block.get("genekeys") or {}
    for sphere in keys.get("spheres") or []:
        _localise_sphere(sphere, language)
    for sequence in (keys.get("sequences") or {}).values():
        for sphere in sequence:
            _localise_sphere(sphere, language)
    for sphere in keys.get("prime_gifts") or []:
        _localise_sphere(sphere, language)
    if isinstance(keys.get("line_themes"), dict):
        keys["line_themes"] = {line: lookup(f"line_theme.{line}", language, theme)
                               for line, theme in keys["line_themes"].items()}
    if isinstance(keys.get("frequency_prompts"), dict):
        keys["frequency_prompts"] = {freq: lookup(f"frequency_prompt.{freq}", language, text)
                                     for freq, text in keys["frequency_prompts"].items()}
    alternate = view.get("alternate")
    if isinstance(alternate, dict):
        _set(alternate, "sun_sign", f"sign.{alternate.get('sun_sign')}", language)
        _set(alternate, "hd_type", f"hd.type.{alternate.get('hd_type')}", language)
    enneagram = view.get("enneagram")
    if isinstance(enneagram, dict) and isinstance(enneagram.get("card"), dict):
        localise_card(enneagram["card"], language)
    view["language"] = language
    return view
