"""JOH HTTP routes (docs/JOH.md §6), mounted by ``digitalmaid.api.create_app``.

Session-only: the app middleware already refuses API tokens outside ``/api/captures*`` and
demands the CSRF marker on writes, so nothing here re-checks those. Every route acts on the
*signed-in user's own* profile. The two things that leave this server — the typed place
(to OpenStreetMap) and the Compass prompt (to the model provider) — go through injectable
transports (``app.state.joh_geocode_transport``, ``app.state.joh_transport_factory``) so
tests never touch the network.
"""

import hashlib
import os

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, ConfigDict, StrictBool, StrictInt

from digitalmaid.errors import ConfigurationError
from digitalmaid.joh.compass import KINDS, build_compass_messages, parse_chart_in_the_room
from digitalmaid.joh.enneagram import SCALE, statements_for, type_card
from digitalmaid.joh.geocode import (GeocodeError, GeocodeRateLimiter, NoPlaceFound, geocode)
from digitalmaid.joh.i18n import localise_card, localise_profile, localise_statements
from digitalmaid.journey import ENNEAGRAM_SOURCES
from digitalmaid.runners import build_live_runner
from digitalmaid.transports import TransportError, credential_env_name, redact

COMPASS_AGENT_ID = "pi-chief-of-staff"
MAX_INPUT_CHARS = 12_000
# A Compass answer carries four sections plus a full email draft; the agent's deliverable budget
# (1500) truncated the first live answer mid-draft (2026-09-16). Cost stays under the Money cap.
COMPASS_MAX_TOKENS = 4000


class EnabledIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: StrictBool


class GeocodeIn(BaseModel):
    city: str
    country: str


class ProfileIn(BaseModel):
    birth_date: str
    birth_time: str | None = None
    timezone: str
    lat: float
    lon: float
    place_display: str | None = None
    country_code: str | None = None
    zodiac: str | None = None


class ZodiacIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    zodiac: str


class EnneagramAnswersIn(BaseModel):
    seed: StrictInt
    answers: list


class EnneagramIn(BaseModel):
    type: StrictInt
    wing: StrictInt | None = None
    instinct: str | None = None
    source: str


class GuidanceIn(BaseModel):
    kind: str
    input_text: str
    extra: dict | None = None


def _enneagram_view(profile: dict) -> dict | None:
    if not profile.get("enneagram_type"):
        return None
    return {"type": profile["enneagram_type"], "wing": profile["enneagram_wing"],
            "instinct": profile["enneagram_instinct"], "source": profile["enneagram_source"],
            "card": type_card(profile["enneagram_type"], profile["enneagram_wing"],
                              profile["enneagram_instinct"])}


def profile_view(profile: dict) -> dict:
    """The response shape of every profile route: the chosen zodiac in full, the other summarised."""
    zodiac = profile["zodiac"]
    other = "tropical" if zodiac == "sidereal" else "sidereal"
    computed = profile["computed"]
    alt = computed[other]
    return {
        "id": profile["id"],
        "birth": {"date": profile["birth_date"], "time": profile["birth_time"],
                  "time_known": profile["time_known"], "place_display": profile["place_display"],
                  "country_code": profile["country_code"], "lat": profile["lat"],
                  "lon": profile["lon"], "timezone": profile["timezone"]},
        "zodiac": zodiac,
        "profile": computed[zodiac],
        "alternate": {"zodiac": other, "sun_sign": alt["astro"]["positions"]["sun"]["sign"],
                      "hd_type": alt["humandesign"]["type"], "profile": alt["humandesign"]["profile"]},
        "enneagram": _enneagram_view(profile),
        "engine_version": profile["engine_version"],
        "created_at": profile["created_at"], "updated_at": profile["updated_at"],
        "revision": profile["revision"],
    }


def attempt_seed(profile_id: str, attempts: int) -> int:
    """Stable until an attempt is recorded, so a reload keeps the statement order."""
    digest = hashlib.sha256(f"{profile_id}:{attempts}".encode("utf-8")).hexdigest()
    return int(digest[:8], 16)


def _guidance_view(row: dict, profile: dict) -> dict:
    return {**row, "chart_in_the_room": parse_chart_in_the_room(row["output_text"], profile)}


def mount_joh_routes(app: FastAPI) -> None:
    limiter = GeocodeRateLimiter()

    def store(request: Request):
        return request.app.state.store

    def session(request: Request) -> dict:
        return request.state.session

    def user_id(request: Request) -> str:
        return session(request)["user"]["id"]

    def actor(request: Request) -> str:
        return session(request)["user"]["username"]

    def language(request: Request) -> str:
        return store(request).language_for(user_id(request), request.headers.get("accept-language"))[0]

    def localised_view(request: Request, profile: dict) -> dict:
        code = language(request)
        return {**localise_profile(profile_view(profile), code), "language": code}

    def own_profile(request: Request) -> dict:
        profile = store(request).get_joh_profile(user_id(request))
        if profile is None:
            raise LookupError("no Journey profile yet")
        return profile

    # -- status + switch --------------------------------------------------------------------

    @app.get("/api/joh")
    async def joh_status(request: Request):
        s = store(request)
        profile = s.get_joh_profile(user_id(request))
        return {"enabled": s.get_joh_enabled(user_id(request)),
                "has_profile": profile is not None,
                "zodiac": profile["zodiac"] if profile else None,
                "enneagram_set": bool(profile and profile["enneagram_type"])}

    @app.put("/api/joh/enabled")
    async def joh_set_enabled(request: Request, body: EnabledIn):
        enabled = store(request).set_joh_enabled(user_id(request), body.enabled, actor=actor(request))
        return {"enabled": enabled}

    # -- geocode -----------------------------------------------------------------------------

    @app.post("/api/joh/geocode")
    async def joh_geocode(request: Request, body: GeocodeIn):
        if not limiter.allow(user_id(request)):
            return JSONResponse({"detail": "too many place lookups; wait a minute and try again"},
                                status_code=429)
        fetch = getattr(request.app.state, "joh_geocode_transport", None)
        try:
            return geocode(body.city, body.country, fetch=fetch)
        except NoPlaceFound as exc:
            return JSONResponse({"detail": "no place found", "reasons": [str(exc)]}, status_code=404)
        except GeocodeError as exc:
            return JSONResponse({"detail": str(exc)}, status_code=502)

    # -- profile -----------------------------------------------------------------------------

    @app.get("/api/joh/profile")
    async def joh_get_profile(request: Request):
        return localised_view(request, own_profile(request))

    @app.put("/api/joh/profile")
    async def joh_put_profile(request: Request, body: ProfileIn):
        data = body.model_dump()
        zodiac = data.pop("zodiac")
        profile = store(request).save_joh_profile(user_id(request), data, zodiac=zodiac,
                                                  actor=actor(request))
        return localised_view(request, profile)

    @app.patch("/api/joh/profile")
    async def joh_patch_profile(request: Request, body: ZodiacIn):
        own_profile(request)
        return localised_view(request, store(request).set_joh_zodiac(user_id(request), body.zodiac,
                                                                     actor=actor(request)))

    @app.delete("/api/joh/profile", status_code=204)
    async def joh_delete_profile(request: Request):
        if not store(request).delete_joh_profile(user_id(request), actor=actor(request)):
            raise LookupError("no Journey profile to delete")
        return Response(status_code=204)

    # -- enneagram ---------------------------------------------------------------------------

    @app.get("/api/joh/enneagram/test")
    async def joh_enneagram_test(request: Request):
        profile = own_profile(request)
        attempts = store(request).list_joh_enneagram_attempts(profile["id"])
        seed = attempt_seed(profile["id"], len(attempts))
        return {"seed": seed, "statements": localise_statements(statements_for(seed), language(request)),
                "scale": list(SCALE), "attempts": len(attempts), "language": language(request)}

    @app.post("/api/joh/enneagram/test", status_code=201)
    async def joh_enneagram_submit(request: Request, body: EnneagramAnswersIn):
        profile = own_profile(request)
        result = store(request).record_joh_enneagram_attempt(profile["id"], body.seed, body.answers)
        return {**result, "card": localise_card(type_card(result["type"], result["wing"], None), language(request))}

    @app.put("/api/joh/enneagram")
    async def joh_set_enneagram(request: Request, body: EnneagramIn):
        own_profile(request)
        if body.source not in ENNEAGRAM_SOURCES:
            raise ValueError(f"source must be one of {ENNEAGRAM_SOURCES}")
        return localised_view(request, store(request).set_joh_enneagram(
            user_id(request), body.type, body.wing, body.instinct, body.source, actor=actor(request)))

    # -- Compass -----------------------------------------------------------------------------

    @app.post("/api/joh/guidance", status_code=201)
    async def joh_guidance(request: Request, body: GuidanceIn):
        profile = own_profile(request)
        if body.kind not in KINDS:
            raise ValueError(f"kind must be one of {KINDS}")
        text = body.input_text
        if not text.strip():
            raise ValueError("input_text is empty")
        if len(text) > MAX_INPUT_CHARS:
            raise ValueError(f"input_text is longer than {MAX_INPUT_CHARS} characters")
        s = store(request)
        agent = s.get_agent(COMPASS_AGENT_ID)
        if agent is None:
            return JSONResponse({"detail": "the Compass is not configured",
                                 "reasons": [f"agent definition {COMPASS_AGENT_ID!r} not found"]},
                                status_code=409)
        factory = getattr(request.app.state, "joh_transport_factory", None)
        runner = build_live_runner(agent, transport_factory=factory)
        problems = runner.problems()
        if problems:
            return JSONResponse({"detail": "the Compass is not configured on this server",
                                 "reasons": problems}, status_code=409)
        config = runner.config
        messages = build_compass_messages(profile, body.kind, text, body.extra, language=language(request))
        try:
            result = runner.transport.complete(config["model"], messages, COMPASS_MAX_TOKENS)
        except (TransportError, ConfigurationError, TimeoutError, OSError) as exc:
            secret = os.environ.get(credential_env_name(config.get("credential_ref")) or "")
            return JSONResponse({"detail": redact(f"{type(exc).__name__}: {exc}", secret or None)},
                                status_code=502)
        row = s.add_joh_guidance(profile["id"], body.kind, text, result.text, result.model,
                                 result.provider, result.cost_minor, result.currency)
        return {**_guidance_view(row, profile), "cap_minor": config.get("max_cost_minor"),
                "cap_currency": config.get("currency") or "USD"}

    @app.get("/api/joh/guidance")
    async def joh_guidance_history(request: Request, limit: int = 20):
        profile = own_profile(request)
        return [_guidance_view(row, profile)
                for row in store(request).list_joh_guidance(profile["id"], limit=limit)]
