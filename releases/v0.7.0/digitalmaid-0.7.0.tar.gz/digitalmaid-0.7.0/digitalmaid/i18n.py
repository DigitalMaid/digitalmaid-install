"""Languages (0.5.1, ADR-010): the five codes, Accept-Language negotiation and the per-user
setting. The setting reuses ``widget_preferences`` under ``scope_id="user:<id>"`` /
``area="language"`` exactly like the JOH switch — personal, not workspace content."""

import json

from digitalmaid.db import new_id, now

LANGUAGES = ("en", "vi", "zh", "fr", "ja")
LANGUAGE_NAMES = {"en": "English", "vi": "Tiếng Việt", "zh": "中文", "fr": "Français", "ja": "日本語"}
DEFAULT_LANGUAGE = "en"
_PREF_SCOPE = "user:"
_PREF_AREA = "language"


def check_language(code) -> str:
    if not isinstance(code, str) or code not in LANGUAGES:
        raise ValueError(f"language must be one of {LANGUAGES}")
    return code


def negotiate(accept_language: str | None) -> str:
    """The supported code with the highest quality in an ``Accept-Language`` header, else en.

    Only the primary subtag is compared (``zh-Hans-CN``, ``zh-TW`` → ``zh``; the app has one
    Chinese catalogue, simplified). Ties keep header order; malformed ``q`` values count as 1.
    """
    if not accept_language:
        return DEFAULT_LANGUAGE
    best, best_q = None, -1.0
    for position, part in enumerate(accept_language.split(",")):
        pieces = [p.strip() for p in part.split(";")]
        tag = pieces[0].lower()
        if not tag or tag == "*":
            continue
        quality = 1.0
        for param in pieces[1:]:
            if param.startswith("q="):
                try:
                    quality = float(param[2:])
                except ValueError:
                    quality = 1.0
        primary = tag.split("-", 1)[0]
        if primary in LANGUAGES and quality > best_q:
            best, best_q = primary, quality
    return best or DEFAULT_LANGUAGE


class Languages:
    """Mixin; expects ``self._db`` and ``self.scope_id``."""

    def get_language(self, user_id: str) -> str | None:
        row = self._db.query_one(
            "SELECT widgets FROM widget_preferences WHERE scope_id = ? AND area = ?",
            (_PREF_SCOPE + user_id, _PREF_AREA))
        if row is None:
            return None
        try:
            code = json.loads(row["widgets"]).get("language")
        except (ValueError, AttributeError):
            return None
        return code if code in LANGUAGES else None

    def set_language(self, user_id: str, language: str, actor: str) -> str:
        if not isinstance(user_id, str) or not user_id.strip():
            raise ValueError("user_id required")
        code = check_language(language)
        key, stamp = _PREF_SCOPE + user_id, now()
        payload = json.dumps({"language": code})
        with self._db.transaction() as cur:
            existing = cur.execute(
                "SELECT id, revision FROM widget_preferences WHERE scope_id = ? AND area = ?",
                (key, _PREF_AREA)).fetchone()
            if existing is None:
                pref_id = new_id()
                cur.execute(
                    "INSERT INTO widget_preferences (id, scope_id, area, widgets, created_at,"
                    " updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (pref_id, key, _PREF_AREA, payload, stamp, stamp))
                self._db.audit(cur, "language_setting", pref_id, "create", actor,
                               {"language": code, "user_id": user_id}, scope_id=self.scope_id)
            else:
                self._db.update_with_revision(
                    "widget_preferences", existing["id"], key, existing["revision"],
                    {"widgets": payload}, actor=actor, action="set_language",
                    details={"language": code, "user_id": user_id}, cur=cur,
                    entity_type="language_setting")
        return code

    def language_for(self, user_id: str, accept_language: str | None) -> tuple[str, str]:
        """``(code, source)`` — the stored choice, else the browser's best match."""
        stored = self.get_language(user_id)
        if stored:
            return stored, "user"
        return negotiate(accept_language), "browser"
