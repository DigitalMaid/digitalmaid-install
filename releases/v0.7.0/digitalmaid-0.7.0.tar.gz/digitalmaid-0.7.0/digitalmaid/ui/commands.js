// Stage J ease-of-use layer (DESIGN.md C3–C5): ⌘K command palette, global keyboard
// shortcuts with a help overlay, the Quick Capture sheet and its toast, and the
// scope-keyed "recent" list in localStorage. No new dependencies; every overlay is
// plain DOM already present in index.html. Nothing here talks to the server except
// the palette's job list (existing GET) and quick capture (existing captures API).

import { api } from "./api.js";
import { el, icon, isReadOnly, readOnlyReason, PHASES } from "./views.js";
import { t } from "./i18n.js";

const RECENT_LIMIT = 8;
const CHORD_TIMEOUT = 1000;
const URL_RE = /^https?:\/\/\S+$/i;
const CHORDS = { t: "#/today", i: "#/capture", a: "#/automations", c: "#/calendar", k: "#/knowledge", s: "#/settings", j: "#/joh" };
// JOH (0.5.0): "Open JOH" and "Ask the Compass" appear only while the section is enabled.
let johEnabled = false;
export function setJohEnabled(on) { johEnabled = Boolean(on); }
// label/hint text lives in the catalogue as commands.create.<id>.label / .hint
const CREATE = ["task", "capture", "note", "journal", "procedure", "event", "goal"];
// title/row text lives in the catalogue as commands.help.<group>.title / commands.help.<group>.<row>
const HELP = [
  ["goTo", [["g", "t", "today"], ["g", "i", "inbox"], ["g", "a", "automations"], ["g", "c", "calendar"], ["g", "k", "knowledge"], ["g", "s", "settings"], ["g", "j", "joh"]]],
  ["do", [["n", null, "newTask"], ["c", null, "quickCapture"], ["/", null, "focusSearch"], ["⌘/Ctrl K", null, "commandPalette"], ["?", null, "thisOverlay"], ["Esc", null, "closeOverlay"]]],
];

let ctx = null;
let scopeId = "default";

// --- recent list (scope-keyed, last 8 opened tasks/notes) -------------------------------

function recentKey() { return `dm:recent:${scopeId}`; }

export function readRecent() {
  try { const list = JSON.parse(localStorage.getItem(recentKey()) || "[]"); return Array.isArray(list) ? list : []; }
  catch { return []; }
}

export function recordRecent({ type, id, title }) {
  if (!id || !title) return;
  const rest = readRecent().filter((r) => !(r.type === type && r.id === id));
  try { localStorage.setItem(recentKey(), JSON.stringify([{ type, id, title }, ...rest].slice(0, RECENT_LIMIT))); }
  catch { /* storage full or disabled: recents are a convenience only */ }
}

// --- fuzzy subsequence scoring -----------------------------------------------------------

// Every query character must appear in order; adjacent and word-start hits score higher.
// Returns null when the query is not a subsequence.
export function fuzzyScore(query, text) {
  const q = query.toLowerCase().replace(/\s+/g, "");
  const t = text.toLowerCase();
  if (!q) return 0;
  let score = 0, ti = 0, last = -2;
  for (const ch of q) {
    const at = t.indexOf(ch, ti);
    if (at < 0) return null;
    score += 1;
    if (at === last + 1) score += 2;
    if (at === 0 || /[\s\-_/(]/.test(t[at - 1])) score += 3;
    last = at;
    ti = at + 1;
  }
  return score - t.length / 100;
}

// --- overlays: shared plumbing --------------------------------------------------------------

const FOCUSABLE = "a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex='-1'])";

function trapTab(container, event) {
  if (event.key !== "Tab") return;
  const items = [...container.querySelectorAll(FOCUSABLE)].filter((n) => n.offsetParent !== null || n === document.activeElement);
  if (!items.length) { event.preventDefault(); return; }
  const first = items[0], last = items[items.length - 1];
  if (event.shiftKey && (document.activeElement === first || !container.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
}

function isEditable(node) {
  if (!(node instanceof Element)) return false;
  return node.matches("input, textarea, select, [contenteditable=''], [contenteditable='true']") || node.isContentEditable;
}

const backdrop = () => document.getElementById("overlay-backdrop");
const openers = new Map();

function openModal(node) {
  openers.set(node.id, document.activeElement);
  backdrop().hidden = false;
  node.hidden = false;
  document.body.dataset.overlay = node.id;
}

function closeModal(node) {
  if (node.hidden) return;
  // A hidden input would otherwise keep focus, and every later shortcut would look "typed".
  if (node.contains(document.activeElement)) document.activeElement.blur();
  node.hidden = true;
  const anyOpen = [...document.querySelectorAll("#command-palette, #help-overlay")].some((n) => !n.hidden);
  if (!anyOpen) { backdrop().hidden = true; delete document.body.dataset.overlay; }
  const opener = openers.get(node.id);
  openers.delete(node.id);
  if (opener && opener.isConnected) opener.focus?.();
}

// --- command palette ---------------------------------------------------------------------

const palette = {
  node: null, input: null, list: null, status: null, items: [], selected: -1, jobs: null, jobsAt: 0,
};

function goToItems() {
  const items = [...document.querySelectorAll("#nav-list .nav-item")].filter((a) => !a.closest("li[hidden]")).map((a) => ({
    group: "Go to", label: a.dataset.route === "joh" ? t("commands.openJoh") : (a.querySelector(".nav-label")?.textContent.trim() || a.title), hint: a.getAttribute("href"),
    run: () => ctx.navigate(a.getAttribute("href")),
  }));
  if (johEnabled) items.push({ group: "Go to", label: t("commands.askCompass"), hint: "#/joh/compass", run: () => ctx.navigate("#/joh/compass") });
  return items;
}

function createItems() {
  return CREATE.map((id) => ({ group: "Create", label: t(`commands.create.${id}.label`), hint: t(`commands.create.${id}.hint`), run: () => ctx.create(id) }));
}

async function runItems() {
  if (!palette.jobs || Date.now() - palette.jobsAt > 30_000) {
    try { palette.jobs = await api.jobs(); palette.jobsAt = Date.now(); } catch { palette.jobs = []; }
  }
  return palette.jobs.map((job) => ({
    group: "Run", label: t("commands.runNow", { purpose: job.purpose }), hint: job.enabled ? t("commands.queuesManual") : t("commands.pausedJob"),
    run: () => ctx.runJob(job),
  }));
}

function recentItems() {
  return readRecent().map((r) => ({
    group: "Recent", label: r.title, hint: t(`commands.recentType.${r.type}`, undefined, r.type),
    run: () => (r.type === "task" ? ctx.openTask(r.id) : ctx.navigate(`#/knowledge/${r.id}`)),
  }));
}

// Internal group ids (also used to filter scored items); their displayed titles come from
// commands.group.<key> so the ids themselves stay stable across languages.
const GROUP_KEYS = { "Go to": "goTo", Create: "create", Run: "run", Recent: "recent" };

function renderPalette(query) {
  const groups = ["Go to", "Create", "Run", "Recent"];
  const scored = palette.all.map((item) => ({ item, score: query ? fuzzyScore(query, item.label) : 0 }))
    .filter((s) => s.score !== null);
  if (query) scored.sort((a, b) => b.score - a.score);
  palette.items = [];
  const rows = [];
  for (const group of groups) {
    const members = scored.filter((s) => s.item.group === group).slice(0, 12).map((s) => s.item);
    if (!members.length) continue;
    rows.push(el("li", { class: "palette-group", role: "presentation" }, t(`commands.group.${GROUP_KEYS[group]}`)));
    for (const item of members) {
      const index = palette.items.push(item) - 1;
      rows.push(el("li", { id: `palette-option-${index}`, role: "option", "aria-selected": "false", dataset: { group: group },
        onmousedown: (e) => e.preventDefault(), onclick: () => runItem(index) },
        el("span", { class: "palette-label" }, item.label), el("span", { class: "palette-hint" }, item.hint || "")));
    }
  }
  palette.list.replaceChildren(...(rows.length ? rows : [el("li", { class: "palette-empty", role: "presentation" }, t("commands.noMatches", { query }))]));
  selectPalette(palette.items.length ? 0 : -1);
  palette.status.textContent = palette.items.length ? t("commands.paletteStatus", { count: palette.items.length }) : t("commands.noMatchingCommands");
}

function selectPalette(index) {
  palette.selected = index;
  for (const [i, option] of [...palette.list.querySelectorAll("[role=option]")].entries()) {
    option.setAttribute("aria-selected", String(i === index));
    if (i === index) { palette.input.setAttribute("aria-activedescendant", option.id); option.scrollIntoView({ block: "nearest" }); }
  }
  if (index < 0) palette.input.removeAttribute("aria-activedescendant");
}

async function runItem(index) {
  const item = palette.items[index];
  if (!item) return;
  closePalette({ restoreFocus: false });
  try { await item.run(); } catch (error) { ctx.showGlobal(t("commands.commandFailed", { message: error.message }), "error", error.reasons); }
}

export async function openPalette() {
  if (!palette.node.hidden) { palette.input.focus(); return; }
  closeHelp();
  openModal(palette.node);
  palette.input.value = "";
  palette.all = [...goToItems(), ...createItems(), ...recentItems()];
  renderPalette("");
  palette.input.focus();
  const runs = await runItems();
  if (palette.node.hidden) return;
  palette.all = [...goToItems(), ...createItems(), ...runs, ...recentItems()];
  renderPalette(palette.input.value.trim());
}

export function closePalette({ restoreFocus = true } = {}) {
  if (palette.node.hidden) return;
  if (!restoreFocus) openers.delete(palette.node.id);
  closeModal(palette.node);
}

function setupPalette() {
  palette.node = document.getElementById("command-palette");
  palette.input = document.getElementById("palette-input");
  palette.list = document.getElementById("palette-list");
  palette.status = document.getElementById("palette-status");
  palette.input.addEventListener("input", () => renderPalette(palette.input.value.trim()));
  palette.node.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); closePalette(); return; }
    if (event.key === "Tab") { trapTab(palette.node, event); return; }
    const n = palette.items.length;
    if (event.key === "ArrowDown" && n) { event.preventDefault(); selectPalette((palette.selected + 1) % n); }
    else if (event.key === "ArrowUp" && n) { event.preventDefault(); selectPalette((palette.selected - 1 + n) % n); }
    else if (event.key === "Home" && n) { event.preventDefault(); selectPalette(0); }
    else if (event.key === "End" && n) { event.preventDefault(); selectPalette(n - 1); }
    else if (event.key === "Enter") { event.preventDefault(); runItem(palette.selected >= 0 ? palette.selected : 0); }
  });
}

// --- help overlay -----------------------------------------------------------------------

let help = null;

function renderHelp() {
  // Phase legend (D2): the same five words, dots and meanings every pill uses.
  document.getElementById("help-legend-list").replaceChildren(...PHASES.flatMap((phase) => [
    el("dt", {}, el("span", { class: "pill", dataset: { status: phase, phase } }, t(`phase.${phase}`))),
    el("dd", {}, t(`views.phaseMeaning.${phase}`))]));
  document.getElementById("help-columns").replaceChildren(...HELP.map(([group, rows]) =>
    el("section", { class: "help-column" }, el("h3", {}, t(`commands.help.${group}.title`)),
      el("dl", { class: "help-list" }, rows.map(([a, b, what]) => [
        el("dt", {}, el("kbd", {}, a), b ? [" ", el("kbd", {}, b)] : null),
        el("dd", {}, t(`commands.help.${group}.${what}`))])))));
}

export function openHelp() {
  if (!help.hidden) return;
  closePalette({ restoreFocus: false });
  localStorage.setItem("dm:hint:shortcuts", "1");
  document.getElementById("shortcut-hint")?.remove();
  // Built on open (not at setup): the catalogue may not have loaded yet at boot, and the
  // language can change between openings (2026-09-16: legend showed raw keys).
  renderHelp();
  openModal(help);
  document.getElementById("help-close").focus();
}

export function closeHelp() { closeModal(help); }

function setupHelp() {
  help = document.getElementById("help-overlay");
  renderHelp();
  document.getElementById("help-close").addEventListener("click", closeHelp);
  help.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); closeHelp(); }
    else trapTab(help, event);
  });
}

// --- quick capture sheet + toast -------------------------------------------------------

let sheet = null, sheetOpener = null, toastTimer = null;

export function showToast(message, { href = null, linkText = t("common.open") } = {}) {
  const toast = document.getElementById("toast");
  clearTimeout(toastTimer);
  toast.replaceChildren(el("span", {}, message), href ? el("a", { class: "pill-btn", href, onclick: () => hideToast() }, linkText) : null);
  toast.hidden = false;
  toastTimer = setTimeout(hideToast, 8000);
}

function hideToast() { const toast = document.getElementById("toast"); toast.hidden = true; toast.replaceChildren(); }

export function openQuickCapture() {
  if (!sheet.hidden) { document.getElementById("qc-text").focus(); return; }
  sheetOpener = document.activeElement;
  sheet.hidden = false;
  const submit = document.getElementById("qc-submit");
  submit.disabled = isReadOnly();
  submit.title = isReadOnly() ? readOnlyReason() : "";
  document.getElementById("qc-text").focus();
}

export function closeQuickCapture() {
  if (sheet.hidden) return;
  if (sheet.contains(document.activeElement)) document.activeElement.blur();
  sheet.hidden = true;
  document.getElementById("qc-alert").replaceChildren();
  if (sheetOpener?.isConnected) sheetOpener.focus?.();
  sheetOpener = null;
}

function setupQuickCapture() {
  sheet = document.getElementById("quick-capture-sheet");
  const form = document.getElementById("qc-form");
  const text = document.getElementById("qc-text");
  const file = document.getElementById("qc-file");
  const alert = document.getElementById("qc-alert");
  const submit = document.getElementById("qc-submit");
  document.getElementById("qc-close").addEventListener("click", closeQuickCapture);
  sheet.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); closeQuickCapture(); }
  });
  text.addEventListener("keydown", (event) => { if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) { event.preventDefault(); form.requestSubmit(); } });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    alert.replaceChildren();
    if (isReadOnly()) { alert.replaceChildren(el("div", {}, readOnlyReason())); return; }
    const value = text.value.trim();
    const chosen = file.files?.[0] || null;
    if (!value && !chosen) { alert.replaceChildren(el("div", {}, t("commands.nothingToCapture"))); text.focus(); return; }
    submit.disabled = true;
    try {
      let capture;
      if (chosen) {
        const body = new FormData();
        body.append("file", chosen, chosen.name);
        if (value) body.append("body_text", value);
        capture = await api.uploadCapture(body);
      } else {
        capture = await api.createCapture(URL_RE.test(value) ? { kind: "link", url: value } : { kind: "text", body_text: value });
      }
      text.value = "";
      file.value = "";
      showToast(t("commands.captured"), { href: `#/capture/${capture.id}`, linkText: t("commands.openInInbox") });
      text.focus();
      ctx.onCaptured?.(capture);
    } catch (error) {
      alert.replaceChildren(el("div", {}, error.reasons ? t("commands.refusedByServer", { reasons: error.reasons.join("; ") }) : error.message));
    } finally {
      submit.disabled = isReadOnly();
    }
  });
}

// --- global shortcuts (C4) --------------------------------------------------------------

let chord = null, chordTimer = null;

function anyModalOpen() {
  return !palette.node.hidden || !help.hidden || document.getElementById("confirm-dialog")?.open;
}

function onKey(event) {
  const key = event.key;
  if ((event.metaKey || event.ctrlKey) && !event.altKey && key.toLowerCase() === "k") {
    event.preventDefault();
    if (!palette.node.hidden) closePalette(); else openPalette();
    return;
  }
  if (key === "Escape") {
    // Overlays handle their own Escape (and stop propagation); the sheet closes from anywhere.
    if (!sheet.hidden && !sheet.contains(event.target)) closeQuickCapture();
    return;
  }
  if (event.metaKey || event.ctrlKey || event.altKey || anyModalOpen() || isEditable(event.target)) { chord = null; return; }
  if (chord === "g") {
    chord = null;
    clearTimeout(chordTimer);
    const target = CHORDS[key.toLowerCase()];
    if (target === "#/joh" && !johEnabled) return;
    if (target) { event.preventDefault(); ctx.navigate(target); }
    return;
  }
  if (key === "g") { chord = "g"; clearTimeout(chordTimer); chordTimer = setTimeout(() => { chord = null; }, CHORD_TIMEOUT); return; }
  if (key === "?") { event.preventDefault(); openHelp(); }
  else if (key === "/") { event.preventDefault(); document.getElementById("global-search")?.focus(); }
  else if (key === "c") { event.preventDefault(); openQuickCapture(); }
  else if (key === "n") { event.preventDefault(); ctx.create("task"); }
}

// --- boot ----------------------------------------------------------------------------

export function setupCommands(context) {
  ctx = context;
  setupPalette();
  setupHelp();
  setupQuickCapture();
  backdrop().addEventListener("click", () => { closePalette(); closeHelp(); });
  document.addEventListener("keydown", onKey);
}

export function setCommandScope(id) { scopeId = id || "default"; }
