// Today hero (DESIGN.md C1, "Observatory" layout 2026-09-09). Left: a serif greeting with
// the signed-in name, the date line and the "Next" block fed by the server's next_action.
// Right: the orrery — a gold ring holding a canvas particle field whose four clusters are
// sized by the open items per PDCC phase — with a column of six node links (Doto badges,
// one may glow). The canvas is aria-hidden and a visually-hidden sentence carries the same
// numbers; the nodes rail stays the keyboard path.
//
// Observatory Stage 2 — the field is an INSTRUMENT: every element maps to `today.instrument`
// (views.instrument). Named stars = open tasks (position hashed from the id, look from the
// phase state: Plan cage/gold glow, Do ember pulse + sparks, Check waiting ring, Correction
// flicker + loop-back arc); the gold thread = next_action; core size/glow = acceptances (a
// comet when one lands); wind motes = open captures; ring beads = automation jobs; worker down
// = the system stills; journal written = the outer ring lights. See DESIGN.md Appendix F.

import { el, icon, pillButton, currentUser } from "./views.js";
import { t, formatDate } from "./i18n.js";

const PHASES = [["plan", "Plan"], ["do", "Do"], ["check", "Check"], ["correction", "Correction"]];
// caption/label text lives in the catalogue as hero.node.<id>.caption / .label (D2); the
// glowing node's title is the Next reason.
const NODES = [
  { id: "plan", href: "#/goals", icon: "plan" },
  { id: "do", href: "#/goals", icon: "do" },
  { id: "check", href: "#/review", icon: "check" },
  { id: "correction", href: "#/review", icon: "correction" },
  { id: "automations", href: "#/automations", icon: "automations" },
  { id: "inbox", href: "#/capture", icon: "capture" },
];
const MIN_DOTS = 240;   // 40 → ×3 (density) → ×2 (extent); the cluster spread grew with it
const MAX_DOTS = 2400;  // 400 → ×3 → ×2
const MAX_SPEED = 5; // px per second, brief: < 6
// Breathing tempo in rad/s per phase (full cycle ≈ 4–7 s). Plan is calm, Do is livelier,
// Check steady, Correction slowest — it should feel like something waiting, not racing.
const BREATH_TEMPO = { plan: 1.0, do: 1.5, check: 1.2, correction: 0.9 };
const HINT_KEY = "dm:hint:shortcuts";

export function summaryText(counts) {
  return PHASES.map(([id, name]) => `${t(`phase.${name}`)} ${counts?.[id] ?? 0}`).join(" · ");
}

// The visually-hidden sentence: the phase counts, then how many named stars the instrument
// shows (omitted when none) and, when the worker is down, that fact.
export function instrumentSummary(counts, instrument) {
  let text = summaryText(counts);
  const n = instrument?.stars?.length || 0;
  if (n) text += ", " + t("hero.tasksOnInstrument", { count: n });
  if (instrument && instrument.worker_alive === false) text += ". " + t("hero.workerOffline");
  return text;
}

// One line of state for a named star's tooltip, per phase.
export function starStateLine(star) {
  switch (star.phase) {
    case "plan": {
      const n = star.gates_unmet ?? 0;
      if (star.ready) return t("hero.tipPlan.ready");
      return n <= 5 ? t("hero.tipPlan.gatesOf5", { count: n }) : t("hero.tipPlan.gatesOver", { count: n });
    }
    case "do": {
      const state = star.execution || "idle";
      return t("hero.tipDo", { state: t(`status.${state}`, undefined, state) });
    }
    case "check": {
      const hours = Math.round(star.waiting_hours ?? 0);
      return star.overdue ? t("hero.tipCheck.overdue", { hours }) : t("hero.tipCheck.waiting", { hours });
    }
    default:
      return t("hero.tipCorrection", { count: star.failed_criteria ?? 0 });
  }
}

// "Good morning, Sang." — the salutation follows the local hour; the name is the signed-in
// username with its first letter capitalised, or nothing when no session is known.
export function greetingParts(username, now = new Date()) {
  const hour = now.getHours();
  const salute = t(hour < 12 ? "hero.goodMorning" : hour < 18 ? "hero.goodAfternoon" : "hero.goodEvening");
  const name = username ? username.trim().charAt(0).toUpperCase() + username.trim().slice(1) : "";
  return { salute, name };
}

export function dateLine(counts, now = new Date()) {
  const open = PHASES.reduce((n, [id]) => n + (Number.isFinite(counts?.[id]) ? counts[id] : 0), 0);
  const date = formatDate(now, { weekday: "long", day: "numeric", month: "long" });
  return `${date} · ${t("hero.openItems", { count: open })}`;
}

// Cluster dot counts: three dots per open item, and an empty phase still reads as a faint cluster.
const DOTS_PER_ITEM = 6;
export function dotCount(n) {
  return Math.max(MIN_DOTS, Math.min(MAX_DOTS, Number.isFinite(n) ? n * DOTS_PER_ITEM : 0));
}

export function renderHero(today, { onCapture, onSearch, onLayout, onInfo, automationsDue = null, hintDismissed = null, onDismissHint, user = currentUser() } = {}) {
  const counts = today.pdcc_counts || {};
  const action = today.next_action || null;
  const instrument = today.instrument || null;

  const { salute, name } = greetingParts(user);
  const greeting = el("h1", { class: "hero-greeting" },
    name ? [`${salute}, `, el("em", {}, `${name}.`)] : `${salute}.`);

  const canvas = el("canvas", { id: "hero-canvas", class: "hero-canvas", "aria-hidden": "true" });
  const ring = el("div", { id: "hero-ring", class: `hero-ring${instrument?.journal_written ? " is-written" : ""}` },
    [0, 1, 2, 3].map(() => el("span", { class: "hero-tick", "aria-hidden": "true" })),
    canvas,
    el("p", { id: "hero-summary", class: "visually-hidden" }, instrumentSummary(counts, instrument)));
  // The tooltip for a hovered named star: a live region beside the canvas, hidden until needed.
  const tip = el("div", { id: "hero-tip", class: "hero-tip", role: "status", hidden: true });
  const stillNote = instrument && instrument.worker_alive === false
    ? el("p", { class: "hero-caption-note" }, t("hero.workerOfflineStill"))
    : null;

  const badges = { ...counts, automations: automationsDue, inbox: today.capture_inbox_count ?? 0 };
  const rail = el("ol", { id: "hero-rail", class: "hero-rail", "aria-label": t("hero.railLabel") }, NODES.map((node) => {
    const glow = action?.phase === node.id;
    const badge = badges[node.id];
    const badgeText = badge === null || badge === undefined ? t("common.none") : String(badge);
    const label = t(`hero.node.${node.id}.label`);
    const caption = t(`hero.node.${node.id}.caption`);
    return el("li", { class: "hero-node-item" },
      el("a", { class: "hero-node", href: node.href, dataset: { node: node.id, glow: String(glow) },
        "aria-label": `${label}: ${badgeText}${glow ? ` — ${action.reason}` : ""}`, title: glow ? action.reason : label },
        el("span", { class: "hero-node-ring", "aria-hidden": "true" }, icon(node.icon)),
        el("span", { class: "badge num", "aria-hidden": "true" }, badgeText),
        el("span", { class: "hero-caption", "aria-hidden": "true" }, caption)));
  }));

  // The hero's tools live as pills under Next: Capture (c) and Shortcuts (?); search is the
  // header pill and "/" (onSearch is kept for the palette); layout editing is the board's pill.
  const capture = pillButton(t("hero.captureLabel"), { id: "hero-capture", onclick: onCapture, title: t("hero.captureTitle"), dataset: { write: "true" } });
  const shortcuts = el("button", { id: "hero-info", class: "pill-btn", type: "button", title: t("hero.shortcutsTitle"), "aria-label": t("hero.shortcutsTitle"), onclick: onInfo },
    t("hero.shortcutsLabel"), el("kbd", { "aria-hidden": "true" }, "?"));
  if (action) capture.classList.remove("gold"); else capture.classList.add("gold");
  const next = el("div", { id: "next-strip", class: "next-strip" },
    el("span", { class: "next-kicker" }, t("hero.next")),
    action
      ? [el("span", { class: "next-label" }, action.label),
        el("span", { class: "next-reason" }, action.reason),
        el("div", { class: "next-acts" }, pillButton(t("common.open"), { href: action.href, class: "next-open gold" }), capture, shortcuts)]
      : [el("span", { class: "next-label is-clear" }, t("hero.nothingWaiting")),
        el("span", { class: "next-reason" }, t("hero.captureOrPlan")),
        el("div", { class: "next-acts" }, capture, shortcuts)]);

  const showHint = hintDismissed === false || (hintDismissed === null && localStorage.getItem(HINT_KEY) !== "1");
  const hint = showHint
    ? el("div", { id: "shortcut-hint", class: "hint-pill" },
      el("span", {}, t("hero.hintBefore"), el("kbd", {}, "?"), t("hero.hintAfter")),
      el("button", { class: "hint-dismiss", type: "button", "aria-label": t("hero.hintDismiss"), onclick: (e) => {
        localStorage.setItem(HINT_KEY, "1");
        e.currentTarget.closest("#shortcut-hint")?.remove();
        onDismissHint?.();
      } }, icon("close")))
    : null;
  if (hint) next.querySelector(".next-acts").append(hint);

  const hero = el("section", { id: "hero", class: "hero", "aria-label": t("hero.sectionLabel") },
    el("div", { class: "hero-text" }, greeting, el("div", { class: "hero-date" }, dateLine(counts)), next),
    el("div", { class: "hero-stage" }, el("div", { class: "hero-orrery" }, ring, rail, tip, stillNote)));

  startField(canvas, counts, instrument, action, tip);
  return hero;
}

// The board's own header: a tri-dot label and the ghost "Edit layout" pill (#hero-layout),
// which toggles the move/hide controls together with the header pencil (app.js).
export function renderBoardHead(onLayout) {
  const editing = document.body.dataset.editing === "true";
  return el("div", { class: "board-head" },
    el("span", { class: "label" }, t("hero.boardLabel")),
    el("button", { id: "hero-layout", class: "pill-btn", type: "button", title: t("hero.editBoardLayout"), "aria-label": t("hero.editBoardLayout"),
      "aria-pressed": String(editing), dataset: { active: String(editing) }, onclick: onLayout }, t("hero.editLayout")));
}

// --- particle field ---------------------------------------------------------------------
// A small star system in three dimensions. Layers, back to front by depth:
//   1. a dust shell of tiny faint stars, each twinkling on its own sine;
//   2. four orbital rings of stars, each in its own tilted plane, alternating direction (inner faster);
//   3. a core cluster at the centre carrying all eight hues, orbited by
//   4. the four PDCC clusters (Plan, Do, Check, Correction), two hues each (eight colours), sized by the live
//      counts, drifting inside their cluster and breathing (size + brightness + halo).
// The whole system rotates slowly on its own, and the user can grab it: dragging left/right
// spins it about the vertical axis, dragging up/down tilts it toward or away from the viewer.
// Release keeps the momentum, which eases back into the idle spin.

function token(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

// Ring star counts are 7.5× the original 30/48/64/84 (30×, halved twice): fine dust bands, each
// ring tinted with one of the eight cluster hues (the companion hues — lighter, so they read as
// dust rather than a fifth cluster) and given a soft glow. Glow is the expensive part (shadowBlur
// per fill), so the count is kept where ~1,700 glowing stars still hold a smooth frame.
const RINGS = [
  { r: 0.30, n: 225, speed: 0.11, tilt: [0.55, 0.20], alpha: 0.75, hue: "--phase-do-2", fallback: "#f2c14e" },
  { r: 0.50, n: 360, speed: -0.075, tilt: [-0.35, 0.45], alpha: 0.65, hue: "--phase-check-2", fallback: "#8fd9a8" },
  { r: 0.72, n: 480, speed: 0.05, tilt: [0.25, -0.50], alpha: 0.55, hue: "--phase-plan-2", fallback: "#8fb8e6" },
  { r: 0.94, n: 630, speed: -0.032, tilt: [-0.15, 0.15], alpha: 0.45, hue: "--phase-correction-2", fallback: "#c39be6" },
];
const DUST = 220;
const IDLE_SPIN = 0.012;    // rad/s about the vertical axis when nobody is touching it
const DRAG_GAIN = 0.0075;   // rad per CSS pixel of drag
const FRICTION = 1.6;       // 1/s — how fast thrown momentum decays toward the idle spin
const CLUSTER_R = 0.66;     // cluster centres sit on this sphere (fraction of the field radius); clear of the core
// Core: a fifth cluster fixed at the centre, warm ink and gold, that the four PDCC clusters
// orbit. The orbit circles in the disc's plane (about the system's z axis), so the four are seen
// going *around* the core rather than across it; one revolution ≈ 60 s. The idle spin and any
// drag tumble the whole system, orbit included, which tilts the orbital plane over time.
const CORE_DOTS = 360;      // 240 × 1.5
// Spreads scale with the cube root of the dot count so dot spacing and size stay the same when
// the count grows: 0.20 × 1.5^(1/3) for the core, 0.30 × 2^(1/3) for the phase clusters.
const CORE_SPREAD = 0.229;  // fraction of R
const ORBIT_SPEED = 0.105;  // rad/s
// Wind dust: free motes that ride a slowly turning breeze across the disc, independent of the
// 3D rotation. Shake dust: extra motes shed from the clusters while dragging, proportional to
// how hard the field is being shaken; they fade out and settle downward.
const WIND_MOTES = 1400;  // 10× the original 140: a visible haze wandering between the clusters
const WIND_SPEED = 0.028;   // fraction of R per second
const SHAKE_MAX = 700;      // cap on live shake motes
const SHAKE_GRAVITY = 0.09; // fraction of R per s² — a gentle settle, not a fall
// Instrument (Stage 2) tuning. Named stars are few (one per open task), so they may glow.
const NAMED_R = [2.2, 2.8];       // named star base radius range, px (hashed per task)
const NAMED_REACH = 0.55;         // named stars sit inside this fraction of the cluster spread
const EMBER_PERIOD = 1.6;         // s — the running-right-now pulse
const SPARKS_PER_STAR = 40;       // live ember sparks per running/failed Do star
const SPARK_LIFE = 1.5;           // s
const SPARK_SPEED = 0.16;         // fraction of R per second along the orbit toward the next phase
const WIND_BASELINE = 400;        // motes always shown; +100 per open capture, capped at WIND_MOTES
const WIND_PER_CAPTURE = 100;
const BEAD_R = 2.4;               // automation bead radius, px
const BEAD_ACCEL = 300;           // display acceleration: one real hour of schedule = 12 s of travel
const COMET_TIME = 1.4;           // s — the acceptance comet's flight from Check into the core
const STARS_PUBLISH_MS = 500;     // how often the canvas republishes projected star positions
const HIT_RADIUS = 10;            // px — hover/click hit radius for a named star
const CLICK_SLOP = 4;             // px — a pointer that moves less than this on release is a click
// Comet memory: accepted_total per scope from the previous render, so a re-render after an
// acceptance fires the comet once and a first load never does.
const lastAccepted = new Map();

// Deterministic per-task randomness (FNV-1a seed, xorshift stream) so a named star keeps its
// place across reloads and re-renders.
function hashSeed(text) {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0 || 1;
}
function seeded(seed) {
  let s = seed;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}

// Rotation helpers: 3×3 matrices as flat arrays, row-major.
const I3 = [1, 0, 0, 0, 1, 0, 0, 0, 1];
function rotX(a) { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, c, -s, 0, s, c]; }
function rotY(a) { const c = Math.cos(a), s = Math.sin(a); return [c, 0, s, 0, 1, 0, -s, 0, c]; }
function rotZ(a) { const c = Math.cos(a), s = Math.sin(a); return [c, -s, 0, s, c, 0, 0, 0, 1]; }
function mul(a, b) {
  const o = new Array(9);
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++)
    o[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
  return o;
}
function apply(m, x, y, z) {
  return [m[0] * x + m[1] * y + m[2] * z, m[3] * x + m[4] * y + m[5] * z, m[6] * x + m[7] * y + m[8] * z];
}

function makeParticles(counts, size, instrument = null, action = null) {
  const centre = size / 2;
  const R = size * 0.47;             // field radius in CSS px
  const spread = 0.378;              // cluster radius, fraction of R (see CORE_SPREAD note)
  const ink = token("--ink-2") || "#c8c2b8";
  // Two hues per cluster (eight in all): the phase colour leads, its companion mixes in for
  // roughly two dots in five so every cluster shimmers rather than reading as a flat blob.
  const colours = {
    plan: [ink, token("--phase-plan-2") || "#8fb8e6"],
    do: [token("--accent"), token("--phase-do-2") || "#f2c14e"],
    check: [token("--phase-check"), token("--phase-check-2") || "#8fd9a8"],
    correction: [token("--phase-correction"), token("--phase-correction-2") || "#c39be6"],
  };
  // Cluster centres: four directions on the sphere, two slightly toward the viewer, two away,
  // so a tilt drag visibly reorders them in depth.
  const dirs = {
    plan: [-0.68, -0.68, 0.28], do: [0.68, -0.68, -0.28],
    check: [0.68, 0.68, 0.28], correction: [-0.68, 0.68, -0.28],
  };
  const rnd = Math.random;

  const dust = [];
  for (let i = 0; i < DUST; i++) {
    // Uniform direction on the sphere, radius between 0.75 and 1.0.
    const u = rnd() * 2 - 1, t = rnd() * Math.PI * 2, s = Math.sqrt(1 - u * u), r = 0.75 + rnd() * 0.25;
    dust.push({ x: s * Math.cos(t) * r, y: s * Math.sin(t) * r, z: u * r, radius: 0.5 + rnd() * 0.8, alpha: 0.25 + rnd() * 0.4, tw: rnd() * Math.PI * 2, tempo: 0.4 + rnd() * 1.2 });
  }

  const rings = RINGS.map((ring) => ({
    ...ring, colour: token(ring.hue) || ring.fallback,
    phase: rnd() * Math.PI * 2, plane: mul(rotX(ring.tilt[0]), rotY(ring.tilt[1])),
    stars: Array.from({ length: ring.n }, () => ({
      a: rnd() * Math.PI * 2, jitter: (rnd() - 0.5) * 0.045,
      radius: 0.45 + rnd() * 0.85, tw: rnd() * Math.PI * 2, tempo: 0.5 + rnd() * 1.0,
    })),
  }));

  const particles = [];
  for (const [id] of PHASES) {
    const [dx, dy, dz] = dirs[id];
    const n = Math.hypot(dx, dy, dz);
    const cx = (dx / n) * CLUSTER_R, cy = (dy / n) * CLUSTER_R, cz = (dz / n) * CLUSTER_R;
    for (let i = 0; i < dotCount(counts[id]); i++) {
      // Uniform direction, radius biased toward the cluster centre.
      const u = rnd() * 2 - 1, t = rnd() * Math.PI * 2, s = Math.sqrt(1 - u * u);
      const r = spread * rnd() * rnd() ** 0.35;
      const speed = (MAX_SPEED / R) * (0.3 + rnd() * 0.7);
      const du = rnd() * 2 - 1, dt = rnd() * Math.PI * 2, ds = Math.sqrt(1 - du * du);
      particles.push({ cx, cy, cz, ox: s * Math.cos(t) * r, oy: s * Math.sin(t) * r, oz: u * r,
        vx: ds * Math.cos(dt) * speed, vy: ds * Math.sin(dt) * speed, vz: du * speed,
        radius: 0.8 + rnd() * 1.0, colour: colours[id][rnd() < 0.4 ? 1 : 0], alpha: 0.6 + rnd() * 0.4,
        breath: rnd() * Math.PI * 2, tempo: BREATH_TEMPO[id] * (0.85 + rnd() * 0.3), breathing: 0.5 });
    }
  }
  // The core carries all eight hues at once, evenly mixed.
  const coreColours = [
    token("--ink") || "#ece8de", token("--phase-plan-2") || "#8fb8e6",
    token("--accent") || "#ff7a2a", token("--phase-do-2") || "#f2c14e",
    token("--phase-check") || "#4fb3a9", token("--phase-check-2") || "#8fd9a8",
    token("--phase-correction") || "#e07a8c", token("--phase-correction-2") || "#c39be6",
  ];
  for (let i = 0; i < CORE_DOTS; i++) {
    const u = rnd() * 2 - 1, t = rnd() * Math.PI * 2, s = Math.sqrt(1 - u * u);
    const r = CORE_SPREAD * rnd() * rnd() ** 0.35;
    const speed = (MAX_SPEED / R) * (0.2 + rnd() * 0.5);
    const du = rnd() * 2 - 1, dt = rnd() * Math.PI * 2, ds = Math.sqrt(1 - du * du);
    particles.push({ core: true, cx: 0, cy: 0, cz: 0, ox: s * Math.cos(t) * r, oy: s * Math.sin(t) * r, oz: u * r,
      vx: ds * Math.cos(dt) * speed, vy: ds * Math.sin(dt) * speed, vz: du * speed,
      radius: 0.9 + rnd() * 1.1, colour: coreColours[i % coreColours.length], alpha: 0.65 + rnd() * 0.35,
      breath: rnd() * Math.PI * 2, tempo: 0.7 * (0.85 + rnd() * 0.3), breathing: 0.5 });
  }
  const wind = [];
  for (let i = 0; i < WIND_MOTES; i++) wind.push(newMote(rnd));

  // --- the instrument: what the real state adds to the field ---------------------------
  const centres = {};
  for (const [id] of PHASES) {
    const [dx, dy, dz] = dirs[id], n = Math.hypot(dx, dy, dz);
    centres[id] = [(dx / n) * CLUSTER_R, (dy / n) * CLUSTER_R, (dz / n) * CLUSTER_R];
  }
  const gold = token("--accent-2") || "#f0d78a";
  const accent = token("--accent") || "#d4af5a";
  const bright = token("--ink") || "#ebe6da";
  const ember = token("--ember") || "#ff7a2a";
  const rose = token("--phase-correction") || "#e07a8c";
  // 1. Named stars: one per open task, hashed into place near its cluster's centre.
  const named = [];
  for (const star of instrument?.stars || []) {
    if (!centres[star.phase]) continue;
    const h = seeded(hashSeed(String(star.id)));
    const u = h() * 2 - 1, t = h() * Math.PI * 2, s = Math.sqrt(1 - u * u);
    const r = spread * NAMED_REACH * (0.2 + 0.8 * Math.cbrt(h()));
    const [cx, cy, cz] = centres[star.phase];
    named.push({ star, phase: star.phase, cx, cy, cz, ox: s * Math.cos(t) * r, oy: s * Math.sin(t) * r, oz: u * r,
      radius: NAMED_R[0] + h() * (NAMED_R[1] - NAMED_R[0]), colour: colours[star.phase][0],
      breath: h() * Math.PI * 2, tempo: BREATH_TEMPO[star.phase] * 0.8, noise: h() * 97, sparks: [] });
  }
  // 9. Automation beads: one per enabled job on the first four rings; one real hour = 12 s.
  //    A periodic job starts from a hashed angle (stable per job); a once job sits at 12 o'clock.
  const beads = (instrument?.rings || []).slice(0, RINGS.length).map((job, i) => ({
    ring: i, job, colour: rings[i].colour,
    a: job.period_seconds ? seeded(hashSeed(String(job.id)))() * Math.PI * 2 : -Math.PI / 2,
    speed: job.period_seconds ? (Math.PI * 2) / (job.period_seconds / BEAD_ACCEL) : 0,
  }));
  // 6. The thread: from the core to the next star, or to the outermost ring for automations.
  const threadTo = named.some((p) => p.star.next) ? "star" : action?.phase === "automations" ? "ring" : null;
  const core = instrument?.core || {};
  const orbit = rnd() * Math.PI * 2;
  const motion = instrument?.worker_alive === false ? 0 : 1;                  // 10. worker down: the system stills
  return { centre, R, spread, ink, dust, rings, particles, wind, shake: [], windAngle: rnd() * Math.PI * 2,
    orbit, orbitM: rotZ(orbit),
    rot: I3, yawV: IDLE_SPIN * motion, pitchV: 0, dragging: false, shakeEnergy: 0, shakeVx: 0, shakeVy: 0,
    // instrument state
    motion, named, beads, centres, gold, accent, bright, ember, rose, threadTo, time: 0, comet: null, screenStars: [],
    coreScale: 1 + Math.min(core.accepted_total || 0, 40) / 40 * 0.35,        // 7. acceptances ever
    coreGlow: 1 + Math.min(core.accepted_7d || 0, 7) / 7 * 1.2,               // 7. acceptances this week
    windVisible: instrument ? Math.min(WIND_MOTES, WIND_BASELINE + (instrument.captures_open || 0) * WIND_PER_CAPTURE) : WIND_MOTES, // 8.
    windTint: colours.do[1],
    ringsAlpha: instrument && (instrument.rings || []).length === 0 ? 0.6 : 1,      // 9. no jobs: quieter bands
  };
}

// A wind mote somewhere on the disc (2D, screen space, fraction of R), with its own slow wobble.
function newMote(rnd, edge = false) {
  const a = rnd() * Math.PI * 2;
  const r = edge ? 1.0 : Math.sqrt(rnd());
  return { x: Math.cos(a) * r, y: Math.sin(a) * r, radius: 0.35 + rnd() * 0.6, alpha: 0.18 + rnd() * 0.3,
    wob: rnd() * Math.PI * 2, wobT: 0.6 + rnd() * 1.4, drift: 0.6 + rnd() * 0.8 };
}

function drawStar(ctx, x, y, radius, colour, alpha, glow) {
  ctx.globalAlpha = alpha;
  ctx.fillStyle = colour;
  ctx.shadowColor = colour;
  ctx.shadowBlur = glow;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
}

// A cluster particle's position in the system's own frame: phase clusters revolve about the
// core on the orbit matrix; the core (and its own drift) stays put, its extent scaled by the
// acceptances ever recorded (7. — drawing scale only, CORE_SPREAD is untouched).
function clusterPos(f, p) {
  if (p.core) { const k = f.coreScale || 1; return [p.ox * k, p.oy * k, p.oz * k]; }
  const [cx, cy, cz] = apply(f.orbitM, p.cx, p.cy, p.cz);
  return [cx + p.ox, cy + p.oy, cz + p.oz];
}

// Depth cue: things toward the viewer (z → +1) are a little larger and brighter.
function depthScale(z) { return 0.7 + 0.3 * (z + 1) / 2; }
function depthAlpha(z) { return 0.35 + 0.65 * (z + 1) / 2; }

// System-frame point → screen: orbit (for cluster-anchored points), then the user's rotation.
function toScreen(f, x, y, z, orbiting = true) {
  const [ox, oy, oz] = orbiting ? apply(f.orbitM, x, y, z) : [x, y, z];
  const [sx, sy, sz] = apply(f.rot, ox, oy, oz);
  return [f.centre + sx * f.R, f.centre + sy * f.R, sz];
}

function strokeCircle(ctx, x, y, r, colour, alpha, width, dash = null, offset = 0) {
  ctx.globalAlpha = alpha; ctx.strokeStyle = colour; ctx.lineWidth = width; ctx.shadowBlur = 0;
  ctx.setLineDash(dash || []); ctx.lineDashOffset = offset;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
  ctx.setLineDash([]);
}

// 6. The gold thread from the core to the next thing: 1px, a slight sinus shimmer along it.
function drawThread(ctx, f, x0, y0, x1, y1) {
  const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy) || 1, nx = -dy / len, ny = dx / len;
  ctx.globalAlpha = 0.55; ctx.strokeStyle = f.gold; ctx.lineWidth = 1; ctx.shadowBlur = 0;
  ctx.beginPath();
  for (let i = 0; i <= 28; i++) {
    const s = i / 28, wave = Math.sin(s * Math.PI) * Math.sin(f.time * 2.2 + s * 7) * 1.6;
    const x = x0 + dx * s + nx * wave, y = y0 + dy * s + ny * wave;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();
}

// Per-phase drawing of a named star (1.–6.). `n` is the named particle, (x, y, z) its screen
// position. The star's own dot is drawn last so it sits on its cage/ring/arc.
function drawNamed(ctx, f, n, x, y, z) {
  const star = n.star, t = f.time;
  const b = 0.5 + 0.5 * Math.sin(n.breath);
  const ds = depthScale(z), da = depthAlpha(z);
  let radius = n.radius * (0.9 + 0.25 * b) * ds, colour = n.colour, alpha = (0.85 + 0.15 * b) * da, glow = 10;
  let ringColour = n.colour, ringAlpha = 0.35, ringWidth = 1;
  if (star.next) { radius *= 1.2; glow = 26; alpha = Math.min(1, alpha + 0.1); ringAlpha = 0.8; ringColour = f.gold; }
  if (n.phase === "plan") {
    if (star.ready) { colour = f.gold; glow = 18; drawStar(ctx, x, y, radius * 3.2, f.gold, 0.16 * da, 0); }
    else {
      alpha *= Math.max(0.35, 1 - (star.gates_unmet || 0) / 5);
      strokeCircle(ctx, x, y, radius * 3, f.ink, 0.25 * da, 1); // the cage
    }
  } else if (n.phase === "do") {
    const state = star.execution;
    if (state === "running") {
      const pulse = 0.5 + 0.5 * Math.sin((t / EMBER_PERIOD) * Math.PI * 2);
      colour = f.ember; glow = 16 + 20 * pulse; alpha = (0.75 + 0.25 * pulse) * da; ringColour = f.ember; ringAlpha = 0.5 + 0.3 * pulse;
      drawStar(ctx, x, y, radius * (2.4 + 1.6 * pulse), f.ember, 0.22 * pulse * da, 0);
    } else if (state === "failed" || state === "blocked") {
      const flick = 0.55 + 0.45 * Math.abs(Math.sin(t * 9 + n.noise) * Math.sin(t * 5.3 + n.noise * 0.7));
      colour = f.rose; alpha *= flick; ringColour = f.rose;
    }
  } else if (n.phase === "check") {
    // 4. the waiting ring: a slow gold dash gap turning; overdue turns it rose and thicker.
    const rr = radius * 2.5, circ = rr * Math.PI * 2;
    const overdue = !!star.overdue;
    strokeCircle(ctx, x, y, rr, overdue ? f.rose : f.accent, (overdue ? 0.7 : 0.55) * da,
      overdue ? 1.6 : 1, [circ * 0.78, circ * 0.22], -t * 6);
  } else if (n.phase === "correction") {
    // 5. rose star; the flicker grows with failed criteria; a thin arc loops back toward Do.
    const amp = Math.min(3, star.failed_criteria || 0) / 3;
    const flick = 1 - amp * 0.55 * Math.abs(Math.sin(t * 11 + n.noise) * Math.sin(t * 4.7 + n.noise * 1.3));
    colour = f.rose; alpha *= flick; ringColour = f.rose;
    const [dx, dy] = toScreen(f, ...f.centres.do);
    const mx = (x + dx) / 2, my = (y + dy) / 2, px = -(dy - y), py = dx - x;
    ctx.globalAlpha = 0.3 * da; ctx.strokeStyle = f.rose; ctx.lineWidth = 1; ctx.shadowBlur = 0;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(mx + px * 0.42, my + py * 0.42, dx, dy); ctx.stroke();
  }
  // 3. sparks (already stepped): tiny, unblurred, fading with life.
  for (const s of n.sparks) {
    const [sx, sy, sz] = toScreen(f, s.x, s.y, s.z);
    const life = s.life / SPARK_LIFE;
    drawStar(ctx, sx, sy, 1.0 * depthScale(sz), s.colour, 0.9 * life * depthAlpha(sz), 0);
  }
  strokeCircle(ctx, x, y, radius + 1.5, ringColour, ringAlpha * da, ringWidth);
  drawStar(ctx, x, y, radius, colour, alpha, glow);
}

function draw(ctx, size, f) {
  ctx.clearRect(0, 0, size, size);
  const c = f.centre, R = f.R, m = f.rot;
  // 0. wind dust — flat, behind the system. 8. Only the first N motes show (baseline + open
  //    captures); those above the baseline are gold-tinted: raw material not yet planned.
  const shown = Math.min(f.windVisible ?? WIND_MOTES, f.wind.length);
  for (let i = 0; i < shown; i++) {
    const w = f.wind[i];
    const tw = 0.6 + 0.4 * Math.sin(w.wob);
    const raw = i >= WIND_BASELINE;
    drawStar(ctx, c + w.x * R, c + w.y * R, w.radius, raw ? f.windTint : f.ink, w.alpha * tw * (raw ? 0.7 : 1), 0);
  }
  // 1. dust
  for (const d of f.dust) {
    const [x, y, z] = apply(m, d.x, d.y, d.z);
    const tw = 0.5 + 0.5 * Math.sin(d.tw);
    drawStar(ctx, c + x * R, c + y * R, d.radius * depthScale(z), f.ink, d.alpha * (0.5 + 0.5 * tw) * depthAlpha(z), 0);
  }
  // 2. rings: stars on a circle in the ring's plane, then the faint orbit line as a polyline
  const ringsAlpha = f.ringsAlpha ?? 1;
  for (const ring of f.rings) {
    const pm = mul(m, ring.plane);
    for (const s of ring.stars) {
      const a = s.a + ring.phase, rr = ring.r + s.jitter;
      const [x, y, z] = apply(pm, Math.cos(a) * rr, Math.sin(a) * rr, 0);
      const tw = 0.5 + 0.5 * Math.sin(s.tw);
      drawStar(ctx, c + x * R, c + y * R, s.radius * (0.8 + 0.5 * tw) * depthScale(z), ring.colour, ring.alpha * ringsAlpha * (0.5 + 0.5 * tw) * depthAlpha(z), 6 * tw);
    }
    ctx.globalAlpha = 0.14 * ringsAlpha; ctx.strokeStyle = ring.colour; ctx.lineWidth = 0.7; ctx.shadowBlur = 0;
    ctx.beginPath();
    for (let i = 0; i <= 72; i++) {
      const a = (i / 72) * Math.PI * 2;
      const [x, y] = apply(pm, Math.cos(a) * ring.r, Math.sin(a) * ring.r, 0);
      if (i === 0) ctx.moveTo(c + x * R, c + y * R); else ctx.lineTo(c + x * R, c + y * R);
    }
    ctx.stroke();
  }
  // 9. automation beads riding their ring planes (a still bead at 12 o'clock for a once job);
  //    the ones on the far side go under the clusters, the near ones over them.
  const beads = (f.beads || []).map((bead) => {
    const ring = f.rings[bead.ring];
    const [x, y, z] = apply(mul(m, ring.plane), Math.cos(bead.a) * ring.r, Math.sin(bead.a) * ring.r, 0);
    bead.sx = c + x * R; bead.sy = c + y * R;
    return { bead, z };
  });
  const drawBead = ({ bead, z }) => {
    // A hue-glow disc under a near-white centre so the bead reads against its own dust band.
    drawStar(ctx, bead.sx, bead.sy, BEAD_R * 2.6 * depthScale(z), bead.colour, 0.18 * depthAlpha(z), 0);
    drawStar(ctx, bead.sx, bead.sy, BEAD_R * depthScale(z), bead.colour, 0.95 * depthAlpha(z), 16);
    drawStar(ctx, bead.sx, bead.sy, BEAD_R * 0.55 * depthScale(z), f.bright, 0.9 * depthAlpha(z), 0);
  };
  for (const b of beads) if (b.z < 0) drawBead(b);
  // 3. clusters, far to near so the front ones overdraw. The core's glow scales with this
  //    week's acceptances (7.).
  const coreGlow = f.coreGlow || 1;
  const projected = f.particles.map((p) => {
    const [wx, wy, wz] = clusterPos(f, p);
    const [x, y, z] = apply(m, wx, wy, wz);
    return { p, x: c + x * R, y: c + y * R, z };
  });
  projected.sort((a, b) => a.z - b.z);
  for (const { p, x, y, z } of projected) {
    const b = p.breathing;
    const radius = p.radius * (0.6 + 1.6 * b) * depthScale(z) * (p.core ? f.coreScale || 1 : 1);
    const alpha = p.alpha * depthAlpha(z);
    if (b > 0.45) drawStar(ctx, x, y, radius * 3.0, p.colour, alpha * (b - 0.45) * 0.22, 0); // halo on the inhale
    drawStar(ctx, x, y, radius, p.colour, alpha * (0.5 + 0.5 * b), 22 * b * b * (p.core ? coreGlow : 1));
  }
  // 4. shake dust — shed motes in the cluster's colour, fading as they settle
  for (const s of f.shake) {
    const life = s.life / s.life0;
    drawStar(ctx, c + s.x * R, c + s.y * R, s.radius * (0.6 + 0.4 * life), s.colour, s.alpha * life, 3 * life);
  }
  for (const b of beads) if (b.z >= 0) drawBead(b);
  // 5. the instrument: named stars after their halos, in depth order, with the thread first
  //    so it runs under the star it points at.
  const named = (f.named || []).map((n) => {
    const [x, y, z] = toScreen(f, n.cx + n.ox, n.cy + n.oy, n.cz + n.oz);
    return { n, x, y, z };
  });
  named.sort((a, b) => a.z - b.z);
  f.screenStars = named.map(({ n, x, y, z }) => ({ id: n.star.id, star: n.star, x, y, z }));
  if (f.threadTo === "star") {
    for (const { n, x, y } of named) if (n.star.next) drawThread(ctx, f, c, c, x, y);
  } else if (f.threadTo === "ring") {
    const ring = f.rings[f.rings.length - 1], bead = (f.beads || []).find((b) => b.ring === f.rings.length - 1);
    const [x, y] = bead ? [bead.sx, bead.sy] : apply(mul(m, ring.plane), 0, -ring.r, 0).map((v, i) => c + v * R).slice(0, 2);
    drawThread(ctx, f, c, c, x, y);
  }
  for (const { n, x, y, z } of named) drawNamed(ctx, f, n, x, y, z);
  // 7. the acceptance comet: a gold streak from the Check cluster into the core, once.
  if (f.comet) {
    const k = Math.min(1, f.comet.t / COMET_TIME), e = 1 - (1 - k) ** 2;
    const [x0, y0] = toScreen(f, ...f.centres.check);
    const hx = x0 + (c - x0) * e, hy = y0 + (c - y0) * e, tail = Math.max(0, e - 0.22);
    ctx.globalAlpha = 0.85 * (1 - k * 0.5); ctx.strokeStyle = f.gold; ctx.lineWidth = 1.4; ctx.shadowBlur = 0;
    ctx.beginPath(); ctx.moveTo(x0 + (c - x0) * tail, y0 + (c - y0) * tail); ctx.lineTo(hx, hy); ctx.stroke();
    drawStar(ctx, hx, hy, 2.6, f.gold, 1 - k * 0.6, 28);
  }
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 1;
}

function step(f, dt) {
  // 10. A dead worker stills the system: the idle spin and the orbit run through this factor.
  const motion = f.motion ?? 1, idle = IDLE_SPIN * motion;
  f.time += dt;
  // Rotation: while dragging the pointer handler turns the system directly; when released the
  // thrown velocity eases back to the idle spin (yaw) and to rest (pitch).
  if (!f.dragging) {
    const k = Math.exp(-FRICTION * dt);
    f.yawV = idle + (f.yawV - idle) * k;
    f.pitchV *= k;
    f.rot = mul(mul(rotY(f.yawV * dt), rotX(f.pitchV * dt)), f.rot);
  }
  // Wind: the breeze direction turns slowly; motes drift with it plus a personal wobble, and
  // re-enter from the upwind edge when they leave the disc.
  f.orbit += ORBIT_SPEED * motion * dt;
  f.orbitM = rotZ(f.orbit);
  f.windAngle += 0.05 * dt;
  const wx = Math.cos(f.windAngle), wy = Math.sin(f.windAngle);
  for (const w of f.wind) {
    w.wob += w.wobT * dt;
    const side = Math.sin(w.wob) * 0.35;
    w.x += (wx * w.drift + -wy * side) * WIND_SPEED * dt;
    w.y += (wy * w.drift + wx * side) * WIND_SPEED * dt;
    if (w.x * w.x + w.y * w.y > 1.02) {
      // Re-enter upwind, at a random point along the edge facing the wind.
      const spreadA = (Math.random() - 0.5) * Math.PI * 0.9;
      const a = Math.atan2(-wy, -wx) + spreadA;
      w.x = Math.cos(a) * 0.995; w.y = Math.sin(a) * 0.995;
    }
  }
  // Shake dust: shed while the field is being shaken, in proportion to the shake energy the
  // pointer handler accumulates; each mote inherits the cluster's colour and a kick outward.
  if (f.shakeEnergy > 0.02 && f.shake.length < SHAKE_MAX) {
    const budget = Math.min(60, Math.round(f.shakeEnergy * 90 * dt * 60));
    for (let i = 0; i < budget && f.shake.length < SHAKE_MAX; i++) {
      const p = f.particles[(Math.random() * f.particles.length) | 0];
      const [wx, wy, wz] = clusterPos(f, p);
      const [x, y, z] = apply(f.rot, wx, wy, wz);
      const kick = 0.15 + Math.random() * 0.35 * Math.min(1, f.shakeEnergy);
      const ang = Math.random() * Math.PI * 2;
      f.shake.push({ x, y, vx: Math.cos(ang) * kick + f.shakeVx * 0.4, vy: Math.sin(ang) * kick + f.shakeVy * 0.4,
        colour: p.colour, radius: 0.5 + Math.random() * 0.9, alpha: 0.5 + Math.random() * 0.4 * depthAlpha(z),
        life0: 1.2 + Math.random() * 1.8, life: 0 });
      f.shake[f.shake.length - 1].life = f.shake[f.shake.length - 1].life0;
    }
  }
  f.shakeEnergy *= Math.exp(-3.5 * dt);
  for (let i = f.shake.length - 1; i >= 0; i--) {
    const s = f.shake[i];
    s.vx *= Math.exp(-1.4 * dt); s.vy = s.vy * Math.exp(-1.4 * dt) + SHAKE_GRAVITY * dt;
    s.x += s.vx * dt; s.y += s.vy * dt;
    s.life -= dt;
    if (s.life <= 0 || s.x * s.x + s.y * s.y > 1.1) { f.shake[i] = f.shake[f.shake.length - 1]; f.shake.pop(); }
  }
  for (const d of f.dust) d.tw += d.tempo * dt;
  for (const ring of f.rings) {
    ring.phase += ring.speed * dt;
    for (const s of ring.stars) s.tw += s.tempo * dt;
  }
  const limit = f.spread * 1.15, coreLimit = CORE_SPREAD * 1.15;
  for (const p of f.particles) {
    const lim = p.core ? coreLimit : limit;
    p.ox += p.vx * dt; p.oy += p.vy * dt; p.oz += p.vz * dt;
    p.breath += p.tempo * dt;
    p.breathing = 0.5 + 0.5 * Math.sin(p.breath);
    // Drift is bounded: past the cluster edge the velocity turns back inward.
    if (p.ox * p.ox + p.oy * p.oy + p.oz * p.oz > lim * lim) {
      if (p.ox * p.vx > 0) p.vx = -p.vx;
      if (p.oy * p.vy > 0) p.vy = -p.vy;
      if (p.oz * p.vz > 0) p.vz = -p.vz;
    }
  }
  stepInstrument(f, dt);
}

// The instrument's own motion: named-star breathing, Do sparks (3.), beads (9.), comet (7.).
function stepInstrument(f, dt) {
  for (const n of f.named || []) {
    n.breath += n.tempo * dt;
    const state = n.phase === "do" ? n.star.execution : null;
    const shedding = state === "running" || state === "failed" || state === "blocked";
    if (shedding && n.sparks.length < SPARKS_PER_STAR) {
      // Toward the next phase (Check) while running; down toward Correction when it failed.
      const [tx, ty, tz] = f.centres[state === "running" ? "check" : "correction"];
      const dx = tx - n.cx, dy = ty - n.cy, dz = tz - n.cz, len = Math.hypot(dx, dy, dz) || 1;
      const budget = Math.min(3, Math.round(SPARKS_PER_STAR / SPARK_LIFE * dt) + (Math.random() < 0.5 ? 1 : 0));
      for (let i = 0; i < budget && n.sparks.length < SPARKS_PER_STAR; i++) {
        const jitter = () => (Math.random() - 0.5) * SPARK_SPEED * 0.6;
        n.sparks.push({ x: n.cx + n.ox, y: n.cy + n.oy, z: n.cz + n.oz,
          vx: (dx / len) * SPARK_SPEED + jitter(), vy: (dy / len) * SPARK_SPEED + jitter(), vz: (dz / len) * SPARK_SPEED + jitter(),
          life: SPARK_LIFE, colour: state === "running" ? f.ember : f.rose });
      }
    }
    for (let i = n.sparks.length - 1; i >= 0; i--) {
      const s = n.sparks[i];
      s.x += s.vx * dt; s.y += s.vy * dt; s.z += s.vz * dt; s.life -= dt;
      if (s.life <= 0) { n.sparks[i] = n.sparks[n.sparks.length - 1]; n.sparks.pop(); }
    }
  }
  for (const bead of f.beads || []) bead.a += bead.speed * dt;
  if (f.comet) { f.comet.t += dt; if (f.comet.t >= COMET_TIME) f.comet = null; }
}

// 12. Hit-testing the named stars: the nearest projected star within HIT_RADIUS CSS px of a
// canvas-relative point, or null.
function starAt(f, x, y) {
  let best = null, bestD = HIT_RADIUS;
  for (const s of f.screenStars || []) {
    const d = Math.hypot(s.x - x, s.y - y);
    if (d <= bestD) { best = s; bestD = d; }
  }
  return best;
}

// The tooltip: title + one line of state, placed beside the pointer inside .hero-orrery and
// flipped to the left when it would overflow the orrery's width.
function showTip(tip, canvas, hit, x, y) {
  if (!tip) return;
  tip.replaceChildren(el("strong", { class: "hero-tip-title" }, hit.star.title),
    el("span", { class: "hero-tip-state" }, starStateLine(hit.star)));
  tip.hidden = false;
  const parent = tip.offsetParent || tip.parentElement, pr = parent.getBoundingClientRect(), cr = canvas.getBoundingClientRect();
  let left = cr.left - pr.left + x + 14, top = cr.top - pr.top + y + 14;
  if (left + tip.offsetWidth > pr.width) left = Math.max(0, cr.left - pr.left + x - tip.offsetWidth - 14);
  if (top + tip.offsetHeight > pr.height) top = Math.max(0, cr.top - pr.top + y - tip.offsetHeight - 14);
  tip.style.left = `${Math.round(left)}px`;
  tip.style.top = `${Math.round(top)}px`;
}
function hideTip(tip, canvas) {
  if (tip && !tip.hidden) tip.hidden = true;
  delete canvas.dataset.hit;
}

// Grab-and-spin. Pointer events cover mouse, touch and pen; the canvas has touch-action: none
// so a phone drag rotates the system instead of scrolling the page. Without a drag the pointer
// hovers the named stars (tooltip, pointer cursor) and a still click opens the task (12.).
function attachDrag(canvas, getField, tip = null) {
  let lastX = 0, lastY = 0, lastT = 0, downX = 0, downY = 0, travelled = 0;
  const local = (e) => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  canvas.addEventListener("pointerdown", (e) => {
    const f = getField();
    if (!f || e.button !== 0 && e.pointerType === "mouse") return;
    f.dragging = true; f.yawV = 0; f.pitchV = 0; f.shakeVx = 0; f.shakeVy = 0;
    lastX = downX = e.clientX; lastY = downY = e.clientY; lastT = performance.now(); travelled = 0;
    canvas.setPointerCapture(e.pointerId);
    canvas.dataset.grabbing = "true";
    hideTip(tip, canvas);
    e.preventDefault();
  });
  canvas.addEventListener("pointermove", (e) => {
    const f = getField();
    if (!f) return;
    if (!f.dragging) {
      const [x, y] = local(e), hit = starAt(f, x, y);
      if (hit) { canvas.dataset.hit = "true"; showTip(tip, canvas, hit, x, y); } else hideTip(tip, canvas);
      return;
    }
    const now = performance.now();
    const dx = e.clientX - lastX, dy = e.clientY - lastY, dt = Math.max((now - lastT) / 1000, 1 / 240);
    travelled = Math.max(travelled, Math.hypot(e.clientX - downX, e.clientY - downY));
    // Drag right → spin right (positive yaw); drag down → tilt the top toward the viewer.
    const yaw = dx * DRAG_GAIN, pitch = -dy * DRAG_GAIN;
    f.rot = mul(mul(rotY(yaw), rotX(pitch)), f.rot);
    // Remember the throw velocity (smoothed) for the release.
    f.yawV = f.yawV * 0.5 + (yaw / dt) * 0.5;
    f.pitchV = f.pitchV * 0.5 + (pitch / dt) * 0.5;
    // Shaking: energy grows with pointer speed and especially with direction reversals, so a
    // rapid back-and-forth sheds far more dust than a smooth slow turn.
    const sx = dx / dt / f.R, sy = dy / dt / f.R; // screen velocity in R/s
    const speed = Math.hypot(sx, sy);
    const reversal = (sx * f.shakeVx + sy * f.shakeVy) < 0 ? 2.5 : 1;
    f.shakeEnergy = Math.min(3, f.shakeEnergy + speed * reversal * dt * 1.6);
    f.shakeVx = sx; f.shakeVy = sy;
    lastX = e.clientX; lastY = e.clientY; lastT = now;
  });
  canvas.addEventListener("pointerleave", () => hideTip(tip, canvas));
  const release = (e, click) => {
    const f = getField();
    if (!f || !f.dragging) return;
    f.dragging = false;
    // Cap the throw so a flick never turns into a blur.
    f.yawV = Math.max(-4, Math.min(4, f.yawV));
    f.pitchV = Math.max(-4, Math.min(4, f.pitchV));
    delete canvas.dataset.grabbing;
    try { canvas.releasePointerCapture(e.pointerId); } catch { /* already released */ }
    if (click && travelled < CLICK_SLOP) {
      const hit = starAt(f, ...local(e));
      if (hit?.star.href) { hideTip(tip, canvas); location.hash = hit.star.href; }
    }
  };
  canvas.addEventListener("pointerup", (e) => release(e, true));
  canvas.addEventListener("pointercancel", (e) => release(e, false));
}

// Renders once (reduced motion) or animates until the canvas leaves the DOM for good.
// The hero is built before it is attached (the Today render awaits other data first), so the
// loop must wait for the canvas to be connected rather than give up on the first frame.
function startField(canvas, counts, instrument = null, action = null, tip = null) {
  const ctx = canvas.getContext?.("2d");
  if (!ctx) return;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let size = 0, field = null, last = null, wasConnected = false, published = -Infinity;
  // 7. A task accepted since the previous render of this scope lands as a comet, once.
  const scope = document.getElementById("scope-label")?.textContent || "";
  const accepted = instrument?.core?.accepted_total;
  const comet = Number.isFinite(accepted) && lastAccepted.has(scope) && accepted > lastAccepted.get(scope);
  if (Number.isFinite(accepted)) lastAccepted.set(scope, accepted);
  const fit = () => {
    const css = Math.round(canvas.clientWidth) || 0;
    if (!css) return false;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (css === size && canvas.width === Math.round(css * dpr)) return false;
    size = css;
    canvas.width = Math.round(css * dpr);
    canvas.height = Math.round(css * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const previous = field;
    field = makeParticles(counts, size, instrument, action);
    if (previous) { field.rot = previous.rot; field.orbit = previous.orbit; field.orbitM = previous.orbitM; field.comet = previous.comet; } // keep the orientation across a resize
    else if (comet) field.comet = { t: 0 };
    return true;
  };
  attachDrag(canvas, () => field, tip);
  // The projected named stars, published on the canvas at most twice a second so tests (and
  // tooling) can find them without reaching into the module.
  const publish = (now) => {
    if (now - published < STARS_PUBLISH_MS) return;
    published = now;
    canvas.dataset.stars = JSON.stringify(field.screenStars.map((s) => ({ id: s.id, x: Math.round(s.x * 10) / 10, y: Math.round(s.y * 10) / 10 })));
  };
  const tick = (now) => {
    if (!canvas.isConnected) {
      if (wasConnected) { observer?.disconnect(); return; } // removed for good
      requestAnimationFrame(tick); // not attached yet — keep waiting
      return;
    }
    wasConnected = true;
    if (document.hidden) { last = null; requestAnimationFrame(tick); return; }
    fit();
    if (!field) { requestAnimationFrame(tick); return; }
    if (last !== null) step(field, Math.min((now - last) / 1000, 0.1));
    last = now;
    draw(ctx, size, field);
    publish(now);
    const idle = IDLE_SPIN * (field.motion ?? 1);
    if (reduced && !field.dragging && Math.abs(field.yawV - idle) < 1e-3 && Math.abs(field.pitchV) < 1e-3) {
      // Reduced motion: hold still, but keep listening so a deliberate drag still works.
      requestAnimationFrame(tick); last = null; return;
    }
    requestAnimationFrame(tick);
  };
  const observer = typeof ResizeObserver === "function"
    ? new ResizeObserver(() => { if (fit() && field) { draw(ctx, size, field); publish(performance.now()); } })
    : null;
  observer?.observe(canvas);
  requestAnimationFrame(tick);
}
