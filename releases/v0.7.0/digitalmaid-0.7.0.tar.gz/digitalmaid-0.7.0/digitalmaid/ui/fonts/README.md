Bundled web fonts (self-hosted; the UI makes no external requests).
- Outfit (variable, weights 300–700) — SIL Open Font License 1.1 — https://github.com/Outfitio/Outfit-Fonts
- Doto (700, 900) — SIL Open Font License 1.1 — https://github.com/oliviersaidi/doto (via Google Fonts)
- Cormorant Garamond by Christian Thalmann (light upright + italic, latin subset) — SIL Open Font License 1.1 — https://github.com/CatharsisFonts/Cormorant (via Google Fonts). Added 2026-09-09 for the "Observatory" direction (docs/DESIGN.md).
Files: outfit-latin.woff2, outfit-latin-ext.woff2, doto-latin.woff2, doto-latin-ext.woff2 (fetched 2026-09-06 from fonts.gstatic.com); cormorant-latin.woff2, cormorant-italic-latin.woff2 (fetched 2026-09-09 from fonts.gstatic.com).
- Vietnamese (added 2026-09-16): cormorant-vietnamese.woff2, cormorant-italic-vietnamese.woff2 (Cormorant Garamond Vietnamese subset); bevietnampro-{300,400,500,600}-vietnamese.woff2 — Be Vietnam Pro by Lâm Bảo, Tony Lê, Duy Đào and Trọng Vũ — SIL Open Font License 1.1 — https://github.com/bettergui/BeVietnamPro (via Google Fonts). Declared under the "Outfit" family name for the Vietnamese unicode-range only, because Outfit has no Vietnamese glyphs.

## Noto Sans / Noto Serif SC + JP (0.5.1, 2026-09-16)

Google Fonts unicode-range slices (450 files: notosanssc-*, notosansjp-*, notoserifsc-*, notoserifjp-*), listed in cjk-manifest.json and declared in ../fonts-cjk.css under the family names NotoSansSC, NotoSansJP, NotoSerifSC, NotoSerifJP. Copyright Google LLC (Noto is a trademark of Google LLC); Source Han derivative glyphs copyright Adobe. Licensed under the SIL Open Font License, Version 1.1 (same OFL text as above). Linked only when the UI language is zh or ja.
