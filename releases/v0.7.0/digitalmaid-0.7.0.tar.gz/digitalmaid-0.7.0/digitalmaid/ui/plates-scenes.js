// JOH Plates — the five scene builders (0.6.0, docs/DESIGN.md Appendix G3). Each takes the live
// profile view (the /api/joh/profile response) and returns plain scene data for plates.js:
// every drawn number comes from the profile; dust is seeded from the profile id and the chart
// name so a re-render never reshuffles it. Labels go through t(); centre and sphere names come
// from the (localised) profile itself.

import { T, rotX, rotY, mul, ap, rad, I3, seeded, hashSeed, cloud, thread, ring, shell, sparks, circle, ticks, polygon, gear, band, seg, shiftLines } from "./plates.js";
import { CENTRES, CHANNELS, GK_NODES, GK_EDGES } from "./joh.js";
import { t } from "./i18n.js";

const TAU = Math.PI * 2;
// The bodies drawn on the wheel: the ten planets and the North Node (the aspect bodies).
const WHEEL_BODIES = ["sun", "moon", "mercury", "venus", "mars", "jupiter", "saturn", "uranus", "neptune", "pluto", "true_node"];
const PLANET_GLYPH = { sun: "☉", moon: "☽", mercury: "☿", venus: "♀", mars: "♂", jupiter: "♃", saturn: "♄", uranus: "♅", neptune: "♆", pluto: "♇", true_node: "☊" };
const PLANET_COL = { sun: T.gold2, moon: T.white, mercury: T.ink, venus: T.gold2, mars: T.rose, jupiter: T.do, saturn: T.gold, uranus: T.sky, neptune: T.sky, pluto: T.violet, true_node: T.ink2 };
const SIGN_GLYPH = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"].map((g) => g + "︎");
const SOFT_ASPECTS = new Set(["conjunction", "trine", "sextile"]);
const CROWD_DEG = 14;   // a name needs about this much arc at the planet ring before it strikes its neighbour's
const GK_SEQ = { "Life's Work": "activation", Evolution: "activation", Radiance: "activation", Purpose: "activation", Attraction: "venus", IQ: "venus", EQ: "venus", SQ: "venus", "Core Wound": "venus", Vocation: "pearl", Culture: "pearl", Pearl: "pearl", Brand: "pearl" };
const SEQ_COL = { activation: T.gold2, venus: T.rose, pearl: T.violet };
// The seated light body in the bodygraph's 300×520 space (head, shoulders/arms, torso, ribs, lotus legs, diagonals).
const FIGURE = [
  Array.from({ length: 28 }, (_, i) => [150 + Math.cos(i * TAU / 28) * 40, 72 + Math.sin(i * TAU / 28) * 44]).concat([[190, 72]]),
  [[128, 112], [122, 138], [60, 158], [38, 230], [48, 300], [70, 330], [100, 372], [120, 392], [150, 400]],
  [[172, 112], [178, 138], [240, 158], [262, 230], [252, 300], [230, 330], [200, 372], [180, 392], [150, 400]],
  [[80, 165], [72, 240], [86, 330], [100, 398]], [[220, 165], [228, 240], [214, 330], [200, 398]],
  [[80, 200], [220, 200]], [[76, 240], [224, 240]], [[82, 290], [218, 290]], [[92, 340], [208, 340]],
  [[100, 398], [40, 440], [24, 470], [90, 496], [150, 484], [176, 470]], [[200, 398], [260, 440], [276, 470], [210, 496], [150, 484], [124, 470]],
  [[80, 165], [150, 240], [220, 165]], [[72, 240], [150, 340], [228, 240]], [[86, 330], [150, 400], [214, 330]], [[60, 158], [150, 185], [240, 158]],
];
const ENNEA_TRIANGLE_HEXAD = [[3, 6], [6, 9], [9, 3], [1, 4], [4, 2], [2, 8], [8, 5], [5, 7], [7, 1]];

export function degText(p) { return `${p.degree}°${String(p.minute).padStart(2, "0")}′`; }
function seedFor(profile, chart) { return hashSeed(`${profile.id}:${chart}`); }

// --- Plate I — The Engine --------------------------------------------------------------------------
export function overviewScene(profile) {
  const seed = seedFor(profile, "overview"), rnd = seeded(seed);
  const stars = [], dust = shell(rnd, 300, 1.05, 1.3), threads = [], lines = [];
  const disc = rotX(1.05);
  lines.push(...band(1.18, 1.3, disc, 0, { n: 144, scallop: 36 }), gear(1.02, 48, 0.035, disc, T.gold, 0.45), gear(0.66, 24, 0.04, disc, T.gold, 0.4), ...band(0.44, 0.52, disc, 0.1, { n: 72, dash: true }));
  for (const [r, a, d] of [[0.3, 0.4], [0.58, 0.35], [0.84, 0.3, [2, 5]], [0.92, 0.45], [1.1, 0.3, [1, 4]]]) lines.push(circle(r, disc, T.gold, a, d ? { dash: d } : {}));
  lines.push(polygon(0.58, 6, disc, T.gold, 0.28), polygon(0.58, 6, disc, T.gold, 0.28, 1, Math.PI / 6), polygon(0.3, 12, disc, T.gold, 0.25, 5), polygon(0.92, 12, disc, T.gold, 0.2, 5));
  lines.push(...ticks(0.3, 1.18, 12, disc, T.gold, 0.18), ...ticks(0.92, 1.02, 48, disc, T.gold, 0.35));
  const arm = mul(rotX(0.4), rotY(0.7));   // a steeper armillary ring crossing the disc
  lines.push(circle(1.12, arm, T.gold, 0.3), circle(1.16, arm, T.gold, 0.2, { dash: [1, 5] }), ...ticks(1.12, 1.16, 60, arm, T.gold, 0.3));
  lines.push(circle(1.0, mul(rotX(-0.3), rotY(-0.9)), T.gold, 0.22, { dash: [3, 3] }));
  const enn = profile.enneagram;
  const medallions = [
    ["astro", t("joh.tab.astro"), t("joh.plate.title.astro"), -90, T.gold2, true],
    ["bodygraph", t("joh.tab.bodygraph"), t("joh.plate.title.bodygraph"), -18, T.rose, false],
    ["genekeys", t("joh.tab.genekeys"), t("joh.plate.title.genekeys"), 54, T.violet, false],
    ["enneagram", t("joh.tab.enneagram"), enn ? `${enn.card.label} · ${enn.card.name}` : t("joh.overview.enneagramNotSet"), 126, T.check, false],
    ["compass", t("joh.tab.compass"), t("joh.askCompass"), 198, T.gold2, false],
  ];
  const C0 = { x: 0, y: 0, z: 0 };
  for (const [id, label, sub, ang, col, ringed] of medallions) {
    const [x, y, z] = ap(disc, Math.cos(rad(ang)) * 0.92, Math.sin(rad(ang)) * 0.92, 0);
    const s = { id, x, y, z, size: 3.0, col, label, sub, tab: id, flare: 2, medallion: 26, orb: true, ringed, tw: rnd() * TAU, tempo: 0.5 + rnd() * 0.5, drift: 0.003 };
    stars.push(s);
    lines.push(seg(C0, s, T.gold, 0.28));
    dust.push(...cloud(rnd, x, y, z, 120, 0.15, col, [0.35, 0.9], [0.3, 0.85]));
    threads.push(thread(rnd, C0, s, T.gold2, 40, 0.5, 0.02, 0.05, { role: "spoke" }));
  }
  const rings = [ring(rnd, 0.66, 320, T.gold2, 0.09, disc, 0.6), ring(rnd, 1.02, 420, T.gold, -0.05, disc, 0.5), ring(rnd, 0.44, 200, T.gold3, 0.13, disc, 0.6), ring(rnd, 1.12, 260, T.ink2, 0.04, arm, 0.35)];
  for (let i = 0; i < 7; i += 1) {   // small wandering orbs riding the rings — decoration
    const r = [0.44, 0.66, 1.02, 1.12][i % 4], a = rnd() * TAU, pl = i % 4 === 3 ? arm : disc;
    const [x, y, z] = ap(pl, Math.cos(a) * r, Math.sin(a) * r, 0);
    stars.push({ x, y, z, size: 1.0 + rnd() * 1.2, col: [T.ink2, T.sky, T.gold][i % 3], orb: true, ringed: i === 2, tw: rnd() * TAU, tempo: 0.4, drift: 0.002, nopick: true, deco: true });
  }
  return { seed, stars, dust, threads, rings, lines, sparks: sparks(rnd, 22, 0.3, 1.25, disc), blaze: { r: 0.17, rays: 36 },
    beam: { a: [0, -1.3, 0], b: [0, 1.3, 0], col: T.gold3, alpha: 0.6, width: 2.4 }, idle: 0.05, restPitch: -0.1, scale: 0.9,
    hoverText: (s) => (s?.label ? `${s.label} · ${s.sub}` : null) };
}

// --- Plate II — The Wheel of Signs -----------------------------------------------------------------
export function astroScene(profile) {
  const chart = profile.profile.astro;
  const seed = seedFor(profile, `astro:${profile.zodiac}`), rnd = seeded(seed);
  const asc = chart.ascendant.longitude, ascIndex = chart.ascendant.sign_index;
  const stars = [], threads = [], dust = shell(rnd, 220, 1.15, 1.35), lines = [];
  const tilt = rotX(0.55);
  // Longitude 0° at the right, the Ascendant on the left: a = 180° − lon + asc.
  const onEcl = (lon, r) => { const a = rad(180 - lon + asc); return ap(tilt, Math.cos(a) * r, Math.sin(a) * r, 0); };
  const ph = rad(180 + asc);
  lines.push(...band(1.2, 1.3, tilt, ph, { n: 360, scallop: 48 }), ...band(0.98, 1.06, tilt, ph, { n: 72, dash: true }), ...band(0.72, 0.76, tilt, ph, { n: 36 }));
  for (const [r, a, d] of [[1.12, 0.45], [0.92, 0.3, [2, 4]], [0.62, 0.3], [0.5, 0.28], [0.5, 0.18, [1, 5]], [0.3, 0.3], [0.18, 0.3]]) lines.push(circle(r, tilt, T.gold, a, d ? { dash: d } : {}));
  lines.push(...ticks(0.76, 1.2, 12, tilt, T.gold, 0.55, 1, ph), ...ticks(1.06, 1.12, 36, tilt, T.gold, 0.5, 1, ph));
  lines.push(polygon(0.5, 12, tilt, T.gold, 0.25, 1, ph), polygon(0.5, 12, tilt, T.gold, 0.22, 5, ph), polygon(0.5, 6, tilt, T.gold, 0.2, 1, ph), polygon(0.5, 6, tilt, T.gold, 0.2, 1, ph + Math.PI / 6), polygon(0.3, 8, tilt, T.gold, 0.25, 3, ph), polygon(0.62, 12, tilt, T.gold, 0.15, 5, ph));
  for (let i = 0; i < 12; i += 1) {   // degree numerals on the outer band
    const [x, y, z] = onEcl(i * 30, 1.34);
    stars.push({ x, y, z, size: 0.01, alpha: 0, col: T.gold, glyph: `${i * 30}°`, glyphFont: "500 ", glyphSize: 8, glyphCol: T.mute, dy: -5, tw: 0, tempo: 0, drift: 0, nopick: true, text: true });
  }
  for (let i = 0; i < 12; i += 1) {   // sign band: alternating dust, glyph medallion, whole-sign house number
    const col = i % 2 ? T.ink2 : T.gold;
    for (let k = 0; k < 50; k += 1) { const [x, y, z] = onEcl(i * 30 + rnd() * 30, 1.07 + rnd() * 0.05); dust.push({ x, y, z: z + (rnd() - 0.5) * 0.02, radius: 0.3 + rnd() * 0.6, alpha: 0.2 + rnd() * 0.35, tw: rnd() * TAU, tempo: 0.4 + rnd(), drift: 0.003, col }); }
    const [x, y, z] = onEcl(i * 30 + 15, 1.12), house = ((i - ascIndex + 12) % 12) + 1;
    stars.push({ x, y, z, size: 1.0, alpha: 0.8, col: T.gold2, glyph: SIGN_GLYPH[i], glyphSize: 19, dy: -24, tw: rnd() * TAU, tempo: 0.4, drift: 0, nopick: true, medallion: 12 });
    const [hx, hy, hz] = onEcl(i * 30 + 15, 0.84);
    stars.push({ x: hx, y: hy, z: hz, size: 0.01, alpha: 0, col: T.gold, glyph: String(house), glyphFont: "500 ", glyphSize: 10, glyphCol: T.ink2, dy: -6, tw: 0, tempo: 0, drift: 0, nopick: true, text: true });
  }
  const bodies = WHEEL_BODIES.filter((k) => chart.positions[k]).sort((a, b) => chart.positions[a].longitude - chart.positions[b].longitude);
  const P = {};
  // Bodies within CROWD_DEG of the previous one form a crowded run: each member steps to an alternate
  // radius (in, out, further in…) and shows its glyph only — the name is one hover away.
  let run = 0;
  bodies.forEach((k, i) => {
    const p = chart.positions[k], prev = bodies[i - 1];
    run = prev && Math.abs(p.longitude - chart.positions[prev].longitude) < CROWD_DEG ? run + 1 : 0;
    const step = [0, 0.12, -0.14, 0.24, -0.26, 0.36, -0.38][Math.min(run, 6)];
    const [x, y, z] = onEcl(p.longitude, 0.62 + step);
    const luminary = k === "sun" || k === "moon";
    P[k] = { id: k, x, y, z, size: luminary ? 3.6 : k === "true_node" ? 1.2 : 2.3, col: PLANET_COL[k], orb: k !== "true_node", ringed: k === "saturn", glyph: PLANET_GLYPH[k], glyphSize: 13,
      label: run ? "" : t(`joh.planet.${k}`), name: t(`joh.planet.${k}`), flare: luminary ? 2 : 1, tw: rnd() * TAU, tempo: 0.5 + rnd() * 0.6, drift: 0.003, body: p };
    stars.push(P[k]);
    const [tx, ty, tz] = onEcl(p.longitude, 0.76), [ux, uy, uz] = onEcl(p.longitude, 0.72);
    lines.push({ pts: [[tx, ty, tz], [ux, uy, uz]], col: T.gold3, alpha: 0.8 });
    const [ox, oy, oz] = onEcl(p.longitude, 1.2), [ix, iy, iz] = onEcl(p.longitude, 1.06);
    lines.push({ pts: [[ix, iy, iz], [ox, oy, oz]], col: T.gold2, alpha: 0.45 });
  });
  for (const a of chart.aspects || []) {   // the API's aspect list — never recomputed here
    if (!P[a.a] || !P[a.b]) continue;
    const soft = SOFT_ASPECTS.has(a.aspect_en ?? a.aspect);
    lines.push(seg(P[a.a], P[a.b], soft ? T.gold : T.rose, 0.35));
    threads.push(thread(rnd, P[a.a], P[a.b], soft ? T.gold3 : T.rose, 26, 0.6, 0.012, 0.03, { role: "aspect" }));
  }
  const centre = { x: 0, y: 0, z: 0 };
  const [ax, ay, az] = onEcl(asc, 1.32), A = { x: ax, y: ay, z: az };
  lines.push(seg(centre, A, T.gold3, 0.7, { width: 0.9 }));
  threads.push(thread(rnd, centre, A, T.gold3, 60, 0.7, 0.006, 0.04, { role: "asc" }));
  stars.push({ ...A, id: "asc", size: 1.6, col: T.gold3, label: t("joh.ascendant"), flare: 2, tw: 0, tempo: 0.3, drift: 0, body: chart.ascendant });
  const [mx, my, mz] = onEcl(chart.mc.longitude, 1.32), M = { x: mx, y: my, z: mz };
  lines.push(seg(centre, M, T.ink2, 0.4));
  stars.push({ ...M, id: "mc", size: 1.1, col: T.ink2, label: t("joh.midheaven"), tw: 0, tempo: 0.3, drift: 0, body: chart.mc });
  dust.push(...cloud(rnd, 0, 0, 0, 160, 0.16, T.gold2, [0.3, 0.9], [0.2, 0.6]));
  return { seed, stars, dust, threads, rings: [ring(rnd, 0.92, 300, T.gold2, 0.02, tilt, 0.4), ring(rnd, 1.16, 200, T.ink2, -0.015, tilt, 0.3)], lines,
    sparks: sparks(rnd, 26, 0.3, 1.3, tilt), blaze: { r: 0.12, rays: 28 }, idle: 0.03, restPitch: -0.3, scale: 0.84, dy: 14,
    hoverText: (s) => (s?.body ? `${s.name || s.label} · ${s.body.sign} ${degText(s.body)}` : null) };
}

// --- Plate III — The Light Body ----------------------------------------------------------------------
export function bodygraphScene(profile) {
  const hd = profile.profile.humandesign;
  const seed = seedFor(profile, "bodygraph"), rnd = seeded(seed);
  const stars = [], threads = [], dust = shell(rnd, 220, 1.1, 1.3), lines = [];
  const sides = hd.gates || {};
  const sideOf = (gate) => sides[String(gate)] || [];
  const byGate = {};
  for (const c of CENTRES) for (const g of c.gates) byGate[g] = c.name;
  const to3 = (x, y, z = 0) => ({ x: (x - 150) / 150 * 0.62, y: (y - 262) / 262 * 0.98, z });
  const C = Object.fromEntries(CENTRES.map((c) => [c.name, to3(c.x, c.y, 0.02)]));
  const definedEn = new Set(hd.defined_centres_en || hd.defined_centres || []);
  // Localised centre names for the defined ones ride on the profile; open centres keep the English name.
  const localName = Object.fromEntries((hd.defined_centres_en || hd.defined_centres || []).map((en, i) => [en, (hd.defined_centres || [])[i] || en]));
  lines.push(...band(1.1, 1.2, I3, 0, { n: 144, scallop: 24 }), circle(0.98, I3, T.gold, 0.3, { dash: [2, 5] }), polygon(1.1, 12, I3, T.gold, 0.2, 5), ...ticks(0.98, 1.1, 24, I3, T.gold, 0.25));
  for (const poly of FIGURE) {
    const pts = poly.map(([x, y]) => { const p = to3(x, y, 0); return [p.x, p.y, p.z]; });
    lines.push({ pts, col: T.gold, alpha: 0.6, width: 0.7, beads: 0.9 });
    for (let i = 1; i < pts.length; i += 1) threads.push(thread(rnd, { x: pts[i - 1][0], y: pts[i - 1][1], z: pts[i - 1][2] }, { x: pts[i][0], y: pts[i][1], z: pts[i][2] }, T.gold3, 8, 0.6, 0.012));
  }
  for (let i = 0; i < 260; i += 1) {   // faint lattice dust within the torso
    const p = to3(70 + rnd() * 160, 150 + rnd() * 250, (rnd() - 0.5) * 0.06);
    dust.push({ ...p, radius: 0.3 + rnd() * 0.6, alpha: 0.12 + rnd() * 0.3, tw: rnd() * TAU, tempo: 0.4 + rnd(), drift: 0.004, col: T.gold2 });
  }
  const seat = rotX(1.25), base = to3(150, 486);   // lotus ripples at the seat
  lines.push(...shiftLines([...band(0.7, 0.78, seat, 0, { n: 96, scallop: 16 }), circle(0.3, seat, T.gold, 0.4), circle(0.45, seat, T.gold, 0.3, { dash: [2, 5] }), circle(0.58, seat, T.gold, 0.35), circle(0.9, seat, T.gold, 0.25), circle(1.02, seat, T.gold, 0.2, { dash: [1, 4] }), polygon(0.58, 8, seat, T.gold, 0.2)], 0, base.y));
  const rings = [ring(rnd, 0.58, 240, T.gold2, 0.06, seat, 0.5, { dy: base.y }), ring(rnd, 0.9, 260, T.gold, -0.04, seat, 0.4, { dy: base.y })];
  const headC = to3(150, 72);   // halo
  lines.push(...shiftLines([circle(0.26, I3, T.gold, 0.45), circle(0.3, I3, T.gold, 0.3, { dash: [1, 3] }), ...ticks(0.26, 0.34, 36, I3, T.gold, 0.35), ...ticks(0.26, 0.4, 12, I3, T.gold2, 0.45), circle(0.44, I3, T.gold, 0.2)], headC.x, headC.y, -0.05));
  for (const c of CENTRES) {
    const p = C[c.name], isDef = definedEn.has(c.name);
    const activeGates = c.gates.filter((g) => sideOf(g).length);
    dust.push(...cloud(rnd, p.x, p.y, p.z, isDef ? 160 : 60, isDef ? 0.11 : 0.08, isDef ? T.gold2 : T.ink2, [0.3, 0.9], isDef ? [0.4, 0.9] : [0.12, 0.4]));
    stars.push({ ...p, id: c.name, size: isDef ? 3.0 : 1.4, alpha: isDef ? 1 : 0.7, col: isDef ? T.gold3 : T.ink2, label: localName[c.name] || c.name, flare: isDef ? 2 : 0, medallion: isDef ? 15 : 10,
      tw: rnd() * TAU, tempo: 0.4 + rnd() * 0.5, drift: 0.003, centre: c.name, defined: isDef, gates: activeGates, labelCol: isDef ? T.ink : T.mute });
  }
  for (const ch of hd.channels || []) {
    const [a, b] = ch.gates, A = C[byGate[a]], B = C[byGate[b]];
    const pers = sideOf(a).includes("personality") && sideOf(b).includes("personality");
    const both = (sideOf(a).includes("personality") || sideOf(b).includes("personality")) && (sideOf(a).includes("design") || sideOf(b).includes("design"));
    const gold = both || pers;
    lines.push(seg(A, B, gold ? T.gold : T.rose, 0.4));
    threads.push(thread(rnd, A, B, gold ? T.gold3 : T.rose, 70, 0.9, 0.035, 0.02, { role: "channel" }));
    if (both) threads.push(thread(rnd, A, B, T.rose, 20, 0.6, 0.01, -0.02));   // counter-flowing rose core
  }
  for (const [a, b] of CHANNELS) {   // hanging gates: a short thread 42 % toward the partner centre
    const ha = sideOf(a).length && !sideOf(b).length, hb = sideOf(b).length && !sideOf(a).length;
    if (!ha && !hb) continue;
    const gate = ha ? a : b, from = C[byGate[gate]], to = C[byGate[ha ? b : a]];
    const mid = { x: from.x + (to.x - from.x) * 0.42, y: from.y + (to.y - from.y) * 0.42, z: from.z };
    threads.push(thread(rnd, from, mid, sideOf(gate).includes("personality") ? T.gold : T.rose, 12, 0.4, 0.015));
  }
  const top = to3(150, 5), bottom = to3(150, 505);
  return { seed, stars, dust, threads, rings, lines, sparks: sparks(rnd, 24, 0.5, 1.2),
    beam: { a: [top.x, top.y, 0], b: [bottom.x, bottom.y, 0], col: T.gold3, alpha: 0.65, width: 2.6 }, blaze: { r: 0.07, rays: 16, y: C.G.y }, idle: 0.02, restPitch: -0.05, scale: 0.88, dy: -18,
    hoverText: (s) => (s?.centre ? `${s.label} · ${s.defined ? t("joh.bodygraph.centreDefined") : t("joh.bodygraph.centreOpen")} · ${s.gates.join(", ") || "—"}` : null) };
}

// --- Plate IV — The Thirteen Spheres --------------------------------------------------------------------
export function genekeysScene(profile) {
  const gk = profile.profile.genekeys;
  const seed = seedFor(profile, "genekeys"), rnd = seeded(seed);
  const stars = [], threads = [], dust = shell(rnd, 220, 1.15, 1.35), lines = [], N = {};
  const by = Object.fromEntries(gk.spheres.map((s) => [s.sphere_en ?? s.sphere, s]));
  lines.push(...band(1.18, 1.28, I3, 0, { n: 156, scallop: 26 }), circle(1.0, I3, T.gold, 0.28, { dash: [2, 6] }), circle(0.55, I3, T.gold, 0.25), polygon(0.55, 6, I3, T.gold, 0.22), polygon(0.55, 6, I3, T.gold, 0.22, 1, Math.PI / 6), polygon(1.0, 13, I3, T.gold, 0.18, 5), ...ticks(1.0, 1.18, 13, I3, T.gold, 0.2));
  for (let i = 0; i < 6; i += 1) { const a = i * Math.PI / 3; lines.push(...shiftLines([circle(0.55, I3, T.gold, 0.12)], Math.cos(a) * 0.55, Math.sin(a) * 0.55)); }   // flower of life
  for (const [name, [x, y]] of Object.entries(GK_NODES)) {
    const s = by[name];
    if (!s) continue;
    const seq = GK_SEQ[name], z = seq === "activation" ? 0.12 : seq === "venus" ? -0.14 : 0.14;
    const p = { x: (x - 150) / 150 * 0.98, y: (y - 222) / 222 * 0.86 - 0.04, z: z + (rnd() - 0.5) * 0.06 };
    N[name] = p;
    dust.push(...cloud(rnd, p.x, p.y, p.z, 70, 0.16, T.ink2, [0.3, 0.7], [0.08, 0.28]), ...cloud(rnd, p.x, p.y, p.z, 90, 0.1, SEQ_COL[seq], [0.3, 0.9], [0.3, 0.75]), ...cloud(rnd, p.x, p.y, p.z, 30, 0.04, T.gold3, [0.3, 0.8], [0.5, 0.9]));
    stars.push({ ...p, id: name, size: name === "Life's Work" || name === "Purpose" ? 2.8 : 2.2, col: SEQ_COL[seq], orb: true, glyph: s.key_line, glyphFont: "600 ", glyphSize: 11, glyphInside: true, label: s.sphere, flare: seq === "activation" ? 2 : 1, medallion: 16,
      tw: rnd() * TAU, tempo: 0.4 + rnd() * 0.5, drift: 0.003, sphere: s, labelCol: T.ink2 });
  }
  for (const [a, b] of GK_EDGES) {
    if (!N[a] || !N[b]) continue;
    lines.push(seg(N[a], N[b], SEQ_COL[GK_SEQ[b]], 0.35));
    threads.push(thread(rnd, N[a], N[b], SEQ_COL[GK_SEQ[b]], 34, 0.5, 0.014, 0.025, { role: "edge" }));
  }
  return { seed, stars, dust, threads, rings: [ring(rnd, 1.0, 280, T.violet, -0.03, I3, 0.35), ring(rnd, 1.23, 200, T.gold, 0.02, I3, 0.35)], lines, sparks: sparks(rnd, 22, 0.4, 1.25),
    blaze: { r: 0.075, rays: 16 }, idle: 0.03, restPitch: -0.12, scale: 1.0, dy: -10,
    hoverText: (s) => { const g = s?.sphere; return g ? `${g.sphere} · ${g.key_line} · ${g.shadow} → ${g.gift} → ${g.siddhi}` : null; } };
}

// --- Plate V — Nine points -----------------------------------------------------------------------------
// `scores` (type → total) comes from a fresh test result when there is one; otherwise the type,
// wing and arrows of the saved card set the weights, and with no type at all the nine are equal.
export function enneagramScene(profile, scores = null) {
  const enn = profile.enneagram;
  const seed = seedFor(profile, "enneagram"), rnd = seeded(seed);
  const stars = [], threads = [], dust = shell(rnd, 220, 1.15, 1.35), lines = [], P = {};
  const type = enn?.type ?? null, wing = enn?.wing ?? null, growth = enn?.card?.growth_arrow ?? null, stress = enn?.card?.stress_arrow ?? null;
  const weight = (n) => {
    if (scores) { const max = Math.max(1, ...Object.values(scores)); return (scores[String(n)] ?? 0) / max; }
    if (!type) return 0.5;
    return n === type ? 1 : n === wing ? 0.65 : 0.35;
  };
  const tilt = rotX(0.42), R = 0.86, ph = -Math.PI / 2;
  lines.push(...band(1.1, 1.2, tilt, ph, { n: 180, scallop: 18 }), ...band(R + 0.06, R + 0.1, tilt, ph, { n: 90 }), circle(R, tilt, T.gold, 0.5), circle(0.5, tilt, T.gold, 0.22), circle(0.22, tilt, T.gold, 0.28), circle(0.34, tilt, T.gold, 0.2, { dash: [1, 4] }), ...ticks(R, 1.1, 9, tilt, T.gold, 0.45, 1, ph), polygon(0.5, 9, tilt, T.gold, 0.2, 1, ph), polygon(0.5, 9, tilt, T.gold, 0.15, 4, ph));
  for (let n = 1; n <= 9; n += 1) {
    const a = rad(-90 + (n - 1) * 40), [x, y, z] = ap(tilt, Math.cos(a) * R, Math.sin(a) * R, 0);
    const isType = n === type, isWing = n === wing, w = weight(n);
    P[n] = { x, y, z };
    const col = isType ? T.gold3 : isWing ? T.gold2 : n === growth ? T.check : n === stress ? T.rose : T.ink2;
    dust.push(...cloud(rnd, x, y, z, Math.round(30 + 130 * w), 0.07 + 0.1 * w, col, [0.3, 0.9], [0.15 + 0.3 * w, 0.45 + 0.4 * w]));
    stars.push({ id: String(n), x, y, z, size: 1.4 + 2.2 * w, col, orb: true, glyph: String(n), glyphFont: "600 ", glyphSize: 12, glyphInside: true, label: t(`joh.enneagramType.${n}`), labelAlign: n === 5 ? "left" : n === 6 ? "right" : null, flare: isType ? 2 : isWing ? 1 : 0, medallion: 11 + 9 * w,
      tw: rnd() * TAU, tempo: 0.35 + rnd() * 0.5, drift: 0.003, n, score: scores ? scores[String(n)] : null, labelCol: isType || isWing ? T.ink : T.mute });
  }
  for (const [a, b] of ENNEA_TRIANGLE_HEXAD) { lines.push(seg(P[a], P[b], T.gold, 0.4)); threads.push(thread(rnd, P[a], P[b], T.gold2, 18, 0.25, 0.008)); }
  const rings = [ring(rnd, R, 260, T.gold2, 0.015, tilt, 0.4), ring(rnd, 1.15, 220, T.ink2, -0.01, tilt, 0.3)];
  if (type) {
    if (growth) threads.push(thread(rnd, P[type], P[growth], T.check, 70, 0.85, 0.016, 0.08, { role: "growth" }));
    if (stress) threads.push(thread(rnd, P[type], P[stress], T.rose, 70, 0.7, 0.016, 0.08, { role: "stress" }));
    if (wing) threads.push(thread(rnd, P[type], P[wing], T.gold3, 44, 0.65, 0.02, 0.03, { role: "wing" }));
  }
  return { seed, stars, dust, threads, rings, lines, sparks: sparks(rnd, 22, 0.3, 1.2, tilt), blaze: { r: 0.1, rays: 18 }, idle: 0.025, restPitch: -0.15, scale: 0.95,
    hoverText: (s) => (s?.n ? `${s.n} ${s.label}${s.score !== null && s.score !== undefined ? ` · ${s.score}` : ""}` : null) };
}
