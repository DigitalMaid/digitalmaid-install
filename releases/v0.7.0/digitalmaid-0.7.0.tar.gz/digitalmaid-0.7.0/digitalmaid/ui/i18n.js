// Languages (0.5.1, docs/ARCHITECTURE.md ADR-010). One flat catalogue per language under
// locales/<code>.json; t(key, vars) interpolates {name} and picks a plural form from a
// {one, other} object with Intl.PluralRules. English is always loaded as the fallback so a
// missing translation shows English, never a raw key. Changing the language re-applies the
// static labels of index.html (data-i18n attributes), sets <html lang>, and links the CJK
// stylesheet only for zh/ja (450 unicode-range slices; too heavy to ride in app.css).
import { BASE } from "./api.js";

export const LANGUAGES = ["en", "vi", "zh", "fr", "ja"];
export const LANGUAGE_NAMES = { en: "English", vi: "Tiếng Việt", zh: "中文", fr: "Français", ja: "日本語" };
// BCP-47 tags for Intl: one simplified-Chinese catalogue, mainland formatting.
const INTL_TAGS = { en: "en", vi: "vi", zh: "zh-CN", fr: "fr", ja: "ja" };
const CJK = new Set(["zh", "ja"]);
const CJK_LINK_ID = "fonts-cjk";

let current = "en";
let catalogue = {};
let english = {};
const loaded = {};

export function currentLanguage() { return current; }
export function intlTag(code = current) { return INTL_TAGS[code] || "en"; }

// The browser's first supported preference (the server negotiates the same way from
// Accept-Language); used before sign-in, when no stored choice is known yet.
export function browserLanguage(list = navigator.languages || [navigator.language]) {
  for (const tag of list || []) {
    const primary = String(tag || "").toLowerCase().split("-")[0];
    if (LANGUAGES.includes(primary)) return primary;
  }
  return "en";
}

async function fetchCatalogue(code) {
  if (loaded[code]) return loaded[code];
  const response = await fetch(`${BASE}/locales/${code}.json`, { credentials: "same-origin", headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`catalogue ${code}: HTTP ${response.status}`);
  loaded[code] = await response.json();
  return loaded[code];
}

function interpolate(text, vars) {
  if (!vars) return text;
  return text.replace(/\{(\w+)\}/g, (whole, name) => (name in vars && vars[name] !== undefined && vars[name] !== null ? String(vars[name]) : whole));
}

function pluralForm(forms, count) {
  if (typeof count !== "number") return forms.other;
  let category = "other";
  try { category = new Intl.PluralRules(intlTag()).select(count); } catch { /* keep other */ }
  if (count === 0 && forms.zero !== undefined) return forms.zero;
  return forms[category] ?? forms.other;
}

// Translate `key`; `fallback` (default: the key itself) is returned when neither the current
// language nor English knows it — used for server enumerations shown as pills.
export function t(key, vars = undefined, fallback = undefined) {
  let value = catalogue[key];
  if (value === undefined) value = english[key];
  if (value === undefined) return fallback !== undefined ? fallback : key;
  if (typeof value === "object") value = pluralForm(value, vars?.count);
  return interpolate(String(value), vars);
}

export function has(key) { return catalogue[key] !== undefined || english[key] !== undefined; }

// data-i18n="key" sets textContent; data-i18n-title / -aria-label / -placeholder set the attribute.
export function applyDom(root = document) {
  for (const node of root.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const attr of ["title", "aria-label", "placeholder"]) {
    const data = `data-i18n-${attr}`;
    for (const node of root.querySelectorAll(`[${data}]`)) node.setAttribute(attr, t(node.getAttribute(data)));
  }
  document.title = t("html.title", undefined, "DigitalMaid");
}

function applyFonts(code) {
  const existing = document.getElementById(CJK_LINK_ID);
  if (CJK.has(code)) {
    if (existing) return;
    const link = document.createElement("link");
    link.id = CJK_LINK_ID;
    link.rel = "stylesheet";
    link.href = "fonts-cjk.css";
    document.head.append(link);
  } else if (existing) {
    existing.remove();
  }
}

// Load and activate a language. Resolves once the catalogue is in place; the caller
// re-renders the current page. Dispatches "dm:language" on window.
export async function setLanguage(code) {
  const next = LANGUAGES.includes(code) ? code : "en";
  const [en, data] = await Promise.all([fetchCatalogue("en"), next === "en" ? fetchCatalogue("en") : fetchCatalogue(next)]);
  english = en;
  catalogue = data;
  current = next;
  document.documentElement.lang = next;
  applyFonts(next);
  applyDom(document);
  window.dispatchEvent(new CustomEvent("dm:language", { detail: { language: next } }));
  return next;
}

// --- dates and numbers ---------------------------------------------------------------------

function toDate(value) {
  if (value instanceof Date) return value;
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function formatDateTime(value, options = { dateStyle: "medium", timeStyle: "short" }) {
  const d = toDate(value);
  if (!d) return value ? String(value) : "";
  return new Intl.DateTimeFormat(intlTag(), options).format(d);
}

export function formatDate(value, options = { dateStyle: "medium" }) {
  const d = toDate(value);
  if (!d) return value ? String(value) : "";
  return new Intl.DateTimeFormat(intlTag(), options).format(d);
}

// A calendar day "YYYY-MM-DD" formatted as a local date (no timezone shift).
export function formatDay(key, options = { weekday: "long", day: "numeric", month: "long" }) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(key || ""));
  if (!m) return key ? String(key) : "";
  return new Intl.DateTimeFormat(intlTag(), options).format(new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
}

export function formatTime(value, options = { timeStyle: "short" }) {
  const d = toDate(value);
  if (!d) return value ? String(value) : "";
  return new Intl.DateTimeFormat(intlTag(), options).format(d);
}

export function formatNumber(value, options = undefined) {
  if (typeof value !== "number" || Number.isNaN(value)) return value === null || value === undefined ? "" : String(value);
  return new Intl.NumberFormat(intlTag(), options).format(value);
}

// Localised names for weekdays/months, e.g. for calendar headers: weekday(0) = Sunday.
export function weekdayName(index, style = "short") {
  const d = new Date(2024, 0, 7 + index); // 2024-01-07 is a Sunday
  return new Intl.DateTimeFormat(intlTag(), { weekday: style }).format(d);
}

export function monthName(monthIndex, year = 2024, style = "long") {
  return new Intl.DateTimeFormat(intlTag(), { month: style, year: "numeric" }).format(new Date(year, monthIndex, 1));
}
