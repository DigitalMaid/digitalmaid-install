// Stage H: Capture Inbox. Quick-capture bar (text or URL → link, Ctrl/Cmd+Enter),
// file drop zone with the server's allow-list, grouped list, and a drawer with the
// original, draft versions, "Convert to…" and archive/unarchive. textContent only.

import { api } from "./api.js";
import { el, append, pill, when, empty, emptyState, alertBox, field, form, isReadOnly, currentUser, pageHeader, segmented, PRIORITY_OPTIONS } from "./views.js";
import { t } from "./i18n.js";

const GROUP_STATUSES = ["inbox", "drafting", "converted", "archived"];
const TARGETS = ["task", "note", "journal", "decision", "event", "goal"];
const URL_RE = /^https?:\/\/\S+$/i;

function render(container, ...children) {
  container.replaceChildren();
  return append(container, children);
}

function targetOptions(values) {
  return values.map((v) => ({ value: v, label: t(`capture.target.${v}`) }));
}

function humanSize(bytes) {
  if (bytes >= 1024 * 1024) return t("capture.sizeMb", { n: Math.round(bytes / (1024 * 1024)) });
  if (bytes >= 1024) return t("capture.sizeKb", { n: Math.round(bytes / 1024) });
  return t("capture.sizeBytes", { n: bytes });
}

function captureLabel(c) {
  if (c.title) return c.title;
  if (c.kind === "link") return c.url.replace(/^https?:\/\//, "");
  if (c.body_text) return c.body_text.split("\n")[0].slice(0, 120);
  return t("capture.kindCapture", { kind: t(`capture.kind.${c.kind}`, undefined, c.kind) });
}

function captureRow(c, onOpen) {
  return el("li", {}, el("button", { class: "task-row", type: "button", dataset: { captureRow: c.id, kind: c.kind }, onclick: () => onOpen(c.id) },
    el("span", {}, captureLabel(c), el("small", {},
      t("capture.row.meta", { kind: t(`capture.kind.${c.kind}`, undefined, c.kind), source: c.source, capturedBy: c.captured_by, when: when(c.captured_at) }),
      c.converted_type ? t("capture.row.convertedTo", { type: t(`capture.target.${c.converted_type}`, undefined, c.converted_type) }) : "",
      c.mime ? t("capture.row.fileMeta", { mime: c.mime, size: humanSize(c.size_bytes) }) : "")),
    pill(c.status === "converted" ? "available" : c.status === "archived" ? "not_applicable" : c.status === "drafting" ? "required" : "Plan", t(`status.${c.status}`, undefined, c.status))));
}

let uploadInfo = null;

export async function renderCapturePage(view, ctx, captureId) {
  const [captures, archived, settings] = await Promise.all([api.captures(), api.captures("archived"), api.settings()]);
  uploadInfo = settings.capture;
  const all = [...captures, ...archived];
  const open = (id) => openCapture(id, ctx);

  // Quick capture: a pasted URL is detected as a link before submit.
  const kindHint = el("span", { id: "quick-capture-kind", class: "meta", role: "status", "aria-live": "polite" }, t("capture.hint.text"));
  const textField = field(t("capture.quickLabel"), "text", { required: true, rows: "2", placeholder: t("capture.quickPlaceholder") }, "textarea");
  const textarea = textField.querySelector("textarea");
  const detect = () => { kindHint.textContent = URL_RE.test(textarea.value.trim()) ? t("capture.hint.link") : t("capture.hint.text"); };
  textarea.addEventListener("input", detect);
  const quick = form([textField, kindHint], t("capture.quickSubmit"), async (data) => {
    const value = data.text.trim();
    if (!value) throw new Error(t("capture.quickEmpty"));
    const body = URL_RE.test(value) ? { kind: "link", url: value } : { kind: "text", body_text: value };
    await api.createCapture(body);
    await ctx.route();
  });
  quick.id = "quick-capture";
  textarea.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); quick.requestSubmit(); } });

  // File drop zone + input. The allow-list and cap come from the server.
  const uploadStatus = el("div", { id: "upload-status", class: "meta", role: "status", "aria-live": "polite" });
  const fileInput = el("input", { id: "capture-file", type: "file", accept: uploadInfo.allowed_types.join(","), disabled: isReadOnly() || null, "aria-describedby": "upload-rules" });
  const upload = async (file) => {
    if (!file) return;
    render(uploadStatus, t("capture.uploading", { name: file.name, size: humanSize(file.size) }));
    try {
      if (!uploadInfo.allowed_types.includes(file.type)) throw new Error(t("capture.typeNotAllowed", { type: file.type || t("capture.unknownType") }));
      if (file.size > uploadInfo.max_bytes) throw new Error(t("capture.tooLarge", { size: humanSize(uploadInfo.max_bytes) }));
      const body = new FormData();
      body.append("file", file, file.name);
      await api.uploadCapture(body);
      render(uploadStatus, t("capture.stored", { name: file.name }));
      await ctx.route();
    } catch (error) {
      render(uploadStatus, alertBox("error", t("capture.uploadRefused", { message: error.message }), error.reasons));
    }
  };
  fileInput.addEventListener("change", () => upload(fileInput.files[0]));
  const dropZone = el("div", { class: "drop-zone", id: "drop-zone", dataset: { active: "false" } },
    el("label", { for: "capture-file" }, t("capture.dropLabel")), fileInput,
    el("p", { id: "upload-rules", class: "meta" }, t("capture.uploadRules", { types: uploadInfo.allowed_types.join(", "), size: humanSize(uploadInfo.max_bytes) })),
    uploadStatus);
  for (const evt of ["dragenter", "dragover"]) dropZone.addEventListener(evt, (e) => { e.preventDefault(); if (!isReadOnly()) dropZone.dataset.active = "true"; });
  for (const evt of ["dragleave", "drop"]) dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.dataset.active = "false"; });
  dropZone.addEventListener("drop", (e) => { if (!isReadOnly()) upload(e.dataTransfer?.files?.[0]); });

  const groups = GROUP_STATUSES.map((status) => {
    const label = t(`capture.group.${status}`);
    const items = all.filter((c) => c.status === status);
    return el("section", { class: "panel", id: `capture-group-${status}`, "aria-labelledby": `capture-group-${status}-title` },
      el("h2", { id: `capture-group-${status}-title` }, t("capture.groupCount", { label, count: items.length })),
      items.length ? el("ul", { class: "list" }, items.map((c) => captureRow(c, open)))
        : status === "inbox" ? emptyState("capture", t("capture.emptyInboxSentence"), t("capture.quickSubmit"), () => textarea.focus())
          : empty(t("capture.noCaptures", { label: t(`status.${status}`, undefined, status) })));
  });

  render(view,
    pageHeader("capture", t("capture.pageTitle"), t("capture.pageHow")),
    el("div", { class: "grid" }, el("section", { class: "panel", "aria-label": t("capture.quickCaptureAriaLabel") }, quick), dropZone),
    el("div", { class: "grid" }, groups));
  if (captureId) await openCapture(captureId, ctx);
}

export async function openCapture(captureId, ctx, notice = null) {
  let c;
  try { c = await api.capture(captureId); } catch (error) {
    ctx.openDrawer(t("capture.errorDrawerTitle"), alertBox("error", t("capture.couldNotLoad", { message: error.message }), error.reasons));
    return;
  }
  const refresh = async (text) => { await openCapture(captureId, ctx, text); ctx.route(); };
  const writable = c.status === "inbox" || c.status === "drafting";
  const info = uploadInfo || (await api.settings()).capture;

  const original = el("section", { class: "drawer-section" }, el("h4", {}, t("capture.original.title")),
    el("dl", { class: "kv" },
      el("dt", {}, t("capture.field.kind")), el("dd", {}, t(`capture.kind.${c.kind}`, undefined, c.kind)),
      el("dt", {}, t("capture.field.source")), el("dd", {}, t("capture.original.source", { source: c.source, capturedBy: c.captured_by, when: when(c.captured_at) })),
      c.url ? [el("dt", {}, t("capture.field.link")), el("dd", {}, el("a", { href: c.url, target: "_blank", rel: "noopener noreferrer" }, c.url))] : null,
      c.original_url ? [
        el("dt", {}, t("capture.field.file")), el("dd", {}, t("capture.original.fileMeta", { title: c.title || t("capture.originalFallbackTitle"), mime: c.mime, size: t("capture.sizeBytes", { n: c.size_bytes }) })),
        el("dt", {}, t("capture.field.sha256")), el("dd", { class: "mono" }, c.original_sha256),
        el("dt", {}, t("capture.field.download")), el("dd", {}, el("a", { href: c.original_url, download: `original`, class: "btn is-small" }, t("capture.downloadOriginal"))),
        c.mime.startsWith("image/") ? [el("dt", {}, t("capture.field.preview")), el("dd", {}, el("img", { class: "capture-preview", src: `${c.original_url}?inline=1`, alt: t("capture.previewAlt", { title: c.title || t("capture.uploadedImageFallback") }) }))] : null,
      ] : null,
      c.kind === "transcript" ? [el("dt", {}, t("capture.field.transcription")), el("dd", {}, t("capture.transcriptionExternal", { status: c.body_text ? t("capture.transcriptSupplied") : t("capture.transcriptPending") }))] : null),
    c.body_text ? el("pre", { class: "version-content" }, c.body_text) : null);

  const drafts = el("section", { class: "drawer-section" }, el("h4", {}, t("capture.draft.title")),
    c.drafts.length ? el("ul", { class: "list" }, c.drafts.slice().reverse().map((d) => el("li", { class: "list-item" },
      el("div", { class: "list-item-title" }, el("strong", {}, t("capture.draft.version", { n: d.version })), el("span", { class: "meta" }, t("capture.draft.meta", { createdBy: d.created_by, when: when(d.created_at) }))),
      el("pre", { class: "version-content" }, d.body_md)))) : empty(t("capture.draft.empty")),
    writable ? (() => {
      const f = form([field(t("capture.draft.fieldLabel"), "body_md", { required: true, rows: "4", value: c.drafts.at(-1)?.body_md || "" }, "textarea")],
        t("capture.draft.submit", { n: c.drafts.length + 1 }), async (data) => { await api.addCaptureDraft(c.id, { body_md: data.body_md }); await refresh(t("capture.draft.saved", { n: c.drafts.length + 1 })); });
      f.id = "draft-form";
      return f;
    })() : null);

  const convert = writable ? await convertForm(c, ctx, refresh) : (c.converted_type
    ? el("div", { class: "stack" }, alertBox("ok", t("capture.convertedAlert", { type: t(`capture.target.${c.converted_type}`, undefined, c.converted_type) })),
      ...c.links.map((l) => el("button", { class: "btn is-small", type: "button", dataset: { convertedLink: l.target_id }, onclick: () => openTarget(l, ctx) },
        t("capture.openTarget", { type: t(`capture.target.${l.target_type}`, undefined, l.target_type.replace("_", " ")), title: l.target_title ?? l.target_id }))))
    : alertBox("info", t("capture.archivedReadOnly")));

  const revision = c.revision;
  const archiveTools = el("div", { class: "form-actions" },
    c.status !== "archived"
      ? el("button", { id: "capture-archive", class: "btn is-small", type: "button", dataset: { write: "true" }, onclick: async () => { try { await api.archiveCapture(c.id, { revision }); await refresh(t("capture.archivedNotice")); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, t("capture.archiveButton"))
      : el("button", { id: "capture-unarchive", class: "btn is-small is-primary", type: "button", dataset: { write: "true" }, onclick: async () => { try { await api.unarchiveCapture(c.id, { revision }); await refresh(t("capture.restoredNotice")); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, t("capture.unarchiveButton")));

  const body = el("div", { id: "capture-detail", class: "stack", dataset: { status: c.status } },
    notice ? alertBox("ok", notice) : null,
    el("div", { class: "meta" }, pill(c.status === "converted" ? "available" : c.status === "archived" ? "not_applicable" : "required", t(`status.${c.status}`, undefined, c.status)),
      t("capture.revision", { n: c.revision }), c.converted_type ? t("capture.convertedToMeta", { type: t(`capture.target.${c.converted_type}`, undefined, c.converted_type) }) : ""),
    original, drafts,
    el("section", { class: "drawer-section" }, el("h4", {}, t("capture.convertTo.title")), convert),
    el("section", { class: "drawer-section" }, el("h4", {}, t("capture.archiveSection.title")), archiveTools));
  ctx.openDrawer(captureLabel(c), body, { kicker: t("capture.drawerKicker", { status: t(`status.${c.status}`, undefined, c.status) }) });
  void info;
}

function openTarget(link, ctx) {
  if (link.target_type === "task") ctx.openTask(link.target_id);
  else if (link.target_type === "note") { ctx.closeDrawer(); location.hash = `#/knowledge/${link.target_id}`; }
  else if (link.target_type === "event") { ctx.closeDrawer(); location.hash = "#/calendar"; }
  else { ctx.closeDrawer(); location.hash = "#/goals"; }
}

async function convertForm(c, ctx, refresh) {
  const targetField = field(t("capture.convertForm.target"), "target", { options: targetOptions(TARGETS) }, "select");
  const targetSelect = targetField.querySelector("select");
  const specific = el("div", { class: "stack", id: "convert-fields" });
  const projects = await api.projects();
  const todayIso = new Date().toISOString().slice(0, 10);
  const build = () => {
    const target = targetSelect.value;
    const rows = [field(t("capture.convertForm.titleLabel"), "title", {})];
    if (target === "task") rows.push(
      el("div", { class: "form-row is-inline" },
        field(t("capture.convertForm.project"), "project_id", { options: projects.map((p) => ({ value: p.id, label: p.title })) }, "select"),
        field(t("capture.convertForm.owner"), "owner", { value: currentUser() || "" })),
      segmented(t("capture.convertForm.priority"), "priority", PRIORITY_OPTIONS, "2"),
      field(t("capture.convertForm.nextAction"), "next_action", {}),
      field(t("capture.convertForm.criteria"), "criteria", { rows: "2" }, "textarea"));
    else if (target === "note") rows.push(field(t("capture.convertForm.kind"), "kind", { options: ["note", "research"].map((v) => ({ value: v, label: t(`capture.noteKind.${v}`) })) }, "select"));
    else if (target === "journal") rows.push(field(t("capture.convertForm.entryDate"), "entry_date", { type: "date", value: todayIso, required: true }));
    else if (target === "decision") rows.push(
      field(t("capture.convertForm.options"), "options", { rows: "2", required: true }, "textarea"),
      el("div", { class: "form-row is-inline" },
        field(t("capture.convertForm.chosen"), "chosen", { required: true }),
        field(t("capture.convertForm.confidence"), "confidence", { type: "number", min: "1", max: "5", value: "3", required: true }),
        field(t("capture.convertForm.reviewDate"), "review_date", { type: "date", required: true })),
      field(t("capture.convertForm.reasoning"), "reasoning", { required: true }), field(t("capture.convertForm.expectedResult"), "expected_result", { required: true }));
    else if (target === "event") rows.push(
      el("div", { class: "form-row is-inline" },
        field(t("capture.convertForm.start"), "start", { type: "datetime-local", required: true }),
        field(t("capture.convertForm.end"), "end", { type: "datetime-local" }),
        field(t("capture.convertForm.kind"), "kind", { options: ["event", "deadline", "block", "milestone"].map((v) => ({ value: v, label: t(`capture.eventKind.${v}`) })) }, "select")));
    else rows.push(field(t("capture.convertForm.successMeasure"), "success_measure", { required: true }), field(t("capture.convertForm.owner"), "owner", { value: currentUser() || "" }));
    render(specific, rows);
  };
  targetSelect.addEventListener("change", build);
  build();
  const node = form([targetField, specific], t("capture.convertForm.submit"), async (data) => {
    const target = data.target;
    const payload = {};
    if (data.title) payload.title = data.title;
    if (target === "task") {
      payload.project_id = data.project_id;
      payload.criteria = (data.criteria || "").split("\n").map((s) => s.trim()).filter(Boolean);
      if (data.owner) payload.owner = data.owner;
      if (data.next_action) payload.next_action = data.next_action;
      if (data.priority) payload.priority = Number.parseInt(data.priority, 10);
    } else if (target === "note") payload.kind = data.kind;
    else if (target === "journal") payload.entry_date = data.entry_date;
    else if (target === "decision") payload.decision = {
      options: data.options.split("\n").map((s) => s.trim()).filter(Boolean), chosen: data.chosen,
      reasoning: data.reasoning, expected_result: data.expected_result,
      confidence: Number.parseInt(data.confidence, 10), review_date: data.review_date };
    else if (target === "event") {
      payload.start_utc = data.start ? new Date(data.start).toISOString() : "";
      if (data.end) payload.end_utc = new Date(data.end).toISOString();
      payload.kind = data.kind;
      payload.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    } else { payload.success_measure = data.success_measure; if (data.owner) payload.owner = data.owner; }
    await api.convertCapture(c.id, { target, payload });
    await refresh(t("capture.convertedAlert", { type: t(`capture.target.${target}`, undefined, target) }));
  });
  node.id = "convert-form";
  return node;
}
