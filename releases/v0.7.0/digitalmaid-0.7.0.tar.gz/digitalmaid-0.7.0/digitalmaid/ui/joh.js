// JOH — Journey of Humanity (0.5.0, docs/JOH.md §2, §4; DESIGN.md F11). Six tabs under
// #/joh: Overview · Astro · Bodygraph · Gene Keys · Enneagram · Compass. Every drawing is
// SVG built here, stroke-only, in the Observatory tokens; text goes through textContent.

import { api } from "./api.js";
import { el, append, pill, when, empty, alertBox, reasonsList, field, form, pageHeader, LEADS, confirmDialog, isReadOnly, applyReadOnly } from "./views.js";
import { t } from "./i18n.js";
import { mountPlate } from "./plates.js";
import { overviewScene, astroScene, bodygraphScene, genekeysScene, enneagramScene } from "./plates-scenes.js";

// LEADS[route] is read as a plain property by views.js's pageHeader on every render; a
// getter keeps the JOH lead in the current language.
Object.defineProperty(LEADS, "joh", { get: () => t("joh.lead"), enumerable: true, configurable: true });

const TABS = ["overview", "astro", "bodygraph", "genekeys", "enneagram", "compass"];
const SIGNS = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"];
const BODIES = [["sun", "Sun", "Su"], ["moon", "Moon", "Mo"], ["mercury", "Mercury", "Me"], ["venus", "Venus", "Ve"], ["mars", "Mars", "Ma"], ["jupiter", "Jupiter", "Ju"], ["saturn", "Saturn", "Sa"], ["uranus", "Uranus", "Ur"], ["neptune", "Neptune", "Ne"], ["pluto", "Pluto", "Pl"], ["true_node", "North Node", "NN"], ["south_node", "South Node", "SN"]];
const HD_BODIES = [["sun", "Sun"], ["earth", "Earth"], ["north_node", "North Node"], ["south_node", "South Node"], ["moon", "Moon"], ["mercury", "Mercury"], ["venus", "Venus"], ["mars", "Mars"], ["jupiter", "Jupiter"], ["saturn", "Saturn"], ["uranus", "Uranus"], ["neptune", "Neptune"], ["pluto", "Pluto"]];
const GOLD_ASPECTS = new Set(["conjunction", "trine", "sextile"]);
// The nine centres (docs/JOH.md §3.5 tables): shape, anchor and the gates that sit in each.
// Centre names are Human Design vocabulary matched against the API's defined_centres list
// (and asserted on literally by tests via data-centre); they are not translated here.
export const CENTRES = [
  { name: "Head", shape: "tri-up", x: 150, y: 38, gates: [64, 61, 63] },
  { name: "Ajna", shape: "tri-down", x: 150, y: 108, gates: [47, 24, 4, 17, 43, 11] },
  { name: "Throat", shape: "square", x: 150, y: 185, gates: [62, 23, 56, 35, 12, 45, 33, 8, 31, 20, 16] },
  { name: "G", shape: "diamond", x: 150, y: 270, gates: [1, 13, 25, 46, 2, 15, 10, 7] },
  { name: "Heart", shape: "tri-heart", x: 226, y: 262, gates: [21, 40, 26, 51] },
  { name: "Sacral", shape: "square", x: 150, y: 372, gates: [5, 14, 29, 59, 9, 3, 42, 27, 34] },
  { name: "Spleen", shape: "tri-left", x: 62, y: 340, gates: [48, 57, 44, 50, 32, 28, 18] },
  { name: "Solar Plexus", shape: "tri-right", x: 238, y: 340, gates: [6, 37, 22, 36, 30, 55, 49] },
  { name: "Root", shape: "square", x: 150, y: 470, gates: [53, 60, 52, 19, 39, 41, 58, 38, 54] },
];
export const CHANNELS = [[1, 8], [2, 14], [3, 60], [4, 63], [5, 15], [6, 59], [7, 31], [9, 52], [10, 20], [10, 34], [10, 57], [11, 56], [12, 22], [13, 33], [16, 48], [17, 62], [18, 58], [19, 49], [20, 34], [20, 57], [21, 45], [23, 43], [24, 61], [25, 51], [26, 44], [27, 50], [28, 38], [29, 46], [30, 41], [32, 54], [34, 57], [35, 36], [37, 40], [39, 55], [42, 53], [47, 64]];
const SEQUENCES = ["activation", "venus", "pearl"];
// Sphere names/positions are Gene Keys vocabulary matched against the API's sphere field
// (and asserted on literally by tests via data-sphere); they are not translated here.
export const GK_NODES = { "Life's Work": [150, 34], Evolution: [96, 96], Radiance: [204, 96], Purpose: [150, 158], Attraction: [60, 214], IQ: [40, 276], EQ: [60, 338], SQ: [104, 384], "Core Wound": [150, 410], Vocation: [240, 214], Culture: [260, 276], Pearl: [240, 338], Brand: [196, 384] };
export const GK_EDGES = [["Life's Work", "Evolution"], ["Life's Work", "Radiance"], ["Evolution", "Purpose"], ["Radiance", "Purpose"], ["Purpose", "Attraction"], ["Attraction", "IQ"], ["IQ", "EQ"], ["EQ", "SQ"], ["SQ", "Core Wound"], ["Purpose", "Vocation"], ["Vocation", "Culture"], ["Culture", "Pearl"], ["Pearl", "Brand"], ["Brand", "Core Wound"]];
const ENNEAGRAM_TYPES = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const SCALE_LABELS = ["notLikeMe", "slightly", "somewhat", "mostly", "veryLikeMe"];
const COMPASS_KINDS = ["email", "decision", "question"];
const HORIZONS = ["this week", "this quarter", "this year", "life"];
const SVG_NS = "http://www.w3.org/2000/svg";

const state = { compassKind: "email", enneagramMode: null, enneagramResult: null, onboarding: false, geocode: null, manual: false };

function svg(tag, attrs = {}, ...children) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) if (value !== null && value !== undefined && value !== false) node.setAttribute(key, String(value));
  for (const child of children.flat()) if (child) node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  return node;
}

function polar(cx, cy, r, degrees) {
  // Zodiac wheel: 0° Aries on the left, counter-clockwise (the astrological convention).
  const a = Math.PI * (180 - degrees) / 180;
  return [cx + r * Math.cos(a), cy - r * Math.sin(a)];
}

function degText(p) { return `${p.degree}°${String(p.minute).padStart(2, "0")}′`; }
function label(text, cls = "") { return el("span", { class: `label${cls ? ` ${cls}` : ""}` }, text); }
function num(text, cls = "") { return el("span", { class: `num joh-num${cls ? ` ${cls}` : ""}` }, String(text)); }
// Bilingual rule (DESIGN.md F12): on the Gene Keys and Bodygraph tabs a translated term shows
// its English in brackets; the server sends the English as <field>_en.
function bi(value, english) { return english && english !== value ? `${value} (${english})` : value; }
function tabHash(tab) { return `#/joh${tab === "overview" ? "" : `/${tab}`}`; }

// Planet/sign display names and abbreviations are built from local maps keyed by the API's
// body key or sign name; the map stays, but the text routes through the catalogue.
function planetName(key) { const dictKey = "joh.planet." + key; return t(dictKey); }
function planetAbbr(key) { const dictKey = "joh.planetAbbr." + key; return t(dictKey); }
function signAbbr(sign) { const dictKey = "joh.signAbbr." + sign; return t(dictKey); }
function tabLabel(id) { const dictKey = "joh.tab." + id; return t(dictKey); }
function compassKindLabel(id) { const dictKey = "joh.compassKind." + id; return t(dictKey); }
function horizonLabel(id) { const dictKey = "joh.horizon." + id; return t(dictKey); }
function scaleLabel(i) { const dictKey = "joh.scale." + SCALE_LABELS[i]; return t(dictKey); }
function enneagramTypeName(n) { const dictKey = "joh.enneagramType." + n; return t(dictKey); }
function sequenceTitle(id) { const dictKey = "joh.sequence." + id + ".title"; return t(dictKey); }
function sequenceLead(id) { const dictKey = "joh.sequence." + id + ".lead"; return t(dictKey); }

// Markdown-lite for Compass answers: headings, bullets, paragraphs and **bold**; DOM only.
function renderMarkdown(text) {
  const root = el("div", { class: "joh-md" });
  let list = null, para = [];
  const flush = () => { if (para.length) { root.append(el("p", {}, inline(para.join(" ")))); para = []; } };
  const inline = (line) => line.split(/(\*\*[^*]+\*\*)/).map((part) => part.startsWith("**") && part.endsWith("**") ? el("strong", {}, part.slice(2, -2)) : part);
  for (const raw of (text || "").split("\n")) {
    const line = raw.trimEnd();
    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    const bullet = line.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if (heading) { flush(); list = null; root.append(el(heading[1].length <= 2 ? "h3" : "h4", {}, heading[2].replace(/\*\*/g, ""))); }
    else if (bullet) { flush(); if (!list) { list = el("ul", {}); root.append(list); } list.append(el("li", {}, inline(bullet[1]))); }
    else if (!line.trim()) { flush(); list = null; }
    else { list = null; para.push(line.trim()); }
  }
  flush();
  return root;
}

// --- plates (0.6.0, DESIGN.md Appendix G) ------------------------------------------------------
// One 3D plate per chart tab above the existing cards. The engine lives in plates.js, the scene
// data in plates-scenes.js; this builds the engraved frame around the canvas, the margin notes,
// the lead line and (Astro) the zodiac toggle, and destroys the previous plate on every render.

let activePlate = null;
const plateOrientation = {};     // yaw/pitch per tab, kept across a zodiac switch (re-render in place)
const CLASSIC_KEY = "dm:joh:classic";
// Engraved margin-note diagrams (30×30 stroke icons), as data for svg().
const NOTE_ICONS = {
  ring: [["circle", { cx: 15, cy: 15, r: 12 }], ["circle", { cx: 15, cy: 15, r: 6 }], ["circle", { class: "dot", cx: 15, cy: 15, r: 1.4 }]],
  star: [["circle", { cx: 15, cy: 15, r: 12 }], ["path", { d: "M15 4v22M4 15h22M7.2 7.2l15.6 15.6M22.8 7.2L7.2 22.8" }], ["circle", { class: "dot", cx: 15, cy: 15, r: 1.6 }]],
  tri: [["circle", { cx: 15, cy: 15, r: 12 }], ["polygon", { points: "15,5 24,21 6,21" }], ["polygon", { points: "15,25 6,9 24,9" }]],
  flower: [["circle", { cx: 15, cy: 15, r: 12 }], ["circle", { cx: 15, cy: 15, r: 4.5 }], ["circle", { cx: 15, cy: 10.5, r: 4.5 }], ["circle", { cx: 19, cy: 12.8, r: 4.5 }], ["circle", { cx: 19, cy: 17.2, r: 4.5 }], ["circle", { cx: 15, cy: 19.5, r: 4.5 }], ["circle", { cx: 11, cy: 17.2, r: 4.5 }], ["circle", { cx: 11, cy: 12.8, r: 4.5 }]],
  spiral: [["circle", { cx: 15, cy: 15, r: 12 }], ["path", { d: "M15 15c0-2 3-2 3 0s-3 5-6 3-3-8 2-9 9 3 8 9-8 9-14 5" }]],
  nine: [["circle", { cx: 15, cy: 15, r: 12 }], ["polygon", { points: "15,3 25.4,21 4.6,21" }], ["path", { d: "M15 3l7.8 3.6-2.3 15.3L9.5 26l-6-9 8.4-6.6z" }]],
  hex: [["circle", { cx: 15, cy: 15, r: 12 }], ["polygon", { points: "15,4.5 24.1,9.75 24.1,20.25 15,25.5 5.9,20.25 5.9,9.75" }], ["polygon", { points: "15,9 20.2,12 20.2,18 15,21 9.8,18 9.8,12" }]],
  orbit: [["circle", { cx: 15, cy: 15, r: 12 }], ["ellipse", { cx: 15, cy: 15, rx: 11, ry: 4, transform: "rotate(-25 15 15)" }], ["circle", { class: "dot", cx: 15, cy: 15, r: 2 }], ["circle", { class: "dot", cx: 24, cy: 10, r: 1.2 }]],
  eye: [["circle", { cx: 15, cy: 15, r: 12 }], ["path", { d: "M4 15c4-6 18-6 22 0-4 6-18 6-22 0z" }], ["circle", { cx: 15, cy: 15, r: 3 }], ["circle", { class: "dot", cx: 15, cy: 15, r: 1 }]],
  hourglass: [["circle", { cx: 15, cy: 15, r: 12 }], ["path", { d: "M10 7h10l-4.5 8 4.5 8H10l4.5-8z" }]],
  axis: [["circle", { cx: 15, cy: 15, r: 12 }], ["path", { d: "M15 3v24" }], ["circle", { cx: 15, cy: 9, r: 1.6 }], ["circle", { cx: 15, cy: 15, r: 1.6 }], ["circle", { cx: 15, cy: 21, r: 1.6 }], ["circle", { class: "dot", cx: 15, cy: 15, r: 0.8 }]],
  seed: [["circle", { cx: 15, cy: 15, r: 12 }], ["circle", { cx: 15, cy: 15, r: 7 }], ["circle", { cx: 15, cy: 8, r: 7 }], ["circle", { cx: 21, cy: 11.5, r: 7 }], ["circle", { cx: 21, cy: 18.5, r: 7 }], ["circle", { cx: 15, cy: 22, r: 7 }], ["circle", { cx: 9, cy: 18.5, r: 7 }], ["circle", { cx: 9, cy: 11.5, r: 7 }]],
};

function plateNote([icon, heading, body]) {
  return el("div", { class: "joh-plate-note" },
    svg("svg", { viewBox: "0 0 30 30", "aria-hidden": "true" }, NOTE_ICONS[icon].map(([tag, attrs]) => svg(tag, attrs))),
    el("h4", {}, heading), el("p", {}, body));
}

function corner(cls) { return el("span", { class: `joh-corner ${cls}`, "aria-hidden": "true" }, el("i")); }

// Builds the frame, mounts the plate and returns the section. `spec`: { tab, scene, sub, notes:
// [left[3], right[3]], lead, toggle? }. The scene's hoverText(star) feeds the subtitle line.
function plateSection(spec, profile, ctx) {
  const { tab, scene } = spec;
  const sub = el("p", { class: "joh-plate-sub", id: `joh-plate-sub-${tab}` }, spec.sub);
  const host = el("div", { class: "joh-plate-canvas" });
  const stage = el("div", { class: "joh-plate-stage" }, host, corner("is-tl"), corner("is-tr"), corner("is-bl"), corner("is-br"),
    el("div", { class: "joh-plate-head" }, el("div", { class: "joh-plate-kicker" }, t(`joh.plate.kicker.${tab}`)), el("h2", {}, t(`joh.plate.title.${tab}`)), el("div", { class: "joh-plate-rule", "aria-hidden": "true" }), sub),
    el("div", { class: "joh-plate-notes is-left" }, spec.notes[0].map(plateNote)),
    el("div", { class: "joh-plate-notes is-right" }, spec.notes[1].map(plateNote)),
    el("p", { class: "joh-plate-lead" }, spec.lead),
    el("span", { class: "joh-plate-hint" }, t("joh.plate.hint")),
    spec.toggle || null);
  const section = el("section", { class: "joh-plate", dataset: { plate: tab } }, stage);
  scene.onHover = (star) => { const text = star ? scene.hoverText?.(star) : null; sub.textContent = text || spec.sub; };
  scene.onClick = (star) => { if (star?.tab && TABS.includes(star.tab)) location.hash = tabHash(star.tab); };
  const kept = plateOrientation[tab];
  const plate = mountPlate(host, scene, { ariaLabel: t(`joh.plate.aria.${tab}`) });
  if (kept) { plate.field.yaw = kept.yaw; plate.field.pitch = kept.pitch; }
  activePlate = { tab, plate };
  return section;
}

function destroyPlate() {
  if (!activePlate) return;
  const { tab, plate } = activePlate;
  plateOrientation[tab] = { yaw: plate.field.yaw, pitch: plate.field.pitch };
  plate.destroy();
  activePlate = null;
}

// The flat, selectable SVG diagram stays under a fold. It opens by default (the diagram carries the
// selectable numerals and the pinned JOH-2/3 checks read it); a user who closes it once keeps it closed.
function classicFold(...children) {
  let open = true;
  try { open = localStorage.getItem(CLASSIC_KEY) !== "closed"; } catch { /* storage is a convenience */ }
  const fold = el("details", { class: "how joh-plate-classic", open: open || null }, el("summary", {}, t("joh.plate.classicSummary")), ...children);
  fold.addEventListener("toggle", () => { try { localStorage.setItem(CLASSIC_KEY, fold.open ? "open" : "closed"); } catch { /* fine */ } });
  return fold;
}

function zodiacToggle(profile, ctx) {
  const current = profile.zodiac;
  const button = (z, labelText) => el("button", { type: "button", dataset: { zodiac: z, write: "true" }, "aria-pressed": String(current === z), onclick: async (event) => {
    if (z === current) return;
    event.currentTarget.disabled = true;
    try { await api.johSetZodiac(z); await ctx.route(); }
    catch (error) { event.currentTarget.disabled = false; ctx.showGlobal(t("joh.zodiac.switchError", { message: error.message }), "error", error.reasons); }
  } }, labelText);
  return el("div", { class: "joh-plate-toggle", role: "group", "aria-label": t("joh.zodiac.sidereal") + " · " + t("joh.zodiac.tropical") },
    button("sidereal", t("joh.zodiac.sidereal")), button("tropical", t("joh.zodiac.tropical")));
}

function zodiacName(profile) { return profile.zodiac === "sidereal" ? t("joh.zodiac.sidereal") : t("joh.zodiac.tropical"); }
function signDeg(p) { return `${p.sign} ${degText(p)}`; }

// --- page ---------------------------------------------------------------------------------

export async function renderJohPage(view, ctx, tabParam) {
  destroyPlate();
  const tab = TABS.includes(tabParam) ? tabParam : "overview";
  let status, profile = null;
  try { status = await api.johStatus(); } catch (error) { view.replaceChildren(alertBox("error", t("joh.loadError", { message: error.message }))); return; }
  if (status.has_profile) {
    try { profile = await api.johProfile(); } catch (error) { if (error.status !== 404) throw error; }
  }
  const head = pageHeader("joh", t("joh.pageTitle"), t("joh.how"),
    { meta: !status.enabled ? el("p", { class: "meta" }, t("joh.disabledNote")) : null });
  const body = el("div", { class: "stack joh-page", id: "joh" });
  view.replaceChildren(head, body);
  if (!profile || state.onboarding) {
    body.append(renderOnboarding(profile, ctx, () => { state.onboarding = false; ctx.route(); }));
    return;
  }
  const tabs = el("div", { class: "tabs joh-tabs", role: "tablist", "aria-label": t("joh.tabsAria") },
    TABS.map((id) => el("button", { class: "tab", type: "button", role: "tab", id: `joh-tab-${id}`, dataset: { johTab: id }, "aria-selected": String(tab === id), "aria-controls": "joh-panel",
      onclick: () => { location.hash = tabHash(id); } }, tabLabel(id))));
  const panel = el("section", { id: "joh-panel", class: "stack joh-panel", role: "tabpanel", "aria-labelledby": `joh-tab-${tab}`, dataset: { tab } });
  body.append(tabs, panel);
  const render = { overview: renderOverview, astro: renderAstro, bodygraph: renderBodygraph, genekeys: renderGeneKeys, enneagram: renderEnneagram, compass: renderCompass }[tab];
  await render(panel, profile, ctx);
  if (tab !== "enneagram" && tab !== "compass") panel.append(zodiacFooter(profile, ctx));
  if (tab === "overview" || tab === "astro" || tab === "bodygraph" || tab === "genekeys") {
    if (!profile.birth.time_known) panel.prepend(el("p", { class: "gate-line joh-time-note" }, el("span", {}, t("joh.timeUnknown"))));
  }
  applyReadOnly(body);
}

function zodiacFooter(profile, ctx) {
  const sidereal = profile.zodiac === "sidereal";
  const button = el("button", { class: "pill-btn", type: "button", id: "joh-zodiac-toggle", dataset: { write: "true" } }, sidereal ? t("joh.zodiac.switchToTropical") : t("joh.zodiac.switchToSidereal"));
  button.addEventListener("click", async () => {
    button.disabled = true;
    try { await api.johSetZodiac(sidereal ? "tropical" : "sidereal"); await ctx.route(); }
    catch (error) { button.disabled = false; ctx.showGlobal(t("joh.zodiac.switchError", { message: error.message }), "error", error.reasons); }
  });
  return el("p", { class: "meta joh-zodiac", id: "joh-zodiac" },
    el("span", { id: "joh-zodiac-name" }, sidereal ? t("joh.zodiac.sidereal") : t("joh.zodiac.tropical")), " · ", button,
    el("span", {}, t("joh.zodiac.otherReads", { sunSign: profile.alternate.sun_sign, hdType: profile.alternate.hd_type, profile: profile.alternate.profile })));
}

// --- onboarding (§2) ------------------------------------------------------------------------

function renderOnboarding(existing, ctx, done) {
  const birth = existing?.birth || {};
  const notice = el("div", { class: "stack", id: "joh-onboarding-notice" });
  const result = el("div", { class: "stack", id: "joh-geocode-result" });
  const city = el("input", { type: "text", name: "city", id: "joh-city", autocomplete: "off", placeholder: t("joh.onboarding.cityPlaceholder") });
  const country = el("input", { type: "text", name: "country", id: "joh-country", autocomplete: "off", placeholder: t("joh.onboarding.countryPlaceholder") });
  const findButton = el("button", { class: "btn", type: "button", id: "joh-find", dataset: { write: "true" } }, t("joh.onboarding.findPlace"));
  const timeInput = el("input", { type: "time", name: "birth_time", id: "joh-time", value: birth.time || "", step: "60" });
  const unknown = el("input", { type: "checkbox", name: "time_unknown", id: "joh-time-unknown", checked: existing && !birth.time_known ? "" : null });
  unknown.addEventListener("change", () => { timeInput.disabled = unknown.checked; if (unknown.checked) timeInput.value = ""; });
  timeInput.disabled = unknown.checked;
  const lat = el("input", { type: "number", name: "lat", id: "joh-lat", step: "0.0001", min: "-90", max: "90", value: birth.lat ?? "" });
  const lon = el("input", { type: "number", name: "lon", id: "joh-lon", step: "0.0001", min: "-180", max: "180", value: birth.lon ?? "" });
  const zone = el("select", { name: "timezone", id: "joh-timezone" });
  const zones = typeof Intl.supportedValuesOf === "function" ? Intl.supportedValuesOf("timeZone") : [];
  const zoneOptions = new Set(zones);
  if (birth.timezone) zoneOptions.add(birth.timezone);
  if (!zoneOptions.size) zoneOptions.add("UTC");
  zone.append(...[...zoneOptions].sort().map((z) => el("option", { value: z, selected: z === birth.timezone || null }, z)));
  const place = el("input", { type: "hidden", name: "place_display", id: "joh-place", value: birth.place_display || "" });
  const code = el("input", { type: "hidden", name: "country_code", id: "joh-country-code", value: birth.country_code || "" });
  const manual = el("div", { class: "stack joh-manual", id: "joh-manual", hidden: !(state.manual || (existing && !state.geocode)) || null },
    el("div", { class: "form-row is-inline" },
      el("div", { class: "form-row" }, el("label", { for: "joh-lat" }, t("joh.onboarding.latitude")), lat),
      el("div", { class: "form-row" }, el("label", { for: "joh-lon" }, t("joh.onboarding.longitude")), lon)),
    el("div", { class: "form-row" }, el("label", { for: "joh-timezone" }, t("joh.onboarding.timezoneLabel")), zone));
  const chosenLine = (name, hitLat, hitLon, tz) => el("p", { class: "gate-line", id: "joh-place-chosen" },
    el("span", {}, `${name} · ${Number(hitLat).toFixed(4)}, ${Number(hitLon).toFixed(4)} · ${tz}`));
  const useResult = (hit) => {
    lat.value = hit.lat; lon.value = hit.lon; place.value = hit.display_name; code.value = hit.country_code || "";
    if (![...zone.options].some((o) => o.value === hit.timezone)) zone.append(el("option", { value: hit.timezone }, hit.timezone));
    zone.value = hit.timezone;
    state.geocode = hit;
    result.replaceChildren(chosenLine(hit.display_name, hit.lat, hit.lon, hit.timezone));
  };
  // Editing: the saved place is shown as the chosen one; the coordinates stay editable below.
  if (existing && !state.geocode) result.append(chosenLine(birth.place_display || t("joh.onboarding.savedPlaceFallback"), birth.lat, birth.lon, birth.timezone));
  findButton.addEventListener("click", async () => {
    notice.replaceChildren();
    if (!city.value.trim() || !country.value.trim()) { notice.replaceChildren(alertBox("error", t("joh.onboarding.needCityCountry"))); return; }
    findButton.disabled = true;
    try {
      const hit = await api.johGeocode(city.value.trim(), country.value.trim());
      result.replaceChildren(el("div", { class: "list-item joh-geocode-hit", id: "joh-geocode-hit" },
        el("div", { class: "list-item-title" }, el("strong", {}, hit.display_name)),
        el("div", { class: "meta" }, `${hit.lat.toFixed(4)}, ${hit.lon.toFixed(4)} · ${hit.timezone}${hit.country_code ? ` · ${hit.country_code.toUpperCase()}` : ""}`),
        el("div", { class: "form-actions" },
          el("button", { class: "btn is-primary is-small", type: "button", id: "joh-use-place", dataset: { write: "true" }, onclick: () => { manual.hidden = true; useResult(hit); } }, t("joh.onboarding.useThis")),
          el("button", { class: "btn is-small", type: "button", id: "joh-manual-toggle", onclick: () => { manual.hidden = false; state.manual = true; lat.focus(); } }, t("joh.onboarding.enterManually")))));
    } catch (error) {
      result.replaceChildren();
      notice.replaceChildren(alertBox("error", error.status === 404 ? t("joh.onboarding.notFound") : t("joh.onboarding.lookupFailed", { message: error.message }), error.reasons),
        el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", id: "joh-manual-toggle", onclick: () => { manual.hidden = false; state.manual = true; lat.focus(); } }, t("joh.onboarding.enterManually"))));
    } finally { findButton.disabled = false; }
  });
  const save = form([
    el("div", { class: "form-row is-inline" },
      el("div", { class: "form-row" }, el("label", { for: "joh-date" }, t("joh.onboarding.dateOfBirth")), el("input", { type: "date", name: "birth_date", id: "joh-date", required: true, value: birth.date || "", min: "1900-01-01", max: "2099-12-31" })),
      el("div", { class: "form-row" }, el("label", { for: "joh-time" }, t("joh.onboarding.timeOfBirth")), timeInput)),
    el("div", { class: "form-row is-check" }, el("label", {}, unknown, " ", t("joh.onboarding.timeUnknownCheckbox"))),
    el("div", { class: "form-row is-inline joh-place-row" },
      el("div", { class: "form-row" }, el("label", { for: "joh-city" }, t("joh.onboarding.cityLabel")), city),
      el("div", { class: "form-row" }, el("label", { for: "joh-country" }, t("joh.onboarding.countryLabel")), country),
      el("div", { class: "form-row joh-find-row" }, findButton)),
    result, manual, place, code,
    el("p", { class: "meta joh-privacy" }, t("joh.privacyLine")),
    el("p", { class: "meta joh-attribution" }, t("joh.attributionLine")),
    notice,
  ], existing ? t("joh.onboarding.saveEdit") : t("joh.onboarding.saveNew"), async (data) => {
    if (!data.birth_date) throw new Error(t("joh.onboarding.dateRequired"));
    const body = {
      birth_date: data.birth_date, birth_time: unknown.checked || !data.birth_time ? null : data.birth_time.slice(0, 5),
      lat: Number.parseFloat(data.lat), lon: Number.parseFloat(data.lon), timezone: data.timezone,
      place_display: data.place_display || (city.value.trim() ? `${city.value.trim()}, ${country.value.trim()}` : null),
      country_code: data.country_code || null,
    };
    if (!Number.isFinite(body.lat) || !Number.isFinite(body.lon)) { manual.hidden = false; throw new Error(t("joh.onboarding.findOrManual")); }
    await api.johSaveProfile(body);
    state.geocode = null; state.manual = false;
    location.hash = "#/joh";
    done();
  });
  save.id = "joh-onboarding-form";
  return el("section", { class: "panel joh-onboarding", id: "joh-onboarding", "aria-labelledby": "joh-onboarding-title" },
    el("h2", { id: "joh-onboarding-title", class: "joh-serif" }, existing ? t("joh.onboarding.editTitle") : t("joh.onboarding.newTitle")),
    el("p", { class: "meta" }, t("joh.onboarding.lead")),
    save,
    existing ? el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", id: "joh-onboarding-cancel", onclick: () => { state.onboarding = false; ctx.route(); } }, t("common.cancel")),
      el("button", { class: "btn is-small is-danger", type: "button", id: "joh-delete", dataset: { write: "true" }, onclick: async () => {
        const ok = await confirmDialog({ title: t("joh.onboarding.deleteConfirmTitle"), message: t("joh.onboarding.deleteConfirmMessage"), confirmLabel: t("joh.onboarding.deleteProfile") });
        if (!ok) return;
        try { await api.johDeleteProfile(); state.onboarding = false; window.dispatchEvent(new CustomEvent("dm:joh-changed")); ctx.route(); }
        catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); }
      } }, t("joh.onboarding.deleteProfile"))) : null);
}

// --- Overview -----------------------------------------------------------------------------

function card(title, ...children) {
  return el("section", { class: "panel joh-card" }, el("h2", { class: "joh-card-title" }, title), ...children);
}

function kv(rows) {
  return el("dl", { class: "kv joh-kv" }, rows.flatMap(([k, v]) => [el("dt", {}, k), el("dd", {}, v)]));
}

async function renderOverview(panel, profile, ctx) {
  const { astro, humandesign: hd, genekeys: gk } = profile.profile;
  const b = profile.birth;
  const who = ctx.currentUser() || t("joh.overview.youFallback");
  const timeText = b.time_known ? t("joh.overview.atTime", { time: b.time }) : t("joh.overview.atUnknownTime");
  const enn = profile.enneagram;
  const place = b.place_display || `${b.lat}, ${b.lon}`;
  panel.append(
    plateSection({
      tab: "overview", scene: overviewScene(profile), sub: t("joh.plate.sub.overview"),
      notes: [[["orbit", "Principium", t("joh.plate.note.principium")], ["hourglass", "Tempus", `${b.date} · ${b.time_known ? b.time : "—"} · ${place}`], ["seed", "Materia", `${zodiacName(profile)} · ${t("joh.plate.note.materia")}`]],
        [["star", "Ignis stellaris", `${t("joh.tab.astro")} · ${t("joh.plate.title.astro")}`], ["axis", "Axis", `${t("joh.tab.bodygraph")} · ${t("joh.plate.title.bodygraph")}`], ["eye", "Compass", t("joh.askCompass")]]],
      lead: t("joh.plate.lead.overview"),
    }, profile, ctx),
    el("p", { class: "joh-greeting", id: "joh-greeting" }, el("em", {}, who), t("joh.overview.greeting", { date: b.date, timeText, place })),
    el("div", { class: "grid is-thirds joh-summary" },
      card(t("joh.overview.sunMoonRising"), kv([
        [t("joh.planet.sun"), el("span", { id: "joh-sun" }, `${astro.positions.sun.sign} ${degText(astro.positions.sun)}`)],
        [t("joh.planet.moon"), el("span", { id: "joh-moon" }, `${astro.positions.moon.sign} ${degText(astro.positions.moon)}`)],
        [t("joh.overview.rising"), el("span", { id: "joh-rising" }, `${astro.ascendant.sign} ${degText(astro.ascendant)}`)]])),
      card(t("joh.overview.humanDesignTitle"), kv([[t("joh.label.type"), el("span", { id: "joh-hd-type" }, hd.type)], [t("joh.label.strategy"), hd.strategy], [t("joh.label.authority"), hd.authority], [t("joh.label.profile"), el("span", { class: "num joh-num" }, hd.profile)]])),
      card(t("joh.tab.enneagram"), enn
        ? el("div", { class: "stack" }, el("p", { class: "joh-type-line", id: "joh-enneagram-summary" }, el("span", { class: "num joh-num" }, enn.card.label), ` · ${enn.card.name}`),
          el("p", { class: "meta" }, enn.card.keywords.join(" · ")), el("a", { class: "pill-btn", href: "#/joh/enneagram" }, t("common.open")))
        : el("div", { class: "stack" }, empty(t("joh.overview.enneagramNotSet")), el("a", { class: "pill-btn gold", href: "#/joh/enneagram", id: "joh-find-type" }, t("joh.overview.findYourType"))))),
    classicFold(card(t("joh.overview.primeGiftsTitle"), primeGiftsArc(gk.prime_gifts), el("p", { class: "meta" }, t("joh.overview.primeGiftsCaption")))),
    el("div", { class: "form-actions" },
      el("button", { class: "pill-btn", type: "button", id: "joh-edit-birth", dataset: { write: "true" }, onclick: () => { state.onboarding = true; ctx.route(); } }, t("joh.editBirthData")),
      el("a", { class: "pill-btn", href: "#/joh/compass" }, t("joh.askCompass"))));
}

function primeGiftsArc(gifts) {
  const width = 640, height = 150;
  const root = svg("svg", { class: "joh-arc", viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": t("joh.overview.primeGiftsAria", { list: gifts.map((g) => `${g.sphere} ${g.key_line} ${g.gift}`).join(", ") }) });
  root.append(svg("path", { class: "joh-hair", d: `M 40 110 Q ${width / 2} -10 ${width - 40} 110`, fill: "none" }));
  gifts.forEach((g, i) => {
    const frac = (i + 0.5) / gifts.length;
    const x = 40 + frac * (width - 80);
    const y = (1 - frac) * (1 - frac) * 110 + 2 * (1 - frac) * frac * -10 + frac * frac * 110;
    root.append(svg("circle", { class: "joh-node", cx: x, cy: y, r: 5 }),
      svg("text", { class: "joh-svg-num", x, y: y + 24, "text-anchor": "middle" }, g.key_line),
      svg("text", { class: "joh-svg-serif", x, y: y + 42, "text-anchor": "middle" }, g.gift),
      svg("text", { class: "joh-svg-label", x, y: y - 14, "text-anchor": "middle" }, g.sphere.toUpperCase()));
  });
  return root;
}

// --- Astro (§4) ---------------------------------------------------------------------------

async function renderAstro(panel, profile, ctx) {
  const chart = profile.profile.astro;
  // dataset.body keeps the raw English name (tests select tr[data-body=Sun] directly);
  // the displayed label is translated separately.
  const rows = [...BODIES.map(([key, name]) => [name, planetName(key), chart.positions[key]]), ["Ascendant", t("joh.ascendant"), chart.ascendant], ["Midheaven", t("joh.midheaven"), chart.mc]];
  panel.append(
    plateSection({
      tab: "astro", scene: astroScene(profile), sub: `${zodiacName(profile)} · ${t("joh.plate.sub.astro")}`,
      notes: [[["star", "Sol", `☉︎ ${signDeg(chart.positions.sun)}`], ["ring", "Luna", `☽︎ ${signDeg(chart.positions.moon)}`], ["axis", "Ascendens", `${signDeg(chart.ascendant)} · I`]],
        [["hex", "Aspectus", `${(chart.aspects || []).length} · ${t("joh.plate.note.aspects")}`], ["orbit", "Domus", t("joh.plate.note.houses")], ["eye", "Medium coeli", signDeg(chart.mc)]]],
      lead: t("joh.plate.lead.astro"), toggle: zodiacToggle(profile, ctx),
    }, profile, ctx),
    el("p", { class: "meta" }, t("joh.astro.lead", { zodiacNote: profile.zodiac === "sidereal" ? t("joh.astro.siderealNote") : t("joh.astro.tropicalNote") })),
    el("div", { class: "joh-astro-layout" },
      el("div", { class: "joh-wheel-box" }, classicFold(drawWheel(chart))),
      el("section", { class: "panel joh-card" }, el("h2", { class: "joh-card-title" }, t("joh.astro.positionsTitle")),
        el("table", { class: "joh-table", id: "joh-positions" },
          el("thead", {}, el("tr", {}, [t("joh.astro.colBody"), t("joh.astro.colSign"), t("joh.astro.colDegree"), t("joh.astro.colHouse"), t("joh.astro.retrogradeAbbr")].map((h) => el("th", {}, h)))),
          el("tbody", {}, rows.map(([rawName, displayName, p]) => el("tr", { dataset: { body: rawName } },
            el("td", {}, displayName), el("td", {}, p.sign), el("td", { class: "num joh-num" }, degText(p)),
            el("td", { class: "num joh-num" }, p.house ?? (rawName === "Ascendant" ? "1" : t("common.none"))), el("td", {}, p.retrograde ? t("joh.astro.retrogradeAbbr") : ""))))))),
    el("details", { class: "how joh-how" }, el("summary", {}, t("joh.astro.howSummary")),
      el("div", { class: "how-body" }, t("joh.astro.howBody"))));
}

function drawWheel(chart) {
  const size = 560, c = size / 2, rOuter = 272, rSign = 236, rHouse = 206, rPlanet = 168, rAspect = 128;
  const root = svg("svg", { class: "joh-wheel", viewBox: `0 0 ${size} ${size}`, role: "img", "aria-label": t("joh.astro.wheelAria") });
  root.append(svg("circle", { class: "joh-hair", cx: c, cy: c, r: rOuter }), svg("circle", { class: "joh-hair", cx: c, cy: c, r: rSign }), svg("circle", { class: "joh-hair", cx: c, cy: c, r: rHouse }), svg("circle", { class: "joh-hair is-faint", cx: c, cy: c, r: rAspect }));
  const ascIndex = chart.ascendant.sign_index;
  for (let i = 0; i < 12; i += 1) {
    const start = i * 30;
    const [x1, y1] = polar(c, c, rHouse, start), [x2, y2] = polar(c, c, rOuter, start);
    root.append(svg("line", { class: "joh-hair", x1, y1, x2, y2 }));
    const [tx, ty] = polar(c, c, (rOuter + rSign) / 2, start + 15);
    const sector = svg("g", { class: "joh-sign", "data-sign": SIGNS[i] });
    sector.append(svg("text", { class: "joh-svg-serif", x: tx, y: ty + 5, "text-anchor": "middle" }, signAbbr(SIGNS[i])));
    const house = ((i - ascIndex + 12) % 12) + 1;
    const [hx, hy] = polar(c, c, (rSign + rHouse) / 2, start + 15);
    sector.append(svg("text", { class: "joh-svg-num", x: hx, y: hy + 4, "text-anchor": "middle" }, house));
    root.append(sector);
  }
  // Ascendant marker.
  const [ax1, ay1] = polar(c, c, rAspect, chart.ascendant.longitude), [ax2, ay2] = polar(c, c, rOuter, chart.ascendant.longitude);
  root.append(svg("line", { class: "joh-asc", x1: ax1, y1: ay1, x2: ax2, y2: ay2 }));
  for (const a of chart.aspects || []) {
    const pa = chart.positions[a.a], pb = chart.positions[a.b];
    if (!pa || !pb) continue;
    const [x1, y1] = polar(c, c, rAspect, pa.longitude), [x2, y2] = polar(c, c, rAspect, pb.longitude);
    root.append(svg("line", { class: `joh-aspect ${GOLD_ASPECTS.has(a.aspect) ? "is-gold" : "is-rose"}`, x1, y1, x2, y2, "data-aspect": a.aspect }));
  }
  // Planets: the tick always sits at the true longitude; labels closer than 6° of arc are
  // fanned out on alternating radii and joined to their tick by a leader hairline.
  for (const item of fanPlanets(chart.positions, rPlanet)) {
    const { key, name, glyph, p, angle, r, fanned } = item;
    const [x, y] = polar(c, c, r, angle);
    const [t1x, t1y] = polar(c, c, rHouse - 2, p.longitude), [t2x, t2y] = polar(c, c, rHouse - 10, p.longitude);
    const g = svg("g", { class: `joh-planet${fanned ? " is-fanned" : ""}`, "data-body": key });
    g.append(svg("line", { class: "joh-tick", x1: t1x, y1: t1y, x2: t2x, y2: t2y }));
    if (fanned) {
      const [lx, ly] = polar(c, c, r + 10, angle);
      g.append(svg("line", { class: "joh-leader", x1: t2x, y1: t2y, x2: lx, y2: ly }));
    }
    g.append(svg("text", { class: "joh-svg-serif is-planet joh-planet-label", x, y: y + 5, "text-anchor": "middle" }, glyph),
      svg("title", {}, `${name} ${p.sign} ${degText(p)}${p.retrograde ? ` ${t("joh.astro.retrogradeAbbr")}` : ""}`));
    root.append(g);
  }
  return root;
}

const FAN_GAP = 6;        // bodies closer than this (degrees of arc) share a fan
const FAN_STEP = 6.5;     // angular spacing between fanned labels
const FAN_DROP = 24;      // radial step for every second label in a fan

function arcGap(from, to) { return ((to - from) % 360 + 360) % 360; }

function fanPlanets(positions, rPlanet) {
  const items = BODIES.filter(([key]) => positions[key]).map(([key]) => ({ key, name: planetName(key), glyph: planetAbbr(key), p: positions[key] }));
  items.sort((a, b) => a.p.longitude - b.p.longitude);
  if (items.length > 1) {
    // Start the sweep after the widest empty arc so a fan never straddles the cut at 0° Aries.
    let cut = 0, widest = -1;
    items.forEach((item, i) => {
      const gap = arcGap(items[(i + items.length - 1) % items.length].p.longitude, item.p.longitude);
      if (gap > widest) { widest = gap; cut = i; }
    });
    items.push(...items.splice(0, cut));
  }
  let clusters = items.map((item) => [item]);
  const span = (cluster) => Math.max(arcGap(cluster[0].p.longitude, cluster[cluster.length - 1].p.longitude), (cluster.length - 1) * FAN_STEP);
  const mid = (cluster) => cluster[0].p.longitude + arcGap(cluster[0].p.longitude, cluster[cluster.length - 1].p.longitude) / 2;
  // Merge neighbours until every fan, at its spread width, clears the next by FAN_GAP.
  let merged = true;
  while (merged && clusters.length > 1) {
    merged = false;
    for (let i = 0; i < clusters.length; i += 1) {
      const a = clusters[i], b = clusters[(i + 1) % clusters.length];
      if (a === b) break;
      const gap = arcGap(mid(a) + span(a) / 2, mid(b) - span(b) / 2);
      const overlap = gap > 180 || gap < FAN_GAP;
      if (overlap) { clusters.splice(i, 1, [...a, ...b]); clusters.splice(clusters.indexOf(b), 1); merged = true; break; }
    }
  }
  const out = [];
  for (const cluster of clusters) {
    if (cluster.length === 1) { out.push({ ...cluster[0], angle: cluster[0].p.longitude, r: rPlanet, fanned: false }); continue; }
    const centre = mid(cluster);
    cluster.forEach((item, i) => out.push({ ...item, angle: centre + (i - (cluster.length - 1) / 2) * FAN_STEP, r: rPlanet - (i % 2) * FAN_DROP, fanned: true }));
  }
  return out;
}

// --- Bodygraph (§4) ---------------------------------------------------------------------

function centreShape(centre) {
  const { x, y, shape } = centre;
  const s = 28;
  const pts = {
    "tri-up": [[x, y - s], [x - s, y + s * 0.7], [x + s, y + s * 0.7]],
    "tri-down": [[x - s, y - s * 0.7], [x + s, y - s * 0.7], [x, y + s]],
    "tri-heart": [[x - 18, y - 16], [x + 22, y - 8], [x + 4, y + 20]],
    "tri-left": [[x + 26, y - 30], [x + 26, y + 30], [x - 32, y]],
    "tri-right": [[x - 26, y - 30], [x - 26, y + 30], [x + 32, y]],
    diamond: [[x, y - 34], [x + 34, y], [x, y + 34], [x - 34, y]],
    square: [[x - 30, y - 30], [x + 30, y - 30], [x + 30, y + 30], [x - 30, y + 30]],
  }[shape];
  return svg("polygon", { points: pts.map((p) => p.join(",")).join(" ") });
}

const GATE_FONT = 10;   // SVG units; the 300-wide graph is drawn at 340 px, so ≈ 11.3 px on screen

function gateNumeral(gate, x, y, cls) {
  // A solid backing under every numeral so the channel line never strikes through it.
  const w = String(gate).length * GATE_FONT * 0.62 + 4, h = GATE_FONT + 2;
  return [
    svg("rect", { class: "joh-gate-bg", x: x - w / 2, y: y - h / 2, width: w, height: h, rx: 2 }),
    svg("text", { class: `joh-svg-num is-gate joh-gate ${cls}`, x, y: y + GATE_FONT * 0.36, "text-anchor": "middle", "data-gate": gate }, gate),
  ];
}

function drawBodygraph(hd) {
  const root = svg("svg", { class: "joh-bodygraph", viewBox: "0 0 300 520", role: "img", "aria-label": t("joh.bodygraph.aria", { type: hd.type, authority: hd.authority, profile: hd.profile }) });
  const byGate = Object.fromEntries(CENTRES.flatMap((c) => c.gates.map((g) => [g, c])));
  const sides = hd.gates || {};
  const active = new Map((hd.channels || []).map((ch) => [ch.gates.join("-"), ch]));
  const pairKey = ([a, b]) => [byGate[a].name, byGate[b].name].sort().join("|");
  const pairTotal = {};
  for (const ch of CHANNELS) pairTotal[pairKey(ch)] = (pairTotal[pairKey(ch)] || 0) + 1;
  const pairIndex = {};
  for (const [a, b] of CHANNELS) {
    const ca = byGate[a], cb = byGate[b];
    const pair = pairKey([a, b]);
    const k = pairIndex[pair] = (pairIndex[pair] || 0) + 1;
    const offset = (k - (pairTotal[pair] + 1) / 2) * 15;   // parallel channels fan out symmetrically
    const dx = cb.x - ca.x, dy = cb.y - ca.y, len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len * offset, ny = dx / len * offset;
    const x1 = ca.x + nx, y1 = ca.y + ny, x2 = cb.x + nx, y2 = cb.y + ny;
    const ch = active.get(`${a}-${b}`);
    const sideOf = (gate) => sides[String(gate)] || [];
    const gateClass = (gate) => { const s = sideOf(gate); return s.length === 2 ? "is-both" : s[0] === "design" ? "is-design" : s[0] === "personality" ? "is-personality" : ""; };
    const g = svg("g", { class: `joh-channel${ch ? " is-active" : ""}`, "data-channel": `${a}-${b}` });
    // Each half is coloured by its own gate's activation, so a half-channel shows as a hanging gate.
    const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
    g.append(svg("line", { class: `joh-half ${gateClass(a)}`, x1, y1, x2: mx, y2: my }), svg("line", { class: `joh-half ${gateClass(b)}`, x1: mx, y1: my, x2, y2 }));
    if (ch) g.append(svg("line", { class: "joh-channel-core", x1, y1, x2, y2 }));
    // Numerals sit a fixed way out from each centre (just past its edge on the long channels),
    // and parallel channels stagger theirs along the line so neighbours never share a row.
    const reach = Math.min(36, 0.3 * len) + (k - (pairTotal[pair] + 1) / 2) * 8;
    const ux = (x2 - x1) / len, uy = (y2 - y1) / len;
    g.append(...gateNumeral(a, x1 + ux * reach, y1 + uy * reach, gateClass(a)),
      ...gateNumeral(b, x2 - ux * reach, y2 - uy * reach, gateClass(b)));
    root.append(g);
  }
  const defined = new Set(hd.defined_centres || []);
  for (const centre of CENTRES) {
    const g = svg("g", { class: `joh-centre${defined.has(centre.name) ? " is-defined" : ""}`, "data-centre": centre.name });
    g.append(centreShape(centre), svg("title", {}, t("joh.bodygraph.centreState", { name: centre.name, state: defined.has(centre.name) ? t("joh.bodygraph.centreDefined") : t("joh.bodygraph.centreOpen") })));
    root.append(g);
  }
  return root;
}

async function renderBodygraph(panel, profile, ctx) {
  const hd = profile.profile.humandesign;
  const activationList = (side) => el("ul", { class: "list joh-activations", dataset: { side } }, HD_BODIES.map(([key]) => {
    const a = hd[side][key];
    return el("li", { class: "list-item" }, el("div", { class: "list-item-title" }, el("span", {}, planetName(key)), el("span", { class: "num joh-num" }, a.key)));
  }));
  panel.append(
    plateSection({
      tab: "bodygraph", scene: bodygraphScene(profile), sub: `${hd.type} · ${hd.profile} · ${hd.authority}`,
      notes: [[["axis", "Axis", `${(hd.defined_centres || []).length} / 9 · ${t("joh.bodygraph.legendDefined")}`], ["ring", "Auctoritas", `${hd.authority} · ${hd.strategy}`], ["hourglass", "Definitio", `${hd.definition} · ${hd.profile}`]],
        [["star", "Personalitas", t("joh.bodygraph.legendPersonality")], ["flower", "Designatio", t("joh.bodygraph.legendDesign")], ["eye", "Crux", hd.incarnation_cross.label]]],
      lead: t("joh.plate.lead.bodygraph"),
    }, profile, ctx),
    el("p", { class: "meta" }, t("joh.bodygraph.lead")),
    el("div", { class: "joh-body-layout" },
      el("div", { class: "joh-body-box" }, classicFold(drawBodygraph(hd),
        el("ul", { class: "joh-legend", "aria-label": t("joh.bodygraph.legendAria") },
          el("li", { class: "is-personality" }, t("joh.bodygraph.legendPersonality")), el("li", { class: "is-design" }, t("joh.bodygraph.legendDesign")), el("li", { class: "is-both" }, t("joh.bodygraph.legendBoth")), el("li", { class: "is-defined" }, t("joh.bodygraph.legendDefined"))))),
      el("div", { class: "stack" },
        card(t("joh.bodygraph.foundationTitle"), kv([[t("joh.label.type"), el("span", { id: "joh-body-type" }, bi(hd.type, hd.type_en))], [t("joh.label.strategy"), hd.strategy], [t("joh.label.authority"), bi(hd.authority, hd.authority_en)], [t("joh.label.profile"), el("span", { class: "num joh-num" }, hd.profile)],
          [t("joh.label.definition"), bi(hd.definition, hd.definition_en)], [t("joh.label.incarnationCross"), hd.incarnation_cross.label], [t("joh.label.notSelfTheme"), hd.not_self_theme], [t("joh.label.signature"), hd.signature]])),
        el("div", { class: "grid joh-two" },
          card(t("joh.label.design"), activationList("design")), card(t("joh.label.personality"), activationList("personality"))))));
}

// --- Gene Keys (§4) --------------------------------------------------------------------------

function drawHologenetic(spheres) {
  // Nodes are keyed on the English sphere name (`sphere_en` on localised responses); the label shows
  // the localised name.
  const by = Object.fromEntries(spheres.map((s) => [s.sphere_en ?? s.sphere, s]));
  const root = svg("svg", { class: "joh-hologenetic", viewBox: "0 0 300 440", role: "img", "aria-label": t("joh.genekeys.diagramAria") });
  for (const [a, b] of GK_EDGES) {
    const [x1, y1] = GK_NODES[a], [x2, y2] = GK_NODES[b];
    root.append(svg("line", { class: "joh-hair", x1, y1, x2, y2 }));
  }
  for (const [name, [x, y]] of Object.entries(GK_NODES)) {
    const s = by[name];
    if (!s) continue;
    const g = svg("g", { class: "joh-gk-node", "data-sphere": name });
    g.append(svg("circle", { class: "joh-node is-ring", cx: x, cy: y, r: 17 }),
      svg("text", { class: "joh-svg-num", x, y: y + 4, "text-anchor": "middle" }, s.key),
      svg("text", { class: "joh-svg-label", x, y: y + 32, "text-anchor": "middle" }, s.sphere.toUpperCase()),
      svg("title", {}, `${s.sphere} ${s.key_line} — ${s.shadow} → ${s.gift} → ${s.siddhi}`));
    root.append(g);
  }
  return root;
}

function sphereRow(s) {
  return el("li", { class: "joh-sphere", dataset: { sphere: s.sphere } },
    el("div", { class: "joh-sphere-head" }, label(s.sphere), el("span", { class: "num joh-num is-gold", dataset: { keyLine: s.key_line } }, s.key_line),
      el("span", { class: "meta" }, t("joh.genekeys.sphereMeta", { line: s.line, theme: s.line_theme, partner: s.programming_partner }))),
    el("div", { class: "joh-spectrum", "aria-label": t("joh.genekeys.spectrumAria", { shadow: s.shadow, gift: s.gift, siddhi: s.siddhi }) },
      el("span", { class: "is-shadow" }, bi(s.shadow, s.shadow_en)), el("span", { class: "joh-arrow", "aria-hidden": "true" }, "→"), el("span", { class: "is-gift" }, bi(s.gift, s.gift_en)), el("span", { class: "joh-arrow", "aria-hidden": "true" }, "→"), el("span", { class: "is-siddhi" }, bi(s.siddhi, s.siddhi_en))),
    el("p", { class: "joh-contemplation" }, s.contemplation));
}

async function renderGeneKeys(panel, profile, ctx) {
  const gk = profile.profile.genekeys;
  const lifesWork = gk.spheres.find((s) => (s.sphere_en ?? s.sphere) === "Life's Work") || gk.spheres[0];
  panel.append(
    plateSection({
      tab: "genekeys", scene: genekeysScene(profile), sub: SEQUENCES.map(sequenceTitle).join(" · "),
      notes: [[["star", "Activatio", `${lifesWork.sphere} ${lifesWork.key_line} · ${lifesWork.gift}`], ["flower", "Venus", t("joh.sequence.venus.lead")], ["spiral", "Margarita", t("joh.sequence.pearl.lead")]],
        [["eye", "Umbra", t("joh.plate.note.shadow")], ["ring", "Donum", t("joh.plate.note.gift")], ["seed", "Siddhi", t("joh.plate.note.siddhi")]]],
      lead: t("joh.plate.lead.genekeys"),
    }, profile, ctx),
    el("p", { class: "meta" }, t("joh.genekeys.lead")),
    el("div", { class: "joh-gk-layout" },
      el("div", { class: "joh-gk-diagram" }, classicFold(drawHologenetic(gk.spheres))),
      el("div", { class: "stack" },
        SEQUENCES.map((id) => card(sequenceTitle(id), el("p", { class: "meta" }, sequenceLead(id)), el("ul", { class: "joh-spheres" }, gk.sequences[id].map(sphereRow)))),
        card(t("joh.genekeys.furtherTitle"), el("ul", { class: "joh-spheres" }, gk.sequences.further.map(sphereRow))),
        el("p", { class: "meta" }, el("a", { href: "https://genekeys.com/", target: "_blank", rel: "noopener" }, t("joh.genekeys.linkText")), t("joh.genekeys.linkTrailing")))));
}

// --- Enneagram (§4) -----------------------------------------------------------------------------

function typeCardNode(cardData, extra) {
  return el("section", { class: "panel joh-card joh-type-card", id: "joh-type-card" },
    el("h2", { class: "joh-card-title" }, el("span", { class: "num joh-num is-gold" }, cardData.label), ` · ${cardData.name}`),
    kv([[t("joh.enneagram.coreFear"), cardData.core_fear], [t("joh.enneagram.coreDesire"), cardData.core_desire], [t("joh.enneagram.basicProposition"), cardData.basic_proposition],
      [t("joh.enneagram.arrows"), t("joh.enneagram.arrowsText", { growthNum: cardData.growth_arrow, growthName: enneagramTypeName(cardData.growth_arrow), stressNum: cardData.stress_arrow, stressName: enneagramTypeName(cardData.stress_arrow) })],
      [t("joh.enneagram.keywords"), cardData.keywords.join(" · ")]]), extra);
}

function scoreBars(scores) {
  const max = Math.max(1, ...Object.values(scores));
  return el("ol", { class: "joh-bars", "aria-label": t("joh.enneagram.scoreBarsAria") }, Object.entries(scores).map(([type, v]) => el("li", { class: "joh-bar", dataset: { type } },
    el("span", { class: "num joh-num" }, type), el("span", { class: "joh-bar-track" }, el("span", { class: "joh-bar-fill", "data-pct": Math.round(100 * v / max) })), el("span", { class: "num joh-num" }, v))));
}

function testKey(seed) { return `dm:joh:enneagram:${seed}`; }

function instinctText(code) {
  const key = { sp: "joh.enneagram.instinctSp", so: "joh.enneagram.instinctSo", sx: "joh.enneagram.instinctSx" }[code];
  return key ? t(key) : t("joh.enneagram.none");
}

async function renderEnneagram(panel, profile, ctx) {
  const enn = profile.enneagram;
  const notice = el("div", { class: "stack", id: "joh-enneagram-notice" });
  const result = state.enneagramResult;
  const card = result ? result.card : enn?.card;
  const arrow = (n) => `→ ${n} ${enneagramTypeName(n)}`;
  panel.append(
    plateSection({
      tab: "enneagram", scene: enneagramScene(result ? { ...profile, enneagram: { type: result.type, wing: result.wing, card: result.card } } : profile, result ? result.scores : null),
      sub: card ? `${card.label} · ${card.name}${enn?.instinct ? ` · ${instinctText(enn.instinct)}` : ""}` : t("joh.overview.enneagramNotSet"),
      notes: [[["nine", "Figura", t("joh.plate.note.figura")], ["star", "Typus", card ? `${card.label} · ${card.name}` : t("joh.overview.enneagramNotSet")], ["hourglass", "Instinctus", instinctText(enn?.instinct)]],
        [["orbit", "Integratio", card ? arrow(card.growth_arrow) : "—"], ["eye", "Tensio", card ? arrow(card.stress_arrow) : "—"], ["ring", "Fons", enn ? (enn.source === "test" ? t("joh.enneagram.sourceTest") : t("joh.enneagram.sourceEntered")) : "—"]]],
      lead: t("joh.plate.lead.enneagram"),
    }, profile, ctx),
    el("p", { class: "meta" }, t("joh.enneagram.lead")), notice);
  if (state.enneagramResult) { renderResult(panel, state.enneagramResult, ctx, notice); return; }
  if (state.enneagramMode === "test") { await renderTest(panel, ctx, notice); return; }
  if (state.enneagramMode === null) {
    // A half-finished attempt (autosaved under its seed) resumes on reload instead of restarting.
    let pending = null;
    try { pending = await api.johEnneagramTest(); } catch { pending = null; }
    if (pending && localStorage.getItem(testKey(pending.seed))) { state.enneagramMode = "test"; await renderTest(panel, ctx, notice, pending); return; }
  }
  if (state.enneagramMode === "choose" || (!enn && state.enneagramMode === null)) {
    panel.append(el("div", { class: "form-actions joh-enn-start" },
      el("button", { class: "pill-btn gold", type: "button", id: "joh-enn-know", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "know"; ctx.route(); } }, t("joh.enneagram.iKnowMyType")),
      el("button", { class: "pill-btn", type: "button", id: "joh-enn-test", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "test"; ctx.route(); } }, t("joh.enneagram.takeTest"))));
    if (enn) panel.append(typeCardNode(enn.card));
    return;
  }
  if (state.enneagramMode === "know") {
    const typeSelect = field(t("joh.label.type"), "type", { options: ENNEAGRAM_TYPES.map((n) => ({ value: String(n), label: `${n} — ${enneagramTypeName(n)}` })) }, "select");
    const wingSelect = field(t("joh.enneagram.wingLabel"), "wing", { options: [{ value: "", label: t("joh.enneagram.none") }] }, "select");
    const instinct = field(t("joh.enneagram.instinctLabel"), "instinct", { options: [{ value: "", label: t("joh.enneagram.instinctNotSure") }, { value: "sp", label: t("joh.enneagram.instinctSp") }, { value: "so", label: t("joh.enneagram.instinctSo") }, { value: "sx", label: t("joh.enneagram.instinctSx") }] }, "select");
    const refreshWings = () => {
      const n = Number.parseInt(typeSelect.querySelector("select").value, 10);
      const low = ((n - 2) % 9 + 9) % 9 + 1, high = n % 9 + 1;
      wingSelect.querySelector("select").replaceChildren(el("option", { value: "" }, t("joh.enneagram.none")), el("option", { value: String(low) }, `${n}w${low}`), el("option", { value: String(high) }, `${n}w${high}`));
    };
    typeSelect.querySelector("select").addEventListener("change", refreshWings);
    refreshWings();
    const chooser = form([el("div", { class: "form-row is-inline" }, typeSelect, wingSelect, instinct)], t("joh.enneagram.saveType"), async (data) => {
      await api.johSetEnneagram({ type: Number.parseInt(data.type, 10), wing: data.wing ? Number.parseInt(data.wing, 10) : null, instinct: data.instinct || null, source: "entered" });
      state.enneagramMode = null;
      window.dispatchEvent(new CustomEvent("dm:joh-changed"));
      await ctx.route();
    });
    chooser.id = "joh-enn-form";
    panel.append(chooser, el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", onclick: () => { state.enneagramMode = null; ctx.route(); } }, t("common.cancel"))));
    return;
  }
  // Set: the type card + Retake / Choose differently.
  panel.append(typeCardNode(enn.card, el("div", { class: "form-actions" },
    el("button", { class: "pill-btn", type: "button", id: "joh-enn-retake", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "test"; ctx.route(); } }, t("joh.enneagram.retakeTest")),
    el("button", { class: "pill-btn", type: "button", id: "joh-enn-change", dataset: { write: "true" }, onclick: () => { state.enneagramMode = "choose"; ctx.route(); } }, t("joh.enneagram.chooseDifferently")))),
    el("p", { class: "meta" }, t("joh.enneagram.sourceLine", { source: enn.source === "test" ? t("joh.enneagram.sourceTest") : t("joh.enneagram.sourceEntered") })));
}

async function renderTest(panel, ctx, notice, loaded = null) {
  let test = loaded;
  try { if (!test) test = await api.johEnneagramTest(); } catch (error) { notice.replaceChildren(alertBox("error", t("joh.enneagram.loadTestError", { message: error.message }))); return; }
  const key = testKey(test.seed);
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(key) || "{}"); } catch { saved = {}; }
  const answers = Array.isArray(saved.answers) && saved.answers.length === 45 ? saved.answers : Array(45).fill(null);
  let index = Number.isInteger(saved.index) ? Math.min(44, Math.max(0, saved.index)) : answers.findIndex((a) => a === null);
  if (index < 0) index = 44;
  const box = el("section", { class: "panel joh-card joh-test", id: "joh-test", dataset: { seed: String(test.seed) } });
  const remember = () => { try { localStorage.setItem(key, JSON.stringify({ answers, index })); } catch { /* autosave is a convenience */ } };
  const draw = () => {
    const statement = test.statements[index];
    const answered = answers.filter((a) => a !== null).length;
    box.replaceChildren(
      el("ol", { class: "joh-progress", "aria-label": t("joh.enneagram.progressAria", { answered }) }, test.statements.map((s, i) => el("li", { class: `joh-progress-dot${answers[i] !== null ? " is-done" : ""}${i === index ? " is-current" : ""}`, "aria-current": i === index ? "step" : null }))),
      el("p", { class: "meta" }, el("span", { class: "num joh-num" }, index + 1), " ", t("joh.enneagram.of45")),
      el("p", { class: "joh-statement", id: "joh-statement", dataset: { statementId: statement.id } }, statement.text),
      el("div", { class: "joh-scale", role: "radiogroup", "aria-label": t("joh.enneagram.scaleAria") }, test.scale.map((v, i) => el("button", {
        class: `joh-scale-dot${answers[index] === v ? " is-chosen" : ""}`, type: "button", role: "radio", "aria-checked": String(answers[index] === v), dataset: { value: String(v), write: "true" }, title: scaleLabel(i), "aria-label": t("joh.enneagram.scaleAriaOption", { value: v, label: scaleLabel(i) }),
        onclick: () => { answers[index] = v; if (index < 44) index += 1; remember(); draw(); },
      }, el("span", { class: "joh-dot-mark", "aria-hidden": "true" }), el("span", { class: "joh-dot-text" }, String(v))))),
      el("div", { class: "joh-scale-ends meta", "aria-hidden": "true" }, el("span", {}, scaleLabel(0)), el("span", {}, scaleLabel(4))),
      el("div", { class: "form-actions" },
        el("button", { class: "btn is-small", type: "button", id: "joh-test-back", disabled: index === 0 || null, onclick: () => { index = Math.max(0, index - 1); remember(); draw(); } }, t("joh.enneagram.back")),
        el("button", { class: "btn is-small", type: "button", id: "joh-test-next", disabled: answers[index] === null || index === 44 || null, onclick: () => { index = Math.min(44, index + 1); remember(); draw(); } }, t("joh.enneagram.next")),
        answers.every((a) => a !== null) ? el("button", { class: "btn is-primary is-small", type: "button", id: "joh-test-submit", dataset: { write: "true" }, onclick: async () => {
          try {
            state.enneagramResult = await api.johSubmitEnneagramTest(test.seed, answers);
            try { localStorage.removeItem(key); } catch { /* fine */ }
            state.enneagramMode = null;
            await ctx.route();
          } catch (error) { notice.replaceChildren(alertBox("error", t("joh.enneagram.scoreError", { message: error.message }), error.reasons)); }
        } }, t("joh.enneagram.seeResult")) : null,
        el("button", { class: "btn is-quiet is-small", type: "button", id: "joh-test-cancel", onclick: () => { state.enneagramMode = null; ctx.route(); } }, t("joh.enneagram.stopForNow"))));
    applyReadOnly(box);
  };
  draw();
  panel.append(box);
}

function renderResult(panel, result, ctx, notice) {
  const chosen = { type: result.type, wing: result.wing };
  const chooser = el("div", { class: "form-actions" },
    el("button", { class: "pill-btn gold", type: "button", id: "joh-result-confirm", dataset: { write: "true" }, onclick: async () => {
      try {
        await api.johSetEnneagram({ type: chosen.type, wing: chosen.wing, instinct: null, source: "test" });
        state.enneagramResult = null;
        window.dispatchEvent(new CustomEvent("dm:joh-changed"));
        await ctx.route();
      } catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); }
    } }, t("joh.enneagram.thisIsRight")),
    el("button", { class: "pill-btn", type: "button", id: "joh-result-choose", dataset: { write: "true" }, onclick: () => { state.enneagramResult = null; state.enneagramMode = "know"; ctx.route(); } }, t("joh.enneagram.chooseDifferently")),
    el("button", { class: "pill-btn", type: "button", id: "joh-result-retake", dataset: { write: "true" }, onclick: () => { state.enneagramResult = null; state.enneagramMode = "test"; ctx.route(); } }, t("joh.enneagram.retake")));
  panel.append(classicFold(card(t("joh.enneagram.yourScoresTitle"), scoreBars(result.scores), el("p", { class: "meta" }, t("joh.enneagram.scoresCaption")))),
    typeCardNode(result.card, chooser));
  for (const fill of panel.querySelectorAll(".joh-bar-fill")) fill.style.width = `${fill.dataset.pct}%`;
}

// --- Compass (§4, §5) -------------------------------------------------------------------------

async function renderCompass(panel, profile, ctx) {
  const [agents, history] = await Promise.all([api.agents().catch(() => []), api.johGuidanceHistory(20).catch(() => [])]);
  const agent = agents.find((a) => a.id === "pi-chief-of-staff") || null;
  const configured = Boolean(agent && agent.runner_status && agent.runner_status.configured);
  const policy = agent?.model_policy || {};
  const last = history[0] || null;
  const notice = el("div", { class: "stack", id: "joh-compass-notice" });
  const answer = el("div", { class: "stack", id: "joh-compass-answer" });
  panel.append(el("p", { class: "joh-greeting joh-compass-lead" }, t("joh.compass.lead")));
  if (!configured) {
    panel.append(el("section", { class: "panel joh-card", id: "joh-compass-unconfigured" },
      el("h2", { class: "joh-card-title" }, t("joh.compass.unconfiguredTitle")),
      el("p", { class: "meta" }, t("joh.compass.unconfiguredMeta", { agentName: agent ? agent.name : "pi-chief-of-staff" })),
      reasonsList((agent?.runner_status?.problems || [t("joh.compass.agentMissingReason")]).map((p) => t("joh.compass.notConfigured", { problem: p })))));
  } else {
    const kindTabs = el("div", { class: "tabs joh-kind-tabs", role: "tablist", "aria-label": t("joh.compass.whatToAskAria") }, COMPASS_KINDS.map((id) => el("button", {
      class: "tab", type: "button", role: "tab", dataset: { kind: id }, "aria-selected": String(state.compassKind === id), onclick: () => { state.compassKind = id; ctx.route(); } }, compassKindLabel(id))));
    const kind = state.compassKind;
    const fields = kind === "email"
      ? [field(t("joh.compass.emailLabel"), "input_text", { required: true, rows: "7" }, "textarea"), field(t("joh.compass.intentLabel"), "intent", { rows: "2" }, "textarea")]
      : kind === "decision"
        ? [field(t("joh.compass.decisionLabel"), "input_text", { required: true, rows: "7" }, "textarea"), field(t("joh.compass.horizonLabel"), "horizon", { options: HORIZONS.map((v) => ({ value: v, label: horizonLabel(v) })) }, "select")]
        : [field(t("joh.compass.questionLabel"), "input_text", { required: true, rows: "5" }, "textarea")];
    const ask = form(fields, t("joh.askCompass"), async (data) => {
      answer.replaceChildren(el("p", { class: "empty" }, t("joh.compass.asking")));
      const extra = kind === "email" ? { intent: data.intent || "" } : kind === "decision" ? { horizon: data.horizon } : {};
      try {
        const reply = await api.johGuidance({ kind, input_text: data.input_text, extra });
        answer.replaceChildren(answerCard(reply));
        ctx.route();
      } catch (error) {
        answer.replaceChildren();
        throw error;
      }
    });
    ask.id = "joh-compass-form";
    panel.append(kindTabs, el("section", { class: "panel joh-card" }, ask),
      el("p", { class: "meta joh-money", id: "joh-compass-money" },
        t("joh.compass.capLine", {
          cap: policy.max_cost_minor ?? t("common.none"), currency: policy.currency || "USD", agentName: agent.name, model: policy.model,
          lastCost: last && last.cost_minor !== null && last.cost_minor !== undefined ? `${last.cost_minor} ${last.currency || ""}` : t("common.none"),
        })));
  }
  panel.append(notice, answer);
  if (last && configured) answer.append(answerCard(last));
  panel.append(card(t("joh.compass.pastAnswersTitle"), history.length
    ? el("ul", { class: "list", id: "joh-history" }, history.map((g) => el("li", { class: "list-item joh-history-item", dataset: { kind: g.kind } },
      el("div", { class: "list-item-title" }, el("span", {}, (g.output_text || "").split("\n").map((l) => l.replace(/^#+\s*/, "").trim()).find(Boolean) || t("joh.compass.emptyAnswer")), pill("not_applicable", t(`status.${g.kind}`, undefined, g.kind))),
      el("div", { class: "meta" }, `${when(g.created_at)}${g.model ? ` · ${g.model}` : ""}${g.cost_minor !== null && g.cost_minor !== undefined ? ` · ${g.cost_minor} ${g.currency || ""}` : ""}`))))
    : empty(t("joh.compass.noAnswersYet"))));
}

function answerCard(reply) {
  return el("section", { class: "panel joh-card joh-answer", id: "joh-answer", dataset: { kind: reply.kind } },
    el("ul", { class: "joh-strip", "aria-label": t("joh.compass.chartInTheRoom") }, el("li", { class: "label" }, t("joh.compass.chartInTheRoom")), (reply.chart_in_the_room || []).map((fact) => el("li", { class: "joh-strip-item" }, fact))),
    renderMarkdown(reply.output_text),
    el("p", { class: "meta" }, `${when(reply.created_at)}${reply.provider ? ` · ${reply.provider}` : ""}${reply.model ? ` / ${reply.model}` : ""}${reply.cost_minor !== null && reply.cost_minor !== undefined ? ` · ${t("joh.compass.costPrefix")} ${reply.cost_minor} ${reply.currency || ""}` : ""}`));
}
