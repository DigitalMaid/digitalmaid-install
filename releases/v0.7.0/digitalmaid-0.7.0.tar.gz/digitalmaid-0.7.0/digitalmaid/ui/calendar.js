// Calendar: Day / Week / Month / Agenda over GET /api/calendar (stored events plus
// derived read-only items). Times are shown in the browser's zone; new events are
// stored with that IANA zone so recurring wall times survive DST.
import { api } from "./api.js";
import { el, append, pill, empty, field, form, alertBox, pageHeader, moreOptions } from "./views.js";
import { t, formatDay, formatTime } from "./i18n.js";

const VIEW_IDS = ["day", "week", "month", "agenda"];
const KINDS = ["event", "deadline", "block", "milestone"];
const STACK_BELOW = 480;
const zone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";

const state = { view: "week", focus: todayKey(), gridHadFocus: false };
let items = [];

// A kind word shown as read-only meta (derived items' own kind, or an event's kind);
// falls back to the raw value for anything not in the catalogue yet.
function kindLabel(kind) { return t(`calendar.kindLabel.${kind}`, undefined, kind); }

// --- date helpers (keys are local YYYY-MM-DD) ----------------------------------------
function pad(n) { return String(n).padStart(2, "0"); }
function keyOf(date) { return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`; }
function todayKey() { return keyOf(new Date()); }
function parseKey(key) { const [y, m, d] = key.split("-").map(Number); return new Date(y, m - 1, d); }
function addDays(key, n) { const d = parseKey(key); d.setDate(d.getDate() + n); return keyOf(d); }
function addMonths(key, n) { const d = parseKey(key); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return keyOf(d); }
function weekStart(key) { const d = parseKey(key); const shift = (d.getDay() + 6) % 7; d.setDate(d.getDate() - shift); return keyOf(d); }
function monthGridStart(key) { const d = parseKey(key); d.setDate(1); return weekStart(keyOf(d)); }
function range(startKey, days) { return Array.from({ length: days }, (_, i) => addDays(startKey, i)); }
function itemDay(item) { return item.all_day && item.local_date ? item.local_date : keyOf(new Date(item.start_utc)); }
function timeLabel(item) {
  if (item.all_day) return t("calendar.allDay");
  const start = formatTime(new Date(item.start_utc), { hour: "2-digit", minute: "2-digit" });
  return item.end_utc ? `${start}–${formatTime(new Date(item.end_utc), { hour: "2-digit", minute: "2-digit" })}` : start;
}
function longDate(key) { return formatDay(key, { weekday: "long", year: "numeric", month: "long", day: "numeric" }); }

function visibleRange() {
  if (state.view === "day") return [state.focus, 1];
  if (state.view === "week") return [weekStart(state.focus), 7];
  if (state.view === "month") return [monthGridStart(state.focus), 42];
  return [state.focus, 30];
}

function periodStep(direction) {
  if (state.view === "day") return addDays(state.focus, direction);
  if (state.view === "week") return addDays(state.focus, 7 * direction);
  if (state.view === "month") return addMonths(state.focus, direction);
  return addDays(state.focus, 30 * direction);
}

function title() {
  if (state.view === "day") return longDate(state.focus);
  if (state.view === "month") return formatDay(state.focus, { month: "long", year: "numeric" });
  const [start, days] = visibleRange();
  return `${formatDay(start, { day: "numeric", month: "short" })} – ${formatDay(addDays(start, days - 1), { day: "numeric", month: "short", year: "numeric" })}`;
}

// --- rendering ------------------------------------------------------------------------

export async function renderCalendarPage(container, ctx) {
  const [startKey, days] = visibleRange();
  const from = parseKey(startKey); from.setDate(from.getDate() - 1);
  const to = parseKey(addDays(startKey, days)); to.setDate(to.getDate() + 1);
  const result = await api.calendar(from.toISOString(), to.toISOString());
  items = result.items;
  const byDay = {};
  for (const item of items) (byDay[itemDay(item)] ||= []).push(item);

  const tabs = el("div", { id: "calendar-views", class: "tabs", role: "tablist", "aria-label": t("calendar.viewsAriaLabel") },
    VIEW_IDS.map((id) => el("button", { class: "tab", type: "button", role: "tab", id: `calendar-tab-${id}`,
      dataset: { view: id }, "aria-selected": String(state.view === id), "aria-controls": "calendar-grid",
      tabindex: state.view === id ? "0" : "-1",
      onclick: () => { state.view = id; rerender(ctx); },
      onkeydown: (e) => {
        const index = VIEW_IDS.indexOf(id);
        if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
          e.preventDefault();
          const next = VIEW_IDS[(index + (e.key === "ArrowRight" ? 1 : VIEW_IDS.length - 1)) % VIEW_IDS.length];
          state.view = next; state.gridHadFocus = false;
          rerender(ctx).then(() => document.getElementById(`calendar-tab-${next}`)?.focus());
        }
      } }, t(`calendar.view.${id}`))));

  const stacked = window.innerWidth < STACK_BELOW;
  const grid = el("div", { id: "calendar-grid", role: "tabpanel", "aria-labelledby": `calendar-tab-${state.view}`,
    dataset: { view: state.view, layout: state.view === "agenda" || stacked ? "stacked" : (state.view === "month" ? "grid" : "grid") },
    class: `calendar-grid is-${state.view}${stacked ? " is-stacked" : ""}`,
    onkeydown: (e) => onGridKey(e, ctx) });
  if (state.view === "agenda") append(grid, [renderAgenda(startKey, days, byDay, ctx)]);
  else append(grid, range(startKey, days).map((key) => dayCell(key, byDay[key] || [], ctx, stacked)));

  const header = pageHeader("calendar", t("calendar.pageTitle"),
    t("calendar.how", { zone }),
    { tools: el("div", { class: "form-actions" },
      el("button", { class: "btn is-small", type: "button", "aria-label": t("calendar.prevPeriod"), onclick: () => { state.focus = periodStep(-1); rerender(ctx); } }, "‹"),
      el("button", { class: "btn is-small", type: "button", onclick: () => { state.focus = todayKey(); rerender(ctx); } }, t("calendar.today")),
      el("button", { class: "btn is-small", type: "button", "aria-label": t("calendar.nextPeriod"), onclick: () => { state.focus = periodStep(1); rerender(ctx); } }, "›"),
      el("button", { class: "btn is-primary is-small", type: "button", id: "new-event-button", dataset: { write: "true" }, onclick: () => openEventDrawer(ctx, null, state.focus) }, t("calendar.newEvent"))) });
  container.replaceChildren(header,
    el("div", { class: "calendar-toolbar" }, el("h2", { id: "calendar-title", "aria-live": "polite" }, title()), tabs),
    grid);
  ctx.applyReadOnly?.(container);
  if (state.gridHadFocus) grid.querySelector("[data-day][tabindex='0']")?.focus();
  state.gridHadFocus = false;
}

async function rerender(ctx) {
  state.gridHadFocus = document.activeElement?.closest?.("#calendar-grid") !== null && document.activeElement?.closest?.("#calendar-grid") !== undefined;
  await ctx.route();
}

function onGridKey(event, ctx) {
  const vertical = state.view === "week" || state.view === "month" ? 7 : 1;
  const moves = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -vertical, ArrowDown: vertical };
  if (event.key in moves) { event.preventDefault(); state.focus = addDays(state.focus, moves[event.key]); return refocus(ctx); }
  if (event.key === "PageDown" || event.key === "PageUp") { event.preventDefault(); state.focus = periodStep(event.key === "PageDown" ? 1 : -1); return refocus(ctx); }
  if (event.key === "t" || event.key === "T") { if (event.target.matches("input, textarea")) return; event.preventDefault(); state.focus = todayKey(); return refocus(ctx); }
  if (event.key === "Enter" && event.target.matches("[data-day]")) { event.preventDefault(); openEventDrawer(ctx, null, event.target.dataset.day); }
}

function refocus(ctx) {
  state.gridHadFocus = true;
  const [start, days] = visibleRange();
  // Stay inside the rendered range where possible; otherwise re-render for the new period.
  const cell = document.querySelector(`#calendar-grid [data-day="${state.focus}"]`);
  const inRange = state.focus >= start && state.focus < addDays(start, days);
  if (cell && inRange) {
    for (const c of document.querySelectorAll("#calendar-grid [data-day]")) c.tabIndex = c === cell ? 0 : -1;
    cell.focus();
    return;
  }
  return rerender(ctx);
}

function dayCell(key, dayItems, ctx, stacked) {
  const isFocus = key === state.focus;
  const d = parseKey(key);
  const outsideMonth = state.view === "month" && d.getMonth() !== parseKey(state.focus).getMonth();
  if (stacked && state.view === "month" && !dayItems.length && !isFocus) return null;
  return el("div", { class: `calendar-day${isFocus ? " is-focus" : ""}${key === todayKey() ? " is-today" : ""}${outsideMonth ? " is-outside" : ""}`,
    dataset: { day: key }, tabindex: isFocus ? "0" : "-1", role: "group",
    "aria-label": t("calendar.dayAriaLabel", { date: longDate(key), count: dayItems.length }),
    onclick: (e) => { if (e.target.closest("[data-item]")) return; state.focus = key; refocus(ctx); },
    ondblclick: (e) => { if (!e.target.closest("[data-item]")) openEventDrawer(ctx, null, key); } },
    el("div", { class: "calendar-day-head" },
      el("span", { class: "calendar-day-num" }, state.view === "month" ? String(d.getDate()) : formatDay(key, { weekday: "short", day: "numeric" }))),
    dayItems.length
      ? el("ul", { class: "calendar-items" }, dayItems.map((item) => itemButton(item, ctx)))
      : (state.view !== "month" || stacked ? el("p", { class: "empty" }, t("common.none")) : null));
}

function itemButton(item, ctx) {
  const derived = item.source !== "event";
  return el("li", {}, el("button", { class: `calendar-item is-${item.kind}${derived ? " is-derived" : ""}`, type: "button",
    dataset: { item: item.id, source: item.source, kind: item.kind },
    title: derived ? t("calendar.derivedTitle", { kind: kindLabel(item.kind) }) : item.title,
    onclick: () => openItem(item, ctx) },
    el("span", { class: "calendar-item-time" }, timeLabel(item)),
    el("span", { class: "calendar-item-title" }, item.title),
    derived ? el("span", { class: "pill is-plain" }, kindLabel(item.kind)) : null,
    item.external_source ? el("span", { class: "pill is-plain" }, t("calendar.ownedBy", { source: item.external_source })) : null));
}

function renderAgenda(startKey, days, byDay, ctx) {
  const keys = range(startKey, days).filter((k) => (byDay[k] || []).length || k === state.focus);
  return el("div", { class: "agenda" }, keys.length ? keys.map((key) => el("section", { class: "agenda-day", dataset: { day: key }, tabindex: key === state.focus ? "0" : "-1",
    "aria-label": longDate(key), onclick: () => { state.focus = key; } },
    el("h3", {}, longDate(key)),
    (byDay[key] || []).length ? el("ul", { class: "calendar-items" }, byDay[key].map((item) => itemButton(item, ctx))) : empty(t("calendar.agenda.nothingScheduled")))) : empty(t("calendar.agenda.nothingInPeriod")));
}

function openItem(item, ctx) {
  if (item.source === "task") return ctx.openTask(item.linked_id);
  if (item.source === "job") { location.hash = "#/automations"; return; }
  if (item.source === "decision") { location.hash = `#/knowledge/${item.linked_id}`; return; }
  openEventDrawer(ctx, item, itemDay(item));
}

// --- event drawer -----------------------------------------------------------------------

async function openEventDrawer(ctx, item, dayKey) {
  let event = null;
  if (item) {
    try { event = await api.event(item.event_id); } catch (error) { ctx.showGlobal(t("calendar.couldNotLoadEvent", { message: error.message })); return; }
  }
  const readOnly = Boolean(event?.external_source);
  const start = event ? new Date(item.start_utc) : null;
  const end = event && item.end_utc ? new Date(item.end_utc) : null;
  const values = {
    title: event?.title || "", kind: event?.kind || "event", date: dayKey,
    start_time: start && !event.all_day ? `${pad(start.getHours())}:${pad(start.getMinutes())}` : "09:00",
    end_time: end && !event.all_day ? `${pad(end.getHours())}:${pad(end.getMinutes())}` : "",
    notes: event?.notes || "", freq: event?.rrule?.freq || "none", until: event?.rrule?.until || "",
  };
  const body = (data) => {
    const startAt = data.all_day ? new Date(parseKey(data.date)) : new Date(`${data.date}T${data.start_time || "09:00"}`);
    const endAt = !data.all_day && data.end_time ? new Date(`${data.date}T${data.end_time}`) : null;
    const rrule = data.freq && data.freq !== "none" ? { freq: data.freq, interval: 1, ...(data.until ? { until: data.until } : {}) } : null;
    return { title: data.title, kind: data.kind, start_utc: startAt.toISOString(), end_utc: endAt ? endAt.toISOString() : null,
      all_day: Boolean(data.all_day), timezone: zone, notes: data.notes || "", rrule };
  };
  const allDay = el("label", { class: "checkbox" }, el("input", { type: "checkbox", name: "all_day", checked: event?.all_day || null }), t("calendar.allDayLabel"));
  // Tier 1 (D3): title + when. Kind, end, all-day, repeat and notes wait under More options,
  // which opens itself when an existing event already uses any of them.
  const nonDefault = Boolean(event && (values.kind !== "event" || values.end_time || event.all_day || values.freq !== "none" || values.notes));
  const eventForm = form([
    field(t("calendar.field.title"), "title", { required: true, value: values.title }),
    el("div", { class: "form-row is-inline" },
      field(t("calendar.field.date"), "date", { type: "date", required: true, value: values.date }),
      field(t("calendar.field.start"), "start_time", { type: "time", value: values.start_time })),
    moreOptions([
      el("div", { class: "form-row is-inline" },
        field(t("calendar.field.kind"), "kind", { options: KINDS.map((v) => ({ value: v, label: t(`calendar.kind.${v}`) })), value: values.kind }, "select"),
        field(t("calendar.field.end"), "end_time", { type: "time", value: values.end_time }),
        el("div", { class: "form-row" }, allDay)),
      el("div", { class: "form-row is-inline" },
        field(t("calendar.field.repeats"), "freq", { options: [
          { value: "none", label: t("calendar.freq.none") },
          { value: "daily", label: t("calendar.freq.daily") },
          { value: "weekly", label: t("calendar.freq.weekly") },
          { value: "monthly", label: t("calendar.freq.monthly") },
        ], value: values.freq }, "select"),
        field(t("calendar.field.until"), "until", { type: "date", value: values.until })),
      field(t("calendar.field.notes"), "notes", { rows: "2", value: values.notes }, "textarea"),
    ], { open: nonDefault }),
  ], event ? t("calendar.saveEvent") : t("calendar.createEvent"), async (data) => {
    const payload = body(data);
    if (event) {
      const update = { revision: event.revision, title: payload.title, kind: payload.kind, start_utc: payload.start_utc, end_utc: payload.end_utc, all_day: payload.all_day, notes: payload.notes };
      if (payload.rrule) update.rrule = payload.rrule; else update.clear_rrule = true;
      await api.updateEvent(event.id, update);
    } else await api.createEvent(payload);
    ctx.closeDrawer();
    await ctx.route();
  });
  eventForm.id = "event-form";
  eventForm.querySelector("[name=kind]").value = values.kind;
  eventForm.querySelector("[name=freq]").value = values.freq;
  const actions = [];
  if (event && !readOnly) {
    actions.push(form([], t("calendar.archiveEvent"), async () => { await api.archiveEvent(event.id, { revision: event.revision }); ctx.closeDrawer(); await ctx.route(); }));
    if (event.rrule) actions.push(form([], t("calendar.skipOccurrence", { date: item.occurrence_local_date }), async () => {
      await api.addEventException(event.id, { occurrence_local_date: item.occurrence_local_date, kind: "skip" }); ctx.closeDrawer(); await ctx.route(); }));
  }
  const sections = [
    readOnly ? alertBox("info", t("calendar.readOnlyOwned", { source: event.external_source })) : null,
    event ? el("dl", { class: "kv" }, el("dt", {}, t("calendar.field.occurrence")), el("dd", {}, `${longDate(dayKey)} · ${timeLabel(item)}`),
      event.rrule ? [el("dt", {}, t("calendar.field.repeats")), el("dd", {}, t("calendar.repeatsValue", {
        freq: t(`calendar.freq.${event.rrule.freq}`), until: event.rrule.until ? t("calendar.until", { date: event.rrule.until }) : "",
        exceptions: t("calendar.exceptionsCount", { count: event.exceptions.length }) }))] : null,
      event.linked_type ? [el("dt", {}, t("calendar.field.linked")), el("dd", {}, `${t(`calendar.linkedType.${event.linked_type}`, undefined, event.linked_type)} ${event.linked_id.slice(0, 8)}…`)] : null) : null,
    readOnly ? null : eventForm,
    ...actions,
  ];
  if (readOnly) eventForm.querySelectorAll("input, select, textarea, button").forEach((n) => { n.disabled = true; });
  if (readOnly) sections.push(eventForm);
  ctx.openDrawer(event ? event.title : t("calendar.newEventOn", { date: longDate(dayKey) }), el("div", { class: "stack" }, sections),
    { focus: "#event-form [name=title]", kicker: event ? t("calendar.eventKicker", { kind: t(`calendar.kind.${event.kind}`) }) : t("calendar.newEvent") });
}

window.digitalmaidCalendar = {
  goTo(dateKey) { state.focus = dateKey; return window.dispatchEvent(new Event("hashchange")); },
  state,
};
