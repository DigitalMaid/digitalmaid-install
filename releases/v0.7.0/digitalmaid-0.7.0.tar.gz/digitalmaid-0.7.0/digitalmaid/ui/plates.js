// JOH Plates engine (0.6.0, docs/DESIGN.md Appendix G) — one 3D "engraved star plate" per chart.
// The particle language is the Today hero's (hero.js): 3×3 rotation matrices, yaw/pitch with
// inertia that eases back to a rest pitch, every dot breathing on its own sine, grab-to-turn
// with pointer capture. Glow is never a canvas shadow: radial-gradient sprites are painted once
// and blitted with drawImage. Scenes (plates-scenes.js) are plain data: engraved lines, dust rings,
// clouds, threads, a beam, a blaze, named stars and sparkles; this module only projects and draws.

const TAU = Math.PI * 2;
const PUBLISH_MS = 500;          // screen positions of the named stars, at most twice a second

// --- colours: the Observatory tokens as "r,g,b" strings (canvas needs the channels) -------------
function readTokens() {
  const css = typeof getComputedStyle === "function" ? getComputedStyle(document.documentElement) : null;
  const rgb = (name, fallback) => {
    const value = css ? css.getPropertyValue(name).trim() : "";
    const m = /^#([0-9a-f]{6})$/i.exec(value);
    return m ? [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16)).join(",") : fallback;
  };
  return {
    ink: rgb("--ink", "235,230,218"), ink2: rgb("--ink-2", "172,167,154"), mute: rgb("--mute", "130,126,116"),
    gold: rgb("--accent", "212,175,90"), gold2: rgb("--accent-2", "240,215,138"), gold3: "255,236,190", white: "255,250,240",
    rose: rgb("--phase-correction", "224,122,140"), violet: rgb("--phase-correction-2", "195,155,230"),
    sky: rgb("--phase-plan-2", "143,184,230"), do: rgb("--phase-do-2", "242,193,78"), check: rgb("--phase-check-2", "143,217,168"),
    serif: css?.getPropertyValue("--serif").trim() || "Cormorant, serif",
    numeral: css?.getPropertyValue("--numeral").trim() || "Doto, monospace",
  };
}
export const T = readTokens();

// --- maths ----------------------------------------------------------------------------------------
export const rotX = (a) => { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, c, -s, 0, s, c]; };
export const rotY = (a) => { const c = Math.cos(a), s = Math.sin(a); return [c, 0, s, 0, 1, 0, -s, 0, c]; };
export const mul = (a, b) => {
  const o = new Array(9);
  for (let r = 0; r < 3; r += 1) for (let c = 0; c < 3; c += 1) o[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
  return o;
};
export const ap = (m, x, y, z) => [m[0] * x + m[1] * y + m[2] * z, m[3] * x + m[4] * y + m[5] * z, m[6] * x + m[7] * y + m[8] * z];
export const rad = (d) => d * Math.PI / 180;
export const I3 = [1, 0, 0, 0, 1, 0, 0, 0, 1];

// xorshift32: the same seed always yields the same dust, so a re-render never reshuffles.
export function seeded(seed) {
  let s = seed >>> 0 || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}
export function hashSeed(text) {
  let h = 2166136261;
  for (const ch of String(text)) { h ^= ch.codePointAt(0); h = Math.imul(h, 16777619) >>> 0; }
  return h || 1;
}

// --- sprites (painted once, cached by colour and size) -------------------------------------------
const spriteCache = new Map();
export function sprite(col, size = 64) {
  const key = "g" + col + size;
  if (spriteCache.has(key)) return spriteCache.get(key);
  const c = document.createElement("canvas"); c.width = c.height = size;
  const x = c.getContext("2d"), h = size / 2;
  const g = x.createRadialGradient(h, h, 0, h, h, h);
  g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.07, `rgba(${col},1)`); g.addColorStop(0.22, `rgba(${col},.5)`);
  g.addColorStop(0.5, `rgba(${col},.1)`); g.addColorStop(1, `rgba(${col},0)`);
  x.fillStyle = g; x.fillRect(0, 0, size, size);
  spriteCache.set(key, c);
  return c;
}
export function orbSprite(col, size = 96) {
  const key = "o" + col + size;
  if (spriteCache.has(key)) return spriteCache.get(key);
  const c = document.createElement("canvas"); c.width = c.height = size;
  const x = c.getContext("2d"), h = size / 2;
  const g = x.createRadialGradient(h * 0.7, h * 0.66, 1, h, h, h * 0.98);
  g.addColorStop(0, "rgba(255,252,240,1)"); g.addColorStop(0.3, `rgba(${col},1)`); g.addColorStop(0.8, `rgba(${col},.55)`);
  g.addColorStop(0.97, "rgba(30,22,12,.95)"); g.addColorStop(1, "rgba(30,22,12,0)");
  x.fillStyle = g; x.beginPath(); x.arc(h, h, h * 0.98, 0, TAU); x.fill();
  const rnd = seeded(size + col.length);   // surface mottle
  x.globalAlpha = 0.18;
  for (let i = 0; i < 40; i += 1) {
    const a = rnd() * TAU, d = rnd() * h * 0.85;
    x.fillStyle = rnd() < 0.5 ? "rgba(0,0,0,1)" : "rgba(255,255,255,1)";
    x.beginPath(); x.arc(h + Math.cos(a) * d, h + Math.sin(a) * d, 1 + rnd() * h * 0.12, 0, TAU); x.fill();
  }
  x.globalAlpha = 1; x.strokeStyle = `rgba(${T.gold3},.8)`; x.lineWidth = 1;
  x.beginPath(); x.arc(h, h, h * 0.97, 0, TAU); x.stroke();
  spriteCache.set(key, c);
  return c;
}

// --- scene helpers ---------------------------------------------------------------------------------
export function cloud(rnd, cx, cy, cz, n, spread, col, radius = [0.4, 1.1], alpha = [0.25, 0.7]) {
  const out = [];
  for (let i = 0; i < n; i += 1) {
    const u = rnd() * 2 - 1, th = rnd() * TAU, s = Math.sqrt(1 - u * u), r = spread * Math.cbrt(rnd());
    out.push({ x: cx + s * Math.cos(th) * r, y: cy + s * Math.sin(th) * r, z: cz + u * r, radius: radius[0] + rnd() * (radius[1] - radius[0]),
      alpha: alpha[0] + rnd() * (alpha[1] - alpha[0]), tw: rnd() * TAU, tempo: 0.4 + rnd() * 1.2, drift: spread * 0.08, col });
  }
  return out;
}
export function thread(rnd, a, b, col, n = 26, alpha = 0.6, spread = 0.012, flow = 0, extra = {}) {
  return { a, b, col, alpha, flow, ...extra, beads: Array.from({ length: n }, () => ({ u: rnd(), ox: (rnd() - 0.5) * spread, oy: (rnd() - 0.5) * spread, oz: (rnd() - 0.5) * spread, radius: 0.5 + rnd() * 0.9, tw: rnd() * TAU })) };
}
export function ring(rnd, r, n, col, speed, plane, alpha = 0.5, extra = {}) {
  return { r, col, speed, alpha, plane: plane.length === 9 ? plane : mul(rotX(plane[0]), rotY(plane[1])),
    stars: Array.from({ length: n }, () => ({ a: rnd() * TAU, j: (rnd() - 0.5) * 0.03, radius: 0.35 + rnd() * 0.8, tw: rnd() * TAU, tempo: 0.5 + rnd() })), ...extra };
}
export function shell(rnd, n, rmin, rmax, col = T.ink) {
  return Array.from({ length: n }, () => {
    const u = rnd() * 2 - 1, th = rnd() * TAU, s = Math.sqrt(1 - u * u), r = rmin + rnd() * (rmax - rmin);
    return { x: s * Math.cos(th) * r, y: s * Math.sin(th) * r, z: u * r, radius: 0.3 + rnd() * 0.7, alpha: 0.15 + rnd() * 0.35, tw: rnd() * TAU, tempo: 0.3 + rnd(), drift: 0.01, col };
  });
}
export function sparks(rnd, n, rmin, rmax, plane = null) {
  return Array.from({ length: n }, () => {
    const a = rnd() * TAU, r = rmin + rnd() * (rmax - rmin);
    let x = Math.cos(a) * r, y = Math.sin(a) * r, z = (rnd() - 0.5) * 0.1;
    if (plane) [x, y, z] = ap(plane, x, y, z);
    else { const u = rnd() * 2 - 1, s = Math.sqrt(1 - u * u); x = s * Math.cos(a) * r; y = s * Math.sin(a) * r; z = u * r; }
    return { x, y, z, size: 3 + rnd() * 6, tw: rnd() * TAU, tempo: 0.2 + rnd() * 0.5 };
  });
}
// engraved primitives (arrays of 3D points; drawn as hairlines in the first layer)
export function circle(r, plane = I3, col = T.gold, alpha = 0.35, opts = {}) {
  const n = 120;
  return { pts: Array.from({ length: n }, (_, i) => ap(plane, Math.cos(i * TAU / n) * r, Math.sin(i * TAU / n) * r, 0)), close: true, col, alpha, ...opts };
}
export function ticks(r0, r1, n, plane = I3, col = T.gold, alpha = 0.4, every = 1, ph = 0) {
  const out = [];
  for (let i = 0; i < n; i += 1) {
    if (i % every) continue;
    const a = i * TAU / n + ph;
    out.push({ pts: [ap(plane, Math.cos(a) * r0, Math.sin(a) * r0, 0), ap(plane, Math.cos(a) * r1, Math.sin(a) * r1, 0)], col, alpha });
  }
  return out;
}
export function polygon(r, n, plane = I3, col = T.gold, alpha = 0.3, step = 1, ph = 0, opts = {}) {
  return { pts: Array.from({ length: n }, (_, i) => { const a = ((i * step) % n) * TAU / n + ph; return ap(plane, Math.cos(a) * r, Math.sin(a) * r, 0); }), close: true, col, alpha, ...opts };
}
export function gear(r, teeth, depth, plane = I3, col = T.gold, alpha = 0.4) {
  const pts = [];
  for (let i = 0; i < teeth * 4; i += 1) { const a = i * TAU / (teeth * 4), k = i % 4, rr = k === 0 || k === 3 ? r : r + depth; pts.push(ap(plane, Math.cos(a) * rr, Math.sin(a) * rr, 0)); }
  return { pts, close: true, col, alpha, width: 0.6 };
}
export function scallop(r, n, depth, plane = I3, col = T.gold, alpha = 0.3) {
  const pts = [], steps = n * 6;
  for (let i = 0; i < steps; i += 1) { const a = i * TAU / steps, rr = r + depth * Math.abs(Math.sin(a * n / 2)); pts.push(ap(plane, Math.cos(a) * rr, Math.sin(a) * rr, 0)); }
  return { pts, close: true, col, alpha };
}
export function seg(a, b, col = T.gold, alpha = 0.3, opts = {}) { return { pts: [[a.x, a.y, a.z], [b.x, b.y, b.z]], col, alpha, ...opts }; }
// a full engraved band: outer/inner circles, fine ticks, optional scallop and dashed middle
export function band(r0, r1, plane, ph = 0, opts = {}) {
  const out = [circle(r0, plane, T.gold, 0.45), circle(r1, plane, T.gold, 0.35),
    ...ticks(r0, r0 + (r1 - r0) * 0.35, opts.n || 120, plane, T.gold, 0.45, 1, ph), ...ticks(r0, r0 + (r1 - r0) * 0.7, opts.n || 120, plane, T.gold, 0.55, 5, ph)];
  if (opts.scallop) out.push(scallop((r0 + r1) / 2, opts.scallop, (r1 - r0) * 0.15, plane, T.gold, 0.28));
  if (opts.dash) out.push(circle((r0 + r1) / 2, plane, T.gold, 0.3, { dash: [2, 4] }));
  return out;
}
export function shiftLines(lines, dx, dy, dz = 0) { return lines.map((l) => ({ ...l, pts: l.pts.map(([x, y, z]) => [x + dx, y + dy, z + dz]) })); }

// --- the field -------------------------------------------------------------------------------------
export class Field {
  constructor(canvas, host, options = {}) {
    this.c = canvas; this.host = host; this.x = canvas.getContext("2d");
    this.reduced = Boolean(options.reduced);
    this.yaw = 0; this.pitch = -0.22; this.vyaw = 0; this.vpitch = 0; this.drag = null; this.hover = null;
    this.raf = null; this.dead = false; this.wasConnected = false; this.published = -Infinity;
    this.frames = 0; this.fpsAt = 0; this.fps = 0; this.W = 0; this.H = 0; this.dpr = 1; this.R = 1;
    this.m = I3;
    this.load({});
    this.observer = typeof ResizeObserver === "function" ? new ResizeObserver(() => { if (this.fit()) this.wake(); }) : null;
    this.observer?.observe(host);
    this.onDown = (e) => { this.drag = { x: e.clientX, y: e.clientY, travel: 0 }; try { canvas.setPointerCapture(e.pointerId); } catch { /* fine */ } host.dataset.grabbing = "true"; this.wake(); };
    this.onMove = (e) => {
      if (this.drag) {
        const dx = e.clientX - this.drag.x, dy = e.clientY - this.drag.y;
        this.yaw += dx * 0.0075; this.pitch = Math.max(-1.3, Math.min(1.3, this.pitch + dy * 0.0075));
        this.vyaw = dx * 0.45; this.vpitch = dy * 0.45;
        this.drag = { x: e.clientX, y: e.clientY, travel: this.drag.travel + Math.hypot(dx, dy) };
        this.wake();
      } else this.pick(e.clientX, e.clientY);
    };
    this.onUp = (e, click) => {
      const drag = this.drag; this.drag = null; delete host.dataset.grabbing;
      try { canvas.releasePointerCapture(e.pointerId); } catch { /* already released */ }
      if (click && drag && drag.travel < 4 && this.hover && this.onClick) this.onClick(this.hover);
      this.wake();
    };
    this.onLeave = () => { if (!this.drag && this.hover) { this.hover = null; this.onHover?.(null); } };
    canvas.addEventListener("pointerdown", this.onDown);
    canvas.addEventListener("pointermove", this.onMove);
    canvas.addEventListener("pointerup", (e) => this.onUp(e, true));
    canvas.addEventListener("pointercancel", (e) => this.onUp(e, false));
    canvas.addEventListener("pointerleave", this.onLeave);
    this.last = performance.now();
    this.wake();
  }
  fit() {
    const r = this.host.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    if (r.width === this.W && r.height === this.H && dpr === this.dpr) return false;
    this.dpr = dpr; this.W = r.width; this.H = r.height;
    this.c.width = Math.round(this.W * dpr); this.c.height = Math.round(this.H * dpr);
    // Phones: a smaller radius so the outer numerals and the Ascendant label stay inside the frame.
    // Clear bands for the plate head (top) and the lead line (bottom) so the rings never run
    // under text: 150 px + 70 px on desktop, 130 + 30 on phone. The field is centred in what
    // remains (see project()).
    this.padTop = this.W < 600 ? 130 : 150; this.padBottom = this.W < 600 ? 30 : 74;
    const free = Math.max(120, this.H - this.padTop - this.padBottom);
    this.R = Math.min(this.W * (this.W < 600 ? 0.9 : 0.8), free) * 0.42;
    return true;
  }
  load(scene) {
    Object.assign(this, { stars: [], dust: [], threads: [], rings: [], lines: [], sparks: [], blaze: null, beam: null, hover: null, scale: 1, dy: 0, idle: 0.04, restPitch: -0.22, seed: 0, onHover: null, onClick: null }, scene);
    if (scene.restPitch !== undefined && !this.wasConnected) this.pitch = scene.restPitch;
    this.published = -Infinity;
    this.wake();
  }
  wake() {
    if (this.dead || this.raf !== null) return;
    const self = this;
    // A named function: tests count plate frame requests by this name to prove the loop stops.
    function plateFrame(now) { self.raf = null; self.tick(now); }
    this.raf = requestAnimationFrame(plateFrame);
  }
  destroy() {
    this.dead = true;
    if (this.raf !== null) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.observer?.disconnect();
    this.c.removeEventListener("pointerdown", this.onDown);
    this.c.removeEventListener("pointermove", this.onMove);
    this.c.removeEventListener("pointerleave", this.onLeave);
  }
  project(x, y, z) {
    const [a, b, c] = ap(this.m, x, y, z);
    const persp = 1 / (1 + c * 0.32), R = this.R * this.scale;
    return [this.W / 2 + a * R * persp, this.padTop + (this.H - this.padTop - this.padBottom) / 2 + (this.dy || 0) + b * R * persp, c, persp];
  }
  pick(px, py) {
    const r = this.c.getBoundingClientRect(); px -= r.left; py -= r.top;
    let best = null, bd = 16;
    for (const s of this.stars) {
      if (!s.p || s.nopick || s.text) continue;
      const d = Math.hypot(s.p[0] - px, s.p[1] - py);
      if (d < bd) { bd = d; best = s; }
    }
    if (best !== this.hover) {
      this.hover = best;
      if (best) this.host.dataset.hover = "true"; else delete this.host.dataset.hover;
      this.onHover?.(best); this.wake();
    }
  }
  tick(now) {
    if (this.dead) return;
    if (!this.c.isConnected) {
      if (this.wasConnected) { this.destroy(); return; }   // removed from the page for good
      this.wake(); return;                                  // not attached yet — keep waiting
    }
    this.wasConnected = true;
    if (document.hidden) { this.last = now; this.wake(); return; }
    this.fit();
    if (!this.W) { this.wake(); return; }
    const dt = Math.min(0.05, (now - this.last) / 1000); this.last = now; const t = now / 1000;
    if (!this.drag && !this.reduced) {
      const k = Math.exp(-1.6 * dt);
      this.vyaw = this.idle + (this.vyaw - this.idle) * k; this.vpitch *= k;
      this.yaw += this.vyaw * dt; this.pitch = Math.max(-1.3, Math.min(1.3, this.pitch + this.vpitch * dt));
      this.pitch += (this.restPitch - this.pitch) * 0.12 * dt;
    }
    this.draw(t);
    this.frames += 1;
    if (now - this.fpsAt >= 1000) { this.fps = this.fpsAt ? Math.round(this.frames * 1000 / (now - this.fpsAt)) : 0; this.frames = 0; this.fpsAt = now; this.publishStats(); }
    if (this.reduced || now - this.published >= PUBLISH_MS) { this.published = now; this.publish(); }
    // Reduced motion: one frame per scene, then hold still; a drag redraws through wake().
    if (this.reduced && !this.drag) return;
    this.wake();
  }
  publishStats() {
    const stars = this.stars.filter((s) => !s.text && !s.deco).length;
    const threads = this.threads.filter((th) => th.role).length;
    this.host.dataset.plateStats = JSON.stringify({ stars, threads, lines: this.lines.length, fps: this.fps, seed: this.seed, dust: this.dust.length });
  }
  publish() {
    if (!this.host.dataset.plateStats) this.publishStats();
    this.c.dataset.plateStars = JSON.stringify(this.stars.filter((s) => s.id && s.p).map((s) => ({ id: s.id, x: Math.round(s.p[0] * 10) / 10, y: Math.round(s.p[1] * 10) / 10 })));
    this.c.dataset.plateYaw = String(Math.round(this.yaw * 1000) / 1000);
  }
  cross(x, y, L, alpha, col = T.gold3, diag = false) {
    const c = this.x; c.globalAlpha = alpha; c.strokeStyle = `rgb(${col})`; c.lineWidth = 0.6;
    c.beginPath(); c.moveTo(x - L, y); c.lineTo(x + L, y); c.moveTo(x, y - L); c.lineTo(x, y + L); c.stroke();
    if (diag) { const l = L * 0.42; c.globalAlpha = alpha * 0.55; c.beginPath(); c.moveTo(x - l, y - l); c.lineTo(x + l, y + l); c.moveTo(x + l, y - l); c.lineTo(x - l, y + l); c.stroke(); }
  }
  draw(t) {
    const x = this.x;
    x.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); x.clearRect(0, 0, this.W, this.H);
    this.m = mul(rotX(this.pitch), rotY(this.yaw));
    const R = this.R * this.scale;
    // 1. engraved lines
    for (const L of this.lines) {
      const pts = L.pts.map(([px, py, pz]) => this.project(px, py, pz));
      const depth = pts.reduce((s, p) => s + p[2], 0) / pts.length;
      x.globalAlpha = L.alpha * (0.6 + 0.4 * (1 - (depth + 1) / 2)) * (L.pulse ? 0.7 + 0.3 * Math.sin(t * 0.7 + (L.ph || 0)) : 1);
      x.strokeStyle = `rgb(${L.col})`; x.lineWidth = L.width || 0.6; x.setLineDash(L.dash || []);
      x.beginPath(); pts.forEach((p, i) => (i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1]))); if (L.close) x.closePath(); x.stroke();
      if (L.beads) { x.fillStyle = `rgb(${T.gold2})`; x.globalAlpha *= 1.3; for (const p of pts) { x.beginPath(); x.arc(p[0], p[1], L.beads, 0, TAU); x.fill(); } }
    }
    x.setLineDash([]);
    // 2–4. dust rings, clouds, threads → one depth-sorted list with the stars and sparkles
    const items = [];
    for (const r of this.rings) {
      const ph = t * r.speed;
      for (const s of r.stars) { const a = s.a + ph; const [px, py, pz] = ap(r.plane, Math.cos(a) * r.r, Math.sin(a) * r.r, s.j); const p = this.project(px + (r.dx || 0), py + (r.dy || 0), pz); items.push({ k: 0, p, r: s.radius * p[3], a: r.alpha * (0.55 + 0.45 * Math.sin(s.tw + t * s.tempo)), col: r.col }); }
    }
    for (const d of this.dust) {
      const dx = d.x + Math.sin(t * d.tempo * 0.3 + d.tw) * d.drift, dy = d.y + Math.cos(t * d.tempo * 0.27 + d.tw) * d.drift;
      const p = this.project(dx, dy, d.z); items.push({ k: 0, p, r: d.radius * p[3], a: d.alpha * (0.5 + 0.5 * Math.sin(d.tw + t * d.tempo)), col: d.col });
    }
    for (const th of this.threads) {
      const A = th.a, B = th.b;
      for (const s of th.beads) { const f = (((s.u + (th.flow ? t * th.flow : 0)) % 1) + 1) % 1; const p = this.project(A.x + (B.x - A.x) * f + s.ox, A.y + (B.y - A.y) * f + s.oy, A.z + (B.z - A.z) * f + s.oz); items.push({ k: 0, p, r: s.radius * p[3], a: th.alpha * (0.6 + 0.4 * Math.sin(s.tw + t * 1.3)), col: th.col }); }
    }
    for (const s of this.stars) {
      const b = 0.5 + 0.5 * Math.sin(s.tw + t * s.tempo), jx = Math.sin(t * 0.21 + s.tw) * s.drift, jy = Math.cos(t * 0.19 + s.tw) * s.drift;
      const p = this.project(s.x + jx, s.y + jy, s.z); s.p = p; items.push({ k: 1, p, s, b });
    }
    for (const s of this.sparks) { const p = this.project(s.x, s.y, s.z); items.push({ k: 2, p, s, b: 0.5 + 0.5 * Math.sin(s.tw + t * s.tempo) }); }
    // 5. beam with rising motes
    if (this.beam) {
      const B = this.beam, a = this.project(B.a[0], B.a[1], B.a[2]), b = this.project(B.b[0], B.b[1], B.b[2]);
      const g = x.createLinearGradient(a[0], a[1], b[0], b[1]); g.addColorStop(0, `rgba(${B.col},0)`); g.addColorStop(0.5, `rgba(${B.col},${B.alpha})`); g.addColorStop(1, `rgba(${B.col},0)`);
      x.strokeStyle = g; x.lineCap = "round";
      for (const [w, k] of [[B.width * 9, 0.1], [B.width * 3.5, 0.3], [B.width * 1.2, 0.8], [B.width * 0.4, 1]]) { x.globalAlpha = k * (0.85 + 0.15 * Math.sin(t * 0.9)); x.lineWidth = w; x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.stroke(); }
      x.fillStyle = `rgb(${T.gold3})`;
      for (let i = 0; i < 26; i += 1) { const f = (t * 0.05 * (0.6 + (i % 5) * 0.2) + i / 26) % 1; const px = a[0] + (b[0] - a[0]) * f + Math.sin(t * 1.3 + i) * B.width * 3, py = a[1] + (b[1] - a[1]) * f; x.globalAlpha = 0.5 * Math.sin(f * Math.PI); x.beginPath(); x.arc(px, py, 0.8, 0, TAU); x.fill(); }
    }
    // 6. blaze
    if (this.blaze) {
      const Bz = this.blaze, c = this.project(Bz.x || 0, Bz.y || 0, 0), s = R * Bz.r * c[3], breath = 0.92 + 0.08 * Math.sin(t * 0.8);
      x.globalAlpha = 0.95; x.drawImage(sprite(T.gold, 128), c[0] - s * 1.6 * breath, c[1] - s * 1.6 * breath, s * 3.2 * breath, s * 3.2 * breath);
      x.drawImage(sprite(T.gold3, 64), c[0] - s * 0.6, c[1] - s * 0.6, s * 1.2, s * 1.2);
      x.drawImage(sprite(T.white, 64), c[0] - s * 0.3, c[1] - s * 0.3, s * 0.6, s * 0.6);
      x.strokeStyle = `rgb(${T.gold2})`; x.lineWidth = 0.5; const n = Bz.rays;
      for (let i = 0; i < n; i += 1) { const a = i * TAU / n + t * 0.02, len = s * (1.1 + 0.9 * Math.abs(Math.sin(t * 0.35 + i * 1.7))) * (i % 4 === 0 ? 1.9 : 1); x.globalAlpha = (i % 4 === 0 ? 0.55 : 0.25) * (0.6 + 0.4 * Math.sin(t * 0.9 + i)); x.beginPath(); x.moveTo(c[0] + Math.cos(a) * s * 0.2, c[1] + Math.sin(a) * s * 0.2); x.lineTo(c[0] + Math.cos(a) * len, c[1] + Math.sin(a) * len); x.stroke(); }
      this.cross(c[0], c[1], s * 3.6, 0.7, T.gold3, true);
      const g = x.createLinearGradient(c[0] - s * 6, c[1], c[0] + s * 6, c[1]); g.addColorStop(0, `rgba(${T.gold2},0)`); g.addColorStop(0.5, `rgba(${T.gold3},.55)`); g.addColorStop(1, `rgba(${T.gold2},0)`);
      x.strokeStyle = g; x.globalAlpha = 0.8; x.lineWidth = 1.2; x.beginPath(); x.moveTo(c[0] - s * 6, c[1]); x.lineTo(c[0] + s * 6, c[1]); x.stroke();
    }
    // 7–8. named stars (glow, orb, flare, medallion) and labels, back to front
    items.sort((p, q) => q.p[2] - p.p[2]);
    for (const it of items) {
      const depth = 0.55 + 0.45 * (1 - (it.p[2] + 1) / 2);
      if (it.k === 0) { x.globalAlpha = Math.min(1, it.a * depth); x.fillStyle = `rgb(${it.col})`; x.beginPath(); x.arc(it.p[0], it.p[1], Math.max(0.3, it.r), 0, TAU); x.fill(); continue; }
      if (it.k === 2) { const s = it.s; this.cross(it.p[0], it.p[1], s.size * it.p[3] * (0.6 + 0.6 * it.b), depth * (0.25 + 0.6 * it.b), s.col || T.gold3); x.fillStyle = `rgb(${T.white})`; x.beginPath(); x.arc(it.p[0], it.p[1], 0.9, 0, TAU); x.fill(); continue; }
      const s = it.s, hov = this.hover === s;
      const size = (s.size * (0.85 + 0.3 * it.b) + (hov ? 3 : 0)) * it.p[3];
      if (size > 0.05) {
        const glow = size * (s.orb ? 7 : 7.5);
        x.globalAlpha = (s.alpha ?? 0.95) * depth * (0.75 + 0.25 * it.b);
        x.drawImage(sprite(s.col), it.p[0] - glow / 2, it.p[1] - glow / 2, glow, glow);
        if (s.orb) {
          const d = size * 2.8; x.globalAlpha = depth; x.drawImage(orbSprite(s.col), it.p[0] - d / 2, it.p[1] - d / 2, d, d);
          if (s.ringed) { x.globalAlpha = depth * 0.85; x.strokeStyle = `rgb(${T.gold2})`; x.lineWidth = 0.8; x.beginPath(); x.ellipse(it.p[0], it.p[1], d * 1.0, d * 0.3, -0.4, 0, TAU); x.stroke(); x.lineWidth = 0.4; x.beginPath(); x.ellipse(it.p[0], it.p[1], d * 1.15, d * 0.35, -0.4, 0, TAU); x.stroke(); }
        }
        if (s.flare || hov) { const L = size * (s.flare === 2 ? 10 : 5.5); this.cross(it.p[0], it.p[1], L, (s.alpha ?? 1) * depth * 0.6 * (0.6 + 0.4 * it.b), s.col, s.flare === 2); }
        if (s.medallion) {
          x.globalAlpha = depth * (hov ? 0.95 : 0.6); x.strokeStyle = `rgb(${T.gold})`; x.lineWidth = 0.6; const mr = s.medallion * it.p[3];
          x.beginPath(); x.arc(it.p[0], it.p[1], mr, 0, TAU); x.stroke();
          x.setLineDash([1, 3]); x.globalAlpha *= 0.8; x.beginPath(); x.arc(it.p[0], it.p[1], mr * 1.14, 0, TAU); x.stroke(); x.setLineDash([]);
          x.globalAlpha *= 0.8; x.beginPath(); x.arc(it.p[0], it.p[1], mr * 1.3, 0, TAU); x.stroke();
          for (let i = 0; i < 8; i += 1) { const a = i * Math.PI / 4 + t * 0.05; x.beginPath(); x.moveTo(it.p[0] + Math.cos(a) * mr * 1.3, it.p[1] + Math.sin(a) * mr * 1.3); x.lineTo(it.p[0] + Math.cos(a) * mr * (i % 2 ? 1.42 : 1.55), it.p[1] + Math.sin(a) * mr * (i % 2 ? 1.42 : 1.55)); x.stroke(); }
        }
      }
      if (s.label || s.glyph) {
        const mr = (s.medallion ? s.medallion * it.p[3] : size * 1.1);
        const off = (s.medallion ? s.medallion * 1.7 : size * 1.9) * (s.medallion ? it.p[3] : 1) + (s.dy || 0);
        x.globalAlpha = depth * (hov ? 1 : 0.9); x.textAlign = "center"; x.textBaseline = "top";
        let y = it.p[1] + off;
        if (s.glyph) {
          x.fillStyle = `rgb(${hov ? T.gold3 : (s.glyphCol || T.gold2)})`;
          x.font = `${s.glyphFont || ""}${Math.round((s.glyphSize || 15) * it.p[3] + (hov ? 3 : 0))}px ${s.glyphFont ? T.numeral : T.serif}`;
          // Inside the medallion the numeral sits in its upper half, clear of the orb and its glow.
          if (s.glyphInside) { x.textBaseline = "middle"; x.fillText(s.glyph, it.p[0], it.p[1] - mr * 0.62); x.textBaseline = "top"; }
          else { x.fillText(s.glyph, it.p[0], y); y += (s.glyphSize || 15) * it.p[3] * 1.15; }
        }
        if (s.label) {
          // Side-aligned labels hug the star horizontally (crowded rims); centred ones sit beneath.
          const side = s.labelAlign === "left" ? 1 : s.labelAlign === "right" ? -1 : 0;
          const lx = it.p[0] + side * mr * 1.25, ly = side ? it.p[1] - 6 : y;
          x.textAlign = side ? s.labelAlign : "center";
          x.fillStyle = `rgb(${hov ? T.gold3 : (s.labelCol || T.ink)})`; x.font = `${Math.round(11.5 * Math.min(1.05, it.p[3]))}px ${T.serif}`;
          if ("letterSpacing" in x) x.letterSpacing = "0.16em";
          x.fillText(s.label.toUpperCase(), lx, ly);
          if ("letterSpacing" in x) x.letterSpacing = "0px";
          x.textAlign = "center";
        }
      }
    }
    x.globalAlpha = 1;
  }
}

// Mounts a plate into `host` (position: relative; the canvas fills it). The loop waits for the
// host to be attached (the JOH panel is built before it is appended) and stops for good once the
// host leaves the page; destroy() cancels the frame request at once (route change).
export function mountPlate(host, scene, options = {}) {
  const canvas = document.createElement("canvas");
  if (options.ariaLabel) { canvas.setAttribute("role", "img"); canvas.setAttribute("aria-label", options.ariaLabel); }
  else canvas.setAttribute("aria-hidden", "true");
  host.append(canvas);
  const reduced = options.reduced ?? window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const field = new Field(canvas, host, { reduced });
  field.load(scene);
  return { canvas, field, load: (next) => field.load(next), destroy: () => field.destroy() };
}
