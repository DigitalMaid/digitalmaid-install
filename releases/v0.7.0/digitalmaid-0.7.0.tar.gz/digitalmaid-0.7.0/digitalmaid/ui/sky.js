// Observatory sky (docs/DESIGN.md, "Observatory" 2026-09-09; Appendix G 0.6.0): a fixed,
// full-viewport canvas behind everything holding a very faint starfield over a nebula wash.
// Decoration only — the canvas is aria-hidden, ignores pointer events and carries no
// information. The wash (violet/magenta radial gradients) and a few faint gold constellation
// lines are painted once per resize into an offscreen layer and blitted every frame; the stars
// and the cross-shaped sparkles twinkle on their own slow sines. With prefers-reduced-motion
// everything is drawn once and holds still, and the loop pauses while the tab is hidden.

const DENSITY = 6500;         // one star per this many CSS px²
const SPARK_DENSITY = 60000;  // one cross sparkle per this many CSS px²
const INK = "235,230,218";    // most stars are the page ink…
const GOLD = "212,175,90";    // …a few are gold or sky-blue
const GOLD_2 = "240,215,138";
const GOLD_3 = "255,236,190";
const WHITE = "255,250,240";
const SKY = "143,184,230";
const VIOLET = "110,70,190";
const MAGENTA = "170,80,160";
// The wash: centre (fractions of the viewport), radius (fraction of the longer side), colour, alpha.
const NEBULAE = [[0.22, 0.3, 0.5, VIOLET, 0.22], [0.8, 0.7, 0.45, MAGENTA, 0.12], [0.55, 0.15, 0.35, SKY, 0.08], [0.5, 0.55, 0.3, GOLD, 0.09]];

function makeStars(width, height) {
  const count = Math.round((width * height) / DENSITY);
  return Array.from({ length: count }, () => {
    const pick = Math.random();
    return {
      x: Math.random() * width, y: Math.random() * height,
      r: 0.3 + Math.random() * 0.9, a: 0.08 + Math.random() * 0.3,
      phase: Math.random() * Math.PI * 2, tempo: 0.2 + Math.random() * 0.6,
      colour: pick < 0.85 ? INK : pick < 0.925 ? GOLD : SKY,
    };
  });
}

function makeSparks(width, height) {
  const count = Math.round((width * height) / SPARK_DENSITY);
  return Array.from({ length: count }, () => ({
    x: Math.random() * width, y: Math.random() * height, r: 4 + Math.random() * 9,
    phase: Math.random() * Math.PI * 2, tempo: 0.15 + Math.random() * 0.3,
  }));
}

export function startSky(canvas = document.getElementById("sky")) {
  const ctx = canvas?.getContext?.("2d");
  if (!ctx) return null;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let stars = [], sparks = [], width = 0, height = 0, dpr = 1, back = null;
  // The static layer: nebula wash + faint constellations, painted once per resize.
  const paintStatic = () => {
    back = document.createElement("canvas");
    back.width = canvas.width; back.height = canvas.height;
    const b = back.getContext("2d");
    b.setTransform(dpr, 0, 0, dpr, 0, 0);
    for (const [cx, cy, r, colour, alpha] of NEBULAE) {
      const g = b.createRadialGradient(width * cx, height * cy, 0, width * cx, height * cy, Math.max(width, height) * r);
      g.addColorStop(0, `rgba(${colour},${alpha})`); g.addColorStop(1, `rgba(${colour},0)`);
      b.fillStyle = g; b.fillRect(0, 0, width, height);
    }
    // constellation lines: a few short gold polylines with a bead at every vertex
    b.strokeStyle = `rgb(${GOLD_2})`; b.fillStyle = `rgb(${GOLD_2})`; b.lineWidth = 0.5; b.globalAlpha = 0.28;
    for (let k = 0; k < Math.round(width / 260); k += 1) {
      const n = 4 + Math.floor(Math.random() * 4), pts = [[Math.random() * width, Math.random() * height]];
      for (let i = 1; i < n; i += 1) pts.push([pts[i - 1][0] + (Math.random() - 0.5) * 120, pts[i - 1][1] + (Math.random() - 0.5) * 120]);
      b.beginPath(); pts.forEach((p, i) => (i ? b.lineTo(p[0], p[1]) : b.moveTo(p[0], p[1]))); b.stroke();
      for (const p of pts) { b.beginPath(); b.arc(p[0], p[1], 1.3, 0, Math.PI * 2); b.fill(); }
    }
    b.globalAlpha = 1;
  };
  const fit = () => {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    width = window.innerWidth; height = window.innerHeight;
    canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
    stars = makeStars(width, height);
    sparks = makeSparks(width, height);
    paintStatic();
  };
  const draw = (t) => {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (back) ctx.drawImage(back, 0, 0);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    for (const s of stars) {
      const twinkle = reduced ? 1 : 0.6 + 0.4 * Math.sin(s.phase + t * 0.001 * s.tempo);
      ctx.globalAlpha = s.a * twinkle;
      ctx.fillStyle = `rgb(${s.colour})`;
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = `rgb(${GOLD_3})`; ctx.lineWidth = 0.6;
    for (const s of sparks) {
      const b = reduced ? 0.5 : 0.5 + 0.5 * Math.sin(s.phase + t * 0.001 * s.tempo);
      const L = s.r * (0.6 + 0.6 * b);
      ctx.globalAlpha = 0.25 + 0.5 * b;
      ctx.beginPath(); ctx.moveTo(s.x - L, s.y); ctx.lineTo(s.x + L, s.y); ctx.moveTo(s.x, s.y - L); ctx.lineTo(s.x, s.y + L); ctx.stroke();
      ctx.fillStyle = `rgb(${WHITE})`;
      ctx.beginPath(); ctx.arc(s.x, s.y, 1, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  };
  const tick = (now) => {
    if (!document.hidden) draw(now);
    if (!reduced) requestAnimationFrame(tick);
  };
  window.addEventListener("resize", () => { fit(); if (reduced) draw(0); });
  fit();
  requestAnimationFrame(tick);
  return canvas;
}
