// DOM builders and render functions. All record text goes through textContent,
// never innerHTML, so output content and titles cannot inject markup.

import { t, formatDateTime } from "./i18n.js";

// The signed-in session; a viewer role turns every form read-only (see form()).
let currentSession = null;
export function setSession(session) { currentSession = session; }
export function isReadOnly() { return currentSession?.role === "viewer"; }
export function currentUser() { return currentSession?.user?.username || null; }
export function readOnlyReason() { return t("views.readOnlyReason"); }

// Disables write controls for viewers, stating why (title + note), never hiding them.
export function applyReadOnly(container) {
  if (!isReadOnly() || !container) return;
  for (const button of container.querySelectorAll("button[type=submit], [data-write]")) {
    button.disabled = true;
    button.title = readOnlyReason();
    button.setAttribute("aria-disabled", "true");
  }
  for (const f of container.querySelectorAll("form.form:not([data-readonly-noted])")) {
    f.dataset.readonlyNoted = "true";
    f.append(el("p", { class: "readonly-note meta" }, readOnlyReason()));
  }
}

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (key === "class") node.className = value;
    else if (key === "dataset") Object.assign(node.dataset, value);
    else if (key.startsWith("on") && typeof value === "function") node.addEventListener(key.slice(2), value);
    else if (key === "text") node.textContent = value;
    else node.setAttribute(key, value === true ? "" : value);
  }
  append(node, children);
  return node;
}

export function append(node, children) {
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

export function pill(status, label) {
  return el("span", { class: "pill", dataset: { status } }, label ?? t(`status.${status}`, undefined, status));
}

// One phase vocabulary everywhere (DESIGN.md D2): the five words, their plain meanings
// and the hero's colour tokens (mapped in app.css by data-status). Every phase pill
// carries the meaning as title + aria-description; non-phase statuses keep pill().
export const PHASES = ["Plan", "Do", "Check", "Correction", "Done"];
// PHASE_MEANINGS[phase] resolves through the catalogue at read time so it follows the language.
export const PHASE_MEANINGS = {};
for (const phase of PHASES) Object.defineProperty(PHASE_MEANINGS, phase, { get: () => t(`views.phaseMeaning.${phase}`), enumerable: true });

export function phaseMeaning(phase) {
  return PHASE_MEANINGS[phase];
}

export function phasePill(phase, label) {
  if (!PHASE_MEANINGS[phase]) return pill(phase, label);
  const meaning = phaseMeaning(phase);
  return el("span", { class: "pill", dataset: { status: phase, phase }, title: meaning, "aria-description": meaning }, label ?? t(`phase.${phase}`));
}

// Plain-language page lead (D1): one sentence, then the original explanation folded into a
// closed "How this works" whose open state is remembered per page.
// LEADS[route] resolves through the catalogue at read time; joh.js adds its own getter.
export const LEADS = {};
for (const route of ["goals", "knowledge", "procedures", "review", "outputs", "automations", "agents", "calendar", "capture", "settings"]) {
  Object.defineProperty(LEADS, route, { get: () => t(`views.lead.${route}`), enumerable: true });
}

export function lead(route) {
  return LEADS[route] ?? t(`views.lead.${route}`);
}

export function howDetails(route, ...children) {
  const key = `dm:how:${route}`;
  const details = el("details", { class: "how", open: localStorage.getItem(key) === "1" || null },
    el("summary", {}, icon("info"), el("span", {}, t("views.howThisWorks"))),
    el("div", { class: "how-body" }, children));
  const remember = (open) => {
    try { localStorage.setItem(key, open ? "1" : "0"); } catch { /* remembering is a convenience */ }
  };
  // `toggle` is dispatched asynchronously; write on the click too so a navigation right after
  // the click (or a reload) never loses the choice.
  details.querySelector("summary").addEventListener("click", () => remember(!details.open));
  details.addEventListener("toggle", () => remember(details.open));
  return details;
}

// Page header: title, the D1 lead, the folded explanation, optional meta after the lead,
// and the page's tools on the right.
export function pageHeader(route, title, how, { meta = null, tools = null } = {}) {
  return el("header", { class: "main-header" },
    el("div", {}, el("h1", {}, title), el("p", {}, lead(route)), meta, howDetails(route, how)),
    tools);
}

// Hashes, fencing tokens, schedule versions, misfire policies (D6): present on the record,
// never on the first line.
export function techDetails(...children) {
  return el("details", { class: "tech" }, el("summary", {}, t("views.technicalDetails")), el("div", { class: "tech-body mono" }, children));
}

// Thin-stroke 16px icon from the symbol sheet in index.html.
export function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "icon");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#i-${name}`);
  svg.append(use);
  return svg;
}

// Small uppercase tracked caption (the signature label style).
export function label(text, attrs = {}) {
  return el("span", { ...attrs, class: `label${attrs.class ? ` ${attrs.class}` : ""}` }, text);
}

// Big number + caption: the numeral face, accent when the number asks for action.
export function bigNumber(value, caption, { action = false } = {}) {
  return el("div", { class: "big-number" },
    el("div", { class: `num${action ? " is-action" : ""}`, "aria-hidden": "true" }, String(value)),
    el("span", { class: "visually-hidden" }, t("views.bigNumberHidden", { value, caption })),
    el("span", { class: "caption", "aria-hidden": "true" }, caption));
}

// Dot row: one dot per day, filled when done, today ringed in accent.
export function dotRow(days) {
  return el("ul", { class: "dot-row", "aria-label": t("views.lastNDays", { count: days.length }) }, days.map((d) => {
    const state = d.on ? t("views.written") : t("views.notWritten");
    const title = t("views.dotStatus", { day: d.key, state });
    return el("li", {
      class: `dot${d.today ? " is-today" : ""}`, dataset: { on: String(Boolean(d.on)), day: d.key },
      title,
    }, el("span", { class: "visually-hidden" }, title));
  }));
}

const PDCC = ["Plan", "Do", "Check", "Correction"];

// Plan → Do → Check → Correction as a chain of nodes; the current one ringed.
// Done means every node has been passed; Correction loops back to Do, so both stay lit.
export function pdccChain(status) {
  const index = PDCC.indexOf(status);
  return el("ol", { class: "pdcc-chain", "aria-label": t("views.pdccStatus", { status: t(`phase.${status}`) }) }, PDCC.map((step, i) => {
    const done = status === "Done" || i < index || (status === "Correction" && step !== "Correction");
    return el("li", { class: "pdcc-node", dataset: { done: String(done) }, "aria-current": step === status ? "step" : null },
      el("span", { class: "node", "aria-hidden": "true" }), el("span", {}, t(`phase.${step}`)));
  }));
}

// In-page confirmation (replaces window.confirm). Resolves true only on an explicit
// confirm; Esc, Cancel and the backdrop resolve false. Focus is trapped by the native
// modal dialog and returns to the opener when it closes.
export function confirmDialog({ title = t("common.confirm"), message = "", confirmLabel = t("common.confirm"), cancelLabel = t("common.cancel") } = {}) {
  const dialog = document.getElementById("confirm-dialog");
  const opener = document.activeElement;
  dialog.querySelector("#confirm-title").textContent = title;
  dialog.querySelector("#confirm-message").textContent = message;
  const ok = dialog.querySelector("#confirm-ok");
  const cancel = dialog.querySelector("#confirm-cancel");
  ok.textContent = confirmLabel;
  cancel.textContent = cancelLabel;
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      ok.removeEventListener("click", onOk);
      cancel.removeEventListener("click", onCancel);
      dialog.removeEventListener("cancel", onNativeCancel);
      dialog.removeEventListener("keydown", onKey);
      dialog.removeEventListener("click", onBackdrop);
      if (dialog.open) dialog.close();
      opener?.focus?.();
      resolve(value);
    };
    const onOk = () => finish(true);
    const onCancel = () => finish(false);
    const onNativeCancel = (e) => { e.preventDefault(); finish(false); };
    const onKey = (e) => {
      if (e.key === "Enter" && e.target !== cancel) { e.preventDefault(); finish(true); }
    };
    const onBackdrop = (e) => { if (e.target === dialog) finish(false); };
    ok.addEventListener("click", onOk);
    cancel.addEventListener("click", onCancel);
    dialog.addEventListener("cancel", onNativeCancel);
    dialog.addEventListener("keydown", onKey);
    dialog.addEventListener("click", onBackdrop);
    dialog.showModal();
    ok.focus();
  });
}

export function when(iso) {
  return formatDateTime(iso);
}

export function empty(text) {
  return el("p", { class: "empty" }, text);
}

// Ghost pill (DESIGN.md B2): hairline border, 10px uppercase tracked. A link when
// given an href, otherwise a button.
export function pillButton(text, { href = null, onclick = null, class: extra = "", ...attrs } = {}) {
  const cls = `pill-btn${extra ? ` ${extra}` : ""}`;
  if (href) return el("a", { ...attrs, class: cls, href, onclick }, text);
  return el("button", { ...attrs, class: cls, type: "button", onclick }, text);
}

// Empty state that teaches (C6): a thin icon, one sentence on what lives here, and the
// area's own create action as a ghost pill. Never an illustration.
export function emptyState(iconName, sentence, actionLabel = null, action = null, attrs = {}) {
  // A link never writes; a button runs the area's create action, so viewers see it disabled.
  const target = typeof action === "string" ? { href: action } : action ? { onclick: action, dataset: { write: "true", ...(attrs.dataset || {}) } } : null;
  return el("div", { class: "empty-state" }, icon(iconName), el("p", {}, sentence),
    actionLabel && target ? pillButton(actionLabel, target) : null);
}

export function reasonsList(reasons) {
  if (!reasons?.length) return null;
  return el("ul", { class: "reasons" }, reasons.map((r) => el("li", {}, r)));
}

// Today's quiet gate line (Observatory): the 5M reasons collapse into "k of 5 readiness checks
// not assessed · money needs a waiver · waiting on: …"; the full list stays in the task drawer.
// The complete reasons ride along as the title.
export function gateSummary(reasons) {
  if (!reasons?.length) return null;
  const assess = /^(\w+) not assessed$/, waiver = /^(\w+) missing without waiver$/;
  const notAssessed = reasons.filter((r) => assess.test(r)).length;
  const waivers = reasons.filter((r) => waiver.test(r)).map((r) => r.match(waiver)[1].toLowerCase());
  const other = reasons.filter((r) => !assess.test(r) && !waiver.test(r));
  const parts = [];
  if (notAssessed) parts.push([el("em", {}, t("views.ofFive", { count: notAssessed })), t("views.readinessCheckSuffix", { count: notAssessed })]);
  for (const w of waivers) parts.push(t("views.needsWaiver", { name: w }));
  parts.push(...other);
  const line = el("span", {});
  parts.forEach((part, i) => { if (i) line.append(" · "); append(line, [part]); });
  return el("div", { class: "gate-line", title: reasons.join("\n") }, line);
}

// The Correction counterpart: one rose-dot line naming the failed criteria.
export function failedLine(criteria) {
  if (!criteria?.length) return null;
  return el("div", { class: "gate-line is-error", title: criteria.join("\n") },
    el("span", {}, el("em", {}, t("views.failedCount", { count: criteria.length })), ": ", criteria.join(" · ")));
}

export function alertBox(kind, message, reasons) {
  const box = el("div", { class: `alert is-${kind}`, role: kind === "error" ? "alert" : "status" });
  if (message) box.append(el("div", {}, message));
  if (reasons?.length) box.append(el("ul", {}, reasons.map((r) => el("li", {}, r))));
  return box;
}

// CSSOM assignment rather than a style attribute: the CSP forbids inline styles.
function bar(pct) {
  const span = el("span");
  span.style.width = `${pct}%`;
  return span;
}

export function progress(done, total) {
  const pct = total ? Math.round((done / total) * 100) : 0;
  return el("div", { class: "progress", role: "group", "aria-label": t("views.deliveryProgress", { done, total }) },
    el("div", { class: "progress-bar", "aria-hidden": "true" }, bar(pct)),
    el("span", { class: "progress-label" }, `${done}/${total}`));
}

// --- Today -------------------------------------------------------------------

export const WIDGET_TITLES = {
  needs_attention: "Needs attention",
  in_progress: "In progress",
  achieved: "Achieved",
  review_inbox: "Review inbox",
  journal: "Journal",
  capture_inbox: "Inbox",
};

// Translated widget title (no count); other modules should call this instead of
// indexing WIDGET_TITLES directly.
export function widgetTitleText(id) {
  return t(`views.widgetTitle.${id}`, undefined, WIDGET_TITLES[id] || id);
}

function widgetTitle(id, today) {
  if (id === "review_inbox") return t("views.widgetTitleReviewInboxCount", { count: today.review_inbox_count ?? 0 });
  if (id === "capture_inbox") return t("views.widgetTitleCaptureInboxCount", { count: today.capture_inbox_count ?? 0 });
  return widgetTitleText(id);
}

const LIVE_STATES = new Set(["running", "queued"]);

function taskItem(task, onOpen, extra, { live = false } = {}) {
  return el("li", { class: `list-item is-clickable${live ? " is-live" : ""}`, tabindex: "0", role: "button", dataset: { status: task.status, live: String(live) },
    onclick: () => onOpen(task.id),
    onkeydown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onOpen(task.id); } } },
    el("div", { class: "list-item-title" }, el("strong", {}, task.title), task.hermes_tags?.length ? pill("hermes") : null, phasePill(task.status)),
    el("div", { class: "meta" }, task.project_title ? `${task.project_title} · ` : "", task.owner),
    extra);
}

// First-run checklist (D4): three steps, hollow → filled as the objects appear. Shown only on
// a scope that had neither goals nor captures when this browser first opened Today; a
// Dismiss hides it for good (localStorage, keyed by workspace id).
const START_STEPS = [
  { id: "goal", textKey: "views.startStepGoalText", actionKey: "views.newGoalAction" },
  { id: "capture", textKey: "views.startStepCaptureText", actionKey: "views.startStepCaptureAction" },
  { id: "task", textKey: "views.startStepTaskText", actionKey: "views.openCaptureInbox" },
];

export function startHereKey(workspaceId) { return `dm:starthere:${workspaceId || "default"}`; }

export function renderStartHere({ goals, captures }, { onNewGoal, onCapture, onOpenInbox, onDismiss }) {
  const firstCapture = captures.find((c) => c.status === "inbox" || c.status === "drafting") || captures[0] || null;
  const done = {
    goal: goals.length > 0,
    capture: captures.length > 0,
    task: captures.some((c) => c.status === "converted" && c.converted_type === "task"),
  };
  const actions = {
    goal: () => onNewGoal(),
    capture: () => onCapture(),
    task: () => onOpenInbox(firstCapture ? firstCapture.id : null),
  };
  return el("section", { id: "start-here", class: "widget start-here", "aria-labelledby": "start-here-title" },
    el("div", { class: "widget-header" },
      el("div", { class: "widget-title" }, icon("today"), el("h2", { id: "start-here-title" }, t("views.startHere"))),
      el("span", { class: "widget-meta" }, t("views.nOfThree", { count: Object.values(done).filter(Boolean).length })),
      pillButton(t("views.dismiss"), { class: "start-dismiss", dataset: { dismiss: "true" }, onclick: onDismiss, "aria-label": t("views.dismissStartHereChecklist") })),
    el("ol", { class: "start-steps" }, START_STEPS.map((step, index) => el("li", { class: "start-step", dataset: { step: step.id, done: String(done[step.id]) } },
      el("span", { class: "start-node", "aria-hidden": "true" }, String(index + 1)),
      el("span", { class: "start-text" }, t(step.textKey), el("span", { class: "visually-hidden" }, done[step.id] ? t("views.doneSuffix") : t("views.notYetSuffix"))),
      done[step.id] ? null : pillButton(t(step.actionKey), { onclick: actions[step.id], ...(step.id === "task" ? {} : { dataset: { write: "true" } }) })))));
}

const WIDGET_ICONS = {
  needs_attention: "review", in_progress: "automations", achieved: "goals",
  review_inbox: "review", journal: "knowledge", capture_inbox: "capture",
};

function localKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

// The last `count` local days ending today, marked from a set of journal entry dates.
export function journalDays(writtenDates, count = 14, now = new Date()) {
  const written = new Set(writtenDates || []);
  const todayKey = localKey(now);
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (count - 1 - i));
    const key = localKey(d);
    return { key, on: written.has(key), today: key === todayKey };
  });
}

export function renderToday(today, prefs, { onOpenTask, onMoveWidget, onToggleWidget, onOpenJournal, onNewTask = null, journalDates = null }) {
  const attention = today.needs_attention;
  const decisions = attention.decision_reviews_due || [];
  const newTask = onNewTask || "#/goals";
  const bodies = {
    needs_attention: () => {
      const total = attention.in_correction.length + attention.awaiting_acceptance.length
        + attention.blocked_in_plan.filter((task) => task.reasons.length).length + decisions.length;
      if (!total) return emptyState("review", t("views.needsAttentionEmpty"), t("views.newTaskAction"), newTask);
      return el("div", { class: "stack" },
        section(t("views.sectionInCorrection"), attention.in_correction, (task) => taskItem(task, onOpenTask, failedLine(task.failed_criteria))),
        section(t("views.sectionAwaitingAcceptance"), attention.awaiting_acceptance, (task) => taskItem(task, onOpenTask,
          task.latest_version ? el("div", { class: "meta" }, t("views.versionPassedCheck", { version: task.latest_version.version })) : null)),
        section(t("views.sectionBlockedInPlan"), attention.blocked_in_plan.filter((task) => task.reasons.length), (task) => taskItem(task, onOpenTask, gateSummary(task.reasons))),
        section(t("views.sectionDecisionReviewsDue"), decisions, (n) => el("li", { class: "list-item", dataset: { status: "required" } },
          el("div", { class: "list-item-title" }, el("a", { href: `#/knowledge/${n.id}` }, n.title), pill("required", n.reason)),
          el("div", { class: "meta" }, t("views.chosenReviewDate", { chosen: n.decision.chosen, date: n.decision.review_date })))));
    },
    review_inbox: () => {
      const count = today.review_inbox_count ?? 0;
      const number = bigNumber(count, t("views.itemsWaitingForHuman", { count }), { action: count > 0 });
      number.append(
        el("p", { class: "meta" }, count ? t("views.reviewInboxMetaSome") : t("views.reviewInboxMetaNone")),
        pillButton(t("views.openReviewInbox"), { href: "#/review" }));
      return number;
    },
    capture_inbox: () => {
      const count = today.capture_inbox_count ?? 0;
      const number = bigNumber(count, count === 1 ? t("views.capturesToDraftOne") : t("views.capturesToDraftOther"), { action: count > 0 });
      number.append(
        el("p", { class: "meta" }, count ? t("views.captureInboxMetaSome") : t("views.captureInboxMetaNone")),
        pillButton(t("views.openCaptureInbox"), { href: "#/capture" }));
      return number;
    },
    journal: () => {
      const j = today.journal_today || {};
      const days = journalDays(journalDates || (j.written && j.entry_date ? [j.entry_date] : []));
      const writtenCount = days.filter((d) => d.on).length;
      return el("div", { class: "stack" },
        dotRow(days),
        el("div", { class: "meta" }, t("views.daysWrittenPrefix", { written: writtenCount, total: days.length }),
          j.written ? t("views.todaysEntryWritten", { date: j.entry_date }) : t("views.noEntryYet", { date: j.entry_date })),
        pillButton(j.written ? t("views.openTodaysEntry") : t("views.writeTodaysEntry"), { onclick: () => onOpenJournal(j), dataset: { write: "true" } }));
    },
    in_progress: () => {
      if (!today.in_progress.length) return emptyState("do", t("views.inProgressEmpty"), t("views.newTaskAction"), newTask);
      return el("ul", { class: "list" }, today.in_progress.map((task) => taskItem(task, onOpenTask,
        task.latest_execution
          ? el("div", { class: "meta" }, t("views.latestExecutionPrefix"), pill(task.latest_execution.status), t("views.byAgentRunner", { agent: task.latest_execution.agent_id, runner: runnerLabel(task.latest_execution) }))
          : el("div", { class: "meta" }, t("views.noExecutionRecorded")),
        { live: LIVE_STATES.has(task.latest_execution?.status) })));
    },
    achieved: () => {
      const { done_tasks, decided_goals } = today.achieved;
      if (!done_tasks.length && !decided_goals.length) return emptyState("goals", t("views.achievedEmpty"), t("views.newGoalAction"), "#/goals");
      return el("div", { class: "stack" },
        section(t("views.sectionRecentlyAccepted"), done_tasks, (task) => taskItem(task, onOpenTask, el("div", { class: "meta" }, t("views.acceptedAt", { when: when(task.updated_at) })))),
        section(t("views.sectionDecidedGoals"), decided_goals, (g) => el("li", { class: "list-item", dataset: { status: g.outcome_status } },
          el("div", { class: "list-item-title" }, el("strong", {}, g.title), pill(g.outcome_status)),
          g.outcome ? el("div", { class: "meta" }, t("views.decidedByEvidence", { by: g.outcome.decided_by, evidence: g.outcome.evidence })) : null)));
    },
  };

  const metas = {
    needs_attention: () => {
      const n = attention.in_correction.length + attention.awaiting_acceptance.length
        + attention.blocked_in_plan.filter((task) => task.reasons.length).length + decisions.length;
      return n ? t("views.itemCount", { count: n }) : t("views.clear");
    },
    in_progress: () => t("views.inPhaseCount", { count: today.in_progress.length, phase: t("phase.Do") }),
    achieved: () => t("views.acceptedDecidedCount", { accepted: today.achieved.done_tasks.length, decided: today.achieved.decided_goals.length }),
    review_inbox: () => t("views.humanGate"),
    journal: () => t("views.journalMeta", { state: today.journal_today?.written ? t("views.written") : t("views.notYetWord") }),
    capture_inbox: () => t("views.rawMaterial"),
  };

  // Board, not document (B1/B2): widgets sit on the page with no box; the row hairlines
  // come from the grid, the title is the 18px uppercase display signature.
  const widgets = prefs.widgets;
  return el("div", { class: "grid board", id: "widgets" }, widgets.map((w, index) => {
    const body = bodies[w.id];
    return el("section", { class: "widget", dataset: { widget: w.id, hidden: String(!w.visible) }, "aria-labelledby": `widget-${w.id}` },
      el("div", { class: "widget-header" },
        el("div", { class: "widget-title" }, icon(WIDGET_ICONS[w.id] || "today"), el("h2", { id: `widget-${w.id}` }, widgetTitle(w.id, today))),
        el("span", { class: "widget-meta" }, metas[w.id] ? metas[w.id]() : ""),
        el("div", { class: "panel-tools", role: "group", "aria-label": t("views.arrangeWidget", { title: widgetTitleText(w.id) }) },
          el("button", { class: "btn is-quiet btn-icon", type: "button", "aria-label": t("views.moveWidgetEarlier"), disabled: index === 0, onclick: () => onMoveWidget(w.id, -1) }, "↑"),
          el("button", { class: "btn is-quiet btn-icon", type: "button", "aria-label": t("views.moveWidgetLater"), disabled: index === widgets.length - 1, onclick: () => onMoveWidget(w.id, 1) }, "↓"),
          el("button", { class: "btn is-quiet btn-icon", type: "button", "aria-label": t("views.hideWidget"), onclick: () => onToggleWidget(w.id, false) }, "×"))),
      body ? body() : empty(t("views.unknownWidget")));
  }));
}

// Only visible while the board is being edited (header pencil); see app.css.
export function renderHiddenWidgets(prefs, onToggleWidget) {
  const hidden = prefs.widgets.filter((w) => !w.visible);
  if (!hidden.length) return null;
  return el("div", { class: "hidden-widgets", id: "hidden-widgets" }, label(t("views.hiddenWidgets")),
    hidden.map((w) => el("button", { class: "btn is-small", type: "button", onclick: () => onToggleWidget(w.id, true) }, t("views.showWidget", { title: widgetTitleText(w.id) }))));
}

function section(title, items, render) {
  if (!items.length) return null;
  return el("div", {}, el("h4", {}, title), el("ul", { class: "list" }, items.map(render)));
}

// --- Goals and projects -------------------------------------------------------

// Goal tasks as a dot row (Observatory): one hollow dot per task, filled when Done, gold
// when someone is working on it (Do).
function goalDots(tasks) {
  if (!tasks.length) return null;
  return el("ul", { class: "dot-row", "aria-label": t("views.tasksCountAria", { count: tasks.length }) }, tasks.map((task) => {
    const title = t("views.taskStatusTitle", { title: task.title, status: t(`phase.${task.status}`) });
    return el("li", {
      class: `dot${task.status === "Do" ? " is-now" : ""}`, dataset: { on: String(task.status === "Done"), status: task.status },
      title,
    }, el("span", { class: "visually-hidden" }, title));
  }));
}

export function renderGoals(goals, projectsByGoal, tasksByProject, handlers) {
  if (!goals.length) return emptyState("goals", t("views.goalsEmpty"), t("views.newGoalAction"), handlers.onNewGoal);
  return el("div", {}, goals.map((goal) => {
    const projects = projectsByGoal[goal.id] || [];
    const goalTasks = projects.flatMap((p) => tasksByProject[p.id] || []);
    const moving = goalTasks.filter((task) => task.status === "Do" || task.status === "Check" || task.status === "Correction").length;
    const done = goalTasks.filter((task) => task.status === "Done").length;
    const goalStatusLabel = t("views.goalStatusLabel", { status: t(`status.${goal.outcome_status}`, undefined, goal.outcome_status.replace("_", " ")) });
    const isOpen = goal.outcome_status === "open";
    const progressText = isOpen ? t("views.tasksMoving", { moving, total: goalTasks.length }) : t("views.tasksDone", { done, total: goalTasks.length });
    const outcome = isOpen ? t("views.doneCountShort", { done }) : t("views.decidedEvidence", { evidence: goal.outcome?.evidence || goal.outcome_status.replace("_", " ") });
    const summary = goalTasks.length ? `${progressText} · ${outcome}` : t("views.noTasksYet");
    // Summary column: status tag, serif title, owner and measure, the task dots, the actions.
    return el("section", { class: "goal", "aria-labelledby": `goal-${goal.id}` },
      el("div", { class: "goal-header" },
        pill(goal.outcome_status, goalStatusLabel),
        el("h2", { id: `goal-${goal.id}` }, goal.title),
        el("div", { class: "goal-meta" }, t("views.ownerPrefix"), el("b", {}, goal.owner), el("br"), t("views.measurePrefix"), el("b", {}, goal.success_measure)),
        goalDots(goalTasks),
        el("div", { class: "goal-meta" }, summary),
        el("div", { class: "form-actions" },
          pillButton(t("views.newProjectAction"), { dataset: { write: "true" }, onclick: () => handlers.onNewProject(goal) }),
          goal.outcome_status === "open"
            ? pillButton(t("views.recordOutcomeAction"), { dataset: { write: "true" }, onclick: () => handlers.onDecideGoal(goal) })
            : null)),
      projects.length
        ? el("div", { class: "projects" }, projects.map((project) => {
          const tasks = tasksByProject[project.id] || [];
          return el("article", { class: "panel project", "aria-labelledby": `project-${project.id}` },
            el("div", { class: "project-head" },
              el("h3", { id: `project-${project.id}` }, project.title),
              progress(project.progress.done, project.progress.total)),
            el("div", { class: "meta" }, t("views.ownerCriteria", { owner: project.owner, criteria: project.success_criteria })),
            tasks.length
              ? el("div", { class: "stack" }, tasks.map((task) => el("button", { class: "task-row", type: "button", dataset: { status: task.status }, onclick: () => handlers.onOpenTask(task.id) },
                el("span", {}, task.title, el("small", {}, t("views.nextAction", { action: task.next_action }))), phasePill(task.status))))
              : emptyState("plan", t("views.projectTasksEmpty"), t("views.newTaskAction"), () => handlers.onNewTask(project), { dataset: { newTask: project.id } }),
            tasks.length ? el("div", {}, pillButton(t("views.newTaskAction"), { dataset: { write: "true", newTask: project.id }, onclick: () => handlers.onNewTask(project) })) : null);
        }))
        : emptyState("goals", t("views.goalNoProjectsEmpty"), t("views.newProjectAction"), () => handlers.onNewProject(goal)));
  }));
}

// --- Automations and agents -----------------------------------------------------

// Executions by the fixture are labelled as such; nothing here may read as a live AI agent.
// For live executions the label is the provider/model the response reported — never the
// policy's requested model, and never what the model said about itself.
export function runnerLabel(policyOrExecution) {
  const kind = policyOrExecution?.kind || policyOrExecution?.provider || policyOrExecution?.model;
  if (kind === "fixture") return t("views.fixtureRunner");
  if (policyOrExecution?.kind === "live") return t("views.liveModelPolicy", { provider: policyOrExecution.provider, model: policyOrExecution.model });
  if (policyOrExecution?.provider) {
    const response = `${policyOrExecution.provider} / ${policyOrExecution.model}`;
    // OpenRouter answers with the upstream provider name ("Anthropic"); keep the
    // requested policy provider visible so the two are never confused.
    return policyOrExecution.policy_provider ? t("views.policyResponse", { policy: policyOrExecution.policy_provider, response }) : response;
  }
  if ((policyOrExecution?.log || "").startsWith("live runner")) return t("views.liveRunNoResponse");
  return t("views.manualRecord");
}

// Tokens and cost as the provider reported them; absent fields stay absent.
export function executionEvidence(execution) {
  const parts = [];
  if (execution?.usage_json) {
    try {
      const usage = JSON.parse(execution.usage_json);
      if (Number.isInteger(usage.total_tokens)) {
        const detail = Number.isInteger(usage.prompt_tokens) && Number.isInteger(usage.completion_tokens)
          ? t("views.promptCompletionDetail", { prompt: usage.prompt_tokens, completion: usage.completion_tokens }) : "";
        parts.push(t("views.tokensCount", { total: usage.total_tokens, detail }));
      }
    } catch { /* unreadable usage is simply not shown */ }
  }
  if (Number.isInteger(execution?.cost_minor)) parts.push(t("views.costMinorUnits", { amount: execution.cost_minor, currency: execution.cost_currency || "" }).replace("  ", " "));
  if (execution?.provider_response_id) parts.push(t("views.responseId", { id: execution.provider_response_id }));
  return parts.length ? ` · ${parts.join(" · ")}` : "";
}

// Full-width hairline banner (D6): paused with the start command, or active with its age.
export function workerStatus(workers) {
  const alive = (workers || []).filter((w) => w.alive).sort((a, b) => a.age_seconds - b.age_seconds);
  const latest = (workers || [])[0];
  const isAlive = alive.length > 0;
  const body = isAlive
    ? [el("span", { class: "banner-dot", "aria-hidden": "true" }),
      el("span", { class: "banner-text" }, t("views.workerActive", { seconds: alive[0].age_seconds })),
      el("span", { class: "banner-hint" }, alive[0].worker_id, alive[0].current_occurrence_id ? t("views.runningOccurrence") : "")]
    : [el("span", { class: "banner-dot", "aria-hidden": "true" }),
      el("span", { class: "banner-text" }, t("views.automationsPaused")),
      el("span", { class: "banner-hint" }, t("views.startOneWith"), el("code", { class: "mono" }, "digitalmaid worker --loop"),
        latest ? t("views.lastWorkerSeen", { id: latest.worker_id, seconds: latest.age_seconds, status: t(`status.${latest.status}`, undefined, latest.status) }) : "")];
  return el("p", { id: "worker-status", class: `worker-banner${isAlive ? " is-live" : ""}`, role: "status", dataset: { alive: String(isAlive) } }, body);
}

function scheduleText(job) {
  const spec = job.schedule_spec;
  if (job.schedule_kind === "external") return t("views.scheduleExternal", { schedule: spec.hermes || "" });
  if (job.schedule_kind === "once") return t("views.scheduleOnce", { when: when(spec.at) });
  if (job.schedule_kind === "interval") return t("views.scheduleInterval", { seconds: spec.every_seconds, start: when(spec.start) });
  const dow = spec.dow ? t("views.scheduleWeekdays", { days: spec.dow.join(",") }) : t("views.scheduleDaily");
  return `${String(spec.hour).padStart(2, "0")}:${String(spec.minute).padStart(2, "0")} ${job.timezone}${dow}`;
}

// One node on the run rail; the leased (claimed, running) node is ringed in accent.
function occurrenceItem(o, onOpenTask) {
  return el("li", { class: `list-item${o.state === "leased" ? " is-live" : ""}`, dataset: { occurrence: o.id, state: o.state, status: o.state } },
    el("div", { class: "list-item-title" },
      el("span", {}, `${o.kind} · ${when(o.occurrence_utc)}`), pill(o.state)),
    el("div", { class: "meta" },
      o.worker_id ? t("views.workerPrefix", { id: o.worker_id }) : "",
      o.execution ? [t("views.executionPrefix"), pill(o.execution.status), t("views.runnerSuffix", { runner: runnerLabel(o.execution) }), executionEvidence(o.execution)] : t("views.noExecution")),
    o.task ? el("button", { class: "btn is-small", type: "button", onclick: () => onOpenTask(o.task.id) }, t("views.openTaskButton", { title: o.task.title }), " ", phasePill(o.task.status)) : null,
    o.blocked_reasons.length ? reasonsList(o.blocked_reasons.map((r) => t("views.blockedReason", { reason: r }))) : null,
    techDetails(t("views.occurrenceTechDetails", { id: o.id, token: o.fencing_token, state: o.state })));
}

function spendText(job) {
  const auth = job.task_template?.spend_authorization;
  if (!auth || auth.amount_minor === null || auth.amount_minor === undefined) return t("views.noSpendAuthorized");
  const by = auth.authorized_by ? t("views.byWhom", { by: auth.authorized_by }) : "";
  return t("views.spendAuthorized", { amount: auth.amount_minor, currency: auth.currency || "", by });
}

export function renderAutomations(jobs, { onOpenTask, onRunNow }) {
  if (!jobs.length) return emptyState("automations", t("views.automationsEmpty"), t("views.openAgentsAction"), "#/agents");
  return el("div", { class: "stack" }, jobs.map((job) => {
    const agentName = job.agent ? job.agent.name : t("views.agentDefinitionMissing", { id: job.agent_id });
    // Ghost button (D6): the solid accent lives only inside the confirmation, which names
    // the spend authorization and the agent that will do the work.
    // 0.7.0 Hermes Sync: a mirrored Hermes cron job is started in Hermes, never here (run-now → 409).
    const external = job.schedule_kind === "external";
    const runButton = external
      ? el("span", { class: "meta", dataset: { runsInHermes: job.id } }, t("views.runsInHermes"))
      : el("button", { class: "btn is-small", type: "button", dataset: { runNow: job.id, write: "true" } }, t("views.runNowAction"));
    // One idempotency key per rendered button: a double click reuses it, so the
    // server returns the same occurrence instead of creating a second one.
    const key = `ui-${crypto.randomUUID()}`;
    if (!external) runButton.addEventListener("click", async () => {
      const spend = spendText(job);
      const confirmed = await confirmDialog({
        title: t("views.runJobConfirmTitle", { purpose: job.purpose }),
        message: t("views.runJobConfirmMessage", { agent: agentName, spend: `${spend[0].toUpperCase()}${spend.slice(1)}` }),
        confirmLabel: t("views.queueTheRun"),
      });
      if (!confirmed) return;
      runButton.disabled = true;
      try { await onRunNow(job, key); } finally { runButton.disabled = false; }
    });
    const history = job.occurrences.filter((o) => o.status !== "due");
    return el("section", { class: "panel", "aria-labelledby": `job-${job.id}` },
      el("div", { class: "panel-header" },
        el("div", {}, el("h2", { id: `job-${job.id}` }, job.purpose),
          el("div", { class: "meta" }, scheduleText(job), job.enabled ? "" : t("views.disabledSuffix"))),
        el("div", { class: "form-actions" }, job.hermes_tags?.length ? pill("hermes") : null, pill(job.enabled ? "available" : "missing", t(job.enabled ? "status.enabled" : "status.paused")), runButton)),
      el("dl", { class: "kv" },
        el("dt", {}, t("views.fieldAgent")), el("dd", {}, job.agent ? t("views.agentRunnerDetail", { name: job.agent.name, runner: runnerLabel(job.agent.model_policy) }) : agentName),
        el("dt", {}, t("views.fieldProject")), el("dd", {}, job.project ? job.project.title : job.project_id),
        el("dt", {}, t("views.fieldTaskTemplate")), el("dd", {}, t("views.taskTemplateDetail", { title: job.task_template.title, owner: job.task_template.owner, count: job.task_template.criteria.length })),
        el("dt", {}, t("views.fieldSpending")), el("dd", {}, spendText(job))),
      techDetails(t("views.jobTechDetails", { id: job.id, policy: job.misfire_policy, version: job.schedule_version, kind: job.schedule_kind, spec: JSON.stringify(job.schedule_spec), timezone: job.timezone })),
      el("h4", {}, t("views.nextOccurrences")),
      job.next_occurrences.length
        ? el("ul", { class: "list rail" }, job.next_occurrences.map((o) => occurrenceItem(o, onOpenTask)))
        : empty(t("views.noOccurrencesYet")),
      el("h4", {}, t("views.runHistory")),
      history.length ? el("ul", { class: "list rail" }, history.map((o) => occurrenceItem(o, onOpenTask))) : empty(t("views.noRunsYet")));
  }));
}

function agentPill(agent) {
  if (agent.model_policy.kind === "fixture") return pill("not_applicable", t("views.testFixtureLabel"));
  const configured = agent.runner_status?.configured === true;
  return pill(configured ? "available" : "required", configured ? t("views.liveConfigured") : t("views.liveUnconfigured"));
}

export function renderAgents(agents) {
  if (!agents.length) return emptyState("agents", t("views.agentsEmpty"), t("views.openSettingsAction"), "#/settings");
  return el("div", { class: "grid" }, agents.map((agent) => el("section", { class: "panel", "aria-labelledby": `agent-${agent.id}` },
    el("div", { class: "panel-header" }, el("h2", { id: `agent-${agent.id}` }, agent.name), agentPill(agent)),
    el("p", {}, agent.responsibility),
    el("dl", { class: "kv" },
      el("dt", {}, t("views.fieldRunsAs")), el("dd", {}, runnerLabel(agent.model_policy),
        agent.runner_status?.problems?.length ? reasonsList(agent.runner_status.problems.map((p) => t("views.notConfiguredReason", { problem: p }))) : null),
      el("dt", {}, t("views.fieldAllowedActions")), el("dd", {}, el("ul", { class: "criteria" }, agent.allowed_actions.map((a) => el("li", {}, a)))),
      el("dt", {}, t("views.fieldReportsTo")), el("dd", {}, agent.reports_to || t("common.none")),
      el("dt", {}, t("views.fieldLimitations")), el("dd", {}, (agent.limitations || []).length ? el("ul", { class: "criteria" }, agent.limitations.map((l) => el("li", {}, l))) : t("common.none")),
      el("dt", {}, t("views.fieldDefinition")), el("dd", { class: "mono" }, agent.definition_path)))));
}

// --- Forms ----------------------------------------------------------------------

let fieldCounter = 0;

export function field(label, name, attrs = {}, tag = "input") {
  const { options, value, ...rest } = attrs;
  const id = `f-${name}-${++fieldCounter}`;
  const input = el(tag, { id, name, ...rest });
  for (const opt of options || []) {
    input.append(el("option", { value: opt.value ?? opt }, opt.label ?? opt));
  }
  // A textarea's initial text is its content, not a value attribute; a select needs its
  // options before its value can be chosen.
  if (value !== undefined && value !== null) input.value = String(value);
  // Required fields carry a small accent dot (D3); the text itself stays the label.
  return el("div", { class: "form-row" }, el("label", { for: id, class: rest.required ? "is-required" : null }, label), input);
}

// Three-way segmented control (D3) — one radio per option, the checked one is the value.
// Priority uses it as Low / Normal / High → 3 / 2 / 1, so the API still receives an integer.
export function segmented(labelText, name, options, value) {
  const id = `f-${name}-${++fieldCounter}`;
  return el("div", { class: "form-row" }, el("span", { class: "label-text", id }, labelText),
    el("div", { class: "segmented", role: "radiogroup", "aria-labelledby": id }, options.map((opt) =>
      el("label", { class: "segment" },
        el("input", { type: "radio", name, value: opt.value, checked: opt.value === value || null }),
        el("span", {}, opt.label)))));
}

export const PRIORITY_OPTIONS = [{ value: "3", label: "Low" }, { value: "2", label: "Normal" }, { value: "1", label: "High" }];

const PRIORITY_LABEL_KEYS = { Low: "views.priority.low", Normal: "views.priority.normal", High: "views.priority.high" };

// Translated priority options; other modules should call this instead of using
// PRIORITY_OPTIONS' English labels directly.
export function priorityOptions() {
  return PRIORITY_OPTIONS.map((opt) => ({ ...opt, label: t(PRIORITY_LABEL_KEYS[opt.label], undefined, opt.label) }));
}

// Tier 2 of a form (D3): closed by default, open when something in it is already non-default.
export function moreOptions(fields, { open = false } = {}) {
  return el("details", { class: "more", open: open || null }, el("summary", {}, t("views.moreOptions")), el("div", { class: "more-body" }, fields));
}

// Required fields that are visible, enabled and still empty; radio groups count as one.
function missingRequired(node) {
  const missing = [];
  const seenRadio = new Set();
  for (const input of node.querySelectorAll("[required]")) {
    if (input.disabled || input.closest("[hidden]")) continue;
    if (input.type === "radio") {
      if (seenRadio.has(input.name)) continue;
      seenRadio.add(input.name);
      if (node.querySelector(`input[type=radio][name="${input.name}"]:checked`)) continue;
    } else if (input.value.trim()) continue;
    const label = input.id ? node.querySelector(`label[for="${input.id}"]`) : input.closest("fieldset")?.querySelector("legend");
    missing.push((label?.textContent || input.name).trim());
  }
  return missing;
}

export function form(fields, submitLabel, onSubmit, { inline = false } = {}) {
  const alert = el("div", { class: "alert is-error", role: "alert" });
  const node = el("form", { class: "form", novalidate: true },
    inline ? el("div", { class: "form-row is-inline" }, fields) : fields,
    alert,
    el("div", { class: "form-actions" }, el("button", { class: "btn is-primary", type: "submit" }, submitLabel)));
  const button = node.querySelector("button[type=submit]");
  // The primary stays disabled until every required field is filled and says why (D3);
  // the viewer's read-only reason wins over it.
  const refresh = () => {
    if (isReadOnly()) return;
    const missing = missingRequired(node);
    button.disabled = missing.length > 0;
    button.title = missing.length ? t("views.fillInFields", { fields: missing.join(", ") }) : "";
    button.dataset.missing = String(missing.length);
  };
  node.addEventListener("input", refresh);
  node.addEventListener("change", refresh);
  node.addEventListener("submit", async (event) => {
    event.preventDefault();
    alert.replaceChildren();
    if (isReadOnly()) { alert.replaceChildren(el("div", {}, readOnlyReason())); return; }
    button.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(node).entries());
      await onSubmit(data, node);
    } catch (error) {
      alert.replaceChildren(el("div", {}, error.reasons ? t("views.refusedByServer") : error.message));
      if (error.reasons) alert.append(el("ul", {}, error.reasons.map((r) => el("li", {}, r))));
    } finally {
      button.disabled = isReadOnly();
      refresh();
    }
  });
  applyReadOnly(node);
  refresh();
  return node;
}
