import { api } from "./api.js";
import {
  el, append, pill, phasePill, when, empty, reasonsList, alertBox, field, form, icon, pdccChain, confirmDialog,
  renderToday, renderHiddenWidgets, renderGoals, renderAutomations, renderAgents, runnerLabel,
  executionEvidence, workerStatus, setSession, isReadOnly, currentUser, applyReadOnly,
  pageHeader, techDetails, segmented, moreOptions, PRIORITY_OPTIONS, renderStartHere, startHereKey,
} from "./views.js";
import { renderKnowledgePage, renderProceduresPage, renderReviewPage, renderOutputsPage, renderSettingsPage } from "./pages.js";
import { renderCalendarPage } from "./calendar.js";
import { renderCapturePage, openCapture } from "./capture.js";
import { renderHero, renderBoardHead } from "./hero.js";
import { startSky } from "./sky.js";
import { setupCommands, setCommandScope, recordRecent, openQuickCapture, openHelp, setJohEnabled } from "./commands.js";
import { renderJohPage } from "./joh.js";
import { t, setLanguage, currentLanguage, browserLanguage } from "./i18n.js";

const ROUTES = ["goals", "knowledge", "procedures", "review", "outputs", "automations", "agents", "calendar", "capture", "settings", "joh"];
const FIVE_M = ["Man", "Method", "Machine", "Material", "Money"];
const RESOURCE_STATUSES = ["required", "available", "missing", "not_applicable"];
const EXECUTION_STATUSES = ["queued", "running", "succeeded", "failed", "cancelled", "interrupted", "uncertain"];

// The session cookie is HttpOnly, so the page cannot see it. A browser that signed in here
// remembers that; without the hint the login form renders with no request at all (D6).
const SIGNED_IN_KEY = "dm:signed-in";
// Inside the Hermes dashboard tab the proxy adds <meta name="dm-trusted"> and vouches for the
// user: the app tries POST /api/auth/trusted once per page load before showing its login form.
// Signing out is deliberate, so it is not retried until the tab is reloaded.
const TRUSTED_PROXY = Boolean(document.querySelector('meta[name="dm-trusted"]'));
let trustedTried = false;
const defaultNextAction = () => t("app.defaultNextAction");

const view = document.getElementById("view");
const drawer = document.getElementById("drawer");
const backdrop = document.getElementById("backdrop");
const globalAlert = document.getElementById("global-alert");
let lastFocus = null;
let workspaceId = null;
let scopeId = null;

function hasSignedInHint() { return localStorage.getItem(SIGNED_IN_KEY) === "1"; }
function setSignedInHint(on) {
  try { if (on) localStorage.setItem(SIGNED_IN_KEY, "1"); else localStorage.removeItem(SIGNED_IN_KEY); } catch { /* storage unavailable */ }
}

// --- navigation -------------------------------------------------------------------

function currentRoute() {
  const hash = location.hash.replace(/^#\/?/, "");
  for (const name of ROUTES) if (hash === name || hash.startsWith(`${name}/`)) return name;
  return "today";
}

// "#/knowledge/<id>" → "<id>"; nothing else is ever read from the hash.
function routeParam() {
  const parts = location.hash.replace(/^#\/?/, "").split("/");
  return parts.length > 1 && parts[1] ? decodeURIComponent(parts[1]) : null;
}

function setActiveNav(route) {
  for (const link of document.querySelectorAll("[data-route]")) {
    if (link.dataset.route === route) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  }
}

function showGlobal(message, kind = "error", reasons) {
  globalAlert.className = `alert is-${kind}`;
  globalAlert.replaceChildren();
  if (!message) return;
  globalAlert.append(el("div", {}, message));
  if (reasons?.length) globalAlert.append(el("ul", {}, reasons.map((r) => el("li", {}, r))));
}

const pageContext = {
  openTask: (id, options) => openTask(id, options), route: (options) => route(options),
  showGlobal: (...args) => showGlobal(...args), openDrawer, closeDrawer, applyReadOnly,
  currentUser, recordRecent,
};

// Change the hash and resolve once the new page has rendered (route() announces it).
function navigate(hash) {
  if (location.hash === hash) return route();
  return new Promise((resolve) => {
    window.addEventListener("dm:routed", () => resolve(), { once: true });
    location.hash = hash;
  });
}

// Palette "Create" entries and the `n` shortcut open the existing create forms.
async function createIntent(kind) {
  if (kind === "capture") { openQuickCapture(); return; }
  if (kind === "goal") { await navigate("#/goals"); view.querySelector("#new-goal")?.click(); return; }
  if (kind === "task") {
    await navigate("#/goals");
    const button = view.querySelector("[data-new-task]");
    if (button) button.click();
    else showGlobal(t("app.createGoalTaskFirst"), "info");
    return;
  }
  if (kind === "inbox") { await navigate("#/capture"); return; }
  if (kind === "note") {
    await navigate("#/knowledge");
    const details = view.querySelector("#new-note");
    if (details) { details.open = true; details.querySelector("[name=title]")?.focus(); }
    return;
  }
  if (kind === "journal") {
    await navigate("#/knowledge");
    const tab = view.querySelector("[data-kind-tab='journal']");
    if (tab && tab.getAttribute("aria-selected") !== "true") { tab.click(); await new Promise((r) => window.addEventListener("dm:routed", r, { once: true })); }
    view.querySelector("#todays-entry")?.click();
    return;
  }
  if (kind === "procedure") {
    await navigate("#/procedures");
    const details = view.querySelector("#new-procedure");
    if (details) { details.open = true; details.querySelector("[name=title]")?.focus(); }
    return;
  }
  if (kind === "event") { await navigate("#/calendar"); view.querySelector("#new-event-button")?.click(); }
}

async function runJobFromPalette(job) {
  await navigate("#/automations");
  view.querySelector(`[data-run-now="${job.id}"]`)?.click();
}

// --- session -------------------------------------------------------------------------------

let session = null;

// 0.5.1: the signed-in user's language (server: stored, else negotiated from Accept-Language).
// Switching re-applies the static labels (i18n.js) and re-renders the page; the language pills
// in Settings call setLanguage directly, so the same event covers both paths.
async function adoptLanguage(me) {
  const code = me?.language;
  if (code && code !== currentLanguage()) await setLanguage(code);
}
let booted = false;
window.addEventListener("dm:language", () => {
  if (!booted) return;
  if (session) setSessionState(session);
  route();
});

function setSessionState(next) {
  session = next;
  setSession(next);
  const label = document.getElementById("session-label");
  const logout = document.getElementById("logout-button");
  const name = document.getElementById("user-name");
  const avatar = document.getElementById("user-avatar");
  document.body.dataset.signedIn = String(Boolean(next));
  setSignedInHint(Boolean(next));
  if (next) {
    label.textContent = `${next.user.username} · ${next.role || t("app.noMembership")}${isReadOnly() ? ` ${t("app.readOnlySuffix")}` : ""}`;
    name.textContent = t("app.signedInAs", { username: next.user.username });
    avatar.replaceChildren(next.user.username.slice(0, 1).toUpperCase());
    logout.hidden = false;
  } else {
    label.textContent = t("app.notSignedIn");
    name.textContent = t("app.notSignedInUser");
    avatar.replaceChildren(icon("user"));
    logout.hidden = true;
    document.getElementById("user-menu").open = false;
    for (const badge of document.querySelectorAll(".nav-badge")) badge.hidden = true;
    johEnabled = false;
    document.getElementById("nav-group-journey-item").hidden = true;
    setJohEnabled(false);
  }
}

// Rail badges (D5): the two inbox counts on every page, hidden at zero. A failed refresh
// leaves the badges as they were; they are a convenience, not a record.
async function refreshCounts() {
  if (!session) return;
  let counts;
  try { counts = await api.counts(); } catch { return; }
  for (const [route, key] of [["capture", "capture_inbox"], ["review", "review_inbox"]]) {
    const badge = document.getElementById(`nav-badge-${route}`);
    const n = counts[key] ?? 0;
    badge.textContent = String(n);
    badge.hidden = n === 0;
    badge.setAttribute("aria-label", t("app.waitingCount", { count: n }));
  }
}

// JOH (0.5.0): the rail item and the two palette entries exist only while the signed-in
// user has turned the section on in Settings; a failed read leaves things as they were.
let johEnabled = false;
async function refreshJoh() {
  if (!session) return;
  let status;
  try { status = await api.johStatus(); } catch { return; }
  johEnabled = Boolean(status.enabled);
  document.getElementById("nav-group-journey-item").hidden = !johEnabled;
  setJohEnabled(johEnabled);
}
window.addEventListener("dm:joh-changed", refreshJoh);

async function loadWorkspace() {
  const ws = await api.workspace();
  workspaceId = ws.workspace_id;
  scopeId = ws.scope_id;
  setCommandScope(ws.scope_id);
  document.getElementById("scope-label").textContent = t("app.scopeLabel", { scope: ws.scope_id });
  document.getElementById("workspace-label").textContent = t("app.workspaceLabel", { id: ws.workspace_id.slice(0, 8) });
}

// Hermes trusted proxy (docs/HERMES-INTEGRATION.md): null when not inside Hermes, already
// tried, or refused — the caller then shows the ordinary login form.
async function trustedSignIn() {
  if (!TRUSTED_PROXY || trustedTried) return null;
  trustedTried = true;
  try { await api.trustedLogin(); return await api.me(); } catch { return null; }
}

function renderLogin(message) {
  const loginForm = form([
    field(t("app.username"), "username", { required: true, autocomplete: "username" }),
    field(t("app.password"), "password", { type: "password", required: true, autocomplete: "current-password" }),
  ], t("app.signIn"), async (data) => {
    const me = await api.login(data.username, data.password);
    setSessionState(me);
    try { await adoptLanguage(await api.me()); } catch { /* keep the current language */ }
    try { await loadWorkspace(); } catch { /* the label stays as it was */ }
    await route();
  });
  loginForm.id = "login-form";
  document.getElementById("scope-label").textContent = t("app.signedOut");
  render(view,
    el("section", { class: "panel login-panel", "aria-labelledby": "login-title" },
      el("div", { class: "wordmark", "aria-hidden": "true" }, el("span", { class: "wordmark-name" }, t("app.brandName")), el("span", { class: "wordmark-sub" }, t("app.brandSub"))),
      el("header", { class: "main-header" }, el("div", {}, el("h1", { id: "login-title" }, t("app.signIn")),
        el("p", {}, t("app.signInLead")))),
      message ? alertBox("info", message) : null, loginForm));
  loginForm.querySelector("[name=username]").focus();
}

async function route(options = {}) {
  const name = currentRoute();
  setActiveNav(name);
  document.body.dataset.route = name;
  document.querySelector(".nav").dataset.open = "false";
  document.getElementById("nav-toggle").setAttribute("aria-expanded", "false");
  showGlobal("");
  if (!session) {
    let me = null;
    if (hasSignedInHint()) { try { me = await api.me(); } catch { me = null; } }
    if (!me) me = await trustedSignIn();
    if (!me) { renderLogin(); return; }
    setSessionState(me);
    await adoptLanguage(me);
    if (!workspaceId) { try { await loadWorkspace(); } catch { /* the label stays as it was */ } }
    await refreshJoh();
  }
  refreshCounts();
  // Re-rendering a page with a focused search box must not throw the caret away.
  const focused = options.keepFocus ? document.querySelector(options.keepFocus) : null;
  const caret = focused && typeof focused.selectionStart === "number" ? focused.selectionStart : null;
  if (!focused) view.replaceChildren(el("p", { class: "empty" }, t("common.loading")));
  try {
    if (name === "goals") await renderGoalsPage(routeParam());
    else if (name === "knowledge") await renderKnowledgePage(view, pageContext, routeParam());
    else if (name === "procedures") await renderProceduresPage(view, pageContext, routeParam());
    else if (name === "review") await renderReviewPage(view, pageContext);
    else if (name === "outputs") await renderOutputsPage(view, pageContext);
    else if (name === "automations") await renderAutomationsPage();
    else if (name === "agents") await renderAgentsPage();
    else if (name === "calendar") await renderCalendarPage(view, pageContext);
    else if (name === "capture") await renderCapturePage(view, pageContext, routeParam());
    else if (name === "settings") await renderSettingsPage(view, pageContext);
    else if (name === "joh") await renderJohPage(view, pageContext, routeParam());
    else await renderTodayPage();
    applyReadOnly(view);
  } catch (error) {
    if (error.status === 401) { setSessionState(null); renderLogin(t("app.sessionEnded")); return; }
    view.replaceChildren();
    showGlobal(t("app.couldNotLoad", { name, message: error.message }), "error", error.reasons);
  }
  if (options.keepFocus) {
    const again = document.querySelector(options.keepFocus);
    if (again) {
      again.focus();
      if (caret !== null && typeof again.setSelectionRange === "function") again.setSelectionRange(caret, caret);
    }
  }
  window.dispatchEvent(new CustomEvent("dm:routed", { detail: { route: name } }));
}

// --- Today -------------------------------------------------------------------------

async function renderTodayPage() {
  // Journal entry dates feed the 14-day dot row and the job list feeds the Automations
  // node badge; a failure in either must not hide the board.
  const [today, prefs, journalNotes, jobs] = await Promise.all([
    api.today(), api.widgetPreferences(), api.notes("journal").catch(() => []), api.jobs().catch(() => null)]);
  const handlers = {
    journalDates: journalNotes.map((n) => n.entry_date).filter(Boolean),
    onOpenTask: openTask,
    onNewTask: () => createIntent("task"),
    onMoveWidget: async (id, delta) => {
      const order = prefs.widgets.slice();
      const index = order.findIndex((w) => w.id === id);
      const target = index + delta;
      if (target < 0 || target >= order.length) return;
      [order[index], order[target]] = [order[target], order[index]];
      await savePrefs(order);
    },
    onToggleWidget: async (id, visible) => {
      await savePrefs(prefs.widgets.map((w) => (w.id === id ? { ...w, visible } : w)));
    },
    onOpenJournal: async (journal) => {
      try {
        let entry = journal.note_id ? { id: journal.note_id } : null;
        if (!entry) entry = await api.createNote({ kind: "journal", title: t("app.journalEntryTitle", { date: journal.entry_date }), body_md: "", actor: "ui", entry_date: journal.entry_date });
        location.hash = `#/knowledge/${entry.id}`;
      } catch (error) {
        showGlobal(t("app.couldNotOpenEntry", { message: error.message }), "error", error.reasons);
      }
    },
  };
  async function savePrefs(widgets) {
    try {
      await api.saveWidgetPreferences(widgets);
      await route();
    } catch (error) {
      showGlobal(t("app.couldNotSaveWidgetPreferences", { message: error.message }), "error", error.reasons);
    }
  }
  // Board, not document (DESIGN.md B1/C1): the hero readout replaces the page title; the
  // scope and generation time become a tiny footer meta line.
  render(view,
    renderHero(today, {
      onCapture: openQuickCapture,
      onSearch: () => document.getElementById("global-search")?.focus(),
      onLayout: toggleEditBoard,
      onInfo: openHelp,
      automationsDue: jobs ? jobs.reduce((n, job) => n + (job.next_occurrences?.length || 0), 0) : null,
    }),
    await startHere(),
    renderBoardHead(toggleEditBoard),
    renderHiddenWidgets(prefs, handlers.onToggleWidget),
    renderToday(today, prefs, handlers),
    el("p", { class: "board-foot" }, el("span", { class: "foot-dot", "aria-hidden": "true" }),
      t("app.generatedFoot", { when: when(today.generated_at), scope: scopeId })));
}

// First-run checklist (D4). The decision is taken once per browser and workspace: a scope
// that already had goals or captures when Today first opened never shows it ("off"); an
// empty one shows it ("active") until all three steps are done or it is dismissed.
async function startHere() {
  const key = startHereKey(workspaceId);
  let state = localStorage.getItem(key);
  if (state === "off") return null;
  let goals, captures;
  try { [goals, captures] = await Promise.all([api.goals(), api.captures()]); } catch { return null; }
  const remember = (value) => { try { localStorage.setItem(key, value); } catch { /* convenience only */ } };
  if (state !== "active") {
    if (goals.length || captures.length) { remember("off"); return null; }
    remember("active");
  }
  const converted = captures.some((c) => c.status === "converted" && c.converted_type === "task");
  if (goals.length && captures.length && converted) { remember("off"); return null; }
  return renderStartHere({ goals, captures }, {
    onNewGoal: () => createIntent("goal"),
    onCapture: openQuickCapture,
    onOpenInbox: (captureId) => { location.hash = captureId ? `#/capture/${captureId}` : "#/capture"; },
    onDismiss: () => { remember("off"); document.getElementById("start-here")?.remove(); },
  });
}

// Header pencil and the hero's layout icon: reveal the move/hide controls while pressed.
function toggleEditBoard() {
  const editing = document.body.dataset.editing !== "true";
  document.body.dataset.editing = String(editing);
  for (const id of ["edit-board", "hero-layout"]) {
    const button = document.getElementById(id);
    if (!button) continue;
    button.setAttribute("aria-pressed", String(editing));
    if (id === "hero-layout") button.dataset.active = String(editing);
  }
}

function setupEditBoard() {
  document.getElementById("edit-board").addEventListener("click", toggleEditBoard);
}

// Narrow screens: the rail becomes a top bar whose list unfolds from a menu button.
function setupNavToggle() {
  const nav = document.querySelector(".nav");
  const button = document.getElementById("nav-toggle");
  button.addEventListener("click", () => {
    const open = nav.dataset.open !== "true";
    nav.dataset.open = String(open);
    button.setAttribute("aria-expanded", String(open));
    if (open) nav.querySelector(".nav-item[aria-current='page'], .nav-item")?.focus();
  });
}

// replaceChildren() stringifies non-Node arguments (a null child becomes the
// text "null"); append() drops null/undefined/false instead.
function render(container, ...children) {
  container.replaceChildren();
  return append(container, children);
}

// --- Goals and projects ------------------------------------------------------------

async function renderGoalsPage(taskId = null) {
  const [goals, projects] = await Promise.all([api.goals(), api.projects()]);
  const projectsByGoal = {};
  for (const project of projects) (projectsByGoal[project.goal_id] ||= []).push(project);
  const taskLists = await Promise.all(projects.map((p) => api.projectTasks(p.id)));
  const tasksByProject = Object.fromEntries(projects.map((p, i) => [p.id, taskLists[i]]));

  const creator = el("div", { class: "stack", id: "creator" });
  const me = currentUser() || "";
  // Two-tier forms (D3): tier 1 is the essential pair; owner, next action, priority and the
  // rest sit under "More options" with defaults, so title + one line is enough to create.
  const handlers = {
    onOpenTask: openTask,
    onNewProject: (goal) => showCreator(creator, t("app.newProjectUnder", { title: goal.title }), form([
      field(t("app.title"), "title", { required: true }),
      moreOptions([
        field(t("app.owner"), "owner", { required: true, value: me }),
        field(t("app.successCriteria"), "success_criteria", { required: true, value: t("app.successCriteriaDefault") }),
      ]),
    ], t("app.createProject"), async (data) => { await api.createProject({ ...data, goal_id: goal.id }); await route(); })),
    onNewTask: (project) => showCreator(creator, t("app.newTaskIn", { title: project.title }), form([
      field(t("app.title"), "title", { required: true }),
      field(t("app.doneLooksLike"), "done", { required: true, placeholder: t("app.doneLooksLikePlaceholder") }),
      moreOptions([
        el("div", { class: "form-row is-inline" },
          field(t("app.owner"), "owner", { required: true, value: me }),
          field(t("app.nextAction"), "next_action", { value: "", placeholder: defaultNextAction() })),
        segmented(t("app.priority"), "priority", PRIORITY_OPTIONS, "2"),
        field(t("app.moreCriteria"), "criteria", { rows: "2" }, "textarea"),
        field(t("app.deadline"), "deadline", { type: "date" }),
        johEnabled ? el("div", { class: "form-row is-check" },
          el("label", {}, el("input", { type: "checkbox", name: "joh", id: "task-joh", value: "true" }), t("app.consultJourneyProfile"))) : null,
      ]),
    ], t("app.createTask"), async (data) => {
      await api.createTask({
        project_id: project.id, title: data.title, owner: data.owner,
        next_action: data.next_action.trim() || defaultNextAction(),
        priority: Number.parseInt(data.priority, 10),
        criteria: [data.done, ...(data.criteria || "").split("\n")].map((s) => s.trim()).filter(Boolean),
        deadline: data.deadline || null,
        ...(data.joh === "true" ? { inputs: { joh: "true" } } : {}),
      });
      await route();
    })),
    onDecideGoal: (goal) => showCreator(creator, t("app.recordOutcomeFor", { title: goal.title }), form([
      el("div", { class: "form-row is-inline" },
        field(t("app.achievedQuestion"), "achieved", { options: [{ value: "true", label: t("app.achievedOption") }, { value: "false", label: t("app.notAchievedOption") }] }, "select")),
      field(t("app.measuredEvidence"), "evidence", { required: true, rows: "3" }, "textarea"),
      el("p", { class: "meta" }, t("app.decidedBy", { user: currentUser() })),
    ], t("app.recordGoalOutcome"), async (data) => {
      await api.recordGoalOutcome(goal.id, { achieved: data.achieved === "true", evidence: data.evidence });
      await route();
    })),
  };

  handlers.onNewGoal = () => showCreator(creator, t("app.newGoal"), form([
    field(t("app.title"), "title", { required: true }),
    field(t("app.measureSuccess"), "success_measure", { required: true, placeholder: t("app.measureSuccessPlaceholder") }),
    moreOptions([field(t("app.owner"), "owner", { required: true, value: me })]),
  ], t("app.createGoal"), async (data) => { await api.createGoal(data); await route(); }));

  render(view,
    pageHeader("goals", t("app.goalsTitle"),
      t("app.goalsLead"),
      { tools: el("button", { id: "new-goal", class: "btn is-primary", type: "button", dataset: { write: "true" }, onclick: handlers.onNewGoal }, t("app.newGoal")) }),
    creator,
    renderGoals(goals, projectsByGoal, tasksByProject, handlers));
  // "#/goals/<task id>" (the hero's Next strip, palette recents) opens that task once;
  // the hash then drops the id so later re-renders do not reopen the drawer.
  if (taskId) {
    history.replaceState(null, "", "#/goals");
    await openTask(taskId);
  }
}

// --- Automations and agents -----------------------------------------------------------

async function renderAutomationsPage(noticeNode = null) {
  const [jobs, workers] = await Promise.all([api.jobs(), api.workers()]);
  const notice = el("div", { class: "stack", id: "automation-notice" }, noticeNode);
  render(view,
    pageHeader("automations", t("app.automationsTitle"),
      t("app.automationsLead")),
    workerStatus(workers),
    notice,
    renderAutomations(jobs, {
      onOpenTask: openTask,
      onRunNow: async (job, key) => {
        try {
          const occurrence = await api.runJobNow(job.id, key);
          await renderAutomationsPage(alertBox("ok", t("app.manualOccurrenceDue", { id: occurrence.id.slice(0, 8), purpose: job.purpose })));
        } catch (error) {
          render(notice, alertBox("error", t("app.runNowRefused", { message: error.message }), error.reasons));
        }
      },
    }));
}

async function renderAgentsPage() {
  const agents = await api.agents();
  render(view,
    pageHeader("agents", t("app.agentsTitle"),
      t("app.agentsLead")),
    renderAgents(agents));
}

function showCreator(container, title, formNode) {
  container.replaceChildren(el("section", { class: "panel", "aria-label": title },
    el("div", { class: "panel-header" }, el("h3", {}, title),
      el("button", { class: "btn is-quiet is-small", type: "button", onclick: () => container.replaceChildren() }, t("common.cancel"))),
    formNode));
  applyReadOnly(container);
  container.querySelector("input, select, textarea")?.focus();
}

// Generic drawer for non-task content (calendar events); same focus handling.
function openDrawer(titleText, bodyNode, { focus = null, kicker = null } = {}) {
  lastFocus = document.activeElement;
  drawer.dataset.open = "true";
  backdrop.hidden = false;
  render(drawer,
    el("div", { class: "drawer-header" },
      el("div", {}, el("span", { class: "drawer-kicker" }, kicker ?? t("app.detailsKicker")), el("h2", { id: "drawer-title", tabindex: "-1" }, titleText)),
      el("button", { class: "btn is-quiet", type: "button", "aria-label": t("common.close"), onclick: closeDrawer }, t("common.close"))),
    el("div", { class: "drawer-body" }, bodyNode));
  applyReadOnly(drawer);
  (focus && drawer.querySelector(focus) || drawer.querySelector("#drawer-title"))?.focus();
}

// --- Task drawer ---------------------------------------------------------------------

async function openTask(taskId, { section = null } = {}) {
  lastFocus = document.activeElement;
  drawer.dataset.open = "true";
  backdrop.hidden = false;
  drawer.replaceChildren(el("p", { class: "empty" }, t("app.loadingTask")));
  await refreshDrawer(taskId);
  // Review Inbox opens the drawer at the relevant form (e.g. the check form).
  const target = section ? drawer.querySelector(`details.action[data-section="${section}"]`) : null;
  if (target) {
    target.open = true;
    target.querySelector("input, select, textarea")?.focus();
    target.scrollIntoView({ block: "start" });
  } else {
    drawer.querySelector("#drawer-title")?.focus();
  }
}

function closeDrawer() {
  drawer.dataset.open = "false";
  backdrop.hidden = true;
  drawer.replaceChildren();
  lastFocus?.focus?.();
}

async function refreshDrawer(taskId, notice) {
  try {
    const detail = await api.taskDetail(taskId);
    recordRecent({ type: "task", id: detail.task.id, title: detail.task.title });
    render(drawer, ...renderTaskDetail(detail, notice));
    applyReadOnly(drawer);
  } catch (error) {
    render(drawer, el("div", { class: "drawer-header" }, el("h2", { id: "drawer-title", tabindex: "-1" }, t("app.taskKicker")),
      el("button", { class: "btn is-quiet", type: "button", onclick: closeDrawer }, t("common.close"))),
      el("div", { class: "drawer-body" }, alertBox("error", t("app.couldNotLoadTask", { message: error.message }), error.reasons)));
  }
}

function renderTaskDetail(detail, notice) {
  const { task } = detail;
  const latestVersion = detail.output_versions.at(-1) || null;
  const latestCheck = detail.checks.at(-1) || null;
  const openCorrection = detail.corrections.find((c) => !c.revised_output_version_id) || null;
  const act = (label, promise) => async (data) => {
    await promise(data);
    await refreshDrawer(task.id, t("app.recordedNotice", { label }));
    // The rest of the page reflects the same records; refresh it quietly.
    route();
  };

  const resourceForm = form([
    el("div", { class: "form-row is-inline" },
      field(t("app.categoryFiveM"), "category", { options: FIVE_M.map((v) => ({ value: v, label: t(`app.fiveM.${v}`) })) }, "select"),
      field(t("app.status"), "status", { options: RESOURCE_STATUSES.map((v) => ({ value: v, label: t(`status.${v}`, undefined, v) })) }, "select")),
    field(t("app.description"), "description", { required: true }),
    el("div", { class: "form-row is-inline" },
      field(t("app.naReason"), "na_reason", {}),
      field(t("app.amountMinorUnits"), "amount_minor", { type: "number", step: "1" }),
      field(t("app.currencyMoney"), "currency", { maxlength: "3" })),
  ], t("app.assessResource"), act(t("app.noticeAssessment"), (data) => api.assessResource(task.id, {
    category: data.category, status: data.status, description: data.description,
    na_reason: data.na_reason || null,
    amount_minor: data.amount_minor === "" ? null : Number.parseInt(data.amount_minor, 10),
    currency: data.currency ? data.currency.toUpperCase() : null,
  })));

  const startButton = el("div", { class: "stack" },
    reasonsList(detail.gate_reasons),
    form([], t("app.startTaskPlanDo"), act(t("app.noticeStart"), () => api.startTask(task.id))));

  const executionForm = form([
    el("div", { class: "form-row is-inline" },
      field(t("app.agentIdManual"), "agent_id", { required: true, value: "manual" }),
      field(t("app.status"), "status", { options: EXECUTION_STATUSES.map((v) => ({ value: v, label: t(`status.${v}`, undefined, v) })) }, "select")),
    field(t("app.log"), "log", { rows: "2" }, "textarea"),
  ], t("app.recordExecution"), act(t("app.noticeExecution"), (data) => api.recordExecution(task.id, { agent_id: data.agent_id, status: data.status, log: data.log || "" })));

  const outputForm = detail.executions.length
    ? form([
      field(t("app.execution"), "execution_id", { options: detail.executions.map((e) => ({ value: e.id, label: `${t(`status.${e.status}`, undefined, e.status)} · ${e.agent_id} · ${when(e.created_at)}` })).reverse() }, "select"),
      field(t("app.contentMarkdown"), "content", { required: true }, "textarea"),
    ], t("app.submitOutputVersion", { version: (latestVersion?.version || 0) + 1 }), act(t("app.noticeOutput"), (data) => api.submitOutput(task.id, data)))
    : alertBox("info", t("app.recordExecutionFirst"));

  const checkForm = latestVersion
    ? form([
      field(t("app.reviewer"), "reviewer", { required: true }),
      ...JSON.parse(latestVersion.criteria_snapshot).map((criterion, i) => el("fieldset", {},
        el("legend", {}, criterion),
        el("div", { class: "radio-group" },
          el("label", {}, el("input", { type: "radio", name: `passed_${i}`, value: "true", required: true }), t("app.pass")),
          el("label", {}, el("input", { type: "radio", name: `passed_${i}`, value: "false" }), t("app.fail"))),
        field(t("app.evidence"), `evidence_${i}`, { required: true }))),
    ], t("app.recordCheckVersion", { version: latestVersion.version }), act(t("app.noticeCheck"), (data) => api.recordCheck(latestVersion.id, {
      reviewer: data.reviewer,
      results: JSON.parse(latestVersion.criteria_snapshot).map((criterion, i) => ({
        criterion, passed: data[`passed_${i}`] === "true", evidence: data[`evidence_${i}`] || "" })),
    })))
    : alertBox("info", t("app.noOutputToCheck"));

  const correctionForm = latestCheck && !latestCheck.passed && task.status === "Correction"
    ? form([
      el("div", { class: "form-row is-inline" }, field(t("app.owner"), "owner", { required: true })),
      field(t("app.correctiveAction"), "action", { required: true, rows: "2" }, "textarea"),
    ], t("app.openCorrectionSubmit"), act(t("app.noticeCorrection"), (data) => api.openCorrection(latestCheck.id, data)))
    : alertBox("info", task.status === "Correction" ? t("app.latestCheckDidNotFail") : t("app.correctionsOpenOnlyFromFailedCheck"));

  const acceptForm = latestVersion
    ? form([el("p", { class: "meta" }, t("app.acceptedByMeta", { user: currentUser() }))],
      t("app.acceptVersion", { version: latestVersion.version }), act(t("app.noticeAcceptance"), () => api.acceptOutput(latestVersion.id)))
    : alertBox("info", t("app.nothingToAcceptYet"));

  const learningForm = form([field(t("app.learning"), "text", { required: true, rows: "2" }, "textarea")],
    t("app.addLearning"), act(t("app.noticeLearning"), (data) => api.addLearning(task.id, data)));

  // Comments live beside a version and never move the PDCC status.
  const commentForm = latestVersion
    ? form([
      field(t("app.commentMarkdown"), "comment_body", { required: true, rows: "2" }, "textarea"),
    ], t("app.commentOnVersion", { version: latestVersion.version }), act(t("app.noticeComment"), (data) => api.addComment(latestVersion.id, { author: currentUser(), body_md: data.comment_body })))
    : alertBox("info", t("app.commentsAttachInfo"));
  if (commentForm.tagName === "FORM") commentForm.id = "comment-form";

  const header = el("div", { class: "drawer-header" },
    el("div", {},
      el("span", { class: "drawer-kicker" }, t("app.taskKicker")),
      el("h2", { id: "drawer-title", tabindex: "-1" }, task.title),
      el("div", { class: "meta" }, el("span", { class: "status-word" }, t(`phase.${task.status}`, undefined, task.status)), phasePill(task.status, t("app.pdccLabel", { phase: t(`phase.${task.status}`, undefined, task.status) })), el("span", {}, t("app.ownerPriorityMeta", { owner: task.owner, priority: PRIORITY_OPTIONS.find((p) => p.value === String(task.priority))?.label.toLowerCase() || task.priority }))),
      pdccChain(task.status)),
    el("button", { class: "btn is-quiet", type: "button", "aria-label": t("app.closeTaskDetailsAria"), onclick: closeDrawer }, t("common.close")));
  const body = el("div", { class: "drawer-body" },
    notice ? alertBox("ok", notice) : null,
    drawerSection(t("phase.Plan"), el("dl", { class: "kv" },
      el("dt", {}, t("app.nextAction")), el("dd", {}, task.next_action),
      el("dt", {}, t("app.deadline")), el("dd", {}, task.deadline || t("common.none")),
      el("dt", {}, t("app.criteria")), el("dd", {}, el("ul", { class: "criteria" }, task.criteria.map((c) => el("li", {}, c)))),
      el("dt", {}, t("app.spending")), el("dd", {}, detail.can_spend ? t("app.explicitlyAuthorized") : t("app.notAuthorizedAllocation")),
      task.procedure_id ? [el("dt", {}, t("app.procedure")), el("dd", {}, el("a", { href: `#/procedures/${task.procedure_id}` }, t("app.procedureStep", { step: task.step_index + 1, version: task.procedure_version })))] : null)),
    detail.dependencies.length ? drawerSection(t("app.dependsOn"), el("ul", { class: "list" }, detail.dependencies.map((d) => el("li", { class: "list-item is-clickable", tabindex: "0", role: "button",
      onclick: () => openTask(d.depends_on_task_id), onkeydown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openTask(d.depends_on_task_id); } } },
      el("div", { class: "list-item-title" }, el("span", {}, d.title), phasePill(d.status)),
      d.status === "Done" ? null : el("div", { class: "meta" }, t("app.waitingReleasedByHuman")))))) : null,
    drawerSection(t("app.fiveMAssessments"), detail.resources.length
      ? el("ul", { class: "list" }, FIVE_M.map((cat) => {
        const r = detail.resources.find((x) => x.category === cat);
        return el("li", { class: "list-item" }, el("div", { class: "list-item-title" }, el("strong", {}, t(`app.fiveM.${cat}`)), r ? pill(r.status) : pill("missing", t("app.notAssessed"))),
          r ? el("div", { class: "meta" }, r.description, r.na_reason ? t("app.naSuffix", { reason: r.na_reason }) : "", r.amount_minor !== null && r.amount_minor !== undefined ? t("app.minorUnitsSuffix", { amount: r.amount_minor, currency: r.currency }) : "") : null);
      }))
      : empty(t("app.notAssessedYet")),
    el("details", { class: "action", dataset: { section: "resource" } }, el("summary", {}, t("app.assessResourceSummary")), resourceForm)),
    task.status === "Plan" ? drawerSection(t("app.start"), startButton) : null,
    drawerSection(t("app.executions"), detail.executions.length
      ? el("ul", { class: "list" }, detail.executions.map((e) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" }, el("span", {}, e.agent_id), pill(e.status)),
        el("div", { class: "meta" }, when(e.created_at), ` · ${runnerLabel(e)}`, executionEvidence(e), e.log ? ` · ${e.log}` : ""))))
      : empty(t("app.noExecutionsRecorded")),
    task.status === "Do" ? el("details", { class: "action", dataset: { section: "execution" } }, el("summary", {}, t("app.recordExecutionSummary")), executionForm) : null),
    drawerSection(t("app.outputVersions"), detail.output_versions.length
      ? el("ul", { class: "list" }, detail.output_versions.map((v) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" }, el("strong", {}, t("app.versionLabel", { version: v.version })), el("span", { class: "meta" }, when(v.created_at))),
        el("pre", { class: "version-content" }, v.content ?? t("app.blobMissing")),
        techDetails(t("app.sha256Line", { hash: v.sha256 }), el("br"), t("app.storedAtLine", { path: v.blob_path })))))
      : empty(t("app.noOutputSubmitted")),
    task.status === "Do" ? el("details", { class: "action", dataset: { section: "output" } }, el("summary", {}, t("app.submitOutputSummary")), outputForm) : null),
    drawerSection(t("app.checks"), detail.checks.length
      ? el("ul", { class: "list" }, detail.checks.map((c) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" }, el("span", {}, t("app.byReviewer", { reviewer: c.reviewer })), pill(c.passed ? "pass" : "fail")),
        el("ul", { class: "criteria meta" }, c.results.map((r) => el("li", {}, `${r.passed ? "✓" : "✗"} ${r.criterion} — ${r.evidence}`))))))
      : empty(t("app.unchecked")),
    task.status === "Do" ? el("details", { class: "action", dataset: { section: "check" } }, el("summary", {}, t("app.recordCheckSummary")), checkForm) : null),
    drawerSection(t("app.reviewComments"), detail.comments.length
      ? el("ul", { class: "list" }, detail.comments.map((c) => el("li", { class: "list-item" }, c.body_md, el("div", { class: "meta" }, t("app.commentMeta", { author: c.author, when: when(c.created_at), version: detail.output_versions.find((v) => v.id === c.output_version_id)?.version ?? "?" })))))
      : empty(t("app.noComments")),
    el("details", { class: "action", dataset: { section: "comment" } }, el("summary", {}, t("app.addCommentSummary")), commentForm)),
    drawerSection(t("app.corrections"), detail.corrections.length
      ? el("ul", { class: "list" }, detail.corrections.map((c) => el("li", { class: "list-item" },
        el("div", {}, c.action),
        el("div", { class: "meta" }, t("app.ownerMetaPrefix", { owner: c.owner }), c.revised_output_version_id ? t("app.revisedInLaterVersion") : t("app.awaitingRevisedOutput")))))
      : empty(t("app.noCorrections")),
    task.status === "Correction" ? el("details", { class: "action", open: true, dataset: { section: "correction" } }, el("summary", {}, t("app.openCorrectionSummary")), correctionForm) : null),
    drawerSection(t("app.acceptance"), detail.acceptance
      ? el("div", {}, t("app.acceptedByAt", { user: detail.acceptance.accepted_by, when: when(detail.acceptance.created_at) }))
      : el("div", { class: "stack" }, empty(t("app.notAcceptedYet")),
        task.status === "Check" ? el("details", { class: "action", open: true, dataset: { section: "accept" } }, el("summary", {}, t("app.acceptCheckedVersionSummary")), acceptForm) : null)),
    drawerSection(t("app.learning"), detail.learnings.length
      ? el("ul", { class: "list" }, detail.learnings.map((l) => el("li", { class: "list-item" }, l.text, el("div", { class: "meta" }, when(l.created_at)))))
      : empty(t("app.nothingRecorded")),
    el("details", { class: "action", dataset: { section: "learning" } }, el("summary", {}, t("app.addLearning")), learningForm)),
    detail.notes.length ? drawerSection(t("app.linkedNotes"), el("ul", { class: "list" }, detail.notes.map((n) => el("li", { class: "list-item" },
      el("div", { class: "list-item-title" }, el("a", { href: `#/knowledge/${n.id}`, onclick: closeDrawer }, n.title), pill(n.kind)))))) : null,
    openCorrection ? alertBox("info", t("app.openCorrectionLinked")) : null);
  return [header, body];
}

function drawerSection(title, ...children) {
  return el("section", { class: "drawer-section" }, el("h4", {}, title), ...children);
}

// --- Global search (combobox + listbox, keyboard first) -------------------------------

function setupGlobalSearch() {
  const input = document.getElementById("global-search");
  const list = document.getElementById("search-results");
  const status = document.getElementById("search-status");
  let items = [];
  let selected = -1;
  let timer = null;

  const close = () => {
    list.hidden = true;
    list.replaceChildren();
    input.setAttribute("aria-expanded", "false");
    input.removeAttribute("aria-activedescendant");
    items = [];
    selected = -1;
  };
  const open = (hit) => {
    close();
    input.value = "";
    if (hit.type === "note") location.hash = `#/knowledge/${hit.id}`;
    else if (hit.type === "task") openTask(hit.id);
    else if (hit.type === "capture") openCapture(hit.id, pageContext);
    else location.hash = "#/goals";
  };
  const select = (index) => {
    selected = index;
    for (const [i, option] of [...list.children].entries()) {
      option.setAttribute("aria-selected", String(i === selected));
      if (i === selected) input.setAttribute("aria-activedescendant", option.id);
    }
    if (selected < 0) input.removeAttribute("aria-activedescendant");
  };
  const show = (result, query) => {
    items = [
      ...result.notes.map((n) => ({ type: "note", id: n.id, label: n.title, meta: `${t(`status.${n.kind}`, undefined, n.kind)}${n.snippet ? ` · ${n.snippet}` : ""}` })),
      ...result.tasks.map((tk) => ({ type: "task", id: tk.id, label: tk.title, meta: `${t("app.searchMetaTask")} · ${t(`phase.${tk.status}`, undefined, tk.status)}` })),
      ...result.goals.map((g) => ({ type: "goal", id: g.id, label: g.title, meta: `${t("app.searchMetaGoal")} · ${t(`status.${g.outcome_status}`, undefined, g.outcome_status)}` })),
      ...(result.captures || []).map((c) => ({ type: "capture", id: c.id, label: c.title || c.url || (c.body_text || "").split("\n")[0].slice(0, 80), meta: `${t("app.searchMetaCapture")} · ${t(`status.${c.kind}`, undefined, c.kind)} · ${t(`status.${c.status}`, undefined, c.status)}${c.snippet ? ` · ${c.snippet}` : ""}` })),
    ];
    list.replaceChildren(...(items.length
      ? items.map((hit, i) => el("li", { id: `search-option-${i}`, role: "option", "aria-selected": "false", dataset: { type: hit.type }, onmousedown: (e) => e.preventDefault(), onclick: () => open(hit) },
        el("span", {}, hit.label), el("small", { class: "meta" }, hit.meta)))
      : [el("li", { class: "listbox-empty", role: "presentation" }, t("app.noSearchMatches", { query }))]));
    list.hidden = false;
    input.setAttribute("aria-expanded", "true");
    selected = -1;
    status.textContent = items.length ? t("app.searchResultsCount", { count: items.length }) : t("app.noResults");
  };
  input.addEventListener("input", () => {
    clearTimeout(timer);
    const query = input.value.trim();
    if (!query) { close(); status.textContent = ""; return; }
    timer = setTimeout(async () => {
      try { show(await api.search(query), query); } catch (error) { showGlobal(t("app.searchFailed", { message: error.message })); }
    }, 200);
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { close(); return; }
    if (list.hidden || !items.length) return;
    if (event.key === "ArrowDown") { event.preventDefault(); select((selected + 1) % items.length); }
    else if (event.key === "ArrowUp") { event.preventDefault(); select((selected - 1 + items.length) % items.length); }
    else if (event.key === "Enter" && selected >= 0) { event.preventDefault(); open(items[selected]); }
  });
  input.addEventListener("blur", () => setTimeout(() => { if (!list.contains(document.activeElement)) close(); }, 150));
}

// --- boot ----------------------------------------------------------------------------

setupGlobalSearch();
setupEditBoard();
setupNavToggle();
startSky();
setupCommands({
  navigate, create: createIntent, runJob: runJobFromPalette, openTask,
  showGlobal, onCaptured: () => { if (currentRoute() === "today" || currentRoute() === "capture") route(); else refreshCounts(); },
});
window.addEventListener("dm:unauthenticated", () => { if (session) { setSessionState(null); renderLogin(t("app.sessionEnded")); } });
document.getElementById("logout-button").addEventListener("click", async () => {
  try { await api.logout(); } catch { /* the cookie is gone either way */ }
  setSessionState(null);
  closeDrawer();
  renderLogin(t("app.signedOutMessage"));
});
backdrop.addEventListener("click", closeDrawer);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && drawer.dataset.open === "true") closeDrawer();
});
window.addEventListener("hashchange", route);

// Boot: a browser that never signed in here renders the login form without a single
// request; one that did asks who it is, then loads the workspace identity for the rail foot.
// The catalogue comes first (the browser's language until the server says otherwise), so the
// very first paint — even the login form — is already in the right language.
const bootLanguage = setLanguage(browserLanguage()).catch(() => { /* English strings remain */ });
if (!hasSignedInHint()) {
  bootLanguage.then(() => { booted = true; return route(); });
} else {
  bootLanguage.then(() => api.me()).then(async (me) => {
    setSessionState(me);
    await adoptLanguage(me);
    await loadWorkspace();
    await refreshJoh();
  }).catch(() => { document.getElementById("scope-label").textContent = "signed out"; }).finally(() => { booted = true; return route(); });
}
