"""Automation jobs and database-backed occurrences with atomic claims (ADR-005).

Occurrence generation is a pure function of (job, window): the same inputs
always produce the same UTC instants, and the UNIQUE key on
(job, schedule_version, occurrence_utc) makes re-planning idempotent.

Local-time policies for ``cron-lite`` schedules: a wall time that does not
exist on a DST day is shifted forward by the size of the gap; a wall time
that occurs twice is taken once, at its first (pre-transition) instant.
Missed instants (already in the past when first planned) follow the job's
``misfire_policy``: ``skip`` records them as skipped, ``run_latest`` makes
only the most recent one due.
"""

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from digitalmaid.db import new_id, now
from digitalmaid.errors import ConflictError
from digitalmaid.tasks import FIVE_M, RESOURCE_STATUSES, _check_money, _clean_criteria

UTC = timezone.utc
SCHEDULE_KINDS = ("once", "interval", "cron-lite")
# "external": the schedule lives in Hermes (0.7.0 Hermes Sync); the job is a paused mirror that
# is never planned or run here. Only the sync path may create one.
EXTERNAL_KIND = "external"
MISFIRE_POLICIES = ("skip", "run_latest")
OCCURRENCE_STATUSES = ("due", "skipped", "succeeded", "failed", "blocked")
TERMINAL_STATUSES = ("succeeded", "failed", "blocked")
_MAX_INSTANTS_PER_PLAN = 10_000


def utc_iso(instant: datetime) -> str:
    """Fixed-width UTC timestamp: lexical order equals chronological order."""
    if instant.tzinfo is None:
        raise ValueError("instant must be timezone-aware")
    return instant.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f+00:00")


def parse_utc(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            raise ValueError("datetime must be timezone-aware")
        return value.astimezone(UTC)
    if not isinstance(value, str):
        raise ValueError("timestamp must be an ISO 8601 string")
    text = value[:-1] + "+00:00" if value.endswith("Z") else value
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        raise ValueError(f"timestamp {value!r} must carry a UTC offset")
    return parsed.astimezone(UTC)


def _check_spec(kind: str, spec, allow_external: bool = False) -> dict:
    if kind == EXTERNAL_KIND and allow_external:
        if not isinstance(spec, dict) or not isinstance(spec.get("hermes"), str):
            raise ValueError("an external schedule_spec must carry the Hermes schedule text")
        return {"hermes": spec["hermes"]}
    if kind not in SCHEDULE_KINDS:
        raise ValueError(f"schedule_kind must be one of {SCHEDULE_KINDS}")
    if not isinstance(spec, dict):
        raise ValueError("schedule_spec must be an object")
    if kind == "once":
        return {"at": utc_iso(parse_utc(spec.get("at")))}
    if kind == "interval":
        every = spec.get("every_seconds")
        if type(every) is not int or every < 1:
            raise ValueError("every_seconds must be a positive int")
        return {"every_seconds": every,
                "start": utc_iso(parse_utc(spec.get("start")))}
    minute, hour, dow = spec.get("minute"), spec.get("hour"), spec.get("dow")
    if type(minute) is not int or not 0 <= minute <= 59:
        raise ValueError("minute must be an int 0-59")
    if type(hour) is not int or not 0 <= hour <= 23:
        raise ValueError("hour must be an int 0-23")
    if dow is not None:
        if (not isinstance(dow, list) or not dow
                or any(type(d) is not int or not 0 <= d <= 6 for d in dow)):
            raise ValueError("dow must be a non-empty list of ints 0-6 (Mon=0)")
        dow = sorted(set(dow))
    return {"minute": minute, "hour": hour, "dow": dow}


def _check_template(template) -> dict:
    if not isinstance(template, dict):
        raise ValueError("task_template must be an object")
    for name in ("title", "owner", "next_action"):
        if not isinstance(template.get(name), str) or not template[name].strip():
            raise ValueError(f"task_template.{name} must be a non-empty string")
    if type(template.get("priority")) is not int:
        raise ValueError("task_template.priority must be an int")
    resources = template.get("resources", {})
    if not isinstance(resources, dict):
        raise ValueError("task_template.resources must be an object")
    for category, entry in resources.items():
        if category not in FIVE_M or not isinstance(entry, dict):
            raise ValueError(f"unknown resource category {category!r}")
        if entry.get("status") not in RESOURCE_STATUSES:
            raise ValueError(f"resource {category}: status must be one of"
                             f" {RESOURCE_STATUSES}")
    inputs = template.get("inputs", {})
    if not isinstance(inputs, dict) or any(
            not isinstance(k, str) or not isinstance(v, (str, int, float))
            for k, v in inputs.items()):
        raise ValueError("task_template.inputs must map names to text or numbers")
    authorization = template.get("spend_authorization")
    if authorization is not None:
        if not isinstance(authorization, dict):
            raise ValueError("task_template.spend_authorization must be an object")
        _check_money(authorization.get("amount_minor"), authorization.get("currency"))
        by = authorization.get("authorized_by")
        if not isinstance(by, str) or not by.strip():
            raise ValueError("spend_authorization.authorized_by must name a human")
    return {**template, "criteria": _clean_criteria(template.get("criteria")),
            "resources": resources}


def generate_instants(kind: str, spec: dict, tz_name: str,
                      after: datetime, until: datetime) -> list[datetime]:
    """UTC instants in the half-open window (after, until], ascending."""
    if until <= after or kind == EXTERNAL_KIND:
        return []
    if kind == "once":
        at = parse_utc(spec["at"])
        return [at] if after < at <= until else []
    if kind == "interval":
        start, every = parse_utc(spec["start"]), spec["every_seconds"]
        step = timedelta(seconds=every)
        k = max(0, (after - start) // step + 1)
        instants = []
        while len(instants) < _MAX_INSTANTS_PER_PLAN:
            instant = start + k * step
            if instant > until:
                break
            if instant > after:
                instants.append(instant)
            k += 1
        return instants
    tz = ZoneInfo(tz_name)
    day = after.astimezone(tz).date() - timedelta(days=1)
    last = until.astimezone(tz).date() + timedelta(days=1)
    instants = []
    while day <= last:
        if spec["dow"] is None or day.weekday() in spec["dow"]:
            local = datetime(day.year, day.month, day.day, spec["hour"],
                             spec["minute"], tzinfo=tz, fold=0)
            # A nonexistent wall time carries the pre-gap offset, which lands
            # after the gap (shift forward); an ambiguous one uses fold=0.
            instant = local.astimezone(UTC)
            if after < instant <= until:
                instants.append(instant)
        day += timedelta(days=1)
    return instants


class Scheduling:
    """Mixin; expects ``self._db``, ``self.scope_id``, GoalsProjects."""

    # -- jobs -----------------------------------------------------------------

    def create_job(self, purpose: str, agent_id: str, project_id: str,
                   task_template: dict, schedule_kind: str,
                   schedule_spec: dict, timezone: str, enabled: bool = True,
                   misfire_policy: str = "skip",
                   created_at: datetime | None = None,
                   allow_external: bool = False) -> dict:
        for name, value in (("purpose", purpose), ("agent_id", agent_id)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        if misfire_policy not in MISFIRE_POLICIES:
            raise ValueError(f"misfire_policy must be one of {MISFIRE_POLICIES}")
        if not isinstance(enabled, bool):
            raise ValueError("enabled must be a bool")
        try:
            ZoneInfo(timezone)
        except (ZoneInfoNotFoundError, ValueError, TypeError):
            raise ValueError(f"unknown IANA timezone {timezone!r}") from None
        spec = _check_spec(schedule_kind, schedule_spec, allow_external=allow_external)
        template = _check_template(task_template)
        if self.get_project(project_id) is None:
            raise ValueError(
                f"project {project_id!r} not found in scope {self.scope_id!r}")
        if self.get_agent(agent_id) is None:
            raise ValueError(f"no agent definition {agent_id!r} in this root")
        stamp = utc_iso(created_at) if created_at else utc_iso(
            datetime.now(UTC))
        job_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO automation_jobs (id, scope_id, purpose, agent_id,"
                " project_id, task_template, schedule_kind, schedule_spec,"
                " timezone, enabled, misfire_policy, schedule_version,"
                " planned_until, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, ?)",
                (job_id, self.scope_id, purpose, agent_id, project_id,
                 json.dumps(template, sort_keys=True), schedule_kind,
                 json.dumps(spec, sort_keys=True), timezone, int(enabled),
                 misfire_policy, stamp, stamp))
            self._db.audit(cur, "automation_job", job_id, "create",
                           template["owner"],
                           {"schedule_kind": schedule_kind, "agent_id": agent_id},
                           scope_id=self.scope_id)
        return self.get_job(job_id)

    def _job_dict(self, row) -> dict:
        job = dict(row)
        job["task_template"] = json.loads(job["task_template"])
        job["schedule_spec"] = json.loads(job["schedule_spec"])
        job["enabled"] = bool(job["enabled"])
        return job

    def get_job(self, job_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM automation_jobs WHERE id = ? AND scope_id = ?",
            (job_id, self.scope_id))
        return None if row is None else self._job_dict(row)

    def _require_job(self, job_id: str) -> dict:
        job = self.get_job(job_id)
        if job is None:
            raise LookupError(
                f"job {job_id!r} not found in scope {self.scope_id!r}")
        return job

    def list_jobs(self) -> list[dict]:
        return [self._job_dict(r) for r in self._db.query(
            "SELECT * FROM automation_jobs WHERE scope_id = ?"
            " ORDER BY created_at, id", (self.scope_id,))]

    def set_job_enabled(self, job_id: str, enabled: bool,
                        actor: str = "owner") -> dict:
        if not isinstance(enabled, bool):
            raise ValueError("enabled must be a bool")
        job = self._require_job(job_id)
        self._db.update_with_revision(
            "automation_jobs", job_id, self.scope_id, job["revision"],
            {"enabled": int(enabled)}, actor=actor,
            action="enable" if enabled else "disable",
            entity_type="automation_job")
        return self.get_job(job_id)

    # -- planning -------------------------------------------------------------

    def plan_occurrences(self, now_utc: datetime | None = None,
                         horizon: timedelta | int = timedelta(days=1)) -> int:
        """Materialise occurrences up to ``now + horizon``; returns rows added."""
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        if not isinstance(horizon, timedelta):
            horizon = timedelta(seconds=int(horizon))
        until = now_utc + horizon
        added = 0
        for job in self.list_jobs():
            if not job["enabled"]:
                continue
            after = parse_utc(job["planned_until"] or job["created_at"])
            if until <= after:
                continue
            instants = generate_instants(job["schedule_kind"],
                                         job["schedule_spec"], job["timezone"],
                                         after, until)
            missed = [i for i in instants if i <= now_utc]
            statuses = {}
            for instant in missed:
                statuses[instant] = "skipped"
            if missed and job["misfire_policy"] == "run_latest":
                statuses[missed[-1]] = "due"
            with self._db.transaction() as cur:
                # Another planner (a second worker process) may have moved
                # this job on since list_jobs(); re-read under the write lock.
                current = cur.execute(
                    "SELECT revision, planned_until FROM automation_jobs"
                    " WHERE id = ? AND scope_id = ?",
                    (job["id"], self.scope_id)).fetchone()
                if current is None or (current["planned_until"]
                                       and current["planned_until"] >= utc_iso(until)):
                    continue
                job = {**job, "revision": current["revision"]}
                for instant in instants:
                    status = statuses.get(instant, "due")
                    occurrence_id = new_id()
                    stamp = now()
                    cur.execute(
                        "INSERT OR IGNORE INTO job_occurrences (id, scope_id,"
                        " job_id, schedule_version, occurrence_utc, kind,"
                        " status, created_at, updated_at)"
                        " VALUES (?, ?, ?, ?, ?, 'scheduled', ?, ?, ?)",
                        (occurrence_id, self.scope_id, job["id"],
                         job["schedule_version"], utc_iso(instant), status,
                         stamp, stamp))
                    if cur.rowcount == 1:
                        added += 1
                        self._db.audit(cur, "job_occurrence", occurrence_id,
                                       "plan", "scheduler",
                                       {"job_id": job["id"], "status": status,
                                        "occurrence_utc": utc_iso(instant)},
                                       scope_id=self.scope_id)
                self._db.update_with_revision(
                    "automation_jobs", job["id"], self.scope_id,
                    job["revision"], {"planned_until": utc_iso(until)},
                    actor="scheduler", action="plan",
                    details={"added": added}, cur=cur,
                    entity_type="automation_job")
        return added

    def request_run_now(self, job_id: str, idempotency_key: str,
                        now_utc: datetime | None = None) -> dict:
        """Manual occurrence; the same key always returns the same row."""
        if not isinstance(idempotency_key, str) or not idempotency_key.strip():
            raise ValueError("idempotency_key must be a non-empty string")
        job = self._require_job(job_id)
        if job["schedule_kind"] == EXTERNAL_KIND:
            raise ConflictError("this automation runs in Hermes; start it from the Hermes"
                                " dashboard, not from here")
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        occurrence_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            existing = cur.execute(
                "SELECT id FROM job_occurrences WHERE job_id = ?"
                " AND idempotency_key = ?", (job_id, idempotency_key)).fetchone()
            if existing is not None:
                return self.get_occurrence(existing["id"])
            try:
                cur.execute(
                    "INSERT INTO job_occurrences (id, scope_id, job_id,"
                    " schedule_version, occurrence_utc, kind, idempotency_key,"
                    " status, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, 'manual', ?, 'due', ?, ?)",
                    (occurrence_id, self.scope_id, job_id,
                     job["schedule_version"], utc_iso(now_utc),
                     idempotency_key, stamp, stamp))
            except sqlite3.IntegrityError as exc:
                raise ConflictError(
                    "an occurrence already exists at this instant") from exc
            self._db.audit(cur, "job_occurrence", occurrence_id, "plan",
                           "manual", {"job_id": job_id, "status": "due",
                                      "idempotency_key": idempotency_key},
                           scope_id=self.scope_id)
        return self.get_occurrence(occurrence_id)

    # -- occurrences ------------------------------------------------------------

    def _occurrence_dict(self, row, now_iso: str) -> dict:
        occurrence = dict(row)
        occurrence["blocked_reasons"] = json.loads(occurrence["blocked_reasons"])
        state = occurrence["status"]
        if (state == "due" and occurrence["lease_until"]
                and occurrence["lease_until"] > now_iso):
            state = "leased"
        occurrence["state"] = state
        return occurrence

    def get_occurrence(self, occurrence_id: str,
                       now_utc: datetime | None = None) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM job_occurrences WHERE id = ? AND scope_id = ?",
            (occurrence_id, self.scope_id))
        if row is None:
            return None
        return self._occurrence_dict(
            row, utc_iso(parse_utc(now_utc or datetime.now(UTC))))

    def list_occurrences(self, job_id: str,
                         now_utc: datetime | None = None) -> list[dict]:
        now_iso = utc_iso(parse_utc(now_utc or datetime.now(UTC)))
        return [self._occurrence_dict(r, now_iso) for r in self._db.query(
            "SELECT * FROM job_occurrences WHERE job_id = ? AND scope_id = ?"
            " ORDER BY occurrence_utc, rowid", (job_id, self.scope_id))]

    def list_due_occurrences(self, now_utc: datetime | None = None) -> list[dict]:
        """Unleased due occurrences whose instant has arrived, oldest first."""
        now_iso = utc_iso(parse_utc(now_utc or datetime.now(UTC)))
        return [self._occurrence_dict(r, now_iso) for r in self._db.query(
            "SELECT * FROM job_occurrences WHERE scope_id = ? AND status = 'due'"
            " AND occurrence_utc <= ? AND (lease_until IS NULL OR lease_until < ?)"
            " ORDER BY occurrence_utc, rowid", (self.scope_id, now_iso, now_iso))]

    def occurrence_for_task(self, task_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM job_occurrences WHERE task_id = ? AND scope_id = ?",
            (task_id, self.scope_id))
        return None if row is None else self._occurrence_dict(
            row, utc_iso(datetime.now(UTC)))

    def claim_occurrence(self, occurrence_id: str, worker_id: str,
                         lease_seconds: int,
                         now_utc: datetime | None = None) -> int | None:
        """Single atomic UPDATE; returns the fencing token or None if taken."""
        if not isinstance(worker_id, str) or not worker_id.strip():
            raise ValueError("worker_id must be a non-empty string")
        if type(lease_seconds) is not int or lease_seconds < 1:
            raise ValueError("lease_seconds must be a positive int")
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        now_iso = utc_iso(now_utc)
        lease_until = utc_iso(now_utc + timedelta(seconds=lease_seconds))
        with self._db.transaction() as cur:
            cur.execute(
                "UPDATE job_occurrences SET lease_until = ?, worker_id = ?,"
                " fencing_token = fencing_token + 1, updated_at = ?,"
                " revision = revision + 1"
                " WHERE id = ? AND scope_id = ? AND status = 'due'"
                " AND (lease_until IS NULL OR lease_until < ?)",
                (lease_until, worker_id, now(), occurrence_id, self.scope_id,
                 now_iso))
            if cur.rowcount != 1:
                return None
            token = cur.execute(
                "SELECT fencing_token FROM job_occurrences WHERE id = ?",
                (occurrence_id,)).fetchone()["fencing_token"]
            self._db.audit(cur, "job_occurrence", occurrence_id, "claim",
                           f"worker:{worker_id}", {"fencing_token": token,
                                       "lease_until": lease_until},
                           scope_id=self.scope_id)
        return token

    def renew_lease(self, occurrence_id: str, fencing_token: int,
                    lease_seconds: int, now_utc: datetime | None = None) -> dict:
        """Extend a held lease; a stale token or finished occurrence raises."""
        if type(fencing_token) is not int:
            raise ValueError("fencing_token must be an int")
        if type(lease_seconds) is not int or lease_seconds < 1:
            raise ValueError("lease_seconds must be a positive int")
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        lease_until = utc_iso(now_utc + timedelta(seconds=lease_seconds))
        with self._db.transaction() as cur:
            cur.execute(
                "UPDATE job_occurrences SET lease_until = ?, updated_at = ?,"
                " revision = revision + 1"
                " WHERE id = ? AND scope_id = ? AND status = 'due'"
                " AND lease_until IS NOT NULL AND fencing_token = ?",
                (lease_until, now(), occurrence_id, self.scope_id, fencing_token))
            if cur.rowcount != 1:
                raise ConflictError(
                    f"occurrence {occurrence_id!r} is not leased with fencing"
                    f" token {fencing_token} in scope {self.scope_id!r}")
            self._db.audit(cur, "job_occurrence", occurrence_id, "renew", "worker",
                           {"fencing_token": fencing_token, "lease_until": lease_until},
                           scope_id=self.scope_id)
        return self.get_occurrence(occurrence_id, now_utc=now_utc)

    def complete_occurrence(self, occurrence_id: str, fencing_token: int,
                            status: str, task_id: str | None = None,
                            execution_id: str | None = None,
                            blocked_reasons: list[str] | None = None,
                            actor: str = "worker") -> dict:
        """Finish a claimed occurrence; a stale token raises ConflictError."""
        if status not in TERMINAL_STATUSES:
            raise ValueError(f"status must be one of {TERMINAL_STATUSES}")
        if type(fencing_token) is not int:
            raise ValueError("fencing_token must be an int")
        reasons = [str(r) for r in (blocked_reasons or [])]
        with self._db.transaction() as cur:
            cur.execute(
                "UPDATE job_occurrences SET status = ?, lease_until = NULL,"
                " task_id = COALESCE(?, task_id),"
                " execution_id = COALESCE(?, execution_id),"
                " blocked_reasons = ?, updated_at = ?, revision = revision + 1"
                " WHERE id = ? AND scope_id = ? AND status = 'due'"
                " AND fencing_token = ?",
                (status, task_id, execution_id, json.dumps(reasons), now(),
                 occurrence_id, self.scope_id, fencing_token))
            if cur.rowcount != 1:
                raise ConflictError(
                    f"occurrence {occurrence_id!r} is not due with fencing"
                    f" token {fencing_token} in scope {self.scope_id!r}")
            self._db.audit(cur, "job_occurrence", occurrence_id,
                           f"status:{status}", actor,
                           {"fencing_token": fencing_token, "task_id": task_id,
                            "execution_id": execution_id,
                            "blocked_reasons": reasons},
                           scope_id=self.scope_id)
        return self.get_occurrence(occurrence_id)
