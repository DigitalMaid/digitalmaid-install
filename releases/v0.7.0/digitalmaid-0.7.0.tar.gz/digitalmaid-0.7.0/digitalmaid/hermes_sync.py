"""Hermes Sync stage 1 (0.7.0, DESIGN.md Appendix H): one-way, re-runnable import.

The Hermes dashboard plugin collects what Hermes handles (cron jobs, kanban tasks, calendar,
mail, memory, skills, files) and posts it here. Every item is keyed by
``external_id = "hermes:<source>:<id>"`` in ``hermes_links`` together with a hash of the
fields we actually write: same hash → nothing is touched, different hash → the local record
is updated in place, unknown → created. Nothing is ever duplicated or deleted; an item that
Hermes no longer lists (``inventory``) keeps its record and gains the ``hermes:gone`` tag.

Mirrored kanban phases are written as ``hermes:mirror`` audit rows — they are a mirror of the
Hermes board, not PDCC gate transitions, and the sync never fakes a check or an acceptance.
"""

import hashlib
import json
from datetime import datetime, timezone

from digitalmaid.db import now
from digitalmaid.errors import ConflictError, InvariantError
from digitalmaid.scheduling import EXTERNAL_KIND

SOURCES = ("cron", "kanban", "calendar", "email", "memory", "skills", "files")
BOARD_SOURCE = "board"
BOARD_GOAL_TITLE = "Hermes board"
BOARD_GOAL_MEASURE = "Mirrors the Hermes kanban board; outcomes are decided in Hermes."
CRON_PROJECT_TITLE = "Hermes cron"
UNSORTED_PROJECT_TITLE = "Unsorted"
EXTERNAL_AGENT_ID = "pi-chief-of-staff"
GONE_TAG = "hermes:gone"
TAGS = {
    "cron": ["hermes"], "kanban": ["hermes"], "calendar": ["hermes"], "board": ["hermes"],
    "memory": ["hermes", "from Hermes", "fact"], "skills": ["hermes", "hermes-skill", "read-only"],
    "files": ["hermes", "file"],
}
# Hermes board status → PDCC phase. "done" mirrors as Done; nothing here is an acceptance.
PHASES = {"todo": "Plan", "backlog": "Plan", "in_progress": "Do", "running": "Do", "review": "Check",
          "blocked": "Correction", "failed": "Correction", "done": "Done"}
PRIORITIES = {"urgent": 1, "high": 1, "medium": 2, "normal": 2, "low": 3}
_TITLE_MAX = 120
_COUNTS = ("created", "updated", "unchanged", "skipped")


def external_id(source: str, item_id) -> str:
    return f"hermes:{source}:{item_id}"


def _hash(material: dict) -> str:
    return hashlib.sha256(json.dumps(material, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _first_line(text, fallback: str) -> str:
    for line in (text or "").splitlines():
        if line.strip():
            return line.strip()[:_TITLE_MAX]
    return fallback


def _title(text, fallback: str = "(untitled)") -> str:
    value = (text or "").strip()
    return value[:_TITLE_MAX] if value else fallback


def _priority(value) -> int:
    if isinstance(value, bool):
        return 2
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        text = value.strip().lower()
        if text.isdigit():
            return int(text)
        return PRIORITIES.get(text, 2)
    return 2


def _instant(value, all_day: bool) -> str:
    """Hermes gives ISO strings; all-day items may be bare dates → midnight UTC."""
    if isinstance(value, str) and all_day and len(value) == 10:
        return value + "T00:00:00+00:00"
    return value


class HermesSync:
    """Mixin; expects ``self._db``, ``self.scope_id`` and every other store mixin."""

    # -- reads ----------------------------------------------------------------------------

    def hermes_tags_for(self, kind: str) -> dict[str, list[str]]:
        """``{local_id: tags}`` for every imported record of one local kind."""
        return {r["local_id"]: json.loads(r["tags"]) for r in self._db.query(
            "SELECT local_id, tags FROM hermes_links WHERE scope_id = ? AND kind = ?",
            (self.scope_id, kind))}

    def hermes_sync_status(self) -> dict:
        row = self._db.query_one(
            "SELECT actor, at, details FROM audit_events WHERE scope_id = ?"
            " AND entity_type = 'hermes_sync' AND action = 'hermes:sync'"
            " ORDER BY at DESC, rowid DESC LIMIT 1", (self.scope_id,))
        links = self._db.query_one("SELECT COUNT(*) AS n FROM hermes_links WHERE scope_id = ?",
                                   (self.scope_id,))["n"]
        last = None
        if row is not None:
            last = {**json.loads(row["details"]), "at": row["at"], "actor": row["actor"]}
        return {"last": last, "links": links}

    # -- the sync -----------------------------------------------------------------------------

    def sync_from_hermes(self, payload: dict, actor: str) -> dict:
        """Apply one validated payload; returns the summary that is also audited."""
        sources = payload.get("sources") or {}
        summary = {name: 0 for name in _COUNTS}
        summary["by_source"] = {}
        summary["skipped_items"] = []
        summary["collected_at"] = payload.get("collected_at")
        board = _BoardCache(self, actor, summary)
        handlers = {"cron": self._sync_cron, "kanban": self._sync_kanban,
                    "calendar": self._sync_calendar, "email": self._sync_email,
                    "memory": self._sync_memory, "skills": self._sync_skill,
                    "files": self._sync_file}
        for source in SOURCES:
            for item in sources.get(source) or []:
                ext = external_id(source, item["id"])
                try:
                    outcome = handlers[source](item, ext, actor, board)
                except (ValueError, ConflictError, InvariantError, LookupError) as exc:
                    outcome = "skipped"
                    summary["skipped_items"].append({"external_id": ext, "reason": str(exc)})
                self._count(summary, source, outcome)
        summary["gone"] = self._mark_gone(payload.get("inventory") or {})
        with self._db.transaction() as cur:
            self._db.audit(cur, "hermes_sync", self.scope_id, "hermes:sync", actor,
                           {k: v for k, v in summary.items() if k != "skipped_items"},
                           scope_id=self.scope_id)
        return summary

    @staticmethod
    def _count(summary: dict, source: str, outcome: str) -> None:
        summary[outcome] += 1
        per = summary["by_source"].setdefault(source, {name: 0 for name in _COUNTS})
        per[outcome] += 1

    # -- link bookkeeping -----------------------------------------------------------------------

    def _link(self, ext: str):
        return self._db.query_one("SELECT * FROM hermes_links WHERE external_id = ? AND scope_id = ?",
                                  (ext, self.scope_id))

    def _upsert(self, ext: str, kind: str, material: dict, tags: list[str], create, update) -> str:
        """The idempotent core: ``create() -> local_id``, ``update(local_id)``; returns the outcome."""
        digest = _hash(material)
        link = self._link(ext)
        stamp = now()
        if link is None:
            local_id = create()
            with self._db.transaction() as cur:
                cur.execute(
                    "INSERT INTO hermes_links (external_id, scope_id, kind, local_id, hash, tags,"
                    " synced_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (ext, self.scope_id, kind, local_id, digest, json.dumps(tags), stamp))
            return "created"
        outcome = "unchanged"
        if link["hash"] != digest:
            update(link["local_id"])
            outcome = "updated"
        if link["hash"] != digest or json.loads(link["tags"]) != tags:
            with self._db.transaction() as cur:
                cur.execute("UPDATE hermes_links SET hash = ?, tags = ?, synced_at = ?"
                            " WHERE external_id = ?", (digest, json.dumps(tags), stamp, ext))
        return outcome

    def _mark_gone(self, inventory: dict) -> int:
        gone = 0
        for source, ids in inventory.items():
            present = {external_id(source, i) for i in ids}
            rows = self._db.query(
                "SELECT external_id, tags FROM hermes_links WHERE scope_id = ?"
                " AND external_id LIKE ?", (self.scope_id, f"hermes:{source}:%"))
            for row in rows:
                tags = json.loads(row["tags"])
                if row["external_id"] in present:
                    continue
                gone += 1
                if GONE_TAG not in tags:
                    with self._db.transaction() as cur:
                        cur.execute("UPDATE hermes_links SET tags = ? WHERE external_id = ?",
                                    (json.dumps(tags + [GONE_TAG]), row["external_id"]))
        return gone

    def _mirror(self, table: str, entity_type: str, local_id: str, fields: dict, actor: str,
                details: dict | None = None) -> None:
        row = self._db.query_one(f"SELECT revision FROM {table} WHERE id = ? AND scope_id = ?",
                                 (local_id, self.scope_id))
        if row is None:
            raise LookupError(f"{entity_type} {local_id!r} vanished")
        self._db.update_with_revision(table, local_id, self.scope_id, row["revision"], fields,
                                      actor=actor, action="hermes:mirror", details=details,
                                      entity_type=entity_type)

    # -- per-source handlers --------------------------------------------------------------------

    def _sync_cron(self, item: dict, ext: str, actor: str, board) -> str:
        name = _title(item.get("name"), f"Hermes job {item['id']}")
        material = {"purpose": name, "next_action": _first_line(item.get("prompt"), name),
                    "schedule": item.get("schedule") or "", "display": item.get("schedule_display")}
        template = {"title": name, "owner": actor, "next_action": material["next_action"],
                    "priority": 2, "criteria": ["Completed by Hermes on its own schedule"],
                    "inputs": {"hermes_schedule": material["display"] or material["schedule"]}}
        spec = {"hermes": material["schedule"]}
        project_id = board.cron_project()

        def create():
            agent = EXTERNAL_AGENT_ID if self.get_agent(EXTERNAL_AGENT_ID) else self.list_agents()[0]["id"]
            job = self.create_job(name, agent, project_id, template, EXTERNAL_KIND, spec,
                                  "UTC", enabled=False, allow_external=True)
            return job["id"]

        def update(job_id):
            self._mirror("automation_jobs", "automation_job", job_id,
                         {"purpose": name, "task_template": json.dumps(
                             {**self.get_job(job_id)["task_template"], **template}, sort_keys=True),
                          "schedule_spec": json.dumps(spec, sort_keys=True)}, actor)
        return self._upsert(ext, "job", material, TAGS["cron"], create, update)

    def _sync_kanban(self, item: dict, ext: str, actor: str, board) -> str:
        phase = PHASES.get(str(item.get("status") or "").lower(), "Plan")
        title = _title(item.get("title"), f"Hermes task {item['id']}")
        next_action = _first_line(item.get("body"), "Open the task on the Hermes board")
        project_id = board.project(item.get("project_id"), item.get("project_title"))
        material = {"title": title, "next_action": next_action, "status": phase,
                    "project_id": project_id, "priority": _priority(item.get("priority"))}

        def create():
            task = self.create_task(project_id, title, actor, next_action,
                                    ["Tracked on the Hermes board"], material["priority"])
            if phase != "Plan":
                self._mirror("tasks", "task", task["id"], {"status": phase}, actor, {"status": phase})
            return task["id"]

        def update(task_id):
            self._mirror("tasks", "task", task_id,
                         {"title": title, "next_action": next_action, "status": phase,
                          "project_id": project_id, "priority": material["priority"]},
                         actor, {"status": phase})
        return self._upsert(ext, "task", material, TAGS["kanban"], create, update)

    def _sync_calendar(self, item: dict, ext: str, actor: str, board) -> str:
        all_day = bool(item.get("all_day"))
        fields = {"title": _title(item.get("title"), "(untitled event)"), "kind": "event",
                  "start_utc": _instant(item.get("start"), all_day),
                  "end_utc": _instant(item.get("end"), all_day), "all_day": all_day,
                  "timezone": "UTC", "notes": item.get("location") or ""}
        clean = self._check_event_fields(fields)          # raises ValueError → skipped
        material = {k: clean[k] for k in ("title", "start_utc", "end_utc", "all_day", "notes")}

        def create():
            return self.create_event(clean["title"], "event", clean["start_utc"], timezone="UTC",
                                     actor=actor, end_utc=clean["end_utc"], all_day=clean["all_day"],
                                     notes=clean["notes"], external_source="hermes",
                                     external_id=ext)["id"]

        def update(event_id):
            self._mirror("events", "event", event_id, {**material, "all_day": int(material["all_day"])},
                         actor)
        return self._upsert(ext, "event", material, TAGS["calendar"], create, update)

    def _sync_email(self, item: dict, ext: str, actor: str, board) -> str:
        tier = str(item.get("tier") or "info").lower()
        title = _title(item.get("subject"), "(no subject)")
        body = "\n\n".join(part for part in (
            (item.get("snippet") or "").strip(),
            "\n".join(f"{label}: {value}" for label, value in (("From", item.get("sender")),
                                                               ("Date", item.get("date"))) if value),
        ) if part) or title
        material = {"title": title, "body_text": body}

        def create():
            return self.create_capture("text", actor, title=title, body_text=body, source="hermes")["id"]

        def update(capture_id):
            self._mirror("captures", "capture", capture_id, material, actor)
        return self._upsert(ext, "capture", material, ["hermes", "email", tier], create, update)

    def _sync_memory(self, item: dict, ext: str, actor: str, board) -> str:
        text = (item.get("text") or "").strip()
        if not text:
            raise ValueError("memory entry is empty")
        title = _first_line(text, "Hermes memory")[:80]
        material = {"title": title, "body_md": text}

        def create():
            return self.create_note("note", title, text, actor)["id"]

        def update(note_id):
            note = self.get_note(note_id)
            if note is None:
                raise LookupError("note vanished")
            self.update_note(note_id, note["revision"], title=title, body_md=text, actor=actor)
        return self._upsert(ext, "note", material, TAGS["memory"], create, update)

    def _sync_skill(self, item: dict, ext: str, actor: str, board) -> str:
        name = _title(item.get("name"), str(item["id"]))
        purpose = _title(item.get("description"), f"Hermes skill {name}")
        steps = [{"title": "Open in Hermes",
                  "instruction_md": f"Open in Hermes: `skill_view('{name}')`",
                  "expected_evidence": "The skill was followed in Hermes", "role": "human"}]
        material = {"title": name, "purpose": purpose, "steps": steps}

        def create():
            return self.create_procedure(name, purpose, actor, steps,
                                         changelog="Imported from Hermes by reference")["id"]

        def update(procedure_id):
            self._mirror("procedures", "procedure", procedure_id, {"title": name, "purpose": purpose},
                         actor)
            current = self.procedure_detail(procedure_id)["current"]
            if current is None or current["steps"] != steps:
                self.publish_procedure_version(procedure_id, self.get_procedure(procedure_id)["revision"],
                                               steps, [], [], "Updated from Hermes", actor)
        return self._upsert(ext, "procedure", material, TAGS["skills"], create, update)

    def _sync_file(self, item: dict, ext: str, actor: str, board) -> str:
        path = str(item.get("path") or item["id"])
        title = _title(path.rsplit("/", 1)[-1], path)
        details = " · ".join(str(part) for part in (
            path, f"{item['size']} bytes" if item.get("size") is not None else None, item.get("mtime"))
            if part)
        material = {"title": title, "body_text": details, "url": item.get("url")}

        def create():
            return self.create_capture("link", actor, title=title, body_text=details,
                                       url=material["url"], source="hermes")["id"]

        def update(capture_id):
            self._mirror("captures", "capture", capture_id, material, actor)
        return self._upsert(ext, "capture", material, TAGS["files"], create, update)


class _BoardCache:
    """The one goal and the per-project_id projects that hold imported tasks and jobs; each is a
    Hermes item itself (``hermes:board:…``) so re-runs reuse them."""

    def __init__(self, store: HermesSync, actor: str, summary: dict):
        self.store, self.actor, self.summary = store, actor, summary
        self._goal_id = None
        self._projects: dict[str, str] = {}

    def goal(self) -> str:
        if self._goal_id is None:
            self._goal_id = self._ensure("hermes:board:goal", "goal", {"title": BOARD_GOAL_TITLE},
                                         lambda: self.store.create_goal(
                                             BOARD_GOAL_TITLE, self.actor, BOARD_GOAL_MEASURE)["id"])
        return self._goal_id

    def project(self, project_id, project_title) -> str:
        key = str(project_id) if project_id not in (None, "") else "unsorted"
        title = _title(project_title, UNSORTED_PROJECT_TITLE if key == "unsorted" else f"Hermes project {key}")
        return self._project(key, title)

    def cron_project(self) -> str:
        return self._project("cron", CRON_PROJECT_TITLE)

    def _project(self, key: str, title: str) -> str:
        if key not in self._projects:
            goal_id = self.goal()
            self._projects[key] = self._ensure(
                f"hermes:board:project:{key}", "project", {"title": title},
                lambda: self.store.create_project(title, self.actor, goal_id,
                                                  "Tracked on the Hermes board")["id"],
                lambda local_id: self.store._mirror("projects", "project", local_id, {"title": title},
                                                    self.actor))
        return self._projects[key]

    def _ensure(self, ext: str, kind: str, material: dict, create, update=None) -> str:
        outcome = self.store._upsert(ext, kind, material, TAGS["board"], create,
                                     update or (lambda local_id: None))
        self.store._count(self.summary, BOARD_SOURCE, outcome)
        return self.store._link(ext)["local_id"]
