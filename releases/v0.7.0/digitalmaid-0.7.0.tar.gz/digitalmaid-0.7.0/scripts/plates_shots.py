"""Screenshots of the five JOH plates at 1280 and 390 (0.6.0 Plates, docs/DESIGN.md G4/P6).

Starts a throwaway demo workspace with a Journey profile, signs in, waits for each plate's first
frame, lets the loop settle and saves the shots plus the measured fps to OUT (default
/opt/data/tmp/plates-shots — outside the repo). Usage:

    PLAYWRIGHT_BROWSERS_PATH=/opt/data/pw-browsers .venv/bin/python scripts/plates_shots.py [OUT]
"""

import json
import os
import socket
import sys
import tempfile
import threading
import time
from pathlib import Path

import uvicorn
from playwright.sync_api import sync_playwright

from digitalmaid.__main__ import seed_demo
from digitalmaid.api import create_app

TABS = ["overview", "astro", "bodygraph", "genekeys", "enneagram"]
VIEWPORTS = {"1280": (1280, 800), "390": (390, 844)}


def main(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix="plates-shots-")) / "workspace"
    password = "plates-shots-demo-password"
    seed_demo(root, demo_password=password, seed_joh=True)
    app = create_app(root, scope_id="demo")
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.05)
    url = f"http://127.0.0.1:{port}"
    fps = {}
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for name, (w, h) in VIEWPORTS.items():
            context = browser.new_context(viewport={"width": w, "height": h})
            login = context.request.post(url + "/api/auth/login", headers={"X-Requested-With": "digitalmaid"},
                                         data={"username": "demo", "password": password})
            assert login.ok, login.text()
            context.add_init_script("localStorage.setItem('dm:signed-in', '1')")
            page = context.new_page()
            problems = []
            page.on("pageerror", lambda err: problems.append(str(err)))
            page.on("console", lambda m: problems.append(m.text) if m.type == "error" else None)
            for tab in TABS:
                page.goto(f"{url}/#/joh/{tab}")
                page.wait_for_selector(f".joh-plate[data-plate={tab}] .joh-plate-canvas[data-plate-stats]")
                page.wait_for_timeout(2600)
                stats = json.loads(page.locator(f".joh-plate[data-plate={tab}] .joh-plate-canvas").get_attribute("data-plate-stats"))
                fps[f"{tab}@{name}"] = stats["fps"]
                page.locator(f".joh-plate[data-plate={tab}]").screenshot(path=str(out / f"{tab}-{name}.png"))
                page.screenshot(path=str(out / f"{tab}-{name}-page.png"), full_page=True)
                print(f"{tab}@{name}: fps {stats['fps']} stars {stats['stars']} threads {stats['threads']} lines {stats['lines']}")
            context.close()
            if problems:
                print("console problems:", problems)
        browser.close()
    server.should_exit = True
    (out / "fps.json").write_text(json.dumps(fps, indent=1))
    print(json.dumps(fps))


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else os.environ.get("PLATES_SHOTS", "/opt/data/tmp/plates-shots")))
