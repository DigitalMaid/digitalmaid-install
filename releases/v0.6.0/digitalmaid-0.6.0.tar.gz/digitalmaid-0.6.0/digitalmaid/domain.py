"""Public facade: a scoped ``Store`` over the workspace database.

Every method reads and writes only records whose ``scope_id`` matches the
Store's scope. Sub-domains live in their own modules and share the
``Database`` via mixins.
"""

import json
from pathlib import Path

from digitalmaid.agents import Agents, ensure_builtin_definitions
from digitalmaid.auth import Auth
from digitalmaid.calendar import Calendar
from digitalmaid.capture import Captures
from digitalmaid.checks import Checks
from digitalmaid.db import SCHEMA_VERSION, Database, new_id, now
from digitalmaid.errors import InvariantError
from digitalmaid.heartbeats import Heartbeats
from digitalmaid.i18n import Languages
from digitalmaid.journey import Journey
from digitalmaid.knowledge import Knowledge
from digitalmaid.outputs import Outputs
from digitalmaid.procedures import Procedures
from digitalmaid.scheduling import Scheduling
from digitalmaid.tasks import Tasks
from digitalmaid.views import Views
from digitalmaid.workspace import Outbox, check_opaque_id, load_or_create_manifest


_GOAL_COLUMNS = ("id, scope_id, title, owner, success_measure, outcome_status,"
                 " created_at, updated_at, revision")
_PROJECT_COLUMNS = ("id, scope_id, title, owner, goal_id, success_criteria,"
                    " status, created_at, updated_at, revision")


class GoalsProjects:
    """Goals and projects (revision-checked writes, scope filtered)."""

    def create_goal(self, title: str, owner: str, success_measure: str) -> dict:
        record = {
            "id": new_id(),
            "scope_id": self.scope_id,
            "title": title,
            "owner": owner,
            "success_measure": success_measure,
        }
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO goals (id, scope_id, title, owner, success_measure,"
                " created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (record["id"], self.scope_id, title, owner, success_measure,
                 stamp, stamp))
            self._db.audit(cur, "goal", record["id"], "create", owner,
                           scope_id=self.scope_id)
        return record

    def create_project(self, title: str, owner: str, goal_id: str,
                       success_criteria: str) -> dict:
        record = {
            "id": new_id(),
            "scope_id": self.scope_id,
            "title": title,
            "owner": owner,
            "goal_id": goal_id,
            "success_criteria": success_criteria,
            "status": "Plan",
        }
        stamp = now()
        with self._db.transaction() as cur:
            goal = cur.execute(
                "SELECT id FROM goals WHERE id = ? AND scope_id = ?",
                (goal_id, self.scope_id)).fetchone()
            if goal is None:
                raise ValueError(
                    f"goal {goal_id!r} not found in scope {self.scope_id!r}")
            cur.execute(
                "INSERT INTO projects (id, scope_id, title, owner, goal_id,"
                " success_criteria, status, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (record["id"], self.scope_id, title, owner, goal_id,
                 success_criteria, record["status"], stamp, stamp))
            self._db.audit(cur, "project", record["id"], "create", owner,
                           scope_id=self.scope_id)
        return record

    def get_goal(self, goal_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_GOAL_COLUMNS} FROM goals WHERE id = ? AND scope_id = ?",
            (goal_id, self.scope_id))
        return None if row is None else dict(row)

    def goal_status(self, goal_id: str) -> str | None:
        """'open' until a human records an outcome; tasks never change it."""
        goal = self.get_goal(goal_id)
        return None if goal is None else goal["outcome_status"]

    def record_goal_outcome(self, goal_id: str, achieved: bool, evidence: str,
                            decided_by: str) -> dict:
        if not isinstance(achieved, bool):
            raise ValueError("achieved must be a bool")
        for name, value in (("evidence", evidence),
                            ("decided_by", decided_by)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        goal = self.get_goal(goal_id)
        if goal is None:
            raise LookupError(
                f"goal {goal_id!r} not found in scope {self.scope_id!r}")
        if goal["outcome_status"] != "open":
            raise InvariantError(
                f"goal outcome already decided: {goal['outcome_status']}")
        status = "achieved" if achieved else "not_achieved"
        outcome_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO goal_outcomes (id, scope_id, goal_id, achieved,"
                " evidence, decided_by, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (outcome_id, self.scope_id, goal_id, int(achieved), evidence,
                 decided_by, now()))
            self._db.update_with_revision(
                "goals", goal_id, self.scope_id, goal["revision"],
                {"outcome_status": status}, actor=decided_by,
                action=f"outcome:{status}",
                details={"outcome_id": outcome_id, "evidence": evidence},
                cur=cur, entity_type="goal")
        row = dict(self._db.query_one(
            "SELECT * FROM goal_outcomes WHERE id = ?", (outcome_id,)))
        row["achieved"] = bool(row["achieved"])
        return row

    def get_project(self, project_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_PROJECT_COLUMNS} FROM projects"
            " WHERE id = ? AND scope_id = ?",
            (project_id, self.scope_id))
        return None if row is None else dict(row)

    def list_goals(self) -> list[dict]:
        return [dict(r) for r in self._db.query(
            f"SELECT {_GOAL_COLUMNS} FROM goals WHERE scope_id = ?"
            " ORDER BY created_at, id", (self.scope_id,))]

    def get_goal_outcome(self, goal_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM goal_outcomes WHERE goal_id = ? AND scope_id = ?",
            (goal_id, self.scope_id))
        if row is None:
            return None
        outcome = dict(row)
        outcome["achieved"] = bool(outcome["achieved"])
        return outcome

    def list_projects(self, goal_id: str | None = None) -> list[dict]:
        sql = f"SELECT {_PROJECT_COLUMNS} FROM projects WHERE scope_id = ?"
        params: list = [self.scope_id]
        if goal_id is not None:
            sql += " AND goal_id = ?"
            params.append(goal_id)
        return [dict(r) for r in self._db.query(
            sql + " ORDER BY created_at, id", params)]


class Store(GoalsProjects, Tasks, Outputs, Checks, Views, Scheduling, Heartbeats,
            Agents, Knowledge, Procedures, Calendar, Auth, Captures, Journey, Languages):
    def __init__(self, root, scope_id: str = "personal"):
        self.scope_id = check_opaque_id(scope_id, "scope_id")
        self.root = Path(root)
        self._db = Database(self.root)
        self.workspace_id = load_or_create_manifest(
            self.root, SCHEMA_VERSION)["workspace_id"]
        self._outbox = Outbox(self.root)
        ensure_builtin_definitions(self.root)
        self._init_search()

    def close(self) -> None:
        self._db.close()

    def audit_trail(self, entity_type: str, entity_id: str) -> list[dict]:
        rows = self._db.query(
            "SELECT id, entity_type, entity_id, action, actor, at, details"
            " FROM audit_events WHERE entity_type = ? AND entity_id = ?"
            " AND scope_id = ? ORDER BY at, rowid",
            (entity_type, entity_id, self.scope_id))
        events = []
        for row in rows:
            event = dict(row)
            event["details"] = json.loads(event["details"])
            events.append(event)
        return events
