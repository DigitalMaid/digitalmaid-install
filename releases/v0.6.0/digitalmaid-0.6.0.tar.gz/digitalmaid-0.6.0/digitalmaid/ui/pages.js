// Stage F pages: Knowledge and Journal, Procedures (Stage K name for Skills and
// Workflows), Review Inbox, Deliverables (Stage K name for Outputs). Same rules as
// views.js: textContent only, every control does something real, keyboard reachable.

import { api } from "./api.js";
import { el, append, pill, phasePill, when, empty, emptyState, reasonsList, alertBox, field, form, runnerLabel, confirmDialog, pageHeader, techDetails, moreOptions, currentUser } from "./views.js";
import { t, setLanguage, currentLanguage, LANGUAGES, LANGUAGE_NAMES } from "./i18n.js";

const NOTE_KINDS = ["note", "journal", "research", "decision"];
const LINK_TARGETS = ["task", "project", "goal", "note", "output_version"];

// Display labels for the kind/target vocabularies above; the underlying value (used in
// dataset attributes, filters and API bodies) never changes. The plain label (pills, the
// kind select, link targets) stays lowercase, as it always was; only the filter tabs
// capitalise it.
function noteKindLabel(kind) {
  return t(`pages.knowledge.kind.${kind}`, undefined, kind);
}

function noteKindTabLabel(kind) {
  return kind === "all" ? t("pages.knowledge.kind.all") : t(`pages.knowledge.kindTab.${kind}`, undefined, kind[0].toUpperCase() + kind.slice(1));
}

function linkTargetLabel(type) {
  return t(`pages.knowledge.linkTarget.${type}`, undefined, type.replace("_", " "));
}

function render(container, ...children) {
  container.replaceChildren();
  return append(container, children);
}

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function debounce(fn, ms) {
  let timer = null;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

function header(route, title, how, { meta = null, tools = [] } = {}) {
  return pageHeader(route, title, how, { meta, tools: tools.length ? el("div", { class: "form-actions" }, tools) : null });
}

// --- Knowledge and Journal ----------------------------------------------------------

const knowledge = { kind: "all", query: "" };

function decisionFields(decision) {
  const d = decision || {};
  return el("fieldset", { class: "decision-fields" }, el("legend", {}, t("pages.knowledge.decisionRecord")),
    field(t("pages.knowledge.optionsOnePerLine"), "options", { required: true, rows: "3", value: (d.options || []).join("\n") }, "textarea"),
    el("div", { class: "form-row is-inline" },
      field(t("pages.knowledge.chosenOption"), "chosen", { required: true, value: d.chosen || "" }),
      field(t("pages.knowledge.confidence"), "confidence", { type: "number", min: "1", max: "5", step: "1", required: true, value: d.confidence ?? "3" }),
      field(t("pages.knowledge.reviewDate"), "review_date", { type: "date", required: true, value: d.review_date || "" })),
    field(t("pages.knowledge.reasoning"), "reasoning", { required: true, rows: "2", value: d.reasoning || "" }, "textarea"),
    field(t("pages.knowledge.expectedResult"), "expected_result", { required: true, rows: "2", value: d.expected_result || "" }, "textarea"));
}

function readDecision(data) {
  return {
    options: data.options.split("\n").map((s) => s.trim()).filter(Boolean),
    chosen: data.chosen, reasoning: data.reasoning, expected_result: data.expected_result,
    confidence: Number.parseInt(data.confidence, 10), review_date: data.review_date,
  };
}

function noteItem(note, onOpen, selected) {
  const reviewDue = note.kind === "decision" && !note.outcome && note.decision && note.decision.review_date <= todayIso();
  return el("li", {},
    el("button", { class: `task-row${selected ? " is-selected" : ""}`, type: "button", dataset: { noteId: note.id }, "aria-current": selected ? "true" : null, onclick: () => onOpen(note.id) },
      el("span", {}, note.title, el("small", {}, note.kind === "journal" ? t("pages.knowledge.journalMeta", { date: note.entry_date }) : noteKindLabel(note.kind),
        note.snippet ? ` · ${note.snippet}` : "", note.archived_at ? t("pages.knowledge.archivedSuffix") : "")),
      pill(reviewDue ? "required" : "not_applicable", reviewDue ? t("pages.knowledge.reviewDue") : noteKindLabel(note.kind))));
}

export async function renderKnowledgePage(view, ctx, noteId) {
  const kind = knowledge.kind === "all" ? undefined : knowledge.kind;
  const [notes, searchHits] = await Promise.all([
    api.notes(kind),
    knowledge.query ? api.search(knowledge.query, 50).then((r) => r.notes) : Promise.resolve(null),
  ]);
  const shown = searchHits ? searchHits.filter((h) => !kind || h.kind === kind) : notes;
  const listNode = el("ul", { class: "list", id: "note-list" });
  const editorNode = el("section", { class: "panel", id: "note-editor", "aria-label": t("pages.knowledge.noteEditor") }, empty(t("pages.knowledge.selectNote")));
  const status = el("div", { id: "note-search-status", class: "meta", role: "status", "aria-live": "polite" },
    knowledge.query ? t("pages.knowledge.matchCount", { count: shown.length, query: knowledge.query }) : t("pages.knowledge.noteCount", { count: shown.length }));

  const openNote = async (id) => {
    location.hash = `#/knowledge/${id}`;
  };
  const openNewNote = () => { const d = document.getElementById("new-note"); if (d) { d.open = true; d.querySelector("[name=title]")?.focus(); } };
  render(listNode, shown.length ? shown.map((n) => noteItem(n, openNote, n.id === noteId))
    : el("li", {}, knowledge.query ? empty(t("pages.knowledge.noNotesMatch"))
      : emptyState("knowledge", t("pages.knowledge.emptyState"), t("pages.knowledge.newNote"), openNewNote)));

  const tabs = el("div", { class: "tabs", role: "tablist", "aria-label": t("pages.knowledge.noteKindsLabel") },
    ["all", ...NOTE_KINDS].map((k) => el("button", {
      class: "tab", type: "button", role: "tab", dataset: { kindTab: k }, "aria-selected": String(knowledge.kind === k),
      onclick: () => { knowledge.kind = k; ctx.route(); },
    }, noteKindTabLabel(k))));

  const searchInput = el("input", { id: "note-search", type: "search", value: knowledge.query, placeholder: t("pages.knowledge.searchPlaceholder"), autocomplete: "off", "aria-describedby": "note-search-status" });
  searchInput.addEventListener("input", debounce(() => { knowledge.query = searchInput.value.trim(); ctx.route({ keepFocus: "#note-search" }); }, 250));

  let journalTools = null;
  if (knowledge.kind === "journal") {
    const today = todayIso();
    const existing = notes.find((n) => n.kind === "journal" && n.entry_date === today) || null;
    const button = el("button", { class: "btn is-primary", type: "button", id: "todays-entry", dataset: { written: String(Boolean(existing)) } },
      existing ? t("pages.knowledge.todayEntryOpen", { date: today }) : t("pages.knowledge.todayEntryWrite", { date: today }));
    button.addEventListener("click", async () => {
      button.disabled = true;
      try {
        let entry = existing;
        if (!entry) {
          try {
            entry = await api.createNote({ kind: "journal", title: t("pages.knowledge.journalEntryTitle", { date: today }), body_md: "", actor: "ui", entry_date: today });
          } catch (error) {
            // Someone else wrote today's entry since the list loaded: open theirs.
            if (error.status !== 409) throw error;
            entry = await api.journalEntry(today);
          }
        }
        location.hash = `#/knowledge/${entry.id}`;
      } catch (error) {
        ctx.showGlobal(t("pages.knowledge.couldNotOpenTodayEntry", { message: error.message }), "error", error.reasons);
        button.disabled = false;
      }
    });
    journalTools = el("div", { class: "form-actions" }, button);
  }

  const newForm = newNoteForm(ctx);
  render(view,
    header("knowledge", t("pages.knowledge.title"), t("pages.knowledge.how")),
    el("div", { class: "knowledge-layout" },
      el("section", { class: "stack", "aria-label": t("pages.knowledge.notesLabel") },
        tabs,
        el("div", { class: "form-row" }, el("label", { for: "note-search" }, t("pages.knowledge.searchNotes")), searchInput, status),
        journalTools,
        listNode,
        el("details", { class: "action", id: "new-note", open: noteId ? null : true }, el("summary", {}, t("pages.knowledge.newNote")), newForm)),
      editorNode));
  if (noteId) await renderNoteEditor(editorNode, noteId, ctx);
}

// Tier 1 is the title; the kind follows the current filter tab. Kind, author, entry date,
// the decision record and the body wait under More options, which opens itself when the
// preselected kind needs more than a title (a decision record).
function newNoteForm(ctx) {
  const preselected = knowledge.kind === "all" ? "note" : knowledge.kind;
  const kindSelect = field(t("pages.knowledge.kindLabel"), "kind", { options: NOTE_KINDS.map((k) => ({ value: k, label: noteKindLabel(k) })), value: preselected }, "select");
  const entryRow = field(t("pages.knowledge.entryDateJournal"), "entry_date", { type: "date", value: todayIso() });
  const decisionRow = decisionFields(null);
  const more = moreOptions([
    el("div", { class: "form-row is-inline" }, kindSelect, field(t("pages.knowledge.author"), "actor", { required: true, value: currentUser() || "" })),
    entryRow, decisionRow,
    field(t("pages.knowledge.bodyMarkdown"), "body_md", { rows: "4" }, "textarea"),
  ], { open: preselected === "decision" });
  const toggle = () => {
    const kind = kindSelect.querySelector("select").value;
    entryRow.hidden = kind !== "journal";
    decisionRow.hidden = kind !== "decision";
    if (kind === "decision") more.open = true;
  };
  kindSelect.querySelector("select").addEventListener("change", toggle);
  const node = form([
    field(t("pages.knowledge.noteTitle"), "title", { required: true }),
    more,
  ], t("pages.knowledge.createNote"), async (data) => {
    const body = { kind: data.kind, title: data.title, body_md: data.body_md || "", actor: data.actor };
    if (data.kind === "journal") body.entry_date = data.entry_date;
    if (data.kind === "decision") body.decision = readDecision(data);
    const note = await api.createNote(body);
    location.hash = `#/knowledge/${note.id}`;
  });
  node.id = "note-form";
  toggle();
  return node;
}

async function renderNoteEditor(container, noteId, ctx) {
  let note;
  try { note = await api.note(noteId); } catch (error) {
    render(container, alertBox("error", t("pages.knowledge.couldNotLoadNote", { message: error.message }), error.reasons));
    return;
  }
  container.dataset.noteId = note.id;
  ctx.recordRecent?.({ type: "note", id: note.id, title: note.title });
  const refresh = () => ctx.route();
  const readOnly = Boolean(note.archived_at);
  const editForm = form([
    el("div", { class: "form-row is-inline" }, field(t("pages.knowledge.noteTitle"), "title", { required: true, value: note.title, disabled: readOnly }), field(t("pages.knowledge.editor"), "actor", { required: true, value: "ui", disabled: readOnly })),
    note.kind === "decision" ? decisionFields(note.decision) : null,
    field(t("pages.knowledge.bodyMarkdown"), "body_md", { rows: "8", value: note.body_md, disabled: readOnly }, "textarea"),
  ], t("common.save"), async (data) => {
    const body = { revision: note.revision, title: data.title, body_md: data.body_md, actor: data.actor };
    if (note.kind === "decision") body.decision = readDecision(data);
    await api.updateNote(note.id, body);
    refresh();
  });
  editForm.querySelector("button[type=submit]").disabled = readOnly;

  const archiveBox = el("div", { class: "form-actions" });
  const archiveButton = el("button", { class: "btn is-small", type: "button", disabled: readOnly }, t("pages.knowledge.archiveEllipsis"));
  archiveButton.addEventListener("click", () => {
    render(archiveBox,
      el("span", { class: "meta" }, t("pages.knowledge.archiveConfirmQuestion")),
      el("button", { class: "btn is-primary is-small", type: "button", onclick: async () => {
        try { await api.archiveNote(note.id, { revision: note.revision, actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(t("pages.knowledge.archiveRefused", { message: error.message }), "error", error.reasons); }
      } }, t("pages.knowledge.confirmArchive")),
      el("button", { class: "btn is-small", type: "button", onclick: () => render(archiveBox, archiveButton) }, t("common.cancel")));
    archiveBox.querySelector("button").focus();
  });
  render(archiveBox, archiveButton);

  const linkPicker = linkPickerForm(note, refresh, ctx);
  const outcomeForm = note.kind === "decision" && !note.outcome
    ? form([field(t("pages.knowledge.outcomeLabel"), "outcome", { required: true, rows: "2" }, "textarea"), field(t("pages.knowledge.recordedBy"), "actor", { required: true })],
      t("pages.knowledge.recordDecisionOutcome"), async (data) => { await api.decisionOutcome(note.id, data); refresh(); })
    : null;

  render(container,
    el("div", { class: "panel-header" },
      el("div", {}, el("h2", {}, note.title), el("div", { class: "meta" }, pill(note.kind, noteKindLabel(note.kind)), note.entry_date ? ` · ${note.entry_date}` : "",
        t("pages.knowledge.revisionUpdatedMeta", { revision: note.revision, updated: when(note.updated_at) }), note.archived_at ? t("pages.knowledge.archivedMeta", { archived: when(note.archived_at) }) : "")),
      archiveBox),
    readOnly ? alertBox("info", t("pages.knowledge.archivedReadOnly")) : null,
    note.kind === "decision" && note.decision ? el("dl", { class: "kv" },
      el("dt", {}, t("pages.knowledge.chosen")), el("dd", {}, t("pages.knowledge.chosenConfidence", { chosen: note.decision.chosen, confidence: note.decision.confidence })),
      el("dt", {}, t("pages.knowledge.review")), el("dd", {}, note.decision.review_date,
        note.outcome ? t("pages.knowledge.outcomeRecordedMeta", { when: when(note.outcome_at), outcome: note.outcome })
          : note.decision.review_date <= todayIso() ? t("pages.knowledge.reviewDueMeta") : "")) : null,
    outcomeForm ? el("details", { class: "action", open: true }, el("summary", {}, t("pages.knowledge.decisionOutcome")), outcomeForm) : null,
    editForm,
    el("section", { class: "drawer-section" }, el("h4", {}, t("pages.knowledge.links")),
      note.links.length ? el("ul", { class: "list" }, note.links.map((l) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" },
          el("span", {}, `${linkTargetLabel(l.target_type)}: ${l.target_title ?? l.target_id}`),
          el("div", { class: "form-actions" },
            l.target_type === "task" ? el("button", { class: "btn is-small", type: "button", onclick: () => ctx.openTask(l.target_id) }, t("pages.knowledge.openTask")) : null,
            l.target_type === "note" ? el("button", { class: "btn is-small", type: "button", onclick: () => { location.hash = `#/knowledge/${l.target_id}`; } }, t("pages.knowledge.openNote")) : null,
            el("button", { class: "btn is-quiet is-small", type: "button", "aria-label": t("pages.knowledge.unlinkAriaLabel", { type: linkTargetLabel(l.target_type), title: l.target_title ?? "" }), onclick: async () => {
              try { await api.unlinkNote(note.id, { target_type: l.target_type, target_id: l.target_id, actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(t("pages.knowledge.unlinkRefused", { message: error.message }), "error", error.reasons); }
            } }, t("pages.knowledge.unlink")))))))
        : empty(t("pages.knowledge.notLinked")),
      el("details", { class: "action" }, el("summary", {}, t("pages.knowledge.linkTo")), linkPicker)));
  container.querySelector("h2")?.setAttribute("tabindex", "-1");
}

function linkPickerForm(note, refresh, ctx) {
  const typeField = field(t("pages.knowledge.targetType"), "target_type", { options: LINK_TARGETS.map((v) => ({ value: v, label: linkTargetLabel(v) })) }, "select");
  const targetField = field(t("pages.knowledge.target"), "target_id", { options: [] }, "select");
  const targetSelect = targetField.querySelector("select");
  const load = async () => {
    const type = typeField.querySelector("select").value;
    targetSelect.replaceChildren(el("option", { value: "" }, t("common.loading")));
    let options = [];
    try {
      if (type === "goal") options = (await api.goals()).map((g) => ({ value: g.id, label: g.title }));
      else if (type === "project") options = (await api.projects()).map((p) => ({ value: p.id, label: p.title }));
      else if (type === "task") options = (await api.get("/tasks")).map((tk) => ({ value: tk.id, label: `${tk.title} (${t(`phase.${tk.status}`, undefined, tk.status)})` }));
      else if (type === "note") options = (await api.notes()).filter((n) => n.id !== note.id).map((n) => ({ value: n.id, label: `${n.title} (${noteKindLabel(n.kind)})` }));
      else options = (await api.outputs()).map((v) => ({ value: v.id, label: `${v.task_title} v${v.version}` }));
    } catch (error) { ctx.showGlobal(t("pages.knowledge.couldNotLoadTargets", { type: linkTargetLabel(type), message: error.message })); }
    targetSelect.replaceChildren(...(options.length ? options.map((o) => el("option", { value: o.value }, o.label)) : [el("option", { value: "" }, t("pages.knowledge.noTargetsAvailable", { type: linkTargetLabel(type) }))]));
  };
  typeField.querySelector("select").addEventListener("change", load);
  const node = form([el("div", { class: "form-row is-inline" }, typeField, targetField)], t("pages.knowledge.link"), async (data) => {
    if (!data.target_id) throw new Error(t("pages.knowledge.chooseTargetFirst"));
    await api.linkNote(note.id, { target_type: data.target_type, target_id: data.target_id, actor: "ui" });
    refresh();
  });
  load();
  return node;
}

// --- Skills and Workflows (procedures) -----------------------------------------------

function stepsToText(steps) {
  return steps.map((s) => `${s.title} | ${s.instruction_md} | ${s.expected_evidence} | ${s.role}`).join("\n");
}

// A bare step title is enough: the evidence then defaults to the title itself, so a
// one-word-per-line list already publishes (the server refuses empty evidence).
function textToSteps(text) {
  return text.split("\n").map((s) => s.trim()).filter(Boolean).map((line) => {
    const [title = "", instruction_md = "", expected_evidence = "", role = "human"] = line.split("|").map((s) => s.trim());
    return { title, instruction_md, expected_evidence: expected_evidence || title, role: role || "human" };
  });
}

function stepsField(value) {
  return field(t("pages.procedures.stepsLabel"), "steps", { required: true, rows: "5", value, placeholder: t("pages.procedures.stepsPlaceholder") }, "textarea");
}

function versionForm(procedure, { changelog = "", steps = null, onDone, proposalId = null }) {
  const current = procedure.current;
  const node = form([
    stepsField(stepsToText(steps || current.steps)),
    el("div", { class: "form-row is-inline" },
      field(t("pages.procedures.inputsCommaSeparated"), "inputs", { value: current.inputs.join(", ") }),
      field(t("pages.procedures.outputsCommaSeparated"), "outputs", { value: current.outputs.join(", ") }),
      field(t("pages.procedures.publishedByHuman"), "created_by", { required: true })),
    field(t("pages.procedures.changelogLabel"), "changelog", { required: true, rows: "2", value: changelog }, "textarea"),
  ], proposalId ? t("pages.procedures.publishApplyingProposal") : t("pages.procedures.publishVersion", { version: procedure.current_version + 1 }), async (data) => {
    const body = {
      revision: procedure.revision, steps: textToSteps(data.steps),
      inputs: data.inputs.split(",").map((s) => s.trim()).filter(Boolean),
      outputs: data.outputs.split(",").map((s) => s.trim()).filter(Boolean),
      changelog: data.changelog,
    };
    if (proposalId) await api.applyProposal(proposalId, { ...body, actor: data.created_by });
    else await api.publishProcedureVersion(procedure.id, { ...body, created_by: data.created_by });
    onDone();
  });
  node.id = proposalId ? "apply-proposal-form" : "new-version-form";
  return node;
}

export async function renderProceduresPage(view, ctx, procedureId) {
  const procedures = await api.procedures();
  const openNewProcedure = () => { const d = document.getElementById("new-procedure"); if (d) { d.open = true; d.querySelector("[name=title]")?.focus(); } };
  const list = el("ul", { class: "list" }, procedures.length
    ? procedures.map((p) => el("li", {}, el("button", { class: `task-row${p.id === procedureId ? " is-selected" : ""}`, type: "button", dataset: { procedure: p.id }, "aria-current": p.id === procedureId ? "true" : null, onclick: () => { location.hash = `#/procedures/${p.id}`; } },
      el("span", {}, p.title, el("small", {}, `${p.purpose} · v${p.current_version}`)), pill(p.status === "active" ? "available" : p.status === "retired" ? "missing" : "required", t(`status.${p.status}`, undefined, p.status)))))
    : el("li", {}, emptyState("procedures", t("pages.procedures.emptyState"), t("pages.procedures.newProcedure"), openNewProcedure)));
  // Tier 1 (D3): a title and the steps — a procedure without steps cannot exist server-side.
  // Purpose falls back to the title; the author defaults to the signed-in user.
  const creator = form([
    field(t("pages.procedures.titleLabel"), "title", { required: true }),
    stepsField(""),
    moreOptions([
      el("div", { class: "form-row is-inline" }, field(t("pages.procedures.purpose"), "purpose", { placeholder: t("pages.procedures.purposePlaceholder") }), field(t("pages.procedures.createdBy"), "created_by", { required: true, value: currentUser() || "" })),
      el("div", { class: "form-row is-inline" }, field(t("pages.procedures.inputsCommaSeparated"), "inputs", {}), field(t("pages.procedures.outputsCommaSeparated"), "outputs", {})),
    ]),
  ], t("pages.procedures.createProcedure"), async (data) => {
    const created = await api.createProcedure({
      title: data.title, purpose: data.purpose.trim() || data.title, created_by: data.created_by, steps: textToSteps(data.steps),
      inputs: data.inputs.split(",").map((s) => s.trim()).filter(Boolean), outputs: data.outputs.split(",").map((s) => s.trim()).filter(Boolean),
      changelog: t("pages.procedures.initialVersion"),
    });
    location.hash = `#/procedures/${created.id}`;
  });
  creator.id = "procedure-form";
  const detail = el("section", { class: "panel", id: "procedure-detail", "aria-label": t("pages.procedures.detailLabel") }, empty(t("pages.procedures.selectProcedure")));
  render(view,
    header("procedures", t("pages.procedures.title"), t("pages.procedures.how")),
    el("div", { class: "knowledge-layout" },
      el("section", { class: "stack", "aria-label": t("pages.procedures.proceduresLabel") }, list, el("details", { class: "action", id: "new-procedure", open: procedures.length ? null : true }, el("summary", {}, t("pages.procedures.newProcedure")), creator)),
      detail));
  if (procedureId) await renderProcedureDetail(detail, procedureId, ctx);
}

async function renderProcedureDetail(container, procedureId, ctx, extra = null) {
  let procedure;
  try { procedure = await api.procedure(procedureId); } catch (error) {
    render(container, alertBox("error", t("pages.procedures.couldNotLoadProcedure", { message: error.message }), error.reasons));
    return;
  }
  const refresh = () => renderProcedureDetail(container, procedureId, ctx);
  const projects = await api.projects();
  const runResult = el("div", { class: "stack", id: "run-result" });
  const runForm = procedure.status === "retired" ? alertBox("info", t("pages.procedures.retiredCannotRun")) : form([
    el("div", { class: "form-row is-inline" },
      field(t("pages.procedures.projectLabel"), "project_id", { options: projects.map((p) => ({ value: p.id, label: p.title })) }, "select"),
      field(t("pages.procedures.versionLabel"), "version", { options: procedure.versions.map((v) => ({ value: String(v.version), label: `v${v.version}` })).reverse() }, "select"),
      field(t("pages.procedures.taskOwner"), "owner", { required: true })),
  ], t("pages.procedures.runInProject"), async (data) => {
    const run = await api.instantiateProcedure(procedure.id, { version: Number.parseInt(data.version, 10), project_id: data.project_id, owner: data.owner });
    render(runResult, alertBox("ok", t("pages.procedures.stepTasksCreated", { count: run.tasks.length })),
      el("ol", { class: "list" }, run.tasks.map((tk) => el("li", {}, el("button", { class: "task-row", type: "button", dataset: { stepTask: tk.id }, onclick: () => ctx.openTask(tk.id) }, el("span", {}, tk.title, el("small", {}, t("pages.procedures.stepNext", { index: tk.step_index + 1, next: tk.next_action }))), phasePill(tk.status))))));
    runResult.querySelector("button")?.focus();
  });
  if (runForm.tagName === "FORM") runForm.id = "run-procedure-form";

  const statusTools = el("div", { class: "form-actions" },
    pill(procedure.status === "active" ? "available" : procedure.status === "retired" ? "missing" : "required", t(`status.${procedure.status}`, undefined, procedure.status)),
    procedure.status === "draft" ? el("button", { class: "btn is-small", type: "button", onclick: async () => { try { await api.activateProcedure(procedure.id, { actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, t("pages.procedures.activate")) : null,
    procedure.status !== "retired" ? el("button", { class: "btn is-quiet is-small", type: "button", onclick: async () => { try { await api.retireProcedure(procedure.id, { actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, t("pages.procedures.retire")) : null);

  const proposalForm = form([
    field(t("pages.procedures.fromTask"), "from_task_id", { options: (await api.get("/tasks")).filter((tk) => tk.procedure_id === procedure.id).map((tk) => ({ value: tk.id, label: `${tk.title} (${t(`phase.${tk.status}`, undefined, tk.status)})` })) }, "select"),
    field(t("pages.procedures.learning"), "text", { required: true, rows: "2" }, "textarea"),
    field(t("pages.procedures.proposedBy"), "actor", { required: true }),
  ], t("pages.procedures.proposeLearning"), async (data) => { await api.proposeLearning(procedure.id, data); refresh(); });

  const roleLabel = (role) => (role === "human" ? t("pages.procedures.roleHuman") : role);
  render(container,
    el("div", { class: "panel-header" }, el("div", {}, el("h2", {}, procedure.title), el("div", { class: "meta" }, `${procedure.purpose} · ${t("pages.procedures.currentVersionMeta", { version: procedure.current_version })}`)), statusTools),
    extra,
    el("section", { class: "drawer-section" }, el("h4", {}, t("pages.procedures.stepsHeading", { version: procedure.current_version })),
      el("ol", { class: "steps" }, procedure.current.steps.map((s) => el("li", {}, el("strong", {}, s.title), el("div", { class: "meta" }, s.instruction_md), el("div", { class: "meta" }, t("pages.procedures.evidenceRole", { evidence: s.expected_evidence, role: roleLabel(s.role) }))))),
      el("div", { class: "meta" }, t("pages.procedures.inputsOutputsMeta", { inputs: procedure.current.inputs.join(", ") || t("common.none"), outputs: procedure.current.outputs.join(", ") || t("common.none") }))),
    el("section", { class: "drawer-section" }, el("h4", {}, t("pages.procedures.runInProjectHeading")), runForm, runResult),
    el("section", { class: "drawer-section" }, el("h4", {}, t("pages.procedures.versionHistoryHeading")),
      el("div", { class: "stack" }, procedure.versions.slice().reverse().map((v) => el("details", { class: "action", dataset: { version: v.version } },
        el("summary", {}, t("pages.procedures.versionSummary", { version: v.version, when: when(v.created_at), createdBy: v.created_by, changelog: v.changelog })),
        el("div", { class: "form" }, el("div", { class: "meta mono" }, t("pages.procedures.sha256Meta", { sha256: v.sha256 })),
          el("ol", { class: "steps" }, v.steps.map((s) => el("li", {}, s.title, el("div", { class: "meta" }, t("pages.procedures.evidenceRoleLine", { instruction: s.instruction_md, evidence: s.expected_evidence, role: roleLabel(s.role) }))))))))),
      procedure.status !== "retired" ? el("details", { class: "action" }, el("summary", {}, t("pages.procedures.publishNewVersion")), versionForm(procedure, { onDone: refresh })) : null),
    el("section", { class: "drawer-section" }, el("h4", {}, t("pages.procedures.learningProposalsHeading")),
      procedure.proposals.length ? el("ul", { class: "list" }, procedure.proposals.map((p) => el("li", { class: "list-item", dataset: { proposal: p.id } },
        el("div", { class: "list-item-title" }, el("span", {}, p.text), pill(p.status === "applied" ? "available" : p.status === "rejected" ? "missing" : "required", t(`status.${p.status}`, undefined, p.status))),
        el("div", { class: "meta" }, t("pages.procedures.proposedByMeta", { proposedBy: p.proposed_by, when: when(p.created_at) }),
          p.applied_version ? t("pages.procedures.appliedInVersion", { version: p.applied_version }) : "",
          p.decided_by && p.status !== "open" ? t("pages.procedures.decidedByMeta", { decidedBy: p.decided_by }) : ""),
        p.status === "open" && procedure.status !== "retired" ? el("div", { class: "form-actions" },
          el("button", { class: "btn is-small is-primary", type: "button", onclick: () => renderProcedureDetail(container, procedureId, ctx,
            el("section", { class: "panel", "aria-label": t("pages.procedures.applyProposalAriaLabel") }, el("h3", {}, t("pages.procedures.applyProposalHeading")), el("p", { class: "meta" }, p.text),
              versionForm(procedure, { proposalId: p.id, changelog: t("pages.procedures.appliedProposalPrefix", { id: p.id }), onDone: refresh }))) }, t("pages.procedures.applyEllipsis")),
          el("button", { class: "btn is-small", type: "button", onclick: async () => { try { await api.rejectProposal(p.id, { actor: "ui" }); refresh(); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, t("pages.procedures.reject"))) : null)))
        : empty(t("pages.procedures.noProposalsYet")),
      el("details", { class: "action" }, el("summary", {}, t("pages.procedures.proposeLearningFromTask")), proposalForm)),
    procedure.instantiations.length ? el("section", { class: "drawer-section" }, el("h4", {}, t("pages.procedures.runsHeading")),
      el("ul", { class: "list" }, procedure.instantiations.map((r) => el("li", { class: "list-item" }, t("pages.procedures.runSummary", { project: r.project_title, version: r.procedure_version, done: r.done, steps: r.steps, when: when(r.created_at) }))))) : null);
  if (extra) container.querySelector("#apply-proposal-form textarea")?.focus();
}

// --- Review Inbox --------------------------------------------------------------------

function reviewItem(task, onOpen, ...extra) {
  return el("li", {}, el("button", { class: "task-row", type: "button", dataset: { taskId: task.id }, onclick: () => onOpen(task.id) },
    el("span", {}, task.title, el("small", {}, task.project_title ? `${task.project_title} · ` : "", ...extra)), phasePill(task.status)));
}

export async function renderReviewPage(view, ctx) {
  const inbox = await api.reviewInbox();
  render(view,
    header("review", t("pages.review.title"), t("pages.review.how"),
      { meta: el("p", { class: "meta" }, t("pages.review.itemsWaiting", { count: inbox.count })) }),
    el("div", { class: "grid is-thirds" },
      el("section", { class: "panel", "aria-labelledby": "review-check-title" }, el("h2", { id: "review-check-title" }, t("pages.review.awaitingCheck", { count: inbox.awaiting_check.length })),
        el("ul", { class: "list", id: "review-awaiting-check" }, inbox.awaiting_check.length
          ? inbox.awaiting_check.map((tk) => reviewItem(tk, (id) => ctx.openTask(id, { section: "check" }), t("pages.review.versionWaitingForCheck", { version: tk.latest_version.version, when: when(tk.latest_version.created_at) })))
          : el("li", {}, emptyState("review", t("pages.review.awaitingCheckEmpty"), t("pages.review.openDeliverables"), "#/outputs")))),
      el("section", { class: "panel", "aria-labelledby": "review-revision-title" }, el("h2", { id: "review-revision-title" }, t("pages.review.awaitingRevision", { count: inbox.awaiting_revision.length })),
        el("ul", { class: "list", id: "review-awaiting-revision" }, inbox.awaiting_revision.length
          ? inbox.awaiting_revision.map((tk) => reviewItem(tk, (id) => ctx.openTask(id, { section: "output" }), t("pages.review.correctionMeta", { action: tk.correction.action, owner: tk.correction.owner })))
          : el("li", {}, emptyState("correction", t("pages.review.awaitingRevisionEmpty"))))),
      el("section", { class: "panel", "aria-labelledby": "review-decision-title" }, el("h2", { id: "review-decision-title" }, t("pages.review.decisionReviewsDue", { count: inbox.decision_reviews_due.length })),
        el("ul", { class: "list", id: "review-decisions" }, inbox.decision_reviews_due.length
          ? inbox.decision_reviews_due.map((n) => el("li", {}, el("button", { class: "task-row", type: "button", onclick: () => { location.hash = `#/knowledge/${n.id}`; } },
            el("span", {}, n.title, el("small", {}, t("pages.review.chosenReviewDate", { chosen: n.decision.chosen, reviewDate: n.decision.review_date }))), pill("required", t("pages.knowledge.reviewDue")))))
          : el("li", {}, emptyState("knowledge", t("pages.review.decisionReviewsDueEmpty"), t("pages.knowledge.newNote"), "#/knowledge"))))));
}

// --- Outputs -------------------------------------------------------------------------

const outputs = { accepted: "" };

export async function renderOutputsPage(view, ctx) {
  const versions = await api.outputs(outputs.accepted);
  const filter = el("select", { id: "outputs-filter", "aria-label": t("pages.outputs.filterAriaLabel") },
    el("option", { value: "" }, t("pages.outputs.allVersions")), el("option", { value: "false" }, t("pages.outputs.notAcceptedFilter")), el("option", { value: "true" }, t("pages.outputs.acceptedFilter")));
  filter.value = outputs.accepted;
  filter.addEventListener("change", () => { outputs.accepted = filter.value; ctx.route({ keepFocus: "#outputs-filter" }); });
  render(view,
    header("outputs", t("pages.outputs.title"), t("pages.outputs.how"),
      { tools: [el("div", { class: "form-row" }, el("label", { for: "outputs-filter" }, t("pages.outputs.show")), filter)] }),
    el("ul", { class: "list", id: "outputs-list" }, versions.length ? versions.map((v) => el("li", { class: "output-item" },
      el("button", { class: "task-row output-row", type: "button", dataset: { versionId: v.id }, onclick: () => ctx.openTask(v.task_id) },
        el("span", {}, t("pages.outputs.taskVersion", { title: v.task_title, version: v.version }), v.superseded ? t("pages.outputs.superseded") : "",
          el("small", {}, t("pages.outputs.checkMeta", { when: when(v.created_at), status: t(`status.${v.check_status}`, undefined, v.check_status) }),
            v.accepted ? t("pages.outputs.acceptedBy", { name: v.acceptance.accepted_by }) : t("status.not_accepted"), v.execution ? ` · ${runnerLabel(v.execution)}` : "")),
        el("span", { class: "form-actions" }, phasePill(v.task_status), pill(v.accepted ? "available" : "required", v.accepted ? t("status.accepted") : t("status.not_accepted")))),
      techDetails(t("pages.outputs.sha256Meta", { sha256: v.sha256 }), el("br"), t("pages.outputs.versionExecutionMeta", { id: v.id, executionId: v.execution_id }))))
      : el("li", {}, outputs.accepted ? empty(t("pages.outputs.noVersionsMatchFilter"))
        : emptyState("outputs", t("pages.outputs.emptyState"), t("pages.outputs.openGoals"), "#/goals"))));
}


// --- Settings and Connections ---------------------------------------------------------------

export async function renderSettingsPage(container, ctx) {
  const settings = await api.settings();
  const notice = el("div", { class: "stack", id: "settings-notice" });
  const agentPill = (a) => a.model_policy.kind === "fixture" ? pill("not_applicable", t("pages.settings.testFixture"))
    : pill(a.runner_status.configured ? "available" : "required", a.runner_status.configured ? t("pages.settings.liveConfigured") : t("pages.settings.liveUnconfigured"));
  const userRow = (u) => {
    const membership = u.memberships.find((m) => m.scope_id === settings.scope_id);
    const roleSelect = el("select", { "aria-label": t("pages.settings.roleOfUser", { username: u.username }), disabled: Boolean(u.disabled_at) || null,
      onchange: async (e) => {
        const from = membership?.role ?? "none", to = e.target.value;
        const fromLabel = t(`status.${from}`, undefined, from), toLabel = t(`status.${to}`, undefined, to);
        const confirmed = await confirmDialog({
          title: t("pages.settings.changeRoleTitle"),
          message: t("pages.settings.changeRoleMessage", { username: u.username, scope: settings.scope_id, from: fromLabel, to: toLabel })
            + (to !== "owner" && from === "owner" ? t("pages.settings.loseOwnerRightsWarning") : ""),
          confirmLabel: t("pages.settings.changeToRole", { to: toLabel }),
        });
        if (!confirmed) { e.target.value = from; return; }
        try { await api.setMembership(u.id, to); await ctx.route(); } catch (error) { e.target.value = from; notice.replaceChildren(alertBox("error", error.message, error.reasons)); } } },
      ["owner", "member", "viewer"].map((r) => el("option", { value: r, selected: membership?.role === r || null }, t(`status.${r}`))));
    return el("li", { class: "list-item", dataset: { username: u.username } },
      el("div", { class: "list-item-title" }, el("strong", {}, u.username), u.disabled_at ? pill("missing", t("status.disabled")) : pill("available", membership ? t(`status.${membership.role}`) : t("pages.settings.noMembershipHere"))),
      el("div", { class: "meta" }, t("pages.settings.createdMemberships", { when: when(u.created_at), memberships: u.memberships.map((m) => `${m.scope_id}=${m.role}`).join(", ") || t("pages.settings.noneWord") })),
      u.disabled_at ? null : el("div", { class: "form-actions" }, roleSelect,
        el("button", { class: "btn is-small", type: "button", dataset: { write: "true" }, onclick: async () => {
          try { await api.disableUser(u.id); await ctx.route(); } catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); } } }, t("pages.settings.disable"))));
  };
  const newUser = settings.users ? form([
    el("div", { class: "form-row is-inline" },
      field(t("pages.settings.username"), "new_username", { required: true, autocomplete: "off" }),
      field(t("pages.settings.passwordMin8"), "new_password", { type: "password", required: true, autocomplete: "new-password" }),
      field(t("pages.settings.roleLabel"), "new_role", { options: ["viewer", "member", "owner"].map((r) => ({ value: r, label: t(`status.${r}`) })) }, "select")),
  ], t("pages.settings.addUser"), async (data) => { await api.createUser({ username: data.new_username, password: data.new_password, role: data.new_role }); await ctx.route(); }, { inline: false }) : null;
  const backup = settings.backup.last_backup_at
    ? t("pages.settings.backupLine", { when: when(settings.backup.last_backup_at), path: settings.backup.last_backup_path })
    : t("pages.settings.noBackupYet");
  // API tokens: owner only; the token value appears exactly once, in the response to create.
  const tokenOnce = el("div", { id: "token-once-box" });
  const tokenList = el("ul", { class: "list", id: "settings-tokens" });
  const renderTokens = (tokens) => tokenList.replaceChildren(...(tokens.length ? tokens.map((tk) => el("li", { class: "list-item", dataset: { tokenId: tk.id } },
    el("div", { class: "list-item-title" }, el("strong", {}, tk.name), tk.revoked_at ? pill("missing", t("status.revoked")) : pill("available", t("status.active"))),
    el("div", { class: "meta" }, t("pages.settings.tokenMeta", { username: tk.username, created: when(tk.created_at), lastUsed: tk.last_used_at ? when(tk.last_used_at) : t("pages.settings.never") }),
      tk.revoked_at ? t("pages.settings.revokedMeta", { when: when(tk.revoked_at) }) : ""),
    tk.revoked_at ? null : el("div", { class: "form-actions" }, el("button", { class: "btn is-small", type: "button", dataset: { write: "true" }, onclick: async () => {
      try { await api.revokeToken(tk.id); renderTokens(await api.tokens()); } catch (error) { notice.replaceChildren(alertBox("error", error.message, error.reasons)); } } }, t("pages.settings.revoke")))))
    : [el("li", {}, emptyState("settings", t("pages.settings.tokensEmptyState"), t("pages.settings.createAToken"),
      () => { const d = document.getElementById("token-details"); if (d) { d.open = true; d.querySelector("[name=name]")?.focus(); } }))]));
  const tokenForm = settings.api_tokens ? form([field(t("pages.settings.tokenNameLabel"), "name", { required: true })], t("pages.settings.createTokenShownOnce"), async (data) => {
    const minted = await api.createToken({ name: data.name });
    tokenOnce.replaceChildren(el("div", { id: "token-once", class: "alert is-info", role: "status" },
      el("div", {}, t("pages.settings.tokenCopyNow", { name: minted.name })), el("code", { class: "mono token-value" }, minted.token)));
    renderTokens(await api.tokens());
  }) : null;
  if (tokenForm) tokenForm.id = "token-form";
  if (settings.api_tokens) renderTokens(settings.api_tokens);
  const passwordForm = form([
    field(t("pages.settings.currentPassword"), "current_password", { type: "password", required: true, autocomplete: "current-password" }),
    field(t("pages.settings.newPassword12"), "new_password", { type: "password", required: true, autocomplete: "new-password" }),
  ], t("pages.settings.changePassword"), async (data) => {
    await api.changePassword(data.current_password, data.new_password);
    notice.replaceChildren(alertBox("info", t("pages.settings.passwordChanged")));
  }, { inline: false });
  passwordForm.id = "password-form";
  const capture = settings.capture || {};
  // F9 — Uninstall: owners only. The app never gets root; it writes one flag file that the
  // installer's root path unit watches, so the button exists only where that unit exists.
  const uninstallPanel = settings.users ? renderUninstallPanel(settings, container) : null;
  // F10 — Hermes integration: owners only; status, the single-login trade-off, one-paste command.
  const hermesPanel = settings.users ? renderHermesPanel(settings) : null;
  // JOH — Journey of Humanity (0.5.0): a personal switch, owner or member; viewers see it disabled.
  let johStatus = { enabled: false };
  try { johStatus = await api.johStatus(); } catch { /* the panel still renders, switch off */ }
  const johPanel = renderJohPanel(johStatus, notice);
  // 0.5.1: the per-user language (stored, else negotiated from the browser by the server).
  let me = { language: currentLanguage(), language_source: "browser" };
  try { me = await api.me(); } catch { /* the panel still renders with the active language */ }
  const hermes = settings.hermes || {};
  const accountLine = hermes.session_trusted
    ? t("pages.settings.signedInViaHermes", { user: ctx.currentUser() ?? t("pages.settings.theOwner") })
    : t("pages.settings.signedInAs", { user: ctx.currentUser() ?? t("pages.settings.you") });
  container.replaceChildren(
    pageHeader("settings", t("pages.settings.title"), t("pages.settings.how")),
    notice,
    el("div", { class: "grid" },
      el("section", { class: "panel", "aria-labelledby": "settings-workspace" }, el("h2", { id: "settings-workspace" }, t("pages.settings.workspace")),
        el("dl", { class: "kv" },
          el("dt", {}, t("pages.settings.workspaceId")), el("dd", { class: "mono" }, settings.workspace_id),
          el("dt", {}, t("pages.settings.scope")), el("dd", {}, settings.scope_id),
          el("dt", {}, t("pages.settings.schemaVersion")), el("dd", {}, String(settings.schema_version)),
          el("dt", {}, t("pages.settings.rootPath")), el("dd", { class: "mono" }, settings.root, el("span", { class: "meta" }, t("pages.settings.serverSideNotEditable"))),
          el("dt", {}, t("pages.settings.remoteAccess")), el("dd", {}, settings.allow_remote ? t("pages.settings.remoteAccessEnabled") : t("pages.settings.loopbackOnly")),
          el("dt", {}, t("pages.settings.backupLabel")), el("dd", {}, backup))),
      el("section", { class: "panel", "aria-labelledby": "settings-account-title" }, el("h2", { id: "settings-account-title" }, t("pages.settings.yourAccount")),
        el("p", { class: "meta", id: "settings-account-line" }, accountLine), passwordForm),
      renderLanguagePanel(me, notice),
      el("section", { class: "panel", "aria-labelledby": "settings-users-title" }, el("h2", { id: "settings-users-title" }, t("pages.settings.usersAndMemberships")),
        settings.users
          ? el("div", { class: "stack" }, el("ul", { class: "list", id: "settings-users" }, settings.users.map(userRow)), el("details", { class: "action" }, el("summary", {}, t("pages.settings.addAUser")), newUser))
          : el("div", { id: "settings-users" }, empty(t("pages.settings.onlyOwnersUsers")))),
      el("section", { class: "panel", "aria-labelledby": "settings-agents-title" }, el("h2", { id: "settings-agents-title" }, t("pages.settings.agentRoles")),
        el("ul", { class: "list", id: "settings-agents" }, settings.agents.map((a) => el("li", { class: "list-item" },
          el("div", { class: "list-item-title" }, el("strong", {}, a.name), agentPill(a)),
          el("div", { class: "meta" }, a.credentials.length
            ? a.credentials.map((c) => t("pages.settings.credentialVariable", { variable: c.variable, state: c.set ? t("pages.settings.setWord") : t("pages.settings.notSetWord") })).join(" · ")
            : t("pages.settings.noCredentialNeeded")),
          a.runner_status.problems.length ? reasonsList(a.runner_status.problems.map((p) => t("pages.settings.notConfigured", { problem: p }))) : null)))),
      el("section", { class: "panel", "aria-labelledby": "settings-workers-title" }, el("h2", { id: "settings-workers-title" }, t("pages.settings.workers")),
        settings.workers.length
          ? el("ul", { class: "list" }, settings.workers.map((w) => el("li", { class: "list-item" },
            el("div", { class: "list-item-title" }, el("span", { class: "mono" }, w.worker_id), pill(w.alive ? "available" : "missing", w.alive ? t("status.alive") : t(`status.${w.status}`, undefined, w.status))),
            el("div", { class: "meta" }, t("pages.settings.lastSeenAgo", { seconds: w.age_seconds }), w.current_occurrence_id ? t("pages.settings.runningOccurrence") : ""))))
          : empty(t("pages.settings.noWorkerHeartbeat"))),
      el("section", { class: "panel", "aria-labelledby": "settings-capture-title" }, el("h2", { id: "settings-capture-title" }, t("pages.settings.captureInbox")),
        el("dl", { class: "kv" },
          el("dt", {}, t("pages.settings.transcription")), el("dd", {}, t("pages.settings.transcriptionExternal")),
          el("dt", {}, t("pages.settings.uploadCap")), el("dd", {}, t("pages.settings.uploadCapValue", { mb: Math.round((capture.max_bytes || 0) / (1024 * 1024)) })),
          el("dt", {}, t("pages.settings.allowedTypes")), el("dd", {}, (capture.allowed_types || []).join(", ")))),
      el("section", { class: "panel", "aria-labelledby": "settings-tokens-title" }, el("h2", { id: "settings-tokens-title" }, t("pages.settings.apiTokens")),
        el("p", { class: "meta" }, t("pages.settings.apiTokensLead")),
        settings.api_tokens ? el("div", { class: "stack" }, tokenOnce, tokenList, el("details", { class: "action", id: "token-details" }, el("summary", {}, t("pages.settings.createAToken")), tokenForm))
          : el("div", { id: "settings-tokens" }, empty(t("pages.settings.onlyOwnersTokens")))),
      el("section", { class: "panel", "aria-labelledby": "settings-connections-title" }, el("h2", { id: "settings-connections-title" }, t("pages.settings.connections")),
        el("p", { class: "meta" }, t("pages.settings.connectionsLead")),
        el("ul", { class: "list", id: "settings-connections" }, settings.connections.length
          ? settings.connections.map((c) => el("li", { class: "list-item" },
            el("div", { class: "list-item-title" }, el("strong", {}, c.name), pill("not_applicable", c.status ? t(`status.${c.status}`, undefined, c.status) : t("pages.settings.declared"))),
            el("div", { class: "meta" }, t("pages.settings.connectionMeta", { kind: c.kind, owner: c.owner }))))
          : el("li", {}, emptyState("settings", t("pages.settings.connectionsEmptyState"))))),
      johPanel, hermesPanel, uninstallPanel));
}

// 0.5.1 — Language: five ghost pills with the native names; choosing one saves it for this
// user and re-renders the whole app in place (i18n.setLanguage → "dm:language" → route()).
function renderLanguagePanel(me, notice) {
  const active = me.language || currentLanguage();
  const pills = el("div", { class: "lang-pills", role: "group", "aria-label": t("settings.language.title") },
    LANGUAGES.map((code) => el("button", {
      class: "pill-btn", type: "button", lang: code, dataset: { language: code }, "aria-pressed": String(code === active),
      onclick: async (event) => {
        const button = event.currentTarget;
        if (button.getAttribute("aria-pressed") === "true") return;
        for (const b of pills.querySelectorAll("button")) b.disabled = true;
        try {
          await api.setLanguage(code);
          await setLanguage(code);
        } catch (error) {
          for (const b of pills.querySelectorAll("button")) b.disabled = false;
          notice.replaceChildren(alertBox("error", error.message, error.reasons));
        }
      },
    }, LANGUAGE_NAMES[code])));
  const source = me.language_source === "user" ? t("settings.language.sourceUser") : t("settings.language.sourceBrowser");
  return el("section", { class: "panel", id: "settings-language", "aria-labelledby": "settings-language-title" },
    el("h2", { id: "settings-language-title" }, t("settings.language.title")),
    el("p", { class: "meta" }, t("settings.language.lead")),
    pills,
    el("p", { class: "meta", id: "settings-language-source" }, source));
}

// F11 — the Journey of Humanity switch: one sentence, the privacy line, one ghost button.
function renderJohPanel(status, notice) {
  const on = Boolean(status.enabled);
  const button = el("button", { class: `btn${on ? "" : " is-primary"}`, type: "button", id: "joh-enable", dataset: { write: "true" }, "aria-pressed": String(on) }, on ? t("pages.settings.turnOff") : t("pages.settings.turnOn"));
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      await api.johSetEnabled(!on);
      window.dispatchEvent(new CustomEvent("dm:joh-changed"));
      if (!on) location.hash = "#/joh";
      else window.dispatchEvent(new CustomEvent("hashchange"));
    } catch (error) {
      button.disabled = false;
      notice.replaceChildren(alertBox("error", error.message, error.reasons));
    }
  });
  return el("section", { class: "panel", id: "settings-joh", "aria-labelledby": "settings-joh-title" },
    el("h2", { id: "settings-joh-title" }, t("pages.settings.journeyOfHumanity")),
    el("p", { class: "meta" }, t("pages.settings.johLead")),
    el("p", { class: "meta" }, t("pages.settings.johPrivacyLine")),
    el("div", { class: "form-actions" }, button, el("span", { class: "meta", id: "joh-enable-state" }, on ? t("pages.settings.johOnState") : t("pages.settings.johOffState"))));
}

const HERMES_ONE_PASTE = "curl -fsSL https://raw.githubusercontent.com/DigitalMaid/digitalmaid-install/main/install.sh | bash -s -- --hermes";

function renderHermesPanel(settings) {
  const hermes = settings.hermes || {};
  const system = settings.install_mode === "system";
  const command = system ? HERMES_ONE_PASTE.replace("| bash -s --", "| sudo bash -s --") : HERMES_ONE_PASTE;
  return el("section", { class: "panel", id: "settings-hermes", "aria-labelledby": "settings-hermes-title" },
    el("h2", { id: "settings-hermes-title" }, t("pages.settings.hermesIntegration")),
    el("p", { class: "meta" }, t("pages.settings.hermesLead")),
    el("dl", { class: "kv" },
      el("dt", {}, t("pages.settings.trustedProxy")), el("dd", {}, hermes.trusted_proxy ? t("pages.settings.trustedProxyConfigured") : t("pages.settings.trustedProxyNotConfigured")),
      el("dt", {}, t("pages.settings.thisSession")), el("dd", {}, hermes.session_trusted ? t("pages.settings.sessionFromHermes") : t("pages.settings.sessionWithPassword"))),
    el("p", { class: "meta" }, t("pages.settings.singleLoginExplanation")),
    el("p", { class: "meta" }, system ? t("pages.settings.installTabSystem") : t("pages.settings.installTabHermes")),
    el("code", { class: "mono token-value", id: "hermes-command" }, command),
    el("p", { class: "meta" }, t("pages.settings.hermesInstallDetails")));
}

function renderUninstallPanel(settings, view) {
  const available = Boolean(settings.uninstall?.available);
  const body = available
    ? el("div", { class: "stack" },
      el("p", { class: "meta" }, t("pages.settings.uninstallLead")),
      el("button", { class: "btn", type: "button", id: "uninstall-open", dataset: { write: "true" }, onclick: () => openUninstallDialog(settings, view) }, t("pages.settings.uninstallEllipsis")))
    : el("p", { class: "meta" }, t("pages.settings.uninstallUnavailable"));
  return el("section", { class: "panel", id: "settings-uninstall", "aria-labelledby": "settings-uninstall-title" },
    el("h2", { id: "settings-uninstall-title" }, t("pages.settings.uninstallDigitalMaid")), body);
}

// The dialog is built per opening and removed on close, so the page never carries a
// half-filled password field. Same shell as #confirm-dialog (native modal, Esc/backdrop cancel).
function openUninstallDialog(settings, view) {
  const opener = document.activeElement;
  const notice = el("div", { id: "uninstall-notice" });
  const purge = el("input", { type: "checkbox", id: "uninstall-purge", name: "purge" });
  const password = el("input", { type: "password", id: "uninstall-password", name: "password", autocomplete: "current-password", required: true });
  const confirm = el("input", { type: "text", id: "uninstall-confirm", name: "confirm", autocomplete: "off", spellcheck: "false", required: true });
  const submit = el("button", { class: "btn is-danger", type: "submit", id: "uninstall-submit", disabled: true }, t("pages.settings.uninstallNow"));
  const cancel = el("button", { class: "btn", type: "button", id: "uninstall-cancel" }, t("common.cancel"));
  const ready = () => { submit.disabled = !(confirm.value === "UNINSTALL" && password.value.length > 0); };
  password.addEventListener("input", ready);
  confirm.addEventListener("input", ready);
  const dialog = el("dialog", { id: "uninstall-dialog", class: "confirm-dialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "uninstall-title", "aria-describedby": "uninstall-message" },
    el("h2", { id: "uninstall-title" }, t("pages.settings.uninstallConfirmTitle")),
    el("p", { id: "uninstall-message" }, t("pages.settings.uninstallConfirmMessage")),
    el("form", { class: "form", id: "uninstall-form", novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      if (submit.disabled) return;
      submit.disabled = true;
      try {
        const result = await api.requestUninstall(password.value, confirm.value, purge.checked);
        close();
        renderUninstalling(view, settings, result);
      } catch (error) {
        notice.replaceChildren(alertBox("error", error.message, error.reasons));
        ready();
      } } },
      el("label", { class: "checkbox", for: "uninstall-purge" }, purge, t("pages.settings.alsoEraseData")),
      el("div", { class: "form-row" }, el("label", { for: "uninstall-password", class: "is-required" }, t("pages.settings.yourPassword")), password),
      el("div", { class: "form-row" }, el("label", { for: "uninstall-confirm", class: "is-required" }, t("pages.settings.typeToContinue", { word: "UNINSTALL" })), confirm),
      notice,
      el("div", { class: "form-actions" }, cancel, submit)));
  const close = () => { if (dialog.open) dialog.close(); dialog.remove(); opener?.focus?.(); };
  cancel.addEventListener("click", close);
  dialog.addEventListener("cancel", (e) => { e.preventDefault(); close(); });
  dialog.addEventListener("click", (e) => { if (e.target === dialog) close(); });
  document.body.append(dialog);
  dialog.showModal();
  password.focus();
}

// 202 accepted: the whole view becomes one quiet card and polls /api/healthz every 2 s; the
// first failure means the root unit has stopped the service, and the line becomes "Done."
function renderUninstalling(view, settings, result) {
  const meta = el("p", { class: "meta", id: "uninstalling-meta" }, t("pages.settings.uninstallingMeta"));
  view.replaceChildren(el("div", { class: "uninstalling", id: "uninstalling", role: "status", "aria-live": "polite" },
    el("h1", {}, t("pages.settings.uninstallingHeading")),
    meta,
    el("p", { class: "meta" }, result.purge ? t("pages.settings.dataBeingErased") : [t("pages.settings.workspaceKeptAt"), el("span", { class: "mono" }, settings.root), "."])));
  const poll = async () => {
    if (!document.getElementById("uninstalling")) return;
    try { await api.healthz(); setTimeout(poll, 2000); } catch { meta.textContent = t("pages.settings.uninstallDone"); }
  };
  setTimeout(poll, 2000);
}
