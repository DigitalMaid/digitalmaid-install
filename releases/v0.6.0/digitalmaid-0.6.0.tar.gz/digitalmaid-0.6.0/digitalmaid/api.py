"""HTTP API and static UI for one workspace root and one server-side scope.

The scope is fixed at ``create_app`` time (server configuration); clients
cannot choose it. Domain errors map to HTTP status codes:
InvariantError → 409 with ``{"reasons": [...]}``, ValueError → 422,
LookupError or a ``None`` lookup → 404.
"""

import hmac
import json
import os
import tempfile
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from email.parser import BytesParser
from email.policy import HTTP as _HTTP_POLICY
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictInt

from digitalmaid import __version__
from digitalmaid.auth import DEFAULT_SESSION_TTL, LoginRateLimiter
from digitalmaid.capture import (ALLOWED_UPLOAD_TYPES, AUDIO_TYPES, INLINE_TYPES,
                                 CAPTURE_SOURCES, capture_extension)
from digitalmaid.db import SCHEMA_VERSION
from digitalmaid.domain import Store
from digitalmaid.errors import ConflictError, InvariantError
from digitalmaid.i18n import LANGUAGES
from digitalmaid.joh.api import mount_joh_routes
from digitalmaid.runners import runner_status
from digitalmaid.transports import credential_env_name
from digitalmaid.workspace import read_manifest

SESSION_COOKIE = "dm_session"
CSRF_HEADER = "x-requested-with"
CSRF_VALUE = "digitalmaid"
UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
UNINSTALL_DIR_ENV = "DIGITALMAID_UNINSTALL_DIR"
UNINSTALL_REQUEST_FILE = "request.json"
UNINSTALL_CONFIRM_WORD = "UNINSTALL"
SECURITY_HEADERS = {
    "Content-Security-Policy": ("default-src 'self'; frame-ancestors 'none'; base-uri 'self';"
                                " form-action 'self'; object-src 'none'"),
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
}
# Trusted sign-in from the Hermes dashboard proxy (docs/HERMES-INTEGRATION.md, "Inside Hermes").
# The proxy runs on the same host, adds this header with the shared secret, and embeds the UI in
# an iframe of its own origin — so a *trusted* request may be framed by 'self' and nothing else.
TRUSTED_PROXY_SECRET_ENV = "DIGITALMAID_TRUSTED_PROXY_SECRET"
TRUSTED_PROXY_SECRET_MIN_LENGTH = 32
# 0.6.0: extra exact client addresses allowed to present the secret (Hermes in Docker reaches
# the host over the bridge, e.g. 172.18.0.2). Comma-separated; loopback is always allowed.
TRUSTED_PROXY_CLIENTS_ENV = "DIGITALMAID_TRUSTED_PROXY_CLIENTS"
PROXY_AUTH_HEADER = "X-DigitalMaid-Proxy-Auth"
TRUSTED_SECURITY_HEADERS = {
    **{k: v for k, v in SECURITY_HEADERS.items() if k != "X-Frame-Options"},
    "Content-Security-Policy": SECURITY_HEADERS["Content-Security-Policy"].replace(
        "frame-ancestors 'none'", "frame-ancestors 'self'"),
}
INSTALL_MODE_ENV = "DIGITALMAID_INSTALL_MODE"
INSTALL_MODES = ("system", "user")
CONNECTIONS_FILE = "os-connections.json"
# API tokens (minted by an owner in Settings) may only reach these paths.
TOKEN_SCOPE_PREFIXES = ("/api/captures",)
TOKEN_SCOPE_EXACT = ("/api/healthz",)
# Personal settings a read-only viewer may still change for themselves (0.5.1: the language).
PERSONAL_WRITE_PATHS = ("/api/preferences/language",)
# Room for multipart framing and the small text fields beside the file.
_MULTIPART_OVERHEAD = 64 * 1024


class Forbidden(Exception):
    """Authenticated, but the session's role may not do this."""


class PayloadTooLarge(Exception):
    """Upload body over the configured cap (HTTP 413)."""

UI_DIR = Path(__file__).parent / "ui"
UI_FILES = {
    "index.html": "text/html; charset=utf-8",
    "app.css": "text/css; charset=utf-8",
    "app.js": "text/javascript; charset=utf-8",
    "api.js": "text/javascript; charset=utf-8",
    "views.js": "text/javascript; charset=utf-8",
    "pages.js": "text/javascript; charset=utf-8",
    "calendar.js": "text/javascript; charset=utf-8",
    "capture.js": "text/javascript; charset=utf-8",
    "hero.js": "text/javascript; charset=utf-8",
    "commands.js": "text/javascript; charset=utf-8",
    "sky.js": "text/javascript; charset=utf-8",
    "joh.js": "text/javascript; charset=utf-8",
    # 0.6.0 Plates (DESIGN.md G2): the 3D plate engine and the five scene builders.
    "plates.js": "text/javascript; charset=utf-8",
    "plates-scenes.js": "text/javascript; charset=utf-8",
    "i18n.js": "text/javascript; charset=utf-8",
    # Page texture as a file: under default-src 'self' a data: URI would be blocked.
    "hex.svg": "image/svg+xml",
    # 0.5.1: 450 CJK @font-face slices (399 KB) live apart from app.css; linked only for zh/ja.
    "fonts-cjk.css": "text/css; charset=utf-8",
    # 0.5.1: one flat UI catalogue per language (served by /locales/{code}.json below).
    **{f"locales/{code}.json": "application/json; charset=utf-8" for code in LANGUAGES},
}
# Self-hosted fonts (SIL OFL, see docs/THIRD_PARTY.md); the UI makes no external requests.
FONT_FILES = {
    "outfit-latin.woff2": "font/woff2",
    "outfit-latin-ext.woff2": "font/woff2",
    "doto-latin.woff2": "font/woff2",
    "doto-latin-ext.woff2": "font/woff2",
    "cormorant-latin.woff2": "font/woff2",
    "cormorant-italic-latin.woff2": "font/woff2",
    "cormorant-vietnamese.woff2": "font/woff2",
    "cormorant-italic-vietnamese.woff2": "font/woff2",
    "bevietnampro-300-vietnamese.woff2": "font/woff2",
    "bevietnampro-400-vietnamese.woff2": "font/woff2",
    "bevietnampro-500-vietnamese.woff2": "font/woff2",
    "bevietnampro-600-vietnamese.woff2": "font/woff2",
    "README.md": "text/plain; charset=utf-8",
    # 0.5.1: Noto Sans/Serif SC + JP slices, listed by the manifest Pi placed beside them.
    **{name: "font/woff2" for name in json.loads(
        (UI_DIR / "fonts" / "cjk-manifest.json").read_text(encoding="utf-8"))},
}
FONT_CACHE = "public, max-age=31536000, immutable"
# App shell (html/js/css/svg): always revalidate so a deploy shows on the next load. Starlette's
# FileResponse adds an ETag from size+mtime, so the revalidation is a cheap 304 most of the time.
UI_CACHE = "no-cache"


def parse_multipart(content_type: str, body: bytes) -> tuple[dict[str, str], dict[str, dict]]:
    """``(fields, files)`` from a multipart/form-data body using the stdlib parser.

    ``files`` maps field name → ``{"filename", "content_type", "data"}``. The
    client file name is returned as text only; callers never build a path
    from it. Bytes round-trip exactly (verified for binary payloads).
    """
    if not content_type.lower().startswith("multipart/form-data"):
        raise ValueError("upload must be multipart/form-data")
    message = BytesParser(policy=_HTTP_POLICY).parsebytes(
        b"Content-Type: " + content_type.encode("latin-1", "replace") + b"\r\nMIME-Version: 1.0\r\n\r\n"
        + body)
    if not message.is_multipart():
        raise ValueError("malformed multipart body")
    fields: dict[str, str] = {}
    files: dict[str, dict] = {}
    for part in message.iter_parts():
        name = part.get_param("name", header="content-disposition")
        if not name:
            continue
        payload = part.get_payload(decode=True) or b""
        filename = part.get_param("filename", header="content-disposition")
        if filename is not None:
            files[name] = {"filename": str(filename), "content_type": part.get_content_type(),
                           "data": payload}
        else:
            fields[name] = payload.decode("utf-8", "replace")
    return fields, files


# -- request bodies -----------------------------------------------------------

class GoalIn(BaseModel):
    title: str
    owner: str
    success_measure: str


class GoalOutcomeIn(BaseModel):
    # The deciding human is the authenticated user; a client-supplied name is refused.
    model_config = ConfigDict(extra="forbid")
    achieved: StrictBool
    evidence: str


class ProjectIn(BaseModel):
    title: str
    owner: str
    goal_id: str
    success_criteria: str


class TaskIn(BaseModel):
    project_id: str
    title: str
    owner: str
    next_action: str
    criteria: list[str]
    priority: StrictInt
    deadline: str | None = None
    # {"joh": "true"} = "Consult my Journey profile" (JOH-2). Stored on the task since
    # migration 14 (JOH-3) — string→string, ≤ 20 keys, ≤ 2000 chars each — and merged over a
    # job template's inputs by the live runner; the request is also audited (joh_requested).
    inputs: dict | None = None


class ResourceIn(BaseModel):
    category: str
    description: str
    status: str
    na_reason: str | None = None
    amount_minor: StrictInt | None = None
    currency: str | None = None


class WaiverIn(BaseModel):
    category: str
    reason: str
    granted_by: str


class SpendIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    amount_minor: StrictInt
    currency: str


class ExecutionIn(BaseModel):
    agent_id: str
    status: str
    model: str | None = None
    provider: str | None = None
    log: str = ""


class OutputIn(BaseModel):
    execution_id: str
    content: str


class CriterionResultIn(BaseModel):
    criterion: str
    passed: StrictBool
    evidence: str


class CheckIn(BaseModel):
    reviewer: str
    results: list[CriterionResultIn]


class CorrectionIn(BaseModel):
    owner: str
    action: str


class LearningIn(BaseModel):
    text: str


class JobIn(BaseModel):
    purpose: str
    agent_id: str
    project_id: str
    task_template: dict
    schedule_kind: str
    schedule_spec: dict
    timezone: str
    enabled: StrictBool = True
    misfire_policy: str = "skip"


class RunNowIn(BaseModel):
    idempotency_key: str


class WidgetIn(BaseModel):
    id: str
    visible: StrictBool


class WidgetPreferencesIn(BaseModel):
    widgets: list[WidgetIn] = Field(min_length=1)


class LanguageIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    language: str


class DecisionIn(BaseModel):
    options: list[str]
    chosen: str
    reasoning: str
    expected_result: str
    confidence: StrictInt
    review_date: str


class NoteIn(BaseModel):
    kind: str
    title: str
    body_md: str = ""
    actor: str
    entry_date: str | None = None
    decision: DecisionIn | None = None


class NoteUpdateIn(BaseModel):
    revision: StrictInt
    title: str | None = None
    body_md: str | None = None
    decision: DecisionIn | None = None
    actor: str = "ui"


class RevisionActorIn(BaseModel):
    revision: StrictInt
    actor: str = "ui"


class ActorIn(BaseModel):
    actor: str


class NoteLinkIn(BaseModel):
    target_type: str
    target_id: str
    actor: str = "ui"


class DecisionOutcomeIn(BaseModel):
    outcome: str
    actor: str


class StepIn(BaseModel):
    title: str
    instruction_md: str
    expected_evidence: str
    role: str


class ProcedureIn(BaseModel):
    title: str
    purpose: str
    created_by: str
    steps: list[StepIn]
    inputs: list[str] = []
    outputs: list[str] = []
    changelog: str = "initial version"


class ProcedureVersionIn(BaseModel):
    revision: StrictInt
    steps: list[StepIn]
    inputs: list[str] = []
    outputs: list[str] = []
    changelog: str
    created_by: str


class InstantiateIn(BaseModel):
    version: StrictInt
    project_id: str
    owner: str
    actor: str | None = None


class ProposalIn(BaseModel):
    text: str
    from_task_id: str
    actor: str


class ApplyProposalIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    revision: StrictInt
    steps: list[StepIn]
    inputs: list[str] = []
    outputs: list[str] = []
    changelog: str


class CommentIn(BaseModel):
    author: str
    body_md: str


class LoginIn(BaseModel):
    username: str
    password: str


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str


class UninstallIn(BaseModel):
    password: str
    confirm: str
    purge: StrictBool = False


class UserIn(BaseModel):
    username: str
    password: str
    role: str


class MembershipIn(BaseModel):
    role: str


class RRuleIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    freq: str
    interval: StrictInt = 1
    byweekday: list[StrictInt] | None = None
    until: str | None = None


class EventIn(BaseModel):
    title: str
    kind: str
    start_utc: str
    end_utc: str | None = None
    all_day: StrictBool = False
    timezone: str
    rrule: RRuleIn | None = None
    notes: str = ""
    linked_type: str | None = None
    linked_id: str | None = None


class EventUpdateIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    revision: StrictInt
    title: str | None = None
    kind: str | None = None
    start_utc: str | None = None
    end_utc: str | None = None
    all_day: StrictBool | None = None
    timezone: str | None = None
    rrule: RRuleIn | None = None
    clear_rrule: StrictBool = False
    notes: str | None = None
    linked_type: str | None = None
    linked_id: str | None = None


class EventExceptionIn(BaseModel):
    occurrence_local_date: str
    kind: str
    new_start_utc: str | None = None
    new_end_utc: str | None = None


class RevisionIn(BaseModel):
    revision: StrictInt


class CaptureIn(BaseModel):
    # captured_by is always the authenticated principal; a client-supplied name is refused.
    model_config = ConfigDict(extra="forbid")
    kind: str
    title: str | None = None
    body_text: str | None = None
    url: str | None = None
    source: str | None = None


class DraftIn(BaseModel):
    body_md: str


class ConvertIn(BaseModel):
    target: str
    payload: dict = {}


class TokenIn(BaseModel):
    name: str


# -- app factory ----------------------------------------------------------------

def _client_listed(host: str, listing: str) -> bool:
    """True when ``host`` is one of the comma-separated addresses or CIDR networks in ``listing``
    (container addresses move between restarts, so the installer lists the bridge subnet)."""
    import ipaddress
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return False
    for item in (c.strip() for c in listing.split(",")):
        if not item:
            continue
        try:
            if "/" in item:
                if addr in ipaddress.ip_network(item, strict=False):
                    return True
            elif addr == ipaddress.ip_address(item):
                return True
        except ValueError:
            continue
    return False


def create_app(root, scope_id: str = "personal", *, allow_remote: bool = False,
               clock=None, session_ttl_seconds: int = DEFAULT_SESSION_TTL) -> FastAPI:
    """``allow_remote`` marks the server as reachable beyond loopback: session
    cookies get the Secure flag (an HTTPS proxy in front is required, ADR-006).
    ``clock`` (monotonic seconds) is injectable for the login rate limiter."""
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.store = Store(root, scope_id=scope_id)
        try:
            yield
        finally:
            app.state.store.close()

    app = FastAPI(title="DigitalMaid Agentic OS", lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.allow_remote = bool(allow_remote)
    app.state.root = Path(root)
    limiter = LoginRateLimiter(**({"clock": clock} if clock else {}))

    def store(request: Request) -> Store:
        return request.app.state.store

    def found(record):
        if record is None:
            raise LookupError("not found in this scope")
        return record

    def user(request: Request) -> str:
        """Username of the authenticated session: the only source of human actors."""
        return request.state.session["user"]["username"]

    def owner_only(request: Request) -> str:
        if request.state.session["role"] != "owner":
            raise Forbidden("this action requires the owner role")
        return user(request)

    # -- authentication, CSRF and security headers ------------------------------------

    def deny(status: int, detail: str, request: Request | None = None) -> JSONResponse:
        response = JSONResponse({"detail": detail}, status_code=status)
        response.headers.update(security_headers(request))
        return response

    def trusted_proxy_secret() -> str | None:
        """The shared secret, read per request; too short counts as unset."""
        value = os.environ.get(TRUSTED_PROXY_SECRET_ENV) or ""
        return value if len(value) >= TRUSTED_PROXY_SECRET_MIN_LENGTH else None

    def is_trusted(request: Request) -> bool:
        """Loopback request carrying the proxy secret (constant-time compare)."""
        secret = trusted_proxy_secret()
        if secret is None:
            return False
        offered = request.headers.get(PROXY_AUTH_HEADER, "")
        if not offered or not hmac.compare_digest(offered.encode(), secret.encode()):
            return False
        client = request.client
        if client is None:
            return False
        if client.host in ("127.0.0.1", "::1"):
            return True
        return _client_listed(client.host, os.environ.get(TRUSTED_PROXY_CLIENTS_ENV, ""))

    def security_headers(request: Request | None) -> dict:
        if request is not None and getattr(request.state, "trusted", False):
            return TRUSTED_SECURITY_HEADERS
        return SECURITY_HEADERS

    def install_mode() -> str | None:
        value = os.environ.get(INSTALL_MODE_ENV)
        return value if value in INSTALL_MODES else None

    def csrf_problem(request: Request) -> str | None:
        if request.headers.get(CSRF_HEADER) != CSRF_VALUE:
            return f"state-changing requests must send X-Requested-With: {CSRF_VALUE}"
        origin = request.headers.get("origin")
        if origin is None:
            return None
        if origin == "null" or urlsplit(origin).netloc.lower() != request.headers.get(
                "host", "").lower():
            return "Origin does not match Host"
        return None

    def bearer_token(request: Request) -> str | None:
        header = request.headers.get("authorization", "")
        scheme, _, value = header.partition(" ")
        return value.strip() if scheme.lower() == "bearer" and value.strip() else None

    def token_in_scope(path: str) -> bool:
        return path in TOKEN_SCOPE_EXACT or any(
            path == p or path.startswith(p + "/") for p in TOKEN_SCOPE_PREFIXES)

    @app.middleware("http")
    async def guard(request: Request, call_next):
        path = request.url.path
        request.state.session = None
        request.state.trusted = is_trusted(request)
        if path.startswith("/api/") and path not in TOKEN_SCOPE_EXACT:
            token = bearer_token(request)
            # A bearer token cannot be attached by a cross-site form post, so
            # the CSRF marker is only demanded of cookie sessions.
            if request.method in UNSAFE_METHODS and token is None:
                problem = csrf_problem(request)
                if problem:
                    return deny(403, problem, request)
            if path == "/api/auth/trusted":
                # Only a request the proxy vouches for may even learn this route exists.
                if not request.state.trusted:
                    return deny(404, "not found", request)
            elif path != "/api/auth/login":
                if token is not None:
                    session = store(request).resolve_api_token(token)
                    if session is None:
                        return deny(401, "invalid or revoked API token", request)
                    if not token_in_scope(path):
                        return deny(403, "token scope: API tokens may only call /api/captures*"
                                         " and /api/healthz", request)
                    session = {**session, "via": "api_token"}
                else:
                    session = store(request).resolve_session(request.cookies.get(SESSION_COOKIE))
                    if session is None:
                        return deny(401, "authentication required", request)
                request.state.session = session
                if path not in ("/api/auth/logout", "/api/auth/me"):
                    if session["role"] is None:
                        return deny(403, f"no membership in scope {scope_id!r}", request)
                    if (session["role"] == "viewer" and request.method in UNSAFE_METHODS
                            and path not in PERSONAL_WRITE_PATHS):
                        return deny(403, "viewer role is read-only", request)
        response = await call_next(request)
        for name, value in security_headers(request).items():
            # A route may tighten a header (the original download sets its own CSP).
            response.headers.setdefault(name, value)
        return response

    @app.exception_handler(Forbidden)
    async def forbidden(request, exc: Forbidden):
        return JSONResponse({"detail": str(exc)}, status_code=403)

    @app.exception_handler(PayloadTooLarge)
    async def too_large(request, exc: PayloadTooLarge):
        return JSONResponse({"detail": str(exc)}, status_code=413)

    @app.get("/healthz")
    @app.get("/api/healthz")
    async def healthz():
        return {"status": "ok", "schema_version": SCHEMA_VERSION}

    @app.post("/api/auth/login")
    async def login(request: Request, body: LoginIn):
        s = store(request)
        if not limiter.allowed(body.username):
            return JSONResponse({"detail": "too many failed logins; try again later"},
                                status_code=429)
        account = s.authenticate(body.username, body.password)
        if account is None:
            limiter.record_failure(body.username)
            return JSONResponse({"detail": "invalid username or password"}, status_code=401)
        limiter.reset(body.username)
        session = s.create_session(account["id"], ttl_seconds=session_ttl_seconds)
        response = JSONResponse({"user": {"id": account["id"], "username": account["username"]},
                                 "role": s.role_for(account["id"], scope_id),
                                 "scope_id": scope_id})
        response.set_cookie(SESSION_COOKIE, session["id"], max_age=session_ttl_seconds,
                            httponly=True, samesite="strict", secure=app.state.allow_remote,
                            path="/")
        return response

    @app.post("/api/auth/trusted")
    async def trusted_login(request: Request):
        """Sign the Hermes user in as this scope's oldest enabled owner (no password).

        Reached only through the middleware's trust check (loopback + proxy secret); to
        anyone else the route answers 404. Owner decision: one Hermes login is one owner,
        so every action inside the Hermes tab is recorded as that owner."""
        s = store(request)
        account = s.first_enabled_owner()
        if account is None:
            return JSONResponse({"detail": f"no enabled owner in scope {scope_id!r}"},
                                status_code=409)
        session = s.create_session(account["id"], ttl_seconds=session_ttl_seconds, trusted=True)
        s.record_trusted_login(account["username"])
        response = JSONResponse({"username": account["username"], "trusted": True,
                                 "role": s.role_for(account["id"], scope_id),
                                 "scope_id": scope_id})
        response.set_cookie(SESSION_COOKIE, session["id"], max_age=session_ttl_seconds,
                            httponly=True, samesite="strict", secure=app.state.allow_remote,
                            path="/")
        return response

    @app.post("/api/auth/logout", status_code=204)
    async def logout(request: Request):
        store(request).delete_session(request.cookies.get(SESSION_COOKIE))
        response = Response(status_code=204)
        response.delete_cookie(SESSION_COOKIE, path="/")
        return response

    @app.post("/api/auth/password")
    async def change_password(request: Request, body: PasswordChangeIn):
        session = request.state.session
        if session.get("via") == "api_token":
            return JSONResponse({"detail": "API tokens cannot change passwords"}, status_code=403)
        try:
            store(request).change_password(session["user"]["id"], body.current_password,
                                           body.new_password,
                                           keep_session_id=request.cookies.get(SESSION_COOKIE))
        except PermissionError:
            return JSONResponse({"detail": "current password is incorrect"}, status_code=403)
        return {"changed": True}

    @app.get("/api/auth/me")
    async def me(request: Request):
        session = request.state.session
        language, source = store(request).language_for(
            session["user"]["id"], request.headers.get("accept-language"))
        return {"user": {"id": session["user"]["id"], "username": session["user"]["username"]},
                "role": session["role"], "scope_id": scope_id,
                "trusted": bool(session.get("trusted", False)),
                "language": language, "language_source": source}

    # -- users (owner only) ---------------------------------------------------------------

    @app.get("/api/users")
    async def list_users(request: Request):
        owner_only(request)
        return store(request).list_users()

    @app.post("/api/users", status_code=201)
    async def create_user(request: Request, body: UserIn):
        actor = owner_only(request)
        s = store(request)
        created = s.create_user(body.username, body.password, actor=actor)
        s.set_membership(created["id"], scope_id, body.role, actor=actor)
        return s.get_user(created["id"])

    @app.put("/api/users/{user_id}/membership")
    async def set_membership(request: Request, user_id: str, body: MembershipIn):
        actor = owner_only(request)
        s = store(request)
        s.set_membership(user_id, scope_id, body.role, actor=actor)
        return s.get_user(user_id)

    @app.post("/api/users/{user_id}/disable")
    async def disable_user(request: Request, user_id: str):
        return store(request).disable_user(user_id, actor=owner_only(request))

    # -- settings & connections (read model) --------------------------------------------

    def uninstall_dir() -> Path | None:
        """The installer's flag directory, if this process may write into it.

        Read per request so a test (or an operator) can flip it without a restart.
        The app never gets root: a root-owned systemd path unit watches this
        directory (docs/OPERATIONS.md, "Uninstall")."""
        value = os.environ.get(UNINSTALL_DIR_ENV)
        if not value:
            return None
        path = Path(value)
        if not path.is_dir() or not os.access(path, os.W_OK | os.X_OK):
            return None
        return path

    @app.get("/api/settings")
    async def settings(request: Request):
        s = store(request)
        manifest = read_manifest(app.state.root)
        agents = []
        for agent in s.list_agents():
            variable = credential_env_name(agent["model_policy"].get("credential_ref"))
            agents.append({**agent, "runner_status": runner_status(agent),
                           "credentials": [{"variable": variable,
                                            "set": os.environ.get(variable) is not None}]
                           if variable else []})
        connections = []
        path = app.state.root / CONNECTIONS_FILE
        if path.is_file():
            try:
                declared = json.loads(path.read_text(encoding="utf-8")).get("connections", [])
            except (ValueError, AttributeError):
                declared = []
            connections = [{key: str(c.get(key, "")) for key in ("name", "kind", "owner", "status")}
                           for c in declared if isinstance(c, dict)]
        return {"workspace_id": s.workspace_id, "scope_id": scope_id,
                "schema_version": SCHEMA_VERSION, "root": str(app.state.root),
                "allow_remote": app.state.allow_remote,
                "users": s.list_users() if request.state.session["role"] == "owner" else None,
                "agents": agents, "workers": s.list_workers(),
                "backup": {"last_backup_at": manifest.get("last_backup_at"),
                           "last_backup_path": manifest.get("last_backup_path")},
                "connections": connections,
                # The app never transcribes audio; Hermes or a human supplies the text.
                "capture": {"transcription": "external", "max_bytes": s.capture_max_bytes,
                            "allowed_types": sorted(ALLOWED_UPLOAD_TYPES)},
                "api_tokens": (s.list_api_tokens()
                               if request.state.session["role"] == "owner" else None),
                "uninstall": {"available": uninstall_dir() is not None},
                # Hermes dashboard plugin (docs/HERMES-INTEGRATION.md): is the trusted-proxy
                # sign-in configured on this server, and did *this* session come through it?
                "hermes": {"trusted_proxy": trusted_proxy_secret() is not None,
                           "session_trusted": bool(request.state.session.get("trusted", False))},
                # Set by the one-command installer in the service unit; the UI uses it to show
                # the right one-paste command (sudo for system installs).
                "install_mode": install_mode()}

    # -- API tokens (owner only; the value is returned exactly once) --------------------

    @app.post("/api/uninstall", status_code=202)
    async def request_uninstall(request: Request, body: UninstallIn):
        actor = owner_only(request)
        if request.state.session.get("via") == "api_token":
            return JSONResponse({"detail": "API tokens cannot uninstall"}, status_code=403)
        target = uninstall_dir()
        if target is None:
            return JSONResponse({"detail": "uninstall from here is only available for installs"
                                 " made by the one-command installer; run digitalmaid-uninstall"
                                 " on the server instead"}, status_code=409)
        if body.confirm != UNINSTALL_CONFIRM_WORD:
            return JSONResponse({"detail": f"type {UNINSTALL_CONFIRM_WORD} to continue"},
                                status_code=422)
        # Password re-entry shares the login limiter: guessing here locks the account
        # exactly as guessing at the login form would.
        if not limiter.allowed(actor):
            return JSONResponse({"detail": "too many failed password attempts; try again later"},
                                status_code=429)
        if store(request).authenticate(actor, body.password) is None:
            limiter.record_failure(actor)
            return JSONResponse({"detail": "password is incorrect"}, status_code=403)
        limiter.reset(actor)
        s = store(request)
        payload = {"purge": body.purge, "requested_by": actor,
                   "at": datetime.now(timezone.utc).isoformat(), "version": __version__}
        # tmp + rename: the root-side path unit only ever sees a complete file.
        final = target / UNINSTALL_REQUEST_FILE
        fd, tmp_name = tempfile.mkstemp(dir=target, prefix=".request-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, sort_keys=True)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, final)
        except BaseException:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
            raise
        s.record_uninstall_request(actor, purge=body.purge)
        return {"scheduled": True, "purge": body.purge}


    @app.get("/api/tokens")
    async def list_tokens(request: Request):
        owner_only(request)
        return store(request).list_api_tokens()

    @app.post("/api/tokens", status_code=201)
    async def create_token(request: Request, body: TokenIn):
        actor = owner_only(request)
        return store(request).create_api_token(request.state.session["user"]["id"], body.name,
                                               actor=actor)

    @app.post("/api/tokens/{token_id}/revoke")
    async def revoke_token(request: Request, token_id: str):
        return store(request).revoke_api_token(token_id, actor=owner_only(request))

    # -- capture inbox -------------------------------------------------------------------

    def capture_view(s: Store, capture: dict) -> dict:
        original_url = (f"/api/captures/{capture['id']}/original"
                        if capture.get("original_path") else None)
        return {**capture, "original_url": original_url}

    def own_capture(request: Request, capture: dict) -> str:
        """Members act on their own captures; owners on any (viewers never get here)."""
        session = request.state.session
        if session["role"] != "owner" and capture["captured_by"] != user(request):
            raise Forbidden("members may only change their own captures")
        return user(request)

    def default_source(request: Request) -> str:
        return "api" if request.state.session.get("via") == "api_token" else "ui"

    @app.get("/api/captures")
    async def list_captures(request: Request, status: str | None = None):
        s = store(request)
        return [capture_view(s, c) for c in s.list_captures(status=status)]

    @app.post("/api/captures", status_code=201)
    async def create_capture(request: Request, body: CaptureIn):
        s = store(request)
        data = body.model_dump()
        source = data.pop("source") or default_source(request)
        if source not in CAPTURE_SOURCES:
            raise ValueError(f"source must be one of {CAPTURE_SOURCES}")
        capture = s.create_capture(data.pop("kind"), captured_by=user(request), source=source,
                                   **data)
        return capture_view(s, capture)

    @app.post("/api/captures/upload", status_code=201)
    async def upload_capture(request: Request):
        s = store(request)
        limit = s.capture_max_bytes + _MULTIPART_OVERHEAD
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > limit:
            raise PayloadTooLarge(
                f"upload exceeds capture_max_bytes {s.capture_max_bytes} (workspace.json)")
        chunks, total = [], 0
        async for chunk in request.stream():
            total += len(chunk)
            if total > limit:
                raise PayloadTooLarge(
                    f"upload exceeds capture_max_bytes {s.capture_max_bytes} (workspace.json)")
            chunks.append(chunk)
        fields, files = parse_multipart(request.headers.get("content-type", ""), b"".join(chunks))
        upload = files.get("file")
        if upload is None:
            raise ValueError("multipart field 'file' is required")
        # Everything that can refuse the file is checked before any row exists.
        mime = upload["content_type"]
        capture_extension(mime)
        if not upload["data"]:
            raise ValueError("upload is empty")
        if len(upload["data"]) > s.capture_max_bytes:
            raise PayloadTooLarge(
                f"upload exceeds capture_max_bytes {s.capture_max_bytes} (workspace.json)")
        kind = "transcript" if mime in AUDIO_TYPES else "file"
        source = fields.get("source") or default_source(request)
        if source not in CAPTURE_SOURCES:
            raise ValueError(f"source must be one of {CAPTURE_SOURCES}")
        capture = s.create_capture(kind, captured_by=user(request), source=source,
                                   title=fields.get("title") or None,
                                   body_text=fields.get("body_text") or None)
        capture = s.attach_original(capture["id"], upload["data"], mime, actor=user(request),
                                    filename=upload["filename"])
        return capture_view(s, capture)

    @app.get("/api/captures/{capture_id}")
    async def get_capture(request: Request, capture_id: str):
        s = store(request)
        return capture_view(s, s.capture_detail(capture_id))

    @app.get("/api/captures/{capture_id}/original")
    async def capture_original(request: Request, capture_id: str, inline: bool = False):
        s = store(request)
        capture = found(s.get_capture(capture_id))
        data = s.read_original(capture_id)
        if data is None:
            raise LookupError("original missing")
        extension = capture_extension(capture["mime"])
        headers = {"X-Content-Type-Options": "nosniff",
                   "Content-Disposition": f'attachment; filename="original.{extension}"'}
        if inline and capture["mime"] in INLINE_TYPES:
            # Rendered inline only inside a sandbox: no scripts, no same-origin access.
            headers["Content-Disposition"] = f'inline; filename="original.{extension}"'
            headers["Content-Security-Policy"] = "sandbox; default-src 'none'"
        return Response(content=data, media_type=capture["mime"], headers=headers)

    @app.post("/api/captures/{capture_id}/drafts", status_code=201)
    async def add_draft(request: Request, capture_id: str, body: DraftIn):
        s = store(request)
        actor = own_capture(request, s.capture_detail(capture_id))
        return s.add_capture_draft(capture_id, body.body_md, created_by=actor)

    @app.post("/api/captures/{capture_id}/convert")
    async def convert_capture(request: Request, capture_id: str, body: ConvertIn):
        s = store(request)
        actor = own_capture(request, s.capture_detail(capture_id))
        s.convert_capture(capture_id, body.target, body.payload, actor=actor)
        return capture_view(s, s.capture_detail(capture_id))

    @app.post("/api/captures/{capture_id}/archive")
    async def archive_capture(request: Request, capture_id: str, body: RevisionIn):
        s = store(request)
        actor = own_capture(request, s.capture_detail(capture_id))
        return capture_view(s, s.archive_capture(capture_id, body.revision, actor=actor))

    @app.post("/api/captures/{capture_id}/unarchive")
    async def unarchive_capture(request: Request, capture_id: str, body: RevisionIn):
        s = store(request)
        actor = own_capture(request, s.capture_detail(capture_id))
        return capture_view(s, s.unarchive_capture(capture_id, body.revision, actor=actor))

    # -- calendar ----------------------------------------------------------------------------

    @app.get("/api/calendar")
    async def calendar(request: Request):
        start, end = request.query_params.get("from"), request.query_params.get("to")
        if not start or not end:
            raise ValueError("from and to are required (ISO 8601 with offset)")
        return {"from": start, "to": end, "timezone": "UTC",
                "items": store(request).expand_events(start, end)}

    @app.get("/api/events")
    async def list_events(request: Request, include_archived: bool = False):
        return store(request).list_events(include_archived=include_archived)

    @app.post("/api/events", status_code=201)
    async def create_event(request: Request, body: EventIn):
        data = body.model_dump()
        return store(request).create_event(
            data.pop("title"), data.pop("kind"), data.pop("start_utc"), actor=user(request),
            **data)

    @app.get("/api/events/{event_id}")
    async def get_event(request: Request, event_id: str):
        s = store(request)
        event = found(s.get_event(event_id))
        return {**event, "exceptions": s.list_event_exceptions(event_id)}

    @app.put("/api/events/{event_id}")
    async def update_event(request: Request, event_id: str, body: EventUpdateIn):
        data = body.model_dump(exclude_unset=True)
        revision = data.pop("revision")
        if data.pop("clear_rrule", False):
            data["rrule"] = None
        return store(request).update_event(event_id, revision, data, actor=user(request))

    @app.post("/api/events/{event_id}/exceptions", status_code=201)
    async def add_exception(request: Request, event_id: str, body: EventExceptionIn):
        return store(request).add_event_exception(event_id, actor=user(request),
                                                  **body.model_dump())

    @app.post("/api/events/{event_id}/archive")
    async def archive_event(request: Request, event_id: str, body: RevisionIn):
        return store(request).archive_event(event_id, body.revision, actor=user(request))

    @app.exception_handler(InvariantError)
    async def invariant(request, exc: InvariantError):
        return JSONResponse({"reasons": exc.reasons}, status_code=409)

    @app.exception_handler(ConflictError)
    async def conflict(request, exc: ConflictError):
        return JSONResponse({"reasons": [str(exc)]}, status_code=409)

    @app.exception_handler(ValueError)
    async def invalid(request, exc: ValueError):
        return JSONResponse({"detail": str(exc)}, status_code=422)

    @app.exception_handler(LookupError)
    async def missing(request, exc: LookupError):
        return JSONResponse({"detail": "not found in this scope"},
                            status_code=404)

    # -- workspace / today / preferences ----------------------------------------

    @app.get("/api/workspace")
    async def workspace(request: Request):
        s = store(request)
        return {"workspace_id": s.workspace_id, "scope_id": s.scope_id}

    @app.get("/api/today")
    async def today(request: Request):
        return store(request).today()

    @app.get("/api/counts")
    async def counts(request: Request):
        # The two numbers the rail badges show on every page; both already feed /api/today.
        s = store(request)
        return {"review_inbox": s.review_inbox()["count"],
                "capture_inbox": s.count_open_captures()}

    @app.get("/api/preferences/widgets")
    async def get_widgets(request: Request):
        return store(request).get_widget_preferences()

    @app.put("/api/preferences/widgets")
    async def put_widgets(request: Request, body: WidgetPreferencesIn):
        return store(request).set_widget_preferences(
            [w.model_dump() for w in body.widgets])

    @app.put("/api/preferences/language")
    async def put_language(request: Request, body: LanguageIn):
        session = request.state.session
        if body.language not in LANGUAGES:
            return JSONResponse({"detail": f"language must be one of {list(LANGUAGES)}"},
                                status_code=422)
        code = store(request).set_language(session["user"]["id"], body.language,
                                           actor=session["user"]["username"])
        return {"language": code, "language_source": "user"}

    # -- goals -------------------------------------------------------------------

    @app.get("/api/goals")
    async def list_goals(request: Request):
        return store(request).list_goals()

    @app.post("/api/goals", status_code=201)
    async def create_goal(request: Request, body: GoalIn):
        return store(request).create_goal(**body.model_dump())

    @app.get("/api/goals/{goal_id}")
    async def get_goal(request: Request, goal_id: str):
        s = store(request)
        goal = found(s.get_goal(goal_id))
        return {**goal, "outcome": s.get_goal_outcome(goal_id),
                "projects": s.list_projects(goal_id=goal_id)}

    @app.post("/api/goals/{goal_id}/outcome", status_code=201)
    async def goal_outcome(request: Request, goal_id: str,
                           body: GoalOutcomeIn):
        return store(request).record_goal_outcome(goal_id, decided_by=owner_only(request),
                                                  **body.model_dump())

    # -- projects ------------------------------------------------------------------

    @app.get("/api/projects")
    async def list_projects(request: Request, goal_id: str | None = None):
        s = store(request)
        return [{**p, "progress": s.project_progress(p["id"])}
                for p in s.list_projects(goal_id=goal_id)]

    @app.post("/api/projects", status_code=201)
    async def create_project(request: Request, body: ProjectIn):
        s = store(request)
        found(s.get_goal(body.goal_id))
        return s.create_project(**body.model_dump())

    @app.get("/api/projects/{project_id}")
    async def get_project(request: Request, project_id: str):
        s = store(request)
        project = found(s.get_project(project_id))
        return {**project, "progress": s.project_progress(project_id),
                "tasks": s.list_tasks(project_id=project_id)}

    @app.get("/api/projects/{project_id}/progress")
    async def project_progress(request: Request, project_id: str):
        return store(request).project_progress(project_id)

    @app.get("/api/projects/{project_id}/tasks")
    async def project_tasks(request: Request, project_id: str):
        s = store(request)
        found(s.get_project(project_id))
        return s.list_tasks(project_id=project_id)

    # -- tasks ---------------------------------------------------------------------

    @app.get("/api/tasks")
    async def list_tasks(request: Request, project_id: str | None = None,
                         status: str | None = None):
        return store(request).list_tasks(project_id=project_id, status=status)

    @app.post("/api/tasks", status_code=201)
    async def create_task(request: Request, body: TaskIn):
        s = store(request)
        found(s.get_project(body.project_id))
        task = s.create_task(**body.model_dump())
        if task["inputs"].get("joh") == "true":
            s.record_joh_task_request(task["id"], actor=user(request))
        return task

    @app.get("/api/tasks/{task_id}")
    async def get_task(request: Request, task_id: str):
        return found(store(request).get_task(task_id))

    @app.get("/api/tasks/{task_id}/detail")
    async def task_detail(request: Request, task_id: str):
        return store(request).task_detail(task_id)

    @app.post("/api/tasks/{task_id}/start")
    async def start_task(request: Request, task_id: str):
        return store(request).start_task(task_id)

    @app.get("/api/tasks/{task_id}/resources")
    async def list_resources(request: Request, task_id: str):
        return store(request).list_resources(task_id)

    @app.post("/api/tasks/{task_id}/resources", status_code=201)
    async def assess_resource(request: Request, task_id: str,
                              body: ResourceIn):
        return store(request).assess_resource(task_id, **body.model_dump())

    @app.post("/api/tasks/{task_id}/waivers", status_code=201)
    async def grant_waiver(request: Request, task_id: str, body: WaiverIn):
        return store(request).grant_waiver(task_id, **body.model_dump())

    @app.post("/api/tasks/{task_id}/spend-authorizations", status_code=201)
    async def authorize_spend(request: Request, task_id: str, body: SpendIn):
        return store(request).authorize_spend(task_id, authorized_by=user(request),
                                              **body.model_dump())

    @app.get("/api/tasks/{task_id}/executions")
    async def list_executions(request: Request, task_id: str):
        return store(request).list_executions(task_id)

    @app.post("/api/tasks/{task_id}/executions", status_code=201)
    async def record_execution(request: Request, task_id: str,
                               body: ExecutionIn):
        return store(request).record_execution(task_id, **body.model_dump())

    @app.get("/api/tasks/{task_id}/outputs")
    async def list_output_versions(request: Request, task_id: str):
        return store(request).list_output_versions(task_id)

    @app.post("/api/tasks/{task_id}/outputs", status_code=201)
    async def submit_output(request: Request, task_id: str, body: OutputIn):
        return store(request).submit_output(task_id, **body.model_dump())

    @app.get("/api/tasks/{task_id}/checks")
    async def list_checks(request: Request, task_id: str):
        return store(request).list_checks(task_id)

    @app.get("/api/tasks/{task_id}/corrections")
    async def list_corrections(request: Request, task_id: str):
        return store(request).list_corrections(task_id)

    @app.get("/api/tasks/{task_id}/learnings")
    async def list_learnings(request: Request, task_id: str):
        return store(request).list_learnings(task_id)

    @app.post("/api/tasks/{task_id}/learnings", status_code=201)
    async def add_learning(request: Request, task_id: str, body: LearningIn):
        return store(request).add_learning(task_id, body.text)

    # -- output versions, checks, corrections, acceptance ----------------------------

    @app.get("/api/output-versions/{version_id}")
    async def get_output_version(request: Request, version_id: str):
        return found(store(request).get_output_version(version_id))

    @app.post("/api/output-versions/{version_id}/checks", status_code=201)
    async def record_check(request: Request, version_id: str, body: CheckIn):
        return store(request).record_check(
            version_id, body.reviewer,
            [r.model_dump() for r in body.results])

    @app.post("/api/output-versions/{version_id}/accept")
    async def accept_output(request: Request, version_id: str):
        return store(request).accept_output(version_id, owner_only(request))

    @app.get("/api/checks/{check_id}")
    async def get_check(request: Request, check_id: str):
        return found(store(request).get_check(check_id))

    @app.post("/api/checks/{check_id}/corrections", status_code=201)
    async def open_correction(request: Request, check_id: str,
                              body: CorrectionIn):
        return store(request).open_correction(check_id, **body.model_dump())

    # -- automations and agents ---------------------------------------------------------

    @app.get("/api/agents")
    async def list_agents(request: Request):
        return [{**a, "runner_status": runner_status(a)}
                for a in store(request).list_agents()]

    @app.get("/api/workers")
    async def list_workers(request: Request):
        return store(request).list_workers()

    @app.get("/api/jobs")
    async def list_jobs(request: Request):
        s = store(request)
        return [s.job_summary(j["id"]) for j in s.list_jobs()]

    @app.post("/api/jobs", status_code=201)
    async def create_job(request: Request, body: JobIn):
        return store(request).create_job(**body.model_dump())

    @app.get("/api/jobs/{job_id}")
    async def get_job(request: Request, job_id: str):
        return store(request).job_summary(job_id)

    @app.post("/api/jobs/{job_id}/run-now", status_code=201)
    async def run_now(request: Request, job_id: str, body: RunNowIn):
        return store(request).request_run_now(job_id, body.idempotency_key)

    # -- knowledge: notes, journal, decisions, links, search ------------------------------

    def note_with_links(s: Store, note: dict) -> dict:
        return {**note, "links": s.list_note_links(note["id"])}

    @app.get("/api/notes")
    async def list_notes(request: Request, kind: str | None = None,
                         include_archived: bool = False):
        return store(request).list_notes(
            kinds=[kind] if kind else None, include_archived=include_archived)

    @app.post("/api/notes", status_code=201)
    async def create_note(request: Request, body: NoteIn):
        data = body.model_dump()
        return note_with_links(store(request), store(request).create_note(**data))

    @app.get("/api/notes/{note_id}")
    async def get_note(request: Request, note_id: str):
        s = store(request)
        return note_with_links(s, found(s.get_note(note_id)))

    @app.put("/api/notes/{note_id}")
    async def update_note(request: Request, note_id: str, body: NoteUpdateIn):
        s = store(request)
        data = body.model_dump()
        revision = data.pop("revision")
        return note_with_links(s, s.update_note(note_id, revision, **data))

    @app.post("/api/notes/{note_id}/archive")
    async def archive_note(request: Request, note_id: str, body: RevisionActorIn):
        return store(request).archive_note(note_id, body.revision, actor=body.actor)

    @app.post("/api/notes/{note_id}/links", status_code=201)
    async def link_note(request: Request, note_id: str, body: NoteLinkIn):
        return store(request).link_note(note_id, **body.model_dump())

    @app.delete("/api/notes/{note_id}/links", status_code=204)
    async def unlink_note(request: Request, note_id: str, body: NoteLinkIn):
        store(request).unlink_note(note_id, **body.model_dump())
        return JSONResponse(None, status_code=204)

    @app.post("/api/notes/{note_id}/decision-outcome")
    async def decision_outcome(request: Request, note_id: str,
                               body: DecisionOutcomeIn):
        return store(request).record_decision_outcome(note_id, **body.model_dump())

    @app.get("/api/journal/{entry_date}")
    async def journal_entry(request: Request, entry_date: str):
        return found(store(request).journal_entry(entry_date))

    @app.get("/api/search")
    async def search(request: Request, q: str, limit: int = 20):
        return store(request).search(q, limit=limit)

    # -- procedures ------------------------------------------------------------------------

    @app.get("/api/procedures")
    async def list_procedures(request: Request):
        return store(request).list_procedures()

    @app.post("/api/procedures", status_code=201)
    async def create_procedure(request: Request, body: ProcedureIn):
        return store(request).create_procedure(**body.model_dump())

    @app.get("/api/procedures/{procedure_id}")
    async def get_procedure(request: Request, procedure_id: str):
        return store(request).procedure_detail(procedure_id)

    @app.post("/api/procedures/{procedure_id}/versions", status_code=201)
    async def publish_version(request: Request, procedure_id: str,
                              body: ProcedureVersionIn):
        data = body.model_dump()
        return store(request).publish_procedure_version(
            procedure_id, data.pop("revision"), **data)

    @app.post("/api/procedures/{procedure_id}/activate")
    async def activate_procedure(request: Request, procedure_id: str, body: ActorIn):
        return store(request).activate_procedure(procedure_id, body.actor)

    @app.post("/api/procedures/{procedure_id}/retire")
    async def retire_procedure(request: Request, procedure_id: str):
        return store(request).retire_procedure(procedure_id, owner_only(request))

    @app.post("/api/procedures/{procedure_id}/instantiate", status_code=201)
    async def instantiate_procedure(request: Request, procedure_id: str,
                                    body: InstantiateIn):
        s = store(request)
        found(s.get_project(body.project_id))
        tasks = s.instantiate_procedure(procedure_id, **body.model_dump())
        return {"procedure_id": procedure_id, "version": body.version,
                "project_id": body.project_id, "tasks": tasks}

    @app.get("/api/procedures/{procedure_id}/proposals")
    async def list_proposals(request: Request, procedure_id: str):
        return store(request).list_learning_proposals(procedure_id)

    @app.post("/api/procedures/{procedure_id}/proposals", status_code=201)
    async def propose(request: Request, procedure_id: str, body: ProposalIn):
        return store(request).propose_learning(procedure_id, **body.model_dump())

    @app.post("/api/proposals/{proposal_id}/apply")
    async def apply_proposal(request: Request, proposal_id: str,
                             body: ApplyProposalIn):
        data = body.model_dump()
        return store(request).apply_learning_proposal(
            proposal_id, owner_only(request), data["steps"], data["inputs"],
            data["outputs"], data["changelog"], expected_revision=data["revision"])

    @app.post("/api/proposals/{proposal_id}/reject")
    async def reject_proposal(request: Request, proposal_id: str, body: ActorIn):
        return store(request).reject_learning_proposal(proposal_id, body.actor)

    # -- review inbox, outputs, comments -------------------------------------------------

    @app.get("/api/review-inbox")
    async def review_inbox(request: Request):
        return store(request).review_inbox()

    @app.get("/api/outputs")
    async def list_outputs(request: Request, accepted: bool | None = None):
        return store(request).list_all_output_versions(accepted=accepted)

    @app.get("/api/output-versions/{version_id}/comments")
    async def list_comments(request: Request, version_id: str):
        s = store(request)
        found(s.get_output_version(version_id))
        return s.list_review_comments(version_id)

    @app.post("/api/output-versions/{version_id}/comments", status_code=201)
    async def add_comment(request: Request, version_id: str, body: CommentIn):
        return store(request).add_review_comment(version_id, **body.model_dump())

    # -- JOH — Journey of Humanity (0.5.0, docs/JOH.md §6; routes live in digitalmaid/joh/api.py)
    mount_joh_routes(app)

    # -- static UI (allow-listed files only; ids in routes, never raw paths) --------

    @app.get("/", include_in_schema=False)
    async def index():
        return FileResponse(UI_DIR / "index.html", media_type=UI_FILES["index.html"],
                            headers={"Cache-Control": UI_CACHE})

    @app.get("/fonts/{filename}", include_in_schema=False)
    async def font_file(filename: str):
        if filename not in FONT_FILES:
            return JSONResponse({"detail": "not found"}, status_code=404)
        return FileResponse(UI_DIR / "fonts" / filename, media_type=FONT_FILES[filename],
                            headers={"Cache-Control": FONT_CACHE})

    @app.get("/locales/{code}.json", include_in_schema=False)
    async def locale_file(code: str):
        name = f"locales/{code}.json"
        if code not in LANGUAGES or name not in UI_FILES:
            return JSONResponse({"detail": "not found"}, status_code=404)
        return FileResponse(UI_DIR / "locales" / f"{code}.json", media_type=UI_FILES[name],
                            headers={"Cache-Control": UI_CACHE})

    @app.get("/{filename}", include_in_schema=False)
    async def static_file(filename: str):
        if filename not in UI_FILES:
            return JSONResponse({"detail": "not found"}, status_code=404)
        return FileResponse(UI_DIR / filename, media_type=UI_FILES[filename],
                            headers={"Cache-Control": UI_CACHE})

    return app
