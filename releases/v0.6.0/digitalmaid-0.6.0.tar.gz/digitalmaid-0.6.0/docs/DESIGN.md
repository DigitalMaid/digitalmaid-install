# DigitalMaid Agentic OS — Visual Direction: "Instrument Panel"

Written by Pi from studying the owner's existing Rubric board as a *reference for feel*. This is a
design brief in my own words. No markup, CSS or JavaScript from any reference is to be read or
reused; the worker builds every rule from this document. Where DigitalMaid's needs differ from the
reference (many more pages, forms, tables, auth), this brief takes precedence.

## 1. Mood in one sentence
A dark, quiet instrument panel at night: near-black paper, warm off-white ink, one hot accent spent
sparingly, small uppercase tracked labels everywhere, large numbers where something matters.
Calm, precise, slightly analogue (dials, dots, ticks), never "SaaS-blue".

## 2. Palette (tokens; values are DigitalMaid's own, chosen for AA contrast)
- `--bg`        #07070a  page background (near-black, hint of blue-black rather than warm)
- `--panel`     #0e0e12  section/side chrome
- `--card`      #17171d  widget/card surface (opaque; optional 0.94 alpha over page texture)
- `--line`      rgba(236,232,222,.14)  hairline dividers
- `--ink`       #ece8de  primary text (warm off-white, *not* pure white)
- `--ink-2`     #b7b2a4  secondary text
- `--mute`      #8a8578  labels/captions — must pass 4.5:1 on `--card`; verify
- `--accent`    #ff7a2a  ONE accent (hot amber-orange). Budget rule: the accent appears at most
                          3 times per viewport: the current/next thing, the primary action, the
                          selected state. Never for decoration, never for all icons.
- Status hues stay desaturated and small (dots/pills only): ok #6fbf8a, warn #e0b04a,
  error #e0605a, info = `--ink-2`. Status is never a filled block of colour.
- Dark only for now. Respect `prefers-color-scheme: light` with an inverted "paper" set later.

## 3. Typography — type sets the personality
- Display/headings: a geometric humanist sans with light and bold weights (self-hosted, e.g. an
  OFL font such as Outfit or Manrope; **no external font CDN calls** — bundle the woff2 files and
  record the licence in THIRD_PARTY.md). Headings light (300–400) and large; not bold.
- Numerals: a dotted/segmented display face for "big numbers" (inbox count, days to deadline,
  clock, progress %). OFL options exist (e.g. Doto or a similar dot-matrix face). Use for numbers
  only, never for sentences.
- Body/forms: the display sans at 400, 14–15px, line-height 1.5.
- Labels: 10–11px, uppercase, letter-spacing 1.5–2px, colour `--mute`. This is the signature
  detail: every widget title, table header, meta caption and pill uses it.
- Monospace only for ids, hashes, paths (system mono stack).

## 4. Layout — "board of instruments"
- A 12-column fluid grid with 16px gutters. Cards span 3/4/6/12 columns; the Today page is a board
  of cards, not a single column. Cards can be reordered/hidden (already supported by preferences) —
  keep that, and show a small "edit board" pencil toggle in the header that reveals move/hide
  controls only while editing (default view is clean).
- Left nav is a slim rail (icons + labels), collapsible to icons-only at ≤1100px; at ≤640px it
  becomes a top bar with a menu button. Never a horizontal scroll.
- Header: product mark left ("DigitalMaid" light + "Agentic OS" in accent, like a wordmark),
  centre global search, right: edit-board pencil, user menu (username, sign out).
- Generous outer margins (24–32px), tight inner density (12–16px paddings). Feels roomy but
  information-dense.

## 5. Card chrome
- Cards: `--card` surface, 8px radius, 1px `--line` border, *hard offset shadow* 3px 3px 0 #000
  (a subtle print-like lift; no blur). The selected/active card upgrades the shadow to the accent
  colour. Hover: border brightens, nothing moves.
- Card header: icon (thin-stroke, 16px) + uppercase tracked title left; a tiny meta on the right
  (count, "synced 07:00", "3/6 today"). One hairline under the header.
- Empty states are quiet single sentences in `--mute`, never illustrations.

## 6. Data display idioms (use these instead of generic tables where it fits)
- **Big number + caption**: the number huge (48–64px, numeral face, accent when it needs action),
  caption in label style beneath ("REVIEW INBOX", "DAYS TO 11 NOV").
- **Dot grids and tick rows** for progress over time: done/planned days as small squares or dots;
  the current one in accent. Use for journal streak, procedure steps, occurrences this month.
- **Pills**: hairline border, uppercase 10px, no fill; status colour only on a leading dot.
- **Rails/rings** for sequences: a vertical chain of small circular nodes for automation runs or
  PDCC state (Plan → Do → Check → Correction), the active node ringed in accent.
- Tables are allowed but styled as rows separated by hairlines, uppercase tracked headers, no
  zebra stripes, numbers right-aligned in tabular figures.

## 7. Motion and texture
- Motion is rare and functional: 150–200ms opacity/border transitions; one slow "breathing" glow on
  the single live element (a running worker/execution). Nothing bounces. `prefers-reduced-motion`
  disables all of it (already required).
- Optional page texture: a faint dark radial vignette behind the board (pure CSS gradient); no
  images.

## 8. Forms, drawers, dialogs
- Inputs: transparent field with 1px `--line` bottom border only, label above in label style,
  focus = accent bottom border. Selects and textareas match. Buttons: ghost (hairline) by default,
  the one primary action per form is solid accent with dark text.
- Drawer (task, capture, event): slides from the right, `--panel` background, same card chrome
  inside; header fixed with uppercase tracked title and a big status word.
- Confirmations (role change, archive) use an in-page dialog styled the same, not the browser
  `confirm()` — replace the existing native confirm with the styled one, keeping the behaviour.

## 9. What must not change
All ids, data attributes, routes, ARIA roles and keyboard behaviour that tests rely on; no new
runtime dependencies; no external network requests from the UI (fonts bundled); CSP `default-src
'self'` still passes; 360px has no horizontal overflow; contrast ≥ 4.5:1 for text, ≥ 3:1 for
UI hairlines on their background.

## 10. Owner credit and originality
This look is an original direction for DigitalMaid, inspired by the owner's taste. The
implementation must be written from this brief only.

## Appendix — as implemented (Stage I, 2026-09-06)

**Tokens (`app.css` `:root`).** `--bg #07070a`, `--panel #0e0e12`, `--card #17171d`, `--ink #ece8de`,
`--ink-2 #b7b2a4`, `--mute #8a8578`, `--accent #ff7a2a`, `--accent-ink #1a0d04` (dark text on the
primary button), `--accent-glow rgba(255,122,42,.28)` (rings and the breathing glow), `--ok #6fbf8a`,
`--warn #e0b04a`, `--error #e0605a`, `--info = --ink-2`. **Deviation:** `--line` is
`rgba(236,232,222,.38)`, not `.14` — at `.14` the hairline reaches only ≈1.5:1 on `--card`; `.38`
gives ≈3.1:1 on the card and more on `--panel`/`--bg`, which §9 requires. `--line-strong` (`.6`) is the
hover state. `tests/test_design_tokens.py` parses these values and asserts ink/ink-2/mute/accent ≥ 4.5:1
on bg/panel/card, `--line` ≥ 3:1 on all three, `--accent-ink` on `--accent` ≥ 4.5:1, status hues ≥ 3:1.
Radii 8px (cards) / 4px (controls); shadow `3px 3px 0 #000`, accent shadow when a card is active or
focused within.

**Type.** Outfit (variable 300–700) for everything; Doto (variable 700–900) only in `.num` inside the
big-number idiom with `font-variant-numeric: tabular-nums`. h1 30px/300, h2 21px/300, body 15px/400,
line-height 1.5. `.label` = 11px, 500, uppercase, 1.6px tracking, `--mute`; applied to widget titles,
card headers (`.panel-header h2/h3`, `.panel > h2:first-child`), `h4` section captions, `dt` keys, form
labels, tabs, pills (10px, 1.2px). Nav labels and drawer titles stay in normal case; the drawer gets an
uppercase kicker ("Task", "Event · kind", "Capture · status") and a big status word instead.

**Breakpoints.** >1100px: 220px rail with icons + labels, 12-column board. ≤1100px: 60px icon rail
(labels visually hidden, `title` tooltips), 3-col cards become 6, 6 stays 6, thirds become halves.
≤880px: all cards full width except the two big numbers (half each), knowledge two-column layout stacks.
≤640px: header wraps (wordmark + controls, search below), the rail becomes a top bar with a **Menu**
button (`aria-expanded`); the list is clipped until opened or focused (`:focus-within`), so every area
stays in tab order. ≤480px: big numbers full width, inline form rows stack, calendar Month switches
to the stacked agenda (unchanged JS).

**Components built.** Shell (`.header` wordmark / centred combobox search / pencil `#edit-board`
toggling `body[data-editing]` / `<details>` user menu with `#session-label` in the summary and Sign out
inside); 15 inline SVG symbols (11 areas + search, pencil, user, menu; 16px, 1.5px stroke) in
`index.html`, drawn from the brief; card chrome; `.big-number` (Review inbox, Inbox); `.dot-row`
(journal, last 14 local days from `GET /api/notes?kind=journal`, today ringed); `.list-item[data-status]`
leading dot rows; `.is-live` breathing glow (running/queued execution, leased occurrence, alive worker;
static ring under reduced motion); `.rail` occurrence nodes (leased ringed in accent); `.pdcc-chain`
Plan → Do → Check → Correction in the task drawer; hairline pills; `.kv` key/value rows; `.steps`
numbered tick column; calendar month grid with shared hairlines, today's number ringed, derived items
as dotted compact rows; bottom-hairline fields; ghost/primary buttons; `.confirm-dialog` on a native
`<dialog>` (`showModal`, Esc/Cancel/backdrop → false, Enter → true, focus returned).
**Accent budget:** the Automations page shows one "Run now" primary per job card, so pages with
several jobs exceed "≤3 per viewport"; every other page keeps to the rule.


---

# Appendix B — Second look (2026-09-06, Pi): what still separates us from the reference feel

Observed on the owner's reference board at 2× zoom. Written as instructions in my own words; still no code from the reference.

## B1. The page is a **board, not a document**
Reference: no page title, no lead paragraph, no card boxes. Widgets sit directly on the dark page and are separated only by **full-width hairlines** between rows; columns have no borders at all. The eye reads three columns of instruments with a hero in the centre.
Ours: every page starts with an H1 + explanatory paragraph, and every widget is a boxed card with border + shadow. That is the single biggest gap.
**Change:** on Today, remove the H1/lead paragraph (move the scope/generated-at text into the tiny footer meta of the rail). Widgets on Today lose the box: no border, no shadow, no surface fill — just the widget header and content on `--bg`, separated by hairlines (horizontal between rows; none vertical). Keep the boxed card style only for *drawers, dialogs and forms*, and for the task/list pages where boxes aid scanning.

## B2. Widget header signature
Reference: a 16px thin icon, then the title in **display sans, 18–20px, weight 400, UPPERCASE, letter-spacing ≈ 0.25em**, colour `--ink`. Right-aligned tiny meta in 9–10px `--mute` ("today", "6/6 fired today") and one ghost pill button ("+ ADD APP", "OPEN CAL": hairline border, 10px uppercase, 1.5px tracking, 6px radius). No underline/hairline under the header — the space does the work.
Ours: header is 10–11px mute label with a hairline under it. Too small, too quiet.
**Change:** widget title = 18px/400/uppercase/0.25em `--ink`; remove the header hairline; right meta 10px `--mute`; actions as ghost pills.

## B3. The clock / big-number treatment
Reference big numbers are **rendered in the display sans at 300–400 weight** (e.g. "08:32:38 am", "66", "0") in accent, 40–56px, with a two-line caption to the right or beneath in 10px uppercase mute. The **dot-matrix face (Doto) is used only for tiny things** — the week label "Wk36", the "30D+"/"2D" badges under nodes — not for the hero numbers.
Ours: hero numerals in Doto. Reverse it.
**Change:** `.big-number .num` → Outfit 300, 48–56px, accent, `tabular-nums`; use Doto 700 at 10–11px for: week number, small counters in node badges, the "1 / 6" style pagers.

## B4. Rhythm and density
Reference: labels 9–10px uppercase with 2–3px tracking; body 12–13px; widget inner padding ≈ 20px; row spacing tight (6–8px); large empty breathing space *below* content inside the widget rather than between widgets.
Ours: labels 10–11px, body 14–15px, generous padding everywhere → looks like a web app, not an instrument.
**Change:** body 13px; labels 9.5–10px with 2.5px tracking; list rows 6px gap; widget padding 20px 24px.

## B5. Micro-idioms to adopt
- **Dot grids** (reference "Q1/Q2" rows of filled squares; "PI REPORTS THIS MONTH" grid of hollow circles with the current one ringed and filled ones solid): squares 8×8 with 3px gap for day grids; hollow 12px circles for slot grids; filled = `--ink` at 70% (not accent); *current* = accent fill or accent ring. Use for: journal 14-day row (squares), procedure steps (circles), occurrences this month (circles).
- **Small mono-ish "system" rows** (reference routines table): time in Doto 10px, name truncated with ellipsis, status word uppercase mute at right ("FIRED"). Use for: Automations run history, worker heartbeats, audit lines.
- **Raised mini-card** (reference skill card): a slightly *lighter* opaque surface (`#1c1b18`-ish), 10px radius, soft 0 6px 20px rgba(0,0,0,.5) shadow, mono command in accent, two 24px icon buttons below (one accent-outlined). Use for: agent roster cards, procedure cards, capture rows with a file.
- **Node ring**: circles 40–44px, 1px hairline, icon inside, a Doto badge beneath ("2D", "30D+"); the one that matters gets an accent ring + glow. Use for: PDCC chain and Automations rail (we have the rail; give it these proportions and the badge).
- **"● SYNCED 08:30 AM" footer**: small accent dot + uppercase mute text at the bottom of a widget. Use for: "generated at", "last backup", "worker last seen".

## B6. Hero
Reference centre is a large ring with a slowly drifting particle sphere and a rail of nodes on its right edge. It gives the board a focal point. We don't need a globe. **Change:** give Today one hero at top-centre: the wordmark large (28px) over a thin 1px ring/arc drawn in CSS/SVG that shows **today's PDCC state at a glance** — four nodes on the arc (Plan/Do/Check/Correction counts in Doto badges), the node with the most items to act on ringed in accent. Static, no canvas, respects reduced motion. Below it the toolbar: pencil (edit board), search, layout, info — 20px thin icons, the active one in an accent-outlined rounded square.

## B7. Texture
Reference background has a barely visible large **hex-grid pattern** (≈2–3% ink) over near-black. **Change:** add a CSS-only repeating SVG data-URI hex pattern at ~3% on `--bg` (no network); off when `prefers-contrast: more`.

## B8. Keep from our version
The rail nav (reference has none — ours is a real product need), forms/drawer chrome, contrast rules, all behaviour and tests.


---

# Appendix C — Stage J brief (2026-09-06, Pi): hero as a readout, and ease of use

Appendix B lists the *look* gaps. This appendix adds meaning to the hero and a usability layer that the reference product does not have. Everything below is DigitalMaid's own design.

## C1. Hero = a live readout, not an ornament
Top-centre of Today, replacing the H1/lead paragraph:
- Wordmark 28px ("DigitalMaid" light / "Agentic OS" accent) above a thin toolbar of four 20px thin-stroke icons: **capture** (pencil → opens Quick Capture, C5), **search** (focuses global search), **layout** (toggles edit-board mode), **info** (opens the shortcuts/help overlay, C4). Active one sits in an accent-outlined 6px-radius square.
- Beneath: a large **ring** (1px hairline, 2 concentric, outer ≈ 520px at 1280, scales to viewport width − 32px at 360). Inside it a `<canvas>` **particle field**: four loosely-clustered colour groups, one per PDCC phase (Plan = mute-ink, Do = accent, Check = a cool teal you choose for AA on bg, Correction = a warm rose you choose). **Dot count per cluster = live number of open items in that phase** for the current scope (min 12 dots so an empty phase still reads as a faint cluster; cap 400 per cluster). Slow drift (< 6px/s), no interaction cost; `prefers-reduced-motion` → static render; canvas is `aria-hidden` and a visually-hidden text summary ("Plan 4 · Do 7 · Check 2 · Correction 1") sits beside it. Data comes from the existing `/api/today` payload — add the four counts to it if not already present (server-side, tested).
- **Node rail** hugging the ring's right edge (arc from ~1 o'clock to ~4 o'clock): six 44px circles, 1px hairline, thin icon inside, **Doto 700 10px badge beneath** showing age of the oldest open item ("2D", "30D+") or the count. Nodes: Plan, Do, Check, Correction, Automations, Inbox. Each is a real `<a>` to its page (keyboard focusable, visible focus ring). The node with the most overdue/needs-attention items gets the accent ring + soft glow; at most one glows.
- Below the ring: a single **"Next" strip** — one line, 13px, `--ink`: the single most important action right now, computed server-side (`GET /api/today` gains `next_action: {label, href, reason}`; priority order: overdue Check > blocked Do > oldest Correction > Inbox older than 24h > next scheduled automation; tested with fixtures). One ghost pill "Open".

## C2. Board rules (from B1–B4, now binding)
No H1/lead on Today; widgets unboxed on `--bg`, hairline separators between rows only; widget title 18px/400/uppercase/0.25em; big numbers Outfit 300 48–56px accent; Doto only for tiny counters/badges/week; body 13px; labels 9.5–10px/2.5px tracking; hex-grid texture 3% via CSS data-URI, off under `prefers-contrast: more`. Boxed cards stay for drawers, dialogs, forms, list pages.

## C3. ⌘K command palette
`Cmd/Ctrl+K` (and the toolbar search icon's long-press is NOT needed — keep it simple) opens a centred palette (`role="dialog"`, focus trapped, Esc closes, returns focus). One input; results grouped: **Go to** (all 11 areas), **Create** (task, capture, note, journal entry, procedure, event, goal — each opens the existing create form/drawer), **Run** (automations by name → existing run-now with the same confirm), **Recent** (last 8 opened tasks/notes, stored in localStorage, scope-keyed). Fuzzy match on title (simple subsequence scoring is fine); arrow keys + Enter; max 12 rows visible. No new dependencies.

## C4. Keyboard shortcuts + help overlay
Global (ignored while typing in inputs/textareas/contenteditable): `g t` Today · `g i` Inbox · `g a` Automations · `g c` Calendar · `g k` Knowledge · `g s` Settings · `n` new task · `c` quick capture · `/` focus search · `?` help overlay · `Esc` closes any overlay/drawer. Help overlay lists them in two columns with `<kbd>` styling; the info icon opens the same overlay. Discoverability: a one-time dismissible hint pill under the Next strip ("Press ? for shortcuts") stored in localStorage.

## C5. Quick Capture everywhere
Pencil icon / `c` opens a small bottom-right sheet (not a full drawer): one textarea, optional file, "Capture" primary; posts to the existing captures API; success toast with "Open in Inbox" link; stays open for another capture until Esc. Keeps the rule that capture is the entry point for everything.

## C6. Empty states that teach
Every widget/list with zero rows shows: a 16px thin icon, one sentence "what lives here" (write them per area), and one ghost pill with the create action for that area. No lorem, no illustration.

## C7. What must not change
All routes, ids, data-attributes, ARIA names the tests use; auth/CSRF; the rail nav; contrast rules; zero functional regression outside the additions named above (today-payload fields, next_action, recent list in localStorage).


---

# Appendix D — as implemented (Stage J, 2026-09-06)

**Board.** Today has no H1/lead; `#hero` (`aria-label="Today"`) is the header. Widgets are `section.widget` on `--bg` with no border, shadow or fill; each draws one bottom hairline that spans the column gap (`.board { overflow: clip }`), so rows read as full-width lines and columns have none. Titles 18px/400/uppercase/0.25em `--ink` with a 16px thin icon, right meta 10px `--mute`, no header hairline; quarter-width widgets (Review inbox, Inbox) drop to 15px/0.2em so the tracked title does not wrap under its count. Body 13px, `.meta` 12px, labels/`h4`/`dt`/form labels 10px with 2–2.5px tracking. Big numbers are Outfit 300 56px (48px ≤480), accent when the count asks for action and `--ink-2` at zero (a hot-orange zero would read as an alarm; this keeps the ≤3 accent budget). Doto 700 10px only in `.badge` (rail node counters). Ghost pills `.pill-btn` (hairline, 10px uppercase, 6px radius) replace the small buttons on the board. Scope + generated-at moved to `.board-foot` (accent dot + uppercase mute, B5). Texture: `hex.svg` at 4.5% stroke opacity tiled under the vignette, off under `prefers-contrast: more` — a static file rather than a data URI because CSP `default-src 'self'` blocks `data:` images.

**Hero (C1).** Wordmark 28px; toolbar of four 20px/1.25px-stroke icons (capture → Quick Capture, search → focuses `#global-search`, layout → edit-board toggle, mirrored with the header pencil, info → help); the active one gets the accent-outlined 6px square. Stage `min(520px, 100% − 48px)` with 48px reserved on the right for the rail; two 1px rings (inner at 7%); canvas at inset 8%, `aria-hidden`, with `#hero-summary` ("Plan 4 · Do 7 · Check 2 · Correction 1") visually hidden beside it. Clusters: Plan `--ink-2`, Do `--accent`, Check `--phase-check #4fb3a9` (8.0:1 on bg), Correction `--phase-correction #e07a8c` (7.0:1); dots `clamp(count, 16, 400)`, drift ≤ 5 px/s bounded to the cluster, single static frame under reduced motion, loop stops when the canvas leaves the DOM. Rail: six 44px nodes on the circumference at 30°–120° (CSS `sin()/cos()` per `nth-child`), thin icon inside, Doto badge beneath (counts; Automations = due occurrences from `GET /api/jobs`, "—" if that call fails); `data-glow="true"` on the node `next_action.phase` names — accent ring + breathing glow, at most one. ≤480px the rail becomes a centred row under a full-width ring. Next strip: accent dot + "NEXT" kicker, label, mute reason, ghost "Open" (`href` from the API; task hrefs open the drawer via `#/goals/<id>`); when null: "Nothing is waiting on you right now." with a "Capture" pill. Hint pill "Press ? for shortcuts" until dismissed or help opened (`localStorage dm:hint:shortcuts`).

**Palette / shortcuts / capture / empty states (C3–C6).** `#command-palette` centred at 12vh, `role=dialog aria-modal`, combobox input + listbox, groups Go to (the 11 nav items, read from the DOM) / Create (task, capture, note, journal entry, procedure, event, goal → the existing forms) / Run (jobs, `Run now: …` → the page's own run-now button) / Recent (8, scope-keyed); subsequence scoring with adjacency and word-start bonuses; arrows/Home/End/Enter, Tab trapped, Esc and backdrop close, focus returns to the opener (a hidden input is blurred first so later shortcuts are not treated as typing). `#help-overlay` two columns of `<kbd>` rows; `#quick-capture-sheet` bottom-right, non-modal, textarea + optional file, stays open after a capture, `#toast` (role=status) with an "Open in Inbox" pill. Empty states `.empty-state` (icon, one sentence, one ghost pill) on every Today list widget, Goals/projects/tasks, Knowledge, Procedures, Review (3 lists), Outputs, Automations, Capture inbox group, Settings tokens/connections. Agents never shows one (built-in roles ship with every workspace).

**Deviations.** `next_action` carries a fourth key `phase`; badges show counts, not ages (allowed by C1); the hex texture is a file, not a data URI; the palette shows every match in a scrolling list of ~12 visible rows rather than truncating.


---

# Appendix D — Stage K brief (2026-09-06, Pi): usable without a manual

Findings from Pi's first-time-user walk of the product (11 pages, `n`, `c`, ⌘K). Principle for this stage: **the product should guide an action, not teach a philosophy.** The philosophy stays true and enforced server-side; it moves out of the user's way.

## D1. Plain-language page leads + "How this works" disclosure
Every page currently opens with an engineering paragraph. Replace each lead with **one sentence in the user's language** (≤ 90 chars) and keep the current text verbatim inside a collapsible `<details class="how">` with summary "How this works" (ⓘ icon, 12px mute, closed by default, state remembered per page in localStorage). Leads to use:
- Goals and Projects: "Goals are the results you want; projects deliver them; tasks are the work."
- Knowledge and Journal: "Notes, research, decisions and your daily journal — nothing is ever deleted."
- Skills and Workflows (renamed **Procedures**): "Step-by-step procedures you can run; each run becomes a chain of tasks."
- Review Inbox: "Work that needs a human decision from you."
- Outputs (renamed **Deliverables**): "Every finished piece of work, with its check and acceptance status."
- Automations: "Scheduled work that runs on its own and lands in your Review Inbox."
- Agents: "The AI roles that do work here, and whether each one is ready."
- Calendar: "Your events plus deadlines, scheduled runs and decision reviews."
- Capture Inbox: "Drop anything here now; shape it into a task, note or goal later."
- Settings and Connections: "People, roles, tokens, backups and what this workspace is connected to."
Today has no lead (hero rule).

## D2. One phase vocabulary everywhere
- Colours: exactly the hero's four tokens on every pill, dot and node — Plan `--ink-2`, Do `--accent`, Check `--phase-check`, Correction `--phase-correction`. Done/accepted uses `--ok` (green); blocked keeps warn.
- Every phase pill gets `title` + `aria-description` with the plain meaning: Plan "Not started — waiting on people, method, tools, materials or budget" · Do "Someone is working on it" · Check "Finished; waiting for a human to check it" · Correction "Failed its check; being fixed" · Done "Checked and accepted by a human".
- Same words on every page: Goals, Outputs, Review Inbox, Today and Calendar must use these five labels (replace "unaccepted", "awaiting check", "in Correction for…" where they act as the phase; keep them as *secondary* meta if they carry extra info).
- The `?` help overlay gains a **Phase legend** section (four coloured dots + one-line meanings) above the shortcuts.
- Hero nodes get a 9px uppercase Doto caption under the badge: PLAN · DO · CHECK · FIX · AUTO · INBOX; the glowing node's `title` = the Next strip's reason.

## D3. Two-tier create forms with defaults
Task, goal, project, event, note, procedure forms: **tier 1** shows only what is essential — Task: Title + "What does done look like?" (single line → becomes the first acceptance criterion). Goal: Title + "How will you measure success?". Project: Title (goal preselected from context). Event: Title + when. Note: Title (kind preselected from the current filter). Procedure: Title.
Everything else (owner, next action, priority, more criteria, resources/5M, schedule details) sits under a `<details>` "More options" — closed by default, open automatically if any of those fields is already non-default (edit mode).
Defaults: owner = current user's display name; priority = Normal; **priority is a 3-way segmented control** Low / Normal / High (maps to 3 / 2 / 1 integers server-side — no API change). Required fields marked with a small accent dot; the primary button is disabled until they are filled and shows why in its `title`.

## D4. First-run checklist on Today
When the scope has **no goals and no captures**, Today shows a "Start here" widget directly under the hero (before Needs attention): three steps with hollow-circle → filled-circle progress —
① "Write your first goal" → opens the goal form (D3 tier 1). ② "Capture something on your mind" → opens Quick Capture. ③ "Turn a capture into a task" → opens Capture Inbox with the first capture selected.
A step fills when its object exists. A "Dismiss" ghost pill hides it forever (localStorage key scoped to workspace id). Never shown in demo scopes with data.

## D5. Grouped rail + counts + renames
Rail groups with 9px uppercase group labels (no boxes): **WORK** Today · Goals and Projects · Calendar — **INBOX** Capture Inbox · Review Inbox — **KNOWLEDGE** Knowledge and Journal · Procedures — **AUTOMATION** Automations · Agents · Deliverables — then Settings and Connections at the bottom. Capture Inbox and Review Inbox show a right-aligned Doto count badge (from existing today/counts endpoints; hidden when 0). Routes/ids unchanged; only labels change (tests that assert nav labels update accordingly and are listed in PROGRESS). Search placeholder and the palette "Go to" group use the new names.

## D6. Frictions
- "Run now" on Automations: ghost button (not solid accent); on click, the in-page confirm states the job's spend authorization amount (or "no spend authorized") and the agent; solid accent only inside the dialog.
- Worker status line → a full-width hairline banner: "Automations are paused — no worker is running." + mute hint "Start one with `digitalmaid worker --loop`" (mono). Green dot + "Worker active · last seen 14 s ago" when alive.
- Hashes, fencing tokens, schedule versions, misfire policy: move into a `<details>` "Technical details" on each row/card; never in the first line.
- Login page must not fire authenticated fetches before login (no 401s in the console).
- Priority integer input removed from all forms (D3).

## D7. Must not change
Routes, ids and ARIA the tests rely on except the label renames listed in D5; server-side transitions; contrast rules; zero functional regression; no new dependencies; no network.

---

# Appendix E — as implemented (Stage K, 2026-09-06)

**D1.** Every page except Today opens with the Appendix D sentence (`LEADS` in `views.js`); the previous lead sits verbatim inside `details.how` ("How this works", ⓘ, 12px mute, closed; state in `localStorage dm:how:<route>`). Review Inbox keeps its count as a small meta line under the lead. **D2.** `phasePill()` for Plan/Do/Check/Correction/Done with `data-phase`, `title` and `aria-description` = the plain meaning; `app.css` maps Check → `--phase-check` and Correction → `--phase-correction` on every dot and pill (blocked/required stay warn); the help overlay opens with a five-row legend; hero nodes carry 9px Doto captions PLAN · DO · CHECK · FIX · AUTO · INBOX and the glowing node's `title` is the Next reason. **D3.** `moreOptions()` (closed unless a field is non-default), `segmented()` Low/Normal/High → 3/2/1, required labels get an accent dot, the primary is disabled with `title="Fill in: …"` until required fields are filled. Tier 1: Task = Title + "What does done look like?" (first criterion); Goal = Title + "How will you measure success?"; Project = Title; Event = Title + date/start; Note = Title (kind follows the filter tab); Procedure = Title + Steps (deviation: the server needs steps; purpose defaults to the title). Owner defaults to the signed-in user. The priority integer input is gone everywhere. **D4.** `#start-here` under the hero: three numbered nodes (filled green when the object exists), each with its ghost action, Dismiss; shown only on a scope with neither goals nor captures at first sight, remembered per workspace in `localStorage dm:starthere:<id>`. **D5.** Rail groups WORK / INBOX / KNOWLEDGE / AUTOMATION, Settings under a hairline; 9px tracked group labels; Doto count badges from `GET /api/counts` hidden at 0 (corner of the icon at ≤1100px); Procedures and Deliverables renamed everywhere including the palette; ids/routes unchanged. **D6.** Run now is a ghost button; the in-page confirm names the agent and the spend authorization ("no spend authorized" otherwise) with the only solid accent inside the dialog; the worker line is a full-width hairline banner (paused + mono start command, or green dot + "Worker active · last seen N s ago"); hashes, fencing tokens, schedule versions and misfire policy live in `details.tech` ("Technical details") on job cards, occurrence rows, deliverable rows and drawer versions; the login page renders with zero requests when the browser has no `dm:signed-in` hint (set on login, cleared on logout or a 401).

**Not verified by eye:** no Stage K screenshots exist yet (see PROGRESS.md).

---

# Appendix F — Observatory (2026-09-09, Pi; implemented Stage 1 the same day)

The owner approved Pi's static mockup (`/opt/data/tmp/mockup/DigitalMaid Observatory.html`) as the new
look. Stage 1 is look-and-feel only: no data or feature changes. Everything below **supersedes** the
matching rule in sections 2–5 and Appendix B; rules not mentioned (layout grid, board editing,
idioms, empty states, D1–D7) stand. History above is kept as written.

## F1. Mood
A quiet night observatory: a faint twinkling starfield behind everything (`sky.js`, fixed canvas,
`aria-hidden`, static under `prefers-reduced-motion`, paused while the tab is hidden), two soft light
sources (warm gold top-centre, cool sky bottom-right via `body::before`), and glass cards floating
over it. Gold replaces orange as the single accent; a light serif carries the titles.

## F2. Tokens (`:root` in app.css; `tests/test_design_tokens.py` enforces contrast)
- Surfaces: `--bg #06070c`, `--bg-2`/`--panel #0a0c14`, `--card rgba(16,18,28,.72)` (glass, `backdrop-filter: blur(10px)`), `--card-solid #10121c` for menus, dialogs, drawer and `<option>`s (and the opaque stand-in the contrast tests measure against; a test keeps it within 6 units of the composite).
- Hairlines: `--line rgba(235,230,218,.09)` (decorative dividers), `--line-strong …,.18` (control borders). *Supersedes* the 3:1 hairline rule of §2 — dividers are decorative; the gold focus ring and every active state must pass 3:1 instead.
- Ink: `--ink #ebe6da`, `--ink-2 #aca79a`, `--mute #827e74` (the mockup's `#6f6b62` reads 3.5:1 on the card; `#827e74` is the darkest value that passes 4.5:1).
- Accent: `--accent #d4af5a` (gold), `--accent-2 #f0d78a`, `--accent-glow rgba(212,175,90,.22)`, `--accent-ink #1a1204`. **`--ember #ff7a2a` is retired to one job: the thing running right now** (running execution dots/pills, the breathing Next dot, the leased run node, the live worker banner).
- Status: `--ok #8fd9a8`, `--warn #d4af5a`, `--error #e07a8c`. Phase companions `--phase-*-2` unchanged (hero.js reads them).
- Phase dots (D2 amended): Plan `--phase-plan-2` (sky), Do `--accent` (gold), Check `--phase-check`, Correction `--phase-correction`, Done `--ok`.
- Radius 14px cards, 999px pills. `--shadow: none`; `--shadow-accent` is a soft gold ring; overlays use `--shadow-float`. *Supersedes* §5's hard offset shadow. The hex texture is no longer drawn (file still served).

## F3. Type
- `--serif` Cormorant Garamond (self-hosted, OFL, latin subset, light upright + italic): page h1 42px/300, hero greeting 46px/300 (italic gold name), card/widget h2 22px/400, goal title 28px/400, project h3 19px/400, drawer/dialog titles 26px/300, the Next title 24px/300, the wordmark 22px/300.
- Outfit stays for body (14.5px/1.55), rows (15px), buttons and labels. Labels: 10px/500, uppercase, 0.22em, `--mute`, led by the tri-dot ornament (`::before`: three 3px dots) on `.label`, widget `h4`, drawer `h4`, rail group labels, kickers, big-number captions.
- Doto stays for numerals: node badges, rail counts (muted), project done/total. Big numbers stay Outfit 300 (test-enforced), gold when they ask for action.

## F4. Surfaces and controls
- Card: `--card` + 1px `--line` + 14px radius + blur + faint top light (`::before` gradient). Header: serif title left, uppercase muted meta right, hairline. Rows: 9 % hairlines, 5px leading status dot, 12px vertical padding.
- Tags (`.pill`): hairline, 9.5px, 0.16em, 5px dot. Buttons (`.btn`, `.pill-btn`): ghost pills, 10.5px, 0.18em, `--line-strong`; **primary = gold text on a gold hairline** (`.gold` / `.is-primary`), never a fill. Inputs keep the bottom-border style, focus gold.
- Shell: rail 236px with the orbit emblem + serif "DigitalMaid" + gold "AGENTIC OS"; the active item is a gold dot in the gutter (no box); badges Doto muted. Header: pill search with a ⌘K key cap, avatar circle with one gold star; the header wordmark is gone (it lives in the rail; ≤640px the rail is a top bar with the mark and a Menu button, above the header).
- Overlays (drawer, palette, help, sheet, confirm, listbox, user menu) use `--card-solid` and `--shadow-float`.

## F5. Today
- Hero (≥1100px) is two columns: left the greeting "Good morning/afternoon/evening, {Name}." (signed-in username, first letter capitalised; "Good morning." when unknown), the date line "Wednesday 9 September · N open items across four phases", and the **Next** block (italic gold serif kicker with the breathing ember dot, serif title, reason, pills Open (gold) / Capture / Shortcuts ?). Right: the orrery — the existing particle field inside a gold ring (`rgba(212,175,90,.18)`) with an outer hairline and four ticks — and the six nodes as a column to its right (a 6-across row under it on narrow screens). The hero wordmark and icon toolbar are gone; `#hero-capture` and `#hero-info` are the pills, search is the header pill and `/`, `#hero-layout` is the ghost "Edit layout" pill in the board head (`renderBoardHead`).
- Board widgets are glass cards (Needs attention 6 / In progress 6 / Achieved 12 / Review 4 / Journal 4 / Inbox 4).
- Blocked-in-Plan rows collapse the 5M reasons into one quiet gold-dot line "*k of 5* readiness checks not assessed · money needs a waiver · waiting on: …" (`gateSummary`, full list in the title and in the task drawer); Correction rows get one rose-dot "Failed: …" line (`failedLine`).

## F6. Goals
Each goal is a row: a 340px summary column (status tag, serif title, Owner/Measure, a dot row of its tasks — filled when Done, gold when in Do — a "k of n tasks moving · m done" line, ghost pills) beside a grid of project cards (`auto-fill, minmax(300px, 1fr)`: serif title, Doto done/total in gold, owner · criteria, task rows with status dots, New task pill). Stacks at ≤1100px.

## F7. Tests adjusted for the change (and why)
`test_design_tokens.py`: accent is gold (ember kept as `--ember`), surfaces measured against `--card-solid` (the card is translucent), the 3:1 hairline test became "hairlines are translucent ink; the focus ring passes 3:1", Cormorant faces and files added. `test_ui_browser.py`: Plan dot is the sky companion hue (was `--ink-2`); Today's only h1 is the hero greeting (was "no h1"); the rail mark is the first Tab stop after the skip link. `test_ui.py`: `sky.js` and the two Cormorant files are on the allow-lists.

## F8. Instrument mapping (Stage 2, 2026-09-09) — every drawn thing is real state
The hero field reads `today.instrument` (`views.instrument`, `tests/test_today_instrument.py`). Nothing
decorative is added without a data source; the tuned constants of the halo field are untouched (the
instrument acts through factors). The canvas stays `aria-hidden`; `#hero-summary` carries the count and
the worker state; the nodes rail remains the keyboard path (no focusable canvas).

| Data (`instrument.…`) | Visual |
| --- | --- |
| `stars[]` (one per open task) | A named star in its phase cluster: 2.2–2.8 px, brighter than the halo dots, position hashed from the task id (stable across renders), nearer the cluster centre, drawn after the halo in depth order with a 1 px ring of the phase colour at 35 %. |
| Plan `ready` / `gates_unmet` | Ready → gold (`--accent-2`) star with a soft halo. Not ready → alpha dimmed by `gates_unmet/5` (floor 0.35) inside a hairline cage circle (3× radius, ink at 25 %). |
| Do `execution` | `running` → the star pulses `--ember` (1.6 s) and sheds ≤ 40 ember sparks that drift toward the Check cluster, fading in 1.5 s. `failed`/`blocked` → rose flicker, sparks fall toward Correction. Otherwise plain gold. |
| Check `waiting_hours` / `overdue` | A slow gold dashed ring (2.5× radius, 1 px, turning gap = waiting). `overdue` → the ring is `--phase-correction` and 1.6 px. |
| Correction `failed_criteria` | Rose star; flicker amplitude 0 → calm, 3+ → strong; a thin rose quadratic arc (1 px, 30 %) from the star back toward the Do cluster centre. |
| `next: true` (or `next_action.phase`) | A 1 px gold thread (α 0.55, sinus shimmer) from the core centre to the star, which is the brightest element. `automations` with no star → thread to the outermost ring's bead/12 o'clock; `inbox` → none. |
| `core.accepted_total` / `accepted_7d` | Core drawing scale `1 + min(total,40)/40 × 0.35` (positions and radii; `CORE_SPREAD` untouched); core shadowBlur `× (1 + min(7d,7)/7 × 1.2)`. A re-render whose total grew fires one comet — a gold streak from the Check cluster into the core over 1.4 s (previous total remembered per `#scope-label`; first load never fires). |
| `captures_open` | Wind motes shown = `min(1400, 400 + captures × 100)` of the 1400 created; motes above the baseline are `--phase-do-2` at 70 % — raw material. |
| `rings[]` (enabled jobs, first four) | A bead (r 2.4, ring hue glow, near-white centre) rides ring *i*'s plane at `2π / (period_seconds / 300)` rad/s (one real hour = 12 s); `period_seconds: null` (once) sits at 12 o'clock; rings without a job carry no bead; no jobs at all → dust bands at 60 %. Beads behind the clusters draw under them, near ones over. |
| `worker_alive: false` | Idle spin and orbit factors → 0 (constants untouched); `#hero-summary` gains "Worker offline."; `<p class="hero-caption-note">Worker offline — the system is still.</p>` under the ring (Outfit 11 px, `--mute`). |
| `journal_written: true` | `#hero-ring.is-written`: brighter gold border, faint gold shadow, brighter ticks. |
| hover / click (12.) | Nearest projected named star within 10 px → `#hero-tip` (`role=status`, Outfit 12 px on `--card-solid`, hairline, 8 px radius: title + "Plan · 3 of 5 gates unmet" / "Do · running" / "Check · waiting 30 h · overdue" / "Correction · 2 criteria failed"), cursor pointer; a still release (< 4 px travel) sets `location.hash = star.href`. Dragging still rotates. The canvas publishes `data-stars` (`[{id,x,y}]`, ≤ 2 Hz) for tests. |
| `prefers-reduced-motion` | Motion stops (as before); cages, rings, thread, beads and the comet's absence remain visible statically. |

Tests adjusted: `test_hero_readout_matches_the_today_api` and the empty-state summary now check the
phase-count prefix (the sentence continues with the star count / worker state — asserted by the new
tests). Headless fps (software GL, 1280×900): 43.5 at dpr 1 (was 43 before Stage 2), 34.5 at dpr 2.

## F9. Uninstall (0.3.0) — one quiet panel, two proofs, no root in the app
The last panel on Settings, owners only (`section#settings-uninstall`, title "Uninstall DigitalMaid"). A
glass panel like every other; nothing red on the page until the dialog opens.

- Available (the process may write `DIGITALMAID_UNINSTALL_DIR`): meta copy "Removes the app and its
  background services from this machine. Your workspace is kept unless you choose to erase it." and one
  ghost button "Uninstall…" (`#uninstall-open`, `data-write`).
- Not available (owner, but no installer watcher): meta line "Uninstall from here is available for installs
  made by the one-command installer. Otherwise run digitalmaid-uninstall on the server." Members and
  viewers never see the panel (the read model omits it: `users` is null for them).
- Dialog (`dialog#uninstall-dialog`, built on open, removed on close, same shell as `#confirm-dialog`):
  title "Uninstall DigitalMaid?", one sentence of consequence, then the checkbox `#uninstall-purge`
  **unchecked by default** — "Also erase my data, backups and account (cannot be undone)" — the password
  field `#uninstall-password`, the text field `#uninstall-confirm` labelled "Type UNINSTALL to continue",
  Cancel, and "Uninstall now" (`#uninstall-submit`, `.btn.is-danger`: `--phase-correction` rose text on a
  rose hairline, still no fill). The danger button stays disabled until the word is exactly `UNINSTALL`
  and the password is non-empty. Server refusals (wrong password 403, wrong word 422, not available 409,
  rate limit 429) appear inside the dialog as an `alertBox`.
- After 202 the whole `#view` becomes `#uninstalling`: serif title "Uninstalling DigitalMaid", meta "This
  page will stop responding in a few seconds. You can close this tab.", then either "Your data is being
  erased." or "Your workspace was kept at <root>." The page polls `/api/healthz` every 2 s; the first
  failure flips the meta line to "Done."

Safety rules: default keeps data; owner role, password re-entry (sharing the login rate limiter) and the
typed word are all checked server-side; CSRF marker required; API tokens are out of scope; the app only
writes `<dir>/request.json` (tmp + rename) and audits `uninstall:request` — the removal itself is done by
the installer's root-owned systemd path unit (`docs/OPERATIONS.md`, "Uninstall"). Tests:
`tests/test_api_uninstall.py`, `tests/test_ui_browser.py` (four `*uninstall*` / dialog tests).

## F10. Hermes integration (0.3.0) — one status panel, the trade-off in plain words, one command
Owners only (`section#settings-hermes`, title "Hermes integration"), placed directly before the Uninstall
panel, which stays last. Same glass panel as the rest of Settings; nothing to click except the copyable
command.

- Lead (meta): "Show DigitalMaid as a tab inside the Hermes Agent dashboard on this machine
  (docs/HERMES-INTEGRATION.md, “Inside Hermes”)."
- Two `dl.kv` rows from `GET /api/settings → hermes`: **Trusted proxy** → "trusted proxy: configured" /
  "trusted proxy: not configured"; **This session** → "this session: signed in from Hermes" / "this session:
  signed in with a password".
- The trade-off, stated once and plainly (meta): "Single login: inside the Hermes tab, whoever is signed in
  to Hermes acts as this workspace’s owner without a second password. The trade-off is a weaker per-user
  audit — every action taken from the tab is recorded as that owner. Keep individual DigitalMaid accounts if
  several people share the Hermes dashboard and you need to tell them apart."
- One-paste command in `code#hermes-command` (`.mono.token-value`, `user-select: all`, so one click selects
  it): `curl -fsSL https://raw.githubusercontent.com/DigitalMaid/digitalmaid-install/main/install.sh | bash -s -- --hermes`;
  when `settings.install_mode === "system"` (the installer sets `DIGITALMAID_INSTALL_MODE` in the unit) the
  pipe reads `| sudo bash -s --` and the lead says "paste this on the server, as root". A closing meta line
  says what the command does and that nothing restarts Hermes for you.
- *Your account* (same page): for a trusted session the line reads "Signed in via Hermes (trusted proxy) —
  all actions are recorded as <owner>." instead of "Signed in as <name>." (`#settings-account-line`).
- Inside the Hermes tab the shell itself is unchanged: relative asset URLs, `api.js` base from
  `document.baseURI`, and the login panel appears only if the trusted sign-in is refused.

Tests: `tests/test_ui_browser.py` (owner sees panel + exact command, sudo variant, viewer never sees it),
`tests/test_hermes_plugin_browser.py` (account line and status rows through the real proxy).

## F11. JOH — Journey of Humanity (0.5.0)
One rail item under a new JOURNEY group, hidden until the user turns it on in Settings. Six tabs in the Knowledge tablist idiom. Every drawing is inline SVG built in `joh.js`, stroke-only, on the transparent card so the sky shows through: the astro wheel (sign ring, whole-sign house ring with Doto numerals, planet marks, aspect lines gold for soft / rose for hard), the bodygraph (nine centres in the standard layout, defined centres washed 14 % gold with a gold stroke; personality channels gold, design channels rose, both = gold with a rose core), the hologenetic diagram (spheres as hairline-joined nodes, key numbers in Doto gold), the four Prime Gifts as gold nodes on one hairline arc, the enneagram result as nine thin gold bars. Serif titles, tri-dot labels, ghost pills, gold primary. Every chart tab ends with the zodiac line — `Sidereal (Lahiri) · Switch to tropical · the other zodiac reads …` — because the owner chose all-sidereal and the official references are tropical. Compass answers open with a "Chart in the room" strip naming the profile facts the answer leaned on. Known cosmetic gaps for the next pass: planet labels collide when several bodies sit within a few degrees; gate numerals on the bodygraph are small at 1280.

**F11 addendum (JOH-3, 2026-09-15) — what changed in the drawings.** *Astro wheel:* the tick stays at the true longitude for every body; labels of bodies closer than 6° of arc form a fan, spread 6.5° apart around the group's midpoint on alternating radii (planet ring, then 24 units inward), each joined to its own tick by a 0.6-unit leader hairline at 55 % ink. Fans that would touch a neighbour merge until every group clears the next by 6°, and the sweep starts after the widest empty arc so a fan never straddles 0° Aries. A body on its own is drawn exactly as before (no leader). Verified in the browser: for ny-1994 (seven bodies within 35°) no two label boxes intersect at 1280 or 390. *Bodygraph:* gate numerals are 10 SVG units (≈ 11.3 px at 1280 where the graph is 340 px wide; ≥ 9 px at 390), each on a small `--card-solid` rounded backing rect so channel lines never strike through the digits; numerals sit a fixed reach from their centre (36 units, or 30 % of a short channel) and parallel channels stagger theirs 8 units along the line, parallels now 15 units apart; defined centres carry a 1.5 px gold stroke. Remaining crowding where many channels leave the Throat and Root is legible but dense — a later pass could route gate numerals around the centre's edge instead of along the channel. *Onboarding card:* "Edit birth data" reopens the same card with the saved date, time, place line, latitude, longitude and timezone filled in; the card now ends with "Place data © OpenStreetMap contributors" under the privacy line.

## F12. Languages (0.5.1, 2026-09-16)
Five languages, chosen per user in Settings (`section#settings-language`, right after "Your account"): five ghost pills with the native names — English · Tiếng Việt · 中文 · Français · 日本語 — the active one gold with `aria-pressed=true`; choosing one saves it and re-renders the app in place, `<html lang>` follows, and a meta line says whether the choice is stored ("Saved for your account.") or came from the browser. First default = the browser's language.

**Type per script.** Latin (en, fr) and Vietnamese: Outfit for body/labels, Cormorant for titles (the Vietnamese ranges are served by Be Vietnam Pro / Cormorant Vietnamese subsets under the same family names). Chinese and Japanese: the same stacks with `NotoSansSC`/`NotoSansJP` after Outfit and `NotoSerifSC`/`NotoSerifJP` after Cormorant (`html[lang=zh]`, `html[lang=ja]` in app.css) — digits and Latin words keep the house faces, CJK glyphs fall to Noto. Noto Serif ships at weight 300 only, so CJK titles stay light (h1–h3 forced to 300, line-height 1.3); Noto Sans at 400 carries body and labels. **CJK line-height is 1.7** for body, paragraphs, rows and inputs (Latin stays 1.55). Uppercase tracked labels lose most of their tracking in CJK (0.08em) because letter-spacing between ideographs reads as gaps, not emphasis. `fonts-cjk.css` (450 unicode-range slices) is linked only for zh/ja; browsers fetch only the slices a page uses.

**Length.** Vietnamese and French run 20–40 % longer than English: pills and buttons wrap (`white-space: normal`) instead of clipping, rail labels may break anywhere (`overflow-wrap: anywhere`); the widget titles, hero pills and Settings pills were checked in the screenshots at 1280 and at 360 (no horizontal overflow on Today, Settings, JOH Overview, Gene Keys).

**Bilingual rule.** Spiritual vocabulary is shown in the user's language with the English in brackets on first mention — "Tự do (Freedom)" — on the **Gene Keys** and **Bodygraph** tabs only; the Overview, Compass strip and everywhere else show the local word alone. Product nouns (DigitalMaid, Agentic OS, JOH, Compass) stay English; Plan/Do/Check/Correction may be translated with the English in brackets on a page lead's first use. Dates and numbers follow the language through `Intl`.

# Appendix G — JOH "Plates" (0.6.0, approved by owner 2026-09-16 from mockup round 3)

Owner brief: "redesign all the charts in JOH — overview, astro, bodygraph, gene keys, enneagram — to look and feel like the drift/breathing dots cluster of the Today hero, 3D, with the astro effect as if they were real stars", then "more like these references" (five engraved gold astro-plates: *World Engine / Machina Mundi*, *Axis of Return* seated light-body, a zodiac wheel with a sun blaze, a golden-spiral chart, a hand touching an orrery). Approved artefact: **`/opt/data/digitalmaid-preparation/joh-3d/mockup-v3/index.html`** (+ `fonts/`), also served from the temporary `/mockup/` route. The mockup is THE SPEC for look and motion; this appendix names what must carry over, what is data-bound, and what must not change.

## G1. Mood
An engraved star plate. Near-black page (`--bg`) under a very faint violet/magenta nebula wash and a few faint gold constellation lines; twinkling cross-shaped sparkles; everything else gold hairline (`--accent` at 20–55 % alpha), spaced-caps Cormorant titles, Doto numerals. One 3D field per chart: idle spin, grab-to-turn (yaw/pitch, inertia, eases back to a rest pitch), every dot breathing on its own sine — the same language as `hero.js`. No `shadowBlur` anywhere: glow is cached radial-gradient sprites drawn with `drawImage`.

## G2. Modules and files
- New `digitalmaid/ui/plates.js` — the engine (class `Field`: fit/ResizeObserver, project with perspective, pick, tick, draw in the fixed layer order; helpers `cloud`, `thread`, `ring`, `shell`, `sparks`, `circle`, `ticks`, `polygon`, `gear`, `scallop`, `band`, `seg`, `shiftLines`; sprites `sprite`, `orbSprite`). Layer order back→front: engraved lines → dust rings → clouds → threads → beam → blaze → named stars (glow, orb, flare, medallion) → labels. Export `mountPlate(host, scene)` that returns `{ canvas, load(scene), destroy() }`; the loop must survive a host that is attached *after* the call (wait for `isConnected`, see the Frozen-canvas lesson in DESIGN F5) and must stop when the host is removed.
- New `digitalmaid/ui/plates-scenes.js` — five scene builders taking the live profile view (`/api/joh/profile` response) and returning a scene: `overviewScene`, `astroScene`, `bodygraphScene`, `genekeysScene`, `enneagramScene`. Every number drawn comes from the profile (positions, aspects, ascendant/mc, houses, hd.channels/gates/type/authority/profile, genekeys spheres, enneagram result/scores). Deterministic per-profile randomness (seed from profile id + chart name) so a re-render doesn't reshuffle dust.
- `digitalmaid/ui/joh.js` — each tab's drawing becomes: plate frame (`<section class="joh-plate">`: corner ornaments, `.joh-plate-head` kicker/title/rule/sub, `<canvas>` host, left/right `.joh-plate-notes`, lead line, zodiac toggle where it exists today) + the existing data cards/tables **unchanged in markup** (positions table `#joh-positions tr[data-body]`, sphere rows `.joh-sphere[data-sphere] [data-key-line]`, enneagram result card, foundation `kv`s, channel list). The old inline SVGs (`svg.joh-wheel`, `svg.joh-bodygraph`, `svg.joh-hologenetic`, `.joh-arc`, `scoreBars`) are **kept, rendered inside a `<details class="how joh-plate-classic">` fold** titled with a new key `joh.plate.classicSummary` ("Classic diagram") — so the existing browser tests keep passing and users keep the flat, selectable diagram.
- `digitalmaid/ui/sky.js` — gains the nebula wash (static layer, painted once per resize), faint constellation lines, and cross sparkles, page-wide, at the mockup's strengths; still `aria-hidden`, still pauses when hidden, still one static frame under `prefers-reduced-motion`. The Today hero must not change (`tests/test_design_tokens.py` hero tests are pinned).
- `digitalmaid/ui/app.css` — additive `.joh-plate*` rules only (frame, corners, head, notes, lead, toggle; hidden notes < 1100 px; phone layout: plate ≥ 54dvh, notes/lead hidden, tabs row scrolls). CSS tokens unchanged.
- `digitalmaid/api.py` `UI_FILES`: add `plates.js`, `plates-scenes.js`. **Remove the temporary `/mockup/` route and delete `digitalmaid/ui/mockup/`** (the approved mockup stays in the prep dir).
- Locale catalogues (all five, `tests/test_i18n_catalogue.py` enforces identical key sets/placeholders): new keys under `joh.plate.*` — per-tab kicker (`joh.plate.kicker.overview` "Plate I — The Engine", `astro` "Plate II — Birth chart", `bodygraph` "Plate III — Axis of Design", `genekeys` "Plate IV — Hologenetic profile", `enneagram` "Plate V — Nine points"), title (`joh.plate.title.*`: "Journey of Humanity", "The Wheel of Signs", "The Light Body", "The Thirteen Spheres", "The Enneagram"), the margin-note headings/bodies (`joh.plate.note.*`), lead lines (`joh.plate.lead.*` — reuse existing `joh.astro.lead`, `joh.bodygraph.lead`, `joh.genekeys.lead`, `joh.enneagram.lead` where the mockup text matches; add only what's new), `joh.plate.hint` "drag to turn · hover a star", `joh.plate.classicSummary`, canvas `aria-label`s (`joh.plate.aria.*`). Translate vi/zh/fr/ja yourself per `.i18n-work/TRANSLATE.md` (register rules), ≤ 40 new keys total. Canvas labels (planet names, sign glyphs, centre names, sphere names, enneagram type names) use the **existing** `t()` keys (`joh.planet.*`, `joh.signAbbr.*`, `joh.enneagramType.*`, sphere names from the localised profile) — never hard-coded English in `plates-scenes.js` (the catalogue scanner test covers every module in `SCANNED`; add both new modules to it).

## G3. Per-plate content (data → visual), from mockup-v3
- **Overview — The Engine.** Tilted disc (rotX 1.05) of engraved rings: outer scalloped band with fine ticks, two gear rings, dashed bands, hexagram + dodecagon lattices, 12 radial spokes, a steeper armillary ring crossing the disc. Five ringed-orb medallions on r≈0.92 at −90°/−18°/54°/126°/198°: Astro (gold), Bodygraph (rose), Gene Keys (violet), Enneagram (green), Compass (pale gold); each with a dust cloud, a gold spoke and a flowing thread to the centre; hover shows label · sub in the plate subtitle; **click opens the tab** (`location.hash`). Central blaze (r 0.17, 36 rays, lens streak, diagonal cross) and a vertical beam with rising motes. Margin notes: Principium / Tempus (birth date · time · place from `profile.birth`) / Materia (zodiac · offline · deterministic) — Ignis stellaris / Axis / Compass.
- **Astro — The Wheel of Signs.** Ecliptic in a plane tilted rotX 0.55, longitude 0° at the right, Ascendant on the left (`a = 180° − lon + asc`). Bands: outer 1.2–1.3 (360 ticks, every 5th longer, scallop 48, degree numerals every 30° in Doto), 0.98–1.06 dashed, 0.72–0.76 inner; 12 spokes 0.76→1.2; dodecagon/hexagram/octagram lattices at r 0.5, 0.3. Sign band: alternating ink/gold dust, sign glyph (`♈︎` text-presentation, Cormorant 19 px) in a small medallion at r 1.12, whole-sign **house number** (Doto) at r 0.84. Planets = textured orbs on r 0.62 (fanned +0.12 outward when < 8° from the previous body), colour per body (Sun/Venus gold, Moon white, Mars rose, Jupiter `--phase-do-2`, Saturn gold **with two rings**, Uranus/Neptune blues, Pluto violet, North Node small plain star); Sun/Moon get the long 8-point flare; each planet has a tick on the inner band and a mark on the sign band; glyph + name beneath. Aspects: hairline + flowing thread, gold for conjunction/trine/sextile, rose for square/opposition (the `chart.aspects` list — do not recompute). ASC: gold meridian centre→1.32 with thread + "ASC" star; MC fainter ink meridian + "MC". Central blaze r 0.12. Hover: name · sign degree°′. Zodiac toggle (existing `api.johSetZodiac`) re-renders the scene in place. Margin notes: Sol / Luna / Ascendens — Aspectus (count) / Domus / Medium coeli.
- **Bodygraph — The Light Body.** Facing the viewer (rest pitch −0.05, idle 0.02): a great mandala band behind (r 1.1–1.2, scallop 24), the seated figure from `FIGURE` (head circle, shoulders/arms, torso sides, four ribs, lotus legs, inner diagonals) as gold hairlines with beads at the vertices, faint gold lattice dust inside the torso, a halo of rings + 36 ticks behind the head, lotus ripples (bands and dashed circles in a rotX 1.25 plane) at the seat with two slow dust rings. Nine centres at the standard `CENTRES` positions mapped to the 300×520 space: defined = big gold-white star with 8-point flare, medallion 15, dense gold cloud; open = small ink star, medallion 10, faint cloud, muted label. Channels from `hd.channels`: hairline + 70-bead thread, gold when personality (or both), rose when design only, both = gold with a counter-flowing rose core; hanging gates = short thread 42 % toward the partner centre. Vertical beam head→root with rising motes; a small blaze (r 0.07) at the G centre. Hover: centre · defined/open · active gates. Margin notes: Center line (n of 9 defined) / Authority · strategy / Definition · profile — Personality / Design / Incarnation cross.
- **Gene Keys — The Thirteen Spheres.** Facing (rest pitch −0.12). Outer scalloped band 1.18–1.28, dashed r 1.0, 13-gon lattice, hexagram r 0.55, flower-of-life (six r 0.55 circles on a r 0.55 hexagon) faint. Spheres at `GK_NODES` mapped to ±0.78/±0.84 (−0.04 up), depth by sequence (activation +0.12, venus −0.14, pearl +0.14). Each sphere = three concentric clouds (ink haze = Shadow, sequence colour = Gift, white-gold heart = Siddhi) + textured orb + medallion 16 + Doto `key.line` glyph + sphere name. Edges from `GK_EDGES` as hairline + flowing thread in the target sphere's sequence colour (activation gold, venus rose, pearl violet). Blaze r 0.075. Hover: sphere · key.line · shadow → gift → siddhi. Margin notes: Activation (Life's Work key) / Venus / Pearl — Umbra / Donum / Siddhi.
- **Enneagram — Nine points.** Plane rotX 0.5, R 0.86, point 1 at −90° going clockwise 40° each. Outer scalloped band 1.1–1.2 (180 ticks), a second band just outside R, the circle R, nine spokes R→1.1, inner nonagon lattices. Nine textured orbs: size 1.4 + 2.2×(score/max), medallion 11 + 9×score, Doto number + type name; colours: type = white-gold with 8-point flare, wing = gold with 4-point flare, growth point green (`--phase-check-2`), stress point rose, others ink; dust cloud per point scaled by score. Triangle 3-6-9 and hexad 1-4-2-8-5-7-1 as gold hairlines + faint threads; **flowing** threads type→growth (green), type→stress (rose), type→wing (gold). Two slow dust rings (R, 1.15). Blaze r 0.1. Hover: n name · score. Before a type exists the plate still draws the figure with all nine equal and the test/choose card stays where it is. Margin notes: Figura / Typus · wing / Instinctus — Integratio / Tensio / Fons.

## G4. Motion and performance (pinned in tests)
- Frame budget: ≥ 45 fps at 1280×800 and ≥ 40 fps at 390×844 in headless Chromium on every plate (measure with a 1 s rAF counter after 1.5 s settle; assert with margin: ≥ 30 / ≥ 25 in CI to allow a slow box, and log the real numbers).
- Nebula/constellation wash and glow sprites are painted once (offscreen canvas) — no per-frame gradients.
- `prefers-reduced-motion`: one static frame per plate, no spin, no twinkle; drag still turns it.
- Loop pauses when `document.hidden`; `destroy()` on route change (no leaked rAF — assert `requestAnimationFrame` count stops growing after navigating away).
- Touch: `touch-action: none` on the canvas host only; drag uses pointer events with capture.

## G5. Must not change
Today hero (`hero.js`) and its pinned tests; every existing JOH data card, table, form, id, `data-*` attribute and the classic SVG diagrams (now inside the fold); the API; the six-tab order; the zodiac footer; the Compass tab (unchanged this stage); tokens in `:root`; fonts; CSP `default-src 'self'` (no inline scripts/styles — everything in modules and app.css).

## G — as implemented (0.6.0, 2026-09-16)
The engine and scene code are the mockup's, lifted into `plates.js` / `plates-scenes.js` with the DATA block replaced by the profile view. Deviations from mockup-v3, each with its reason:
- **Classic fold opens by default** and remembers a close in `localStorage` (`dm:joh:classic`). The pinned JOH-2/3 browser tests wait for *visible* `svg.joh-wheel` / `svg.joh-bodygraph` selectors and this stage may not edit them; a closed-by-default fold needs a one-line test edit (open the fold first) — Pi's call. On the Enneagram tab the fold holds the score bars and therefore exists only for a fresh test result.
- **Margin-note headings stay Latin** (Principium, Tempus, Sol, Luna, Umbra, Figura …) in every language: they are the plates' engraving, not copy, and the ≤ 40-key budget went to the bodies, leads, kickers, titles and aria labels (32 keys). Bodygraph headings are Latinised the same way (Auctoritas, Definitio, Personalitas, Designatio, Crux) instead of the mockup's English "Center line / Authority / Definition / Personality / Design / Incarnation cross".
- **Crowded planets show their glyph only.** ny-1994 puts seven bodies within ~35°; the mockup's single +0.12 fan still piled the names up. Bodies within 14° of the previous one step to alternating radii (0.74, 0.48, 0.86, 0.36 …) and drop the name; the hover subtitle and the classic wheel carry it. Isolated bodies are drawn exactly as in the mockup.
- **Numerals inside the medallion** (Gene Keys `key.line`, Enneagram type numbers) sit in the medallion's upper half instead of beneath the star: below the star they collided with the next sphere's name in the Venus/Pearl columns and with the lead line.
- **Enneagram 5 and 6 names hug their points sideways** (`labelAlign` left/right); the plane is tilted 0.42 rad instead of 0.5 so the bottom points are less magnified. Astro scale 0.84 (+14 px down), Bodygraph 0.88 (−18 px), Gene Keys nodes on ±0.98/±0.86 (−10 px): each cleared a collision with the subtitle or the lead line seen in the 1280 screenshots. Phones (< 600 px host) use radius factor 0.32 (mockup 0.36) so the Ascendant label and outer degree numerals stay inside the frame.
- **Zodiac toggle re-renders through `ctx.route()`** (the footer's existing path) rather than `field.load()` alone, so the positions table, footer and notes switch together; the plate keeps its yaw/pitch across the re-render (`plateOrientation`), which is what "in place" meant visually.
- **Enneagram weights without scores:** the profile stores type/wing/arrows, not the 45-statement totals, so brightness follows 1.0 / 0.65 / 0.35 (type / wing / others), the real scores only for a fresh test result, and all nine equal (0.5) before a type exists.
- **Colours come from the tokens** (`--accent`, `--accent-2`, `--phase-*-2`, `--ink*`) read once at module load, with the mockup's values as fallbacks; `gold3`/`white` highlights are the mockup's literals (no token exists for them).
- The canvas has `role=img` + a localised `aria-label` (mockup: none). `data-plate-stats` also reports `seed` and `dust` so the determinism test can compare re-renders. Measured in headless Chromium (software GL): **60 fps on every plate at 1280×800 and 390×844** (the rAF cap), floors 30/25 asserted.
