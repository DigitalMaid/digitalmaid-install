# DigitalMaid development contract

Sang Ly is developer/project owner. Pi coordinates. Primary coding model: Claude Fable 5.1 (anthropic/claude-fable-5.1) via Claude Code CLI over OpenRouter — switched by owner decision on 2026-09-06, replacing GPT 6 Astra/Codex. Never silently substitute; report the model actually used.

Build original software. Do not read, copy, execute or import reference implementations. docs contain Pi's independent behavioral requirements. Do not touch /opt/data/rubric-agentic-os, Hermes config/auth/cron, other profiles or source archives.

Use strict vertical TDD: write one behavior test, execute and observe expected missing-feature failure, implement minimally, rerun green, refactor; save actual evidence. No fabricated output. Report blockers promptly.

Exact frameworks: Plan / Do / Check / Correction and Man / Method / Machine / Material / Money. Enforce transitions server-side. Process exit is not acceptance. Every output check targets an immutable version. No retroactive pass after edits.

One writer per owned subtree; Pi merges dependent work. Keep private state, credentials and logs out of git. No shell-command templates from user data, no blanket bypass permissions, no network deployment or new schedules. Defaults deny external spending/actions. Tool execution must use validated argv and scoped paths.

Update docs/PROGRESS.md with completed work, evidence, unresolved checks and exact next step before finishing. Never call a scaffold complete. No model self-identification counts as model verification.
