#!/bin/bash
# Keep DigitalMaid Agentic OS (server + worker) alive. Idempotent; safe every 2 min.
REPO=/opt/data/DigitalMaid-Agentic-OS
ROOT=/opt/data/digitalmaid-workspace
LOG=/opt/data/digitalmaid-workspace/logs
BIN=$REPO/.venv/bin/digitalmaid
PORT=8765
mkdir -p "$LOG"
export PLAYWRIGHT_BROWSERS_PATH=/opt/data/pw-browsers
out=""
if ! curl -fs -m 4 "http://127.0.0.1:$PORT/healthz" >/dev/null 2>&1; then
  cd "$REPO" && nohup "$BIN" serve --root "$ROOT" --scope personal --host 0.0.0.0 --port $PORT --allow-remote >> "$LOG/serve.log" 2>&1 &
  sleep 3
  if curl -fs -m 4 "http://127.0.0.1:$PORT/healthz" >/dev/null 2>&1; then out="digitalmaid serve restarted $(date -u +%FT%TZ)"; else out="digitalmaid serve FAILED $(date -u +%FT%TZ): $(tail -n 3 "$LOG/serve.log")"; fi
fi
if ! pgrep -f "digitalmaid worker --loop --root $ROOT" >/dev/null 2>&1; then
  # Live-agent credential: only exported into the worker process, read from .env at start.
  KEY=$(grep '^OPENROUTER_API_KEY=' /opt/data/.env | cut -d= -f2- | tr -d '"')
  cd "$REPO" && DIGITALMAID_LLM_API_KEY="$KEY" nohup "$BIN" worker --loop --root "$ROOT" --scope personal --interval-seconds 20 --lease-seconds 180 >> "$LOG/worker.log" 2>&1 &
  unset KEY
  sleep 2
  pgrep -f "digitalmaid worker --loop --root $ROOT" >/dev/null && out="$out; worker restarted $(date -u +%FT%TZ)" || out="$out; worker FAILED $(date -u +%FT%TZ)"
fi
[ -n "$out" ] && echo "$out"
exit 0
