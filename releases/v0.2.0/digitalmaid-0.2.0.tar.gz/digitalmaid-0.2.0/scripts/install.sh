#!/usr/bin/env bash
# DigitalMaid Agentic OS — idempotent installer for Desktop (local) and VPS profiles.
# Usage: scripts/install.sh [--profile desktop|vps] [--root PATH] [--allow-root] [--demo]
# Each step prints what it does and how it was checked. Re-running is safe.
set -euo pipefail

PROFILE="desktop"
ROOT=""
ALLOW_ROOT="no"
DEMO="no"
while [ $# -gt 0 ]; do
  case "$1" in
    --profile) PROFILE="$2"; shift 2 ;;
    --root) ROOT="$2"; shift 2 ;;
    --allow-root) ALLOW_ROOT="yes"; shift ;;
    --demo) DEMO="yes"; shift ;;
    -h|--help) sed -n '2,4p' "$0"; exit 0 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

step() { printf '\n== %s\n' "$1"; }
check() { printf '   check: %s\n' "$1"; }
fail() { printf 'error: %s\n' "$1" >&2; exit 1; }

if [ "$(id -u)" = "0" ] && [ "$ALLOW_ROOT" != "yes" ]; then
  fail "refusing to run as root; create a service user or pass --allow-root"
fi
case "$PROFILE" in desktop|vps) ;; *) fail "--profile must be desktop or vps" ;; esac

REPO="$(cd "$(dirname "$0")/.." && pwd)"
ROOT="${ROOT:-$HOME/digitalmaid-workspace}"
VENV="$REPO/.venv"

step "1/6 Python 3.12+ and uv"
if ! command -v uv >/dev/null 2>&1; then
  fail "uv not found. Install it from https://docs.astral.sh/uv/ (no network call is made by this script)"
fi
PY="$(uv python find '>=3.12' 2>/dev/null || true)"
[ -n "$PY" ] || fail "no Python >= 3.12 visible to uv (uv python install 3.12)"
check "uv $(uv --version | awk '{print $2}') · python $("$PY" -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')"

step "2/6 Virtual environment at $VENV"
if [ ! -x "$VENV/bin/python" ]; then
  uv venv --python "$PY" "$VENV" >/dev/null
fi
uv pip install --python "$VENV/bin/python" -e "$REPO" >/dev/null
check "$("$VENV/bin/python" -c 'import digitalmaid; print("digitalmaid", digitalmaid.__version__)')"

step "3/6 Workspace root at $ROOT"
mkdir -p "$ROOT"
[ -w "$ROOT" ] || fail "$ROOT is not writable"
if [ "$DEMO" = "yes" ] && [ ! -f "$ROOT/workspace.json" ]; then
  "$VENV/bin/digitalmaid" demo --root "$ROOT"
  echo "   (copy the demo password above now; it is printed once)"
fi
"$VENV/bin/digitalmaid" migrate --root "$ROOT" --preview >/dev/null
check "migrate --preview ran; pending migrations: $("$VENV/bin/digitalmaid" migrate --root "$ROOT" --preview | "$VENV/bin/python" -c 'import json,sys; print(len(json.load(sys.stdin)["pending"]))')"

step "4/6 Owner user"
OWNERS="$("$VENV/bin/digitalmaid" user list --root "$ROOT" 2>/dev/null | "$VENV/bin/python" -c 'import json,sys; d=json.load(sys.stdin); print(sum(1 for u in d if not u["disabled_at"] and any(m["role"]=="owner" for m in u["memberships"])))' || echo 0)"
if [ "$OWNERS" = "0" ]; then
  echo "   no owner yet. Create one (password is prompted, never stored in clear):"
  echo "   $VENV/bin/digitalmaid user create --root $ROOT --username <you> --scope personal --role owner"
  [ "$PROFILE" = "vps" ] && echo "   (required before serve --allow-remote will start)"
else
  check "$OWNERS enabled owner user(s) present"
fi

step "5/6 Health check script"
chmod +x "$REPO/scripts/healthcheck.sh"
check "scripts/healthcheck.sh is executable (use: scripts/healthcheck.sh http://127.0.0.1:8765)"

step "6/6 Next steps for profile: $PROFILE"
if [ "$PROFILE" = "desktop" ]; then
  echo "   start:  $VENV/bin/digitalmaid serve --root $ROOT $([ "$DEMO" = yes ] && echo '--scope demo')"
  echo "   open:   http://127.0.0.1:8765  (loopback only; sign in with your owner user)"
else
  echo "   start:  $VENV/bin/digitalmaid serve --root $ROOT --allow-remote --host 0.0.0.0 --port 8765"
  echo "   proxy:  put an HTTPS reverse proxy (Caddy example in docs/INSTALL.md) in front; the app never terminates TLS"
  echo "   unit:   see docs/INSTALL.md for the systemd unit and the s6/nohup alternative"
fi
echo "   worker: $VENV/bin/digitalmaid worker --loop --root $ROOT"
echo "   backup: $VENV/bin/digitalmaid backup --root $ROOT --out $ROOT-backups/\$(date +%F).tar.gz"
echo "Done. Nothing here opened a network connection or stored a password."
