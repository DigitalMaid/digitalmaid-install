#!/usr/bin/env bash
# Exit 0 when GET /healthz answers {"status":"ok",...}; exit 1 otherwise.
# Usage: scripts/healthcheck.sh [BASE_URL]   (default http://127.0.0.1:8765)
set -u
BASE="${1:-http://127.0.0.1:8765}"
BODY="$(curl -fsS --max-time 5 "$BASE/healthz" 2>/dev/null)" || { echo "healthcheck: no answer from $BASE/healthz" >&2; exit 1; }
case "$BODY" in
  *'"status":"ok"'*|*'"status": "ok"'*) echo "healthcheck: ok $BODY"; exit 0 ;;
  *) echo "healthcheck: unexpected body: $BODY" >&2; exit 1 ;;
esac
