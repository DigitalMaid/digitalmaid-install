#!/bin/bash
# Nightly backup of the DigitalMaid workspace; keeps 14 days.
REPO=/opt/data/DigitalMaid-Agentic-OS
ROOT=/opt/data/digitalmaid-workspace
OUT=/opt/data/digitalmaid-backups
mkdir -p "$OUT"
F="$OUT/digitalmaid-$(date -u +%F).tar.gz"
"$REPO/.venv/bin/digitalmaid" backup --root "$ROOT" --out "$F" >/dev/null && "$REPO/.venv/bin/digitalmaid" backup --verify "$F" >/dev/null && echo "backup ok $F $(du -h "$F" | cut -f1)" || { echo "backup FAILED $(date -u +%FT%TZ)"; exit 1; }
find "$OUT" -name 'digitalmaid-*.tar.gz' -mtime +14 -delete
