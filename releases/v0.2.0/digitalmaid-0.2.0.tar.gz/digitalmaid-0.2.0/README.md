# DigitalMaid Agentic OS

A local-first operating layer for turning goals into checked results. Every piece of work follows **Plan → Do → Check → Correction**: a task is planned with its five resources (**Man, Method, Machine, Material, Money** — money allocation is never spending permission), executed by a human or a bounded agent, produces an immutable output version, is checked criterion by criterion against that version, corrected if it fails, and only counts as done when a human accepts it. A finished process, a checked output, a human acceptance and an achieved goal are four different records — the software never blurs them.

What you get: Today view with movable widgets · Goals and Projects · Knowledge and Journal (notes, journal, decisions with review dates, links, search) · Skills and Workflows (versioned procedures that become dependent tasks) · Review Inbox · Outputs · Automations (database-backed schedules with leases, a worker process, fixture and live model runners with a spend cap) · Agents roster · Calendar (day/week/month/agenda, recurrence, DST-safe, derived deadlines) · Capture Inbox (text, links, files and transcripts kept as immutable originals, drafted and converted into tasks, notes, journal entries, decisions, events or goals; Hermes posts into it with a scoped API token) · Settings and Connections · login with owner/member/viewer roles · backup and verified restore. All 11 navigation areas are built. Everything is Python 3.12+ with SQLite and a vanilla-JS UI: no Node, no build step, no external services.

## 5-minute start — Desktop

```bash
uv venv .venv && uv pip install --python .venv/bin/python -e .
.venv/bin/digitalmaid demo --root ./workspace        # fictional demo data; prints the demo owner password once
.venv/bin/digitalmaid serve --root ./workspace --scope demo
```

Open http://127.0.0.1:8765, sign in as `demo`. For your own workspace: `digitalmaid user create --root ./workspace --username you --scope personal --role owner`, then `serve --root ./workspace`. Run `digitalmaid worker --loop --root ./workspace` alongside so automations execute.

## 5-minute start — VPS

```bash
scripts/install.sh --profile vps --root /srv/digitalmaid/workspace
.venv/bin/digitalmaid user create --root /srv/digitalmaid/workspace --username you --scope personal --role owner
.venv/bin/digitalmaid serve --root /srv/digitalmaid/workspace --allow-remote --host 127.0.0.1 --port 8765
```

Put Caddy (or any HTTPS reverse proxy) in front; the app never terminates TLS and refuses `--allow-remote` without an owner user. Full details, systemd units, backups and the restore drill: [docs/INSTALL.md](docs/INSTALL.md) and [docs/OPERATIONS.md](docs/OPERATIONS.md).

Letting Hermes Agent do the install for you: paste the single prompt in [docs/HERMES-BOOTSTRAP.md](docs/HERMES-BOOTSTRAP.md).

## Commands

`digitalmaid serve | demo | worker --once|--loop | user create|list|disable | backup [--verify] | restore | migrate [--preview]` — all take `--root PATH`. Tests: `.venv/bin/python -m pytest -q` (Playwright browser tests skip unless `PLAYWRIGHT_BROWSERS_PATH` points at an installed Chromium).

## Status and honesty

Verified on Linux with CPython 3.13 and Chromium only; see [docs/PROGRESS.md](docs/PROGRESS.md) for exactly what each stage proved and what remains unverified. Audio captures are stored but never transcribed by the app (Hermes or a human supplies the text; see [docs/HERMES-INTEGRATION.md](docs/HERMES-INTEGRATION.md)). Live model runs have been exercised once against OpenRouter under an owner-authorized smoke test; every other run in the test suite uses a deterministic fixture that is labelled as such in the UI.

## Documentation

[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) (ADRs and "as implemented" notes) · [docs/REQUIREMENTS.md](docs/REQUIREMENTS.md) · [docs/BACKLOG.md](docs/BACKLOG.md) · [docs/CALENDAR-SYNC.md](docs/CALENDAR-SYNC.md) · [docs/HERMES-INTEGRATION.md](docs/HERMES-INTEGRATION.md) · [docs/LIVE-AGENT.md](docs/LIVE-AGENT.md) · [docs/THIRD_PARTY.md](docs/THIRD_PARTY.md).

## Credits and license

Developer and project owner: **Sang Ly**. Orchestrator: **Pi (Hermes Agent)**. Coding worker: Claude (Anthropic) via Claude Code, under Pi's review.

Private development; no public release or license has been granted yet. All rights reserved by the owner until a license file is added. No code, prompts, templates or assets were copied from reference projects. Workspace content and credentials never belong in this repository.
