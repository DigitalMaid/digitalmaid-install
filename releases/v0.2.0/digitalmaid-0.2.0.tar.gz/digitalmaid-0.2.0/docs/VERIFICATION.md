# Verification evidence — preparation checkpoint

## Executed and observed
- Archive downloads previously passed ZIP integrity checks. Reference documents inspected without execution or copying into app.
- Linux x86_64 host, Python 3.13.5, Node v26.5.1, git 2.47.3 discovered live.
- Isolated Codex CLI reports 0.153.4.
- Hermes config resolves model to `openai/gpt-6-astra-pro`, provider `openrouter`; live OpenRouter model catalog contains exact ID.
- Codex probe produced a real response and tool attempt; persisted session_meta provider=openrouter, turn_context model=openai/gpt-6-astra-pro. This is route evidence, not independent model-weights attestation.
- Codex tool execution failed: `bwrap: No permissions to create a new namespace`. pwd and git status did not execute inside Codex. Docker daemon unavailable. Legacy Landlock profile rejected. No unrestricted fallback used.
- Patch-only Astra test-authoring attempt started but was stopped by budget watchdog before emitting files. No generated tests or implementation claimed.
- Shared OpenRouter key usage increased to an observed $7.818653 above checkpoint baseline; a subsequent API read returned a lower increase. Because the key is shared and totals were inconsistent, exact Codex-only cost is not established. Conservative stop remains latched. No further paid worker calls without renewed authorization.
- GitHub SSH authenticates account DigitalMaid. Requested remote repository lookup returned not found/not accessible. API device authorization still pending at this checkpoint; private repository creation and upload NOT verified.

## Product acceptance
Not run: application installation, project→5M→agent→Check→Correction journey, persistence tests, scheduler/recovery tests, scope enforcement, backup/restore, UI, accessibility or OS deployment matrix. No runnable application exists yet.

## Development PDCC
Plan: requirements and proposed architecture recorded.
Do: environment/reference/auth/model preparation.
Check: sandbox probe failed; bounded patch-only workaround did not yield code before spend stop.
Correction: retain sandbox boundary; require explicit spend renewal or subscription route before continuing Astra implementation. Resume with a small single-behavior RED test, then GREEN implementation; do not claim tests pass until executed.

## Subsequent $80 authorization checkpoint
Astra returned one project-persistence test; Pi applied it and ran unittest: one expected failure (`domain implementation missing`). GREEN attempt returned no code before watchdog termination. Shared-key high-water reached $81.026191, exceeding the $80 authorization. Stop is latched; no further paid workers. This is not verified Codex-only spend. Budget enforcement failed to guarantee the ceiling. A provider-side cap and per-generation reconciliation are required before resuming. No application test has passed; GitHub authorization expired.
