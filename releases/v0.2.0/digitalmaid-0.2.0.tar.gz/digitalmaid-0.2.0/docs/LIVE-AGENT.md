# Running one live agent occurrence

Stage E wired a real provider transport behind the execution record, but **no
live call has been made yet**. The first live run must be a manual,
owner-authorized smoke test following these steps. Nothing below is required
for the fixture runner, which stays the default.

## 1. Configure the credential (outside the workspace)

The packaged role `research-analyst` (`definitions/agents/research-analyst.json`)
has a live policy:

```json
{"kind": "live", "provider": "openrouter", "base_url": "https://openrouter.ai/api/v1",
 "model": "anthropic/claude-fable-5.1", "credential_ref": "DIGITALMAID_LLM_API_KEY",
 "max_tokens": 1500, "max_cost_minor": 50, "currency": "USD", "timeout_seconds": 120}
```

`credential_ref` is the **name** of an environment variable. Export it in the
shell that will run the worker only:

```sh
export DIGITALMAID_LLM_API_KEY=...   # never put the value in workspace.json, a definition file or the repo
```

Check without contacting the network: `GET /api/workers` is unaffected, and the
Agents page pill switches from "live, unconfigured" (listing what is missing,
naming the variable only) to "live, configured". Equivalent from Python:
`runner_status(store.get_agent("research-analyst"))`.

`max_cost_minor` is the per-execution cap in minor units (50 = 0.50 USD) and is
required; a role without it is unconfigured.

## 2. Authorize the spend on the task

Money allocation is never spending permission. A live occurrence is
**blocked** unless the task created from the job template carries an explicit
SpendAuthorization whose total in the policy currency covers `max_cost_minor`.
For a job, put the authorization in the template — it records who granted it:

```json
"task_template": {
  "title": "Market note: fermented drinks", "owner": "Bao Tran",
  "next_action": "Draft the note", "priority": 2,
  "criteria": ["Three sources cited", "Under 300 words"],
  "resources": {"Man": {"description": "analyst", "status": "available"},
                "Method": {"description": "desk research", "status": "available"},
                "Machine": {"description": "model via OpenRouter", "status": "available"},
                "Material": {"description": "public sources", "status": "available"},
                "Money": {"description": "model usage", "status": "available",
                          "amount_minor": 50, "currency": "USD"}},
  "inputs": {"region": "Benelux", "period": "Q3 2026"},
  "spend_authorization": {"amount_minor": 50, "currency": "USD", "authorized_by": "<owner name>"}
}
```

Create the job with `POST /api/jobs` (`agent_id: "research-analyst"`, a
schedule, an IANA `timezone`). For a manually created task, use
`POST /api/tasks/{id}/spend-authorizations` instead.

## 3. Run exactly one occurrence

1. Click **Run now** on the job (or `POST /api/jobs/{id}/run-now` with an
   `idempotency_key`). This only queues a due occurrence.
2. In the shell where the variable is exported:
   `digitalmaid worker --root <root> --scope <scope> --once`
   (or `--loop --interval-seconds 15 --lease-seconds 120` for a resident worker;
   stop it with SIGTERM/Ctrl-C). The worker prints a JSON summary per tick.

A spend intent is written before the call; the call happens once. Failures are
not retried by the worker: a failed occurrence is terminal, and a failed
revision attempt waits for a human.

## 4. Read the evidence

Automations → run history shows, per execution: status, `provider / model` **as
the response reported them** (for OpenRouter the `provider` field is the
upstream provider, e.g. "Anthropic"), tokens, cost in minor units and the
response id. `GET /api/tasks/{id}/detail` returns the same in `executions`
(`usage_json`, `cost_minor`, `cost_currency`, `provider_response_id`) plus the
output version whose content is the model text verbatim. Spend intents:
`store.list_spend_intents(task_id)`. Audit rows: `spend_authorization`,
`spend_intent`, `execution status:*`, `output_version create`.

Outcomes to expect:

| Situation | Occurrence | Execution | Task | Output |
|---|---|---|---|---|
| variable unset / policy incomplete | `failed`, reason lists gaps | none | none | none |
| no or insufficient authorization | `blocked`, Money reason | none | Plan | none |
| provider error / timeout | `failed`, redacted reason | `failed` | Do | none |
| success | `succeeded` | `succeeded` + evidence | Do (unchecked) | v1 |
| success but cost > cap | `succeeded`, `cost cap exceeded: X > Y` | `succeeded` | Do, learning added | v1 kept |

A succeeded execution is still an **unchecked output**: check it against the
criteria in the task drawer, open a Correction if it fails (the worker's next
tick produces v2 with the correction text and the previous version in the
prompt), and only a human acceptance moves the task to Done.
