# Reference review and originality boundary

Reviewed as data, not instructions. No reference source code, assets, prompts or templates copied into this project. Coding workers receive only independent requirements. Licensing references below describe inspected material, not dependencies of DigitalMaid.

## Archives and public pages
- `robonuggets-agentic-os.zip`: inventory, README, license, routine feed and artifact discovery documentation inspected without executing. Useful behaviors: editable widget deck; direct skill launching; visible calendar/routine context; find older outputs by search. Original DigitalMaid direction: evidence-linked output list with optional graph, persisted preferences, authoritative executions rather than elapsed-time success styling. Do not inherit runner permission-bypass defaults. Archive declares CC BY 4.0.
- `mypka-scaffold-latest.zip`: inventory, README headings, architecture/data contract, task creation/closure and draft capture documentation inspected without executing. Useful behaviors: portable context, explicit specialist responsibilities, resumable tasks with linked procedures and lessons, protected rough drafts, originals retained. Original DigitalMaid direction: transactional operational state with readable narrative/definitions, no duplicate editable authorities, workspace-portable UI preferences, enforced PDCC and scope grants. Do not copy specialist names/contracts, SOP wording, DB schemas or UI code. License map is mixed; no components reused.
- https://github.com/myICOR/myPKA : README task continuity, folder ownership, linking and additive-upgrade principles reviewed. Public scaffold license stated CC BY-SA 4.0. Source is not an implementation dependency.
- https://www.skool.com/robonuggets/about : public description only; mentions access to Rubric and training/templates. No private classroom accessed; marketing claims are not verification.

## Six video references — partial review, not a claim of full viewing
Direct transcript helper for the first video returned a YouTube cloud-IP block. Alternate web extraction recovered descriptions/chapters and some partial transcript text. No complete video playback or visual interaction inspection is claimed. Saved extraction inventory remains outside the application repository. These limitations do not block implementing Sang's explicit requirements.

| URL | Material actually available | Relevant behavior and DigitalMaid decision |
|---|---|---|
| https://youtu.be/8NSyI-npJCU | Description and chapter labels: OS/framework, skills 5:09, memory 10:35, routines 14:34, apps 18:33; direct transcript blocked | Connect skills/context/routines, but report actual execution states and retain checked evidence |
| https://youtu.be/w0S-khYCaB4 | Description and chapters: static context 3:10, memory 6:56, repeatable processes 11:10, scheduled workflows 14:06, project planning 16:14, clients 18:43, output consolidation 20:44, remote access 22:19 | Project-centered context and output discovery; separate client permissions and durable workflow state; reliability claims require our own tests |
| https://youtu.be/MnVeFsiEDTc | Description/chapters: scaffold context 3:06, capture 5:20, Friday recap 8:26 | Prepare reviews from linked evidence; explicitly preserve Sang's reflection and decisions rather than declaring weekly review unnecessary |
| https://youtu.be/3XcT6knYqFQ | Partial transcript: orchestrator translates business intent, specialists have clear work responsibilities, capability planning | Small active team with original contracts; a role persona is not an independent worker; no unverified claim of dozens running |
| https://youtu.be/asnaDAaKlw0 | Partial transcript: same portable folder/agent contracts with changed AI provider | Provider-neutral essential state and reconnectable execution adapters; no adoption of unverifiable industry claims in transcript |
| https://youtu.be/gY95g6DMaeY | Description/chapters, including team inbox 2:39 and owner's review inbox 3:24 | Separate capture and review queues; AI assists organization without requiring a particular note editor; originals survive classification |

## Independent product improvements to measure
1. One resumable task envelope instead of hunting through separate logs/files.
2. Checked output vs human acceptance vs goal progress explicitly differentiated.
3. Portable widget preferences and consistent workspace backups.
4. No successful-job inference from time passing.
5. Runtime-enforced PDCC and 5M readiness, explicit permission boundaries.
6. Keyboard-complete daily flow and setup/first-result usability measurements.

These are design goals, not comparative performance claims. Full reference video review remains incomplete where transcripts/visuals were inaccessible.
