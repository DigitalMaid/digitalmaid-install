# Hermes bootstrap prompt

Paste the block below into Hermes Agent as one message. It is self-contained: Hermes needs shell access on the target machine and the repository URL you give it. Nothing else.

````
You are installing DigitalMaid Agentic OS (a Python 3.12+ / uv application with a web UI) for me. Follow these rules exactly and report what you did with evidence (the actual command output), not summaries.

HARD RULES
1. Never store, log, echo, paste back or save my password anywhere — not in files, environment variables, shell history, notes, memory or your reply. The only place it may exist is the interactive prompt of `digitalmaid user create` (type it there yourself only if I dictate it; otherwise stop and let me type it). Prefer telling me the exact command to run myself.
2. Never expose the port to a network interface without HTTPS in front. `serve --allow-remote --host 0.0.0.0` is only allowed when an HTTPS reverse proxy (Caddy or equivalent) is configured and the port is firewalled from the internet. On a desktop, bind to 127.0.0.1 only.
3. Ask me at most three questions, all at once, before doing anything: (a) desktop (local) or VPS? (b) workspace root path? (c) owner username? Use sensible defaults if I skip one (desktop; ~/digitalmaid-workspace; my system username).
4. Do not modify any other software, cron entries, Hermes configuration or firewall rules beyond what these steps need, and say so when a step would require it.

STEPS
1. Detect the host: OS and version, architecture, whether systemd is present, whether `uv` and a Python >= 3.12 exist, whether you are root. Print the findings.
2. Clone or update the repository I give you (private; do not publish it), then run `scripts/install.sh --profile <desktop|vps> --root <root>` (add `--demo` only if I asked for the demo). It is idempotent and prints each step with its check. Do not run it as root; create a service user on a VPS.
3. Create the owner user: `.venv/bin/digitalmaid user create --root <root> --username <owner> --scope personal --role owner`. This prompts for the password (rule 1).
4. Start it:
   - desktop: `.venv/bin/digitalmaid serve --root <root>` (loopback), plus `.venv/bin/digitalmaid worker --loop --root <root>` in a second process;
   - VPS: install the two systemd units from docs/INSTALL.md (or the s6/nohup alternative if there is no systemd), bind serve to 127.0.0.1, configure Caddy for my domain, then enable both units.
5. Verify: `scripts/healthcheck.sh http://127.0.0.1:8765` must print `healthcheck: ok {"status":"ok","schema_version":N}`; `curl -s http://127.0.0.1:8765/api/today` must return HTTP 401 (auth is on). Show both outputs.
6. Run `.venv/bin/digitalmaid backup --root <root> --out <root>-backups/first.tar.gz` and then `backup --verify` on it, so a restore path exists from day one.
7. Report: the exact URL to open (http://127.0.0.1:8765 or https://<domain>), the owner username (never the password), the workspace root, where logs go, the health check command, the backup command for cron, and the next steps: sign in, create the first goal, and read docs/OPERATIONS.md. If anything failed, quote the failing command and its output and stop; do not work around a refusal such as "--allow-remote refused: create an owner user first".
````

Notes for the person pasting it: the demo profile prints the `demo` user's password once on stdout; Hermes must not repeat it in its report. The prompt intentionally forbids any change to Hermes' own configuration or schedules.
