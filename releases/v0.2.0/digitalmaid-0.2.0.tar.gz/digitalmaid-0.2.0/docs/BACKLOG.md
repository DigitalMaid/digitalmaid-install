# Ordered implementation backlog

Every item uses Plan → Do → Check → Correction → recheck. Pending until verified.

1. Confirm Codex/Astra execution and sandbox; record model metadata and spend. GitHub authorization/private repo setup.
2. Astra reviews architecture; choose and lock maintainable stack; bootstrap repeatable dev install and one failing persisted-project test.
3. Persistence/scopes: workspace root initialization, SQLite migrations, membership, project and goal CRUD, optimistic concurrency, audit.
4. 5M planning and task resume envelope; server-enforced transitions; project/list UI on real records.
5. One scheduled task + real bounded agent execution; immutable output; failed check; Correction/revised output; recheck; human acceptance; learning and separate goal progress. Run browser journey and restart test.
6. Expand Today and remaining navigation without dead controls; global capture/search, widget preference persistence and keyboard alternatives.
7. Project board/timeline, milestones/dependencies, owner/team, habits, decisions and resource/cost records; cross-view consistency.
8. Capture file/link/transcript originals and draft lifecycle; knowledge/journal links/search; review comments/revisions/archive; versioned procedures/workflow pauses; learning proposals with rollback.
9. Agent roster/org chart and all role contracts; five industry templates. Small active team; actual worker telemetry.
10. Calendar four views, recurrence exceptions, zones/DST, event types; explicit external ownership and sync conflict policy.
11. Automation editor/preview, run controls, durable occurrence/lease/retry/cancel/misfire/idempotency/recovery; Hermes authority adapter and read-only fallback.
12. Import authorized context privately; map existing routines without duplication; propose only missing Monthly Hermes Profile Review timing/delivery in one consolidated setup. Research evidence schema, dedupe, opportunities-to-projects.
13. Hardening: authorization on all routes and worker context, upload/path/CSRF/XSS/process validation, secrets, rate limiting and health.
14. Safe complete backup/restore; migrations preview/conflict/recovery, export relationships/history; move to second supported host.
15. Desktop and VPS install profiles, authenticated HTTPS and service management; single Hermes bootstrap prompt; health/onboarding/recovery docs.
16. Verification matrix: fresh/repeat install, complete PDCC/5M, DST/retries/duplicates/interruption, scope boundaries, cross-view persistence, backup/restore, each advertised OS, responsive/keyboard/reduced motion. Record failures and corrections, never mark untested platform passed.
17. License/secret scan, owner credit, example workspace separation, private remote readback and commit verification; owner trial and measured usability improvements.

## Ownership
Pi owns requirements/coordination/reference synthesis and final verification. One Astra worker owns first slice to avoid API/schema conflicts. Parallel workers only after explicit file ownership or worktree separation. No unattended unlimited fan-out; owner-approved incremental build spend ceiling is tracked externally.
