# Hermes → DigitalMaid: posting into the Capture Inbox

Hermes Agent can drop a voice-note transcript, a link or a file into the Capture
Inbox without a browser session. Nothing here is executed by DigitalMaid on
Hermes's behalf: a capture is raw material that a human drafts and converts.

## 1. Mint an API token (owner, once)

Settings and Connections → **API tokens** → *Create a token*. The value
(`dmt_<id>_<secret>`) is shown **once**; only a scrypt hash is stored. Keep it in
Hermes's own secret store, never in this repository or in `workspace.json`.

Tokens are scoped: they may call `POST/GET /api/captures*` and `GET /api/healthz`
only. Any other route answers `403 {"detail": "token scope: …"}`. Revoking a
token (Settings) or disabling its user stops it immediately. The token acts as
the user who minted it (`captured_by` = that username), with that user's role in
the served scope; viewers cannot post.

## 2. Post a transcript (text)

```bash
DM_URL="https://digitalmaid.example.internal"      # or http://127.0.0.1:8765 on the same host
DM_TOKEN="dmt_REPLACE_WITH_THE_TOKEN_SHOWN_ONCE"     # placeholder, not a real token

curl -sS -X POST "$DM_URL/api/captures" \
  -H "Authorization: Bearer $DM_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"kind": "transcript", "source": "hermes",
       "title": "Voice note 2026-09-06 09:12",
       "body_text": "Order more lime before the Friday tasting panel."}'
```

Response `201` with the capture record (`status: "inbox"`). No `X-Requested-With`
header is needed for bearer requests (that CSRF marker guards cookie sessions).

## 3. Post a link

```bash
curl -sS -X POST "$DM_URL/api/captures" \
  -H "Authorization: Bearer $DM_TOKEN" -H "Content-Type: application/json" \
  -d '{"kind": "link", "source": "hermes", "url": "https://example.org/article"}'
```

Only absolute `http://`/`https://` URLs are accepted.

## 4. Post the audio original (optional)

```bash
curl -sS -X POST "$DM_URL/api/captures/upload" \
  -H "Authorization: Bearer $DM_TOKEN" \
  -F "file=@voice-note.ogg;type=audio/ogg" \
  -F "title=Voice note 2026-09-06 09:12" \
  -F "body_text=Order more lime before the Friday tasting panel." \
  -F "source=hermes"
```

Allowed types: `text/plain, text/markdown, application/pdf, image/png, image/jpeg,
audio/ogg, audio/mpeg, application/json`; default cap 25 MB
(`capture_max_bytes` in `workspace.json`). Audio uploads become `transcript`
captures. **DigitalMaid never transcribes**: `body_text` is whatever Hermes (or a
human, later, as a draft) supplies — Settings shows `transcription: external`.
The original is stored once under `captures/<scope>/<id>/original.<ext>` (extension
from the allow-list, never from the file name) and is immutable.

## 5. Check health

`GET $DM_URL/api/healthz` → `{"status":"ok","schema_version":N}` (no token needed).

## What Hermes must not do

Do not store the DigitalMaid password, do not use the token for anything beyond
captures (it will be refused), do not attempt to convert captures — conversion
is a human step in the Capture Inbox that goes through the same PDCC gates as
everything else.
