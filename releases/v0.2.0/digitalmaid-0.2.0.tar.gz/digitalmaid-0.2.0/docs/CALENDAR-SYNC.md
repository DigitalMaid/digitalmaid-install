# Calendar ownership and sync conflict policy (seam only)

No synchronisation is implemented. This note fixes the rules the seam already enforces so a future adapter cannot silently violate ADR-002/ADR-005.

- **Ownership is explicit.** An `events` row with `external_source` (e.g. `hermes`, `caldav:work`) is owned by that source. The API and UI refuse `PUT`, `archive` and exceptions on it with 409 `owned by <source>`; it renders with an "owned by" pill and disabled form.
- **Application-owned events** (`external_source IS NULL`) are the only ones DigitalMaid edits. A future push adapter may export them; the export is a projection, never a second authority.
- **Derived items are never stored.** Task deadlines, due job occurrences and decision review dates are computed at read time and open their source. Moving them on the calendar is not possible; change the task/job/decision instead (ADR-005: calendar movement never edits a job schedule).
- **Conflict policy for a future pull adapter:** the external system wins for rows it owns; DigitalMaid keeps `external_id` + the source's version/etag and overwrites its mirror. If a local edit somehow exists on an owned row it is discarded and audited (`event` entity, action `sync:overwritten`). Mirrors are matched by `(external_source, external_id)`, never by title/time.
- **Unavailable adapter = honest read-only.** Mirrored rows stay visible with their last-seen state and an "owned by" label; nothing is invented.
- **Recurrence.** Local wall time + IANA zone are stored; occurrences are expanded per request with the same DST policy as scheduling (nonexistent times shift forward, ambiguous times take the first instant). Exceptions are keyed by the occurrence's local date (`skip` or `move`).
