# Operations

## Health
- `GET /healthz` → `{"status":"ok","schema_version":N}`; unauthenticated, nothing else disclosed. `scripts/healthcheck.sh [BASE_URL]` wraps it for cron/systemd/uptime monitors.
- Settings and Connections (UI) shows worker heartbeats (`alive` uses `2 × interval` / `2 × lease/3` + 5 s staleness), agent configuration status, last backup and declared connections.
- `GET /api/workers` (authenticated) exposes the same heartbeat rows.

## Logs
- `serve` logs to stdout (uvicorn). With systemd: `journalctl -u digitalmaid -f`; with nohup, the redirected file.
- `worker --loop` prints one JSON summary per tick: `planned, claimed, succeeded, blocked, failed, lost`.
- Audit trail per record: `audit_events` (`Store.audit_trail(entity_type, id)`), actors are usernames, `worker:<id>` or `scheduler`.
- Nothing logs credentials; transport errors are redacted before they reach an execution record.

## Backup and restore (ADR-007)
- Backup: `digitalmaid backup --root ROOT --out FILE.tar.gz`. Uses the SQLite online backup API into a temp copy (never a raw copy of the live DB), tars it with `outputs/`, `captures/`, `definitions/`, `knowledge/`, `attachments/`, `workspace.json` and `MANIFEST.json` (sha256 per file, schema and app version). Records `last_backup_at`/`last_backup_path` in `workspace.json`. A backup **must** include `captures/` — capture rows reference those blobs by path and hash; the restore round-trip with an uploaded file is tested (`test_backup_cli.py`).
- Disk growth: `captures/<scope>/<id>/original.<ext>` holds every uploaded original, immutable and never deleted by the app (archiving a capture hides it, nothing more). Growth is bounded only by `capture_max_bytes` per upload (default 25 MB, `workspace.json`) times the number of uploads; watch the directory with `du -sh ROOT/captures` and size the backup target accordingly. Interrupted uploads can leave `*.staging` files or a blob without a row; they are never removed automatically.
- Verify: `digitalmaid backup --verify FILE` re-hashes without restoring.
- Restore: `digitalmaid restore --archive FILE --root NEWROOT`. Refuses a non-empty root, verifies every hash, refuses a manifest `schema_version` newer than the app, extracts with the `data` tar filter, then applies pending migrations. Switch authority to the restored root only after the old `serve` and `worker` have stopped; never run two live servers on copies of the same workspace.
- Secrets are not in backups by design (credentials are environment variables). After restoring on a new host, set the variable again ("explicit reconnect").

## Upgrade
1. Stop `worker`, then `serve`.
2. Backup (above).
3. `git pull` / install the new version into `.venv` (`uv pip install -e .`).
4. `digitalmaid migrate --root ROOT --preview` lists pending migrations with a summary; nothing is applied.
5. `digitalmaid migrate --root ROOT` applies them (or simply start `serve`, which migrates on open). Migrations are journaled in `schema_migrations`.
6. Start `serve`, check `/healthz` reports the new `schema_version`, start `worker`.
Rollback = restore the pre-upgrade backup into a fresh root with the previous app version.

## Recovery when a worker dies mid-lease
- A claimed occurrence holds `lease_until` and a fencing token. If the worker dies, its heartbeat goes stale (Settings/Automations show "no worker running") and the lease expires after `--lease-seconds` (default 120).
- The next `worker --loop` tick (or `worker --once`) re-claims the due occurrence with a higher fencing token; the dead worker's late completion, if it ever arrives, is refused (`ConflictError`) and counted as `lost`.
- Any execution left `running` belongs to the interrupted attempt; the task stays in Do with no output version. Review it in the task drawer and record an execution status of `interrupted` or `uncertain` if a side effect may have happened. Non-idempotent external actions are never retried blindly.
- Orphaned blobs (a file under `outputs/` with no row) are listed by `Store.orphaned_blobs()`; they are never deleted automatically.

## Users
- `digitalmaid user create --root ROOT --username U --scope S --role owner|member|viewer` (password prompted, or `--password-stdin`), `user list`, `user disable --username U`.
- The last enabled owner of a scope cannot be disabled. Disabling a user deletes their sessions immediately.
- Login is rate-limited to 10 failures per username per 15 minutes (in memory, per process).
