# DigitalMaid Agentic OS — worker contract

Read AGENTS.md (binding rules), docs/ARCHITECTURE.md (ADRs, data model), docs/REQUIREMENTS.md, docs/BACKLOG.md, docs/PROGRESS.md before working.

## Commands
- Create env once: `uv venv .venv && uv pip install --python .venv/bin/python -e ".[dev]"`
- Tests: `.venv/bin/python -m pytest -q`
- Server: `.venv/bin/python -m digitalmaid serve --root ./workspace`

## Standards
- TDD: failing test first, then minimal code, then refactor. Never weaken a test to pass.
- Python 3.12+, type hints on public functions, stdlib sqlite3, parameterized SQL, transactions with revision checks + audit row.
- Exact vocabulary: PDCC = Plan/Do/Check/Correction. 5M = Man/Method/Machine/Material/Money. Money allocation is never spending permission.
- Process exit ≠ checked output ≠ human acceptance ≠ goal achieved. Model these as separate records/states.
- No code, prompts, templates or assets copied from reference projects (Rubric/robonuggets, myPKA). Original work only.
- Never write credentials, personal data or workspace content into the repo. `workspace/` is gitignored.
- End every task with: files changed, exact test command + output, what remains unverified. Do not claim more than the tests prove.
