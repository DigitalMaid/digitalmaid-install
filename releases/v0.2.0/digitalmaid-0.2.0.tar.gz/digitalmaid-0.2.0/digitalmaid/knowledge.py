"""Knowledge: notes, journal entries, research and decisions with typed links.

Notes are never hard-deleted; ``archive_note`` stamps ``archived_at`` and
archived notes drop out of lists and search unless asked for. Full-text
search uses an FTS5 table when the SQLite build has it and falls back to
``LIKE`` otherwise; the index is derived and can be rebuilt from ``notes``.
"""

import json
import re
import sqlite3
from datetime import date

from digitalmaid.db import new_id, now
from digitalmaid.errors import ConflictError, InvariantError

NOTE_KINDS = ("note", "journal", "research", "decision")
LINK_TARGETS = ("goal", "project", "task", "output_version", "note")
DECISION_FIELDS = ("options", "chosen", "reasoning", "expected_result",
                   "confidence", "review_date")
_ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_WORD = re.compile(r"\w+", re.UNICODE)
_SNIPPET_CONTEXT = 40

_NOTE_COLUMNS = ("id, scope_id, kind, title, body_md, entry_date, decision_json,"
                 " outcome, outcome_at, archived_at, created_at, updated_at,"
                 " revision")


def fts5_available(conn: sqlite3.Connection) -> bool:
    """True when this SQLite build can create FTS5 virtual tables."""
    try:
        conn.execute("CREATE VIRTUAL TABLE temp.fts5_probe USING fts5(x)")
        conn.execute("DROP TABLE temp.fts5_probe")
        return True
    except sqlite3.OperationalError:
        return False


def check_iso_date(value, name: str) -> str:
    if not isinstance(value, str) or not _ISO_DATE.match(value):
        raise ValueError(f"{name} must be an ISO date (YYYY-MM-DD)")
    try:
        date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"{name} is not a valid date: {exc}") from exc
    return value


def check_decision(decision) -> dict:
    """Validate the structured decision record; returns a normalised copy."""
    if not isinstance(decision, dict):
        raise ValueError("decision must be an object")
    unknown = set(decision) - set(DECISION_FIELDS)
    missing = [f for f in DECISION_FIELDS if f not in decision]
    if unknown or missing:
        raise ValueError(f"decision needs exactly {DECISION_FIELDS};"
                         f" missing {missing}, unknown {sorted(unknown)}")
    options = decision["options"]
    if (not isinstance(options, list) or not options
            or any(not isinstance(o, str) or not o.strip() for o in options)):
        raise ValueError("decision.options must be a non-empty list of strings")
    if decision["chosen"] not in options:
        raise ValueError("decision.chosen must be one of the options")
    for name in ("reasoning", "expected_result"):
        value = decision[name]
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"decision.{name} must be a non-empty string")
    confidence = decision["confidence"]
    if type(confidence) is not int or not 1 <= confidence <= 5:
        raise ValueError("decision.confidence must be an integer from 1 to 5")
    check_iso_date(decision["review_date"], "decision.review_date")
    return {field: decision[field] for field in DECISION_FIELDS}


def search_tokens(query) -> list[str]:
    """Plain words only: FTS5/LIKE operators and quotes are never syntax."""
    if not isinstance(query, str):
        return []
    return _WORD.findall(query)


def like_snippet(title: str, body: str, tokens: list[str]) -> str:
    """Excerpt around the first token found in the body (or title)."""
    for source in (body, title):
        lowered = source.lower()
        for token in tokens:
            index = lowered.find(token.lower())
            if index >= 0:
                start = max(0, index - _SNIPPET_CONTEXT)
                end = min(len(source), index + len(token) + _SNIPPET_CONTEXT)
                prefix = "…" if start > 0 else ""
                suffix = "…" if end < len(source) else ""
                return f"{prefix}{source[start:end]}{suffix}"
    return body[:2 * _SNIPPET_CONTEXT] + ("…" if len(body) > 2 * _SNIPPET_CONTEXT else "")


def _like_pattern(token: str) -> str:
    escaped = token.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def _note_dict(row) -> dict:
    note = dict(row)
    raw = note.pop("decision_json")
    note["decision"] = json.loads(raw) if raw else None
    return note


class Knowledge:
    """Mixin; expects ``self._db``, ``self.scope_id`` and the other mixins."""

    # -- search index -------------------------------------------------------------

    def _init_search(self) -> None:
        """Create the FTS5 index when possible; remember which backend we use."""
        conn = self._db._conn
        with self._db._lock:
            self._fts = fts5_available(conn)
            if not self._fts:
                self.search_backend = "like"
                return
            self.search_backend = "fts5"
            exists = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table'"
                " AND name = 'notes_fts'").fetchone()
            if exists is None:
                conn.execute(
                    "CREATE VIRTUAL TABLE notes_fts USING fts5("
                    "note_id UNINDEXED, title, body)")
                self.rebuild_search_index()

    def rebuild_search_index(self) -> None:
        """Repopulate the derived index from ``notes`` (all scopes; the index
        is shared, every query filters by scope)."""
        if not self._fts:
            return
        with self._db.transaction() as cur:
            cur.execute("DELETE FROM notes_fts")
            cur.execute("INSERT INTO notes_fts (note_id, title, body)"
                        " SELECT id, title, body_md FROM notes")

    def _index_note(self, cur, note_id: str, title: str, body: str) -> None:
        if not self._fts:
            return
        cur.execute("DELETE FROM notes_fts WHERE note_id = ?", (note_id,))
        cur.execute("INSERT INTO notes_fts (note_id, title, body) VALUES (?, ?, ?)",
                    (note_id, title, body))

    # -- notes ------------------------------------------------------------------------

    def create_note(self, kind: str, title: str, body_md: str, actor: str,
                    entry_date: str | None = None,
                    decision: dict | None = None) -> dict:
        if kind not in NOTE_KINDS:
            raise ValueError(f"kind must be one of {NOTE_KINDS}, got {kind!r}")
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must be a non-empty string")
        if not isinstance(body_md, str):
            raise ValueError("body_md must be a string")
        if not isinstance(actor, str) or not actor.strip():
            raise ValueError("actor required")
        if kind == "journal":
            if entry_date is None:
                raise ValueError("journal entries need an entry_date")
            check_iso_date(entry_date, "entry_date")
        elif entry_date is not None:
            raise ValueError("entry_date only applies to journal entries")
        decision_json = None
        if kind == "decision":
            if decision is None:
                raise ValueError("decision notes need a decision record")
            decision_json = json.dumps(check_decision(decision), sort_keys=True)
        elif decision is not None:
            raise ValueError("decision only applies to decision notes")
        note_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            if kind == "journal":
                clash = cur.execute(
                    "SELECT id FROM notes WHERE scope_id = ? AND kind = 'journal'"
                    " AND entry_date = ?", (self.scope_id, entry_date)).fetchone()
                if clash is not None:
                    raise ConflictError(
                        f"journal entry for {entry_date} already exists"
                        f" ({clash['id']}); edit it instead")
            try:
                cur.execute(
                    "INSERT INTO notes (id, scope_id, kind, title, body_md,"
                    " entry_date, decision_json, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (note_id, self.scope_id, kind, title.strip(), body_md,
                     entry_date, decision_json, stamp, stamp))
            except sqlite3.IntegrityError as exc:
                raise ConflictError(f"journal entry for {entry_date} already exists") from exc
            self._index_note(cur, note_id, title.strip(), body_md)
            self._db.audit(cur, "note", note_id, "create", actor,
                           {"kind": kind, "entry_date": entry_date},
                           scope_id=self.scope_id)
        return self.get_note(note_id)

    def get_note(self, note_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_NOTE_COLUMNS} FROM notes WHERE id = ? AND scope_id = ?",
            (note_id, self.scope_id))
        return None if row is None else _note_dict(row)

    def _require_note(self, note_id: str) -> dict:
        note = self.get_note(note_id)
        if note is None:
            raise LookupError(
                f"note {note_id!r} not found in scope {self.scope_id!r}")
        return note

    def update_note(self, note_id: str, expected_revision: int,
                    title: str | None = None, body_md: str | None = None,
                    decision: dict | None = None, actor: str = "ui") -> dict:
        note = self._require_note(note_id)
        if note["archived_at"] is not None:
            raise InvariantError("archived notes are read-only")
        fields = {}
        if title is not None:
            if not isinstance(title, str) or not title.strip():
                raise ValueError("title must be a non-empty string")
            fields["title"] = title.strip()
        if body_md is not None:
            if not isinstance(body_md, str):
                raise ValueError("body_md must be a string")
            fields["body_md"] = body_md
        if decision is not None:
            if note["kind"] != "decision":
                raise ValueError("decision only applies to decision notes")
            fields["decision_json"] = json.dumps(check_decision(decision), sort_keys=True)
        if not fields:
            raise ValueError("nothing to update")
        with self._db.transaction() as cur:
            self._db.update_with_revision(
                "notes", note_id, self.scope_id, expected_revision, fields,
                actor=actor, action="update",
                details={"fields": sorted(fields)}, cur=cur, entity_type="note")
            self._index_note(cur, note_id, fields.get("title", note["title"]),
                             fields.get("body_md", note["body_md"]))
        return self.get_note(note_id)

    def archive_note(self, note_id: str, expected_revision: int,
                     actor: str = "ui") -> dict:
        note = self._require_note(note_id)
        if note["revision"] != expected_revision:
            raise ConflictError(
                f"notes {note_id!r} not at revision {expected_revision}")
        if note["archived_at"] is not None:
            raise InvariantError("note is already archived")
        with self._db.transaction() as cur:
            self._db.update_with_revision(
                "notes", note_id, self.scope_id, expected_revision,
                {"archived_at": now()}, actor=actor, action="archive",
                cur=cur, entity_type="note")
        return self.get_note(note_id)

    def list_notes(self, kinds=None, include_archived: bool = False) -> list[dict]:
        sql = f"SELECT {_NOTE_COLUMNS} FROM notes WHERE scope_id = ?"
        params: list = [self.scope_id]
        kinds = self._check_kinds(kinds)
        if kinds:
            sql += f" AND kind IN ({','.join('?' for _ in kinds)})"
            params.extend(kinds)
        if not include_archived:
            sql += " AND archived_at IS NULL"
        return [_note_dict(r) for r in self._db.query(
            sql + " ORDER BY created_at DESC, rowid DESC", params)]

    @staticmethod
    def _check_kinds(kinds) -> list[str]:
        if kinds is None:
            return []
        kinds = list(kinds)
        for kind in kinds:
            if kind not in NOTE_KINDS:
                raise ValueError(f"unknown note kind {kind!r}")
        return kinds

    def journal_entry(self, entry_date: str) -> dict | None:
        check_iso_date(entry_date, "entry_date")
        row = self._db.query_one(
            f"SELECT {_NOTE_COLUMNS} FROM notes WHERE scope_id = ?"
            " AND kind = 'journal' AND entry_date = ?",
            (self.scope_id, entry_date))
        return None if row is None else _note_dict(row)

    # -- decisions --------------------------------------------------------------------

    def record_decision_outcome(self, note_id: str, outcome: str,
                                actor: str = "ui") -> dict:
        note = self._require_note(note_id)
        if note["kind"] != "decision":
            raise ValueError("outcomes only apply to decision notes")
        if not isinstance(outcome, str) or not outcome.strip():
            raise ValueError("outcome must be a non-empty string")
        if note["outcome"] is not None:
            raise InvariantError("decision outcome already recorded")
        self._db.update_with_revision(
            "notes", note_id, self.scope_id, note["revision"],
            {"outcome": outcome.strip(), "outcome_at": now()}, actor=actor,
            action="decision_outcome", entity_type="note")
        return self.get_note(note_id)

    def decision_reviews_due(self, today: str | None = None) -> list[dict]:
        """Open decisions whose review date has arrived (oldest first)."""
        today = today or date.today().isoformat()
        return [_note_dict(r) for r in self._db.query(
            f"SELECT {_NOTE_COLUMNS} FROM notes WHERE scope_id = ?"
            " AND kind = 'decision' AND archived_at IS NULL AND outcome IS NULL"
            " AND json_extract(decision_json, '$.review_date') <= ?"
            " ORDER BY json_extract(decision_json, '$.review_date'), created_at",
            (self.scope_id, today))]

    # -- links ------------------------------------------------------------------------

    def _target_title(self, target_type: str, target_id: str) -> str | None:
        """Title of a same-scope target, or None when it does not exist here."""
        if target_type == "goal":
            record = self.get_goal(target_id)
            return record and record["title"]
        if target_type == "project":
            record = self.get_project(target_id)
            return record and record["title"]
        if target_type == "task":
            record = self.get_task(target_id)
            return record and record["title"]
        if target_type == "note":
            record = self.get_note(target_id)
            return record and record["title"]
        if target_type == "output_version":
            version = self.get_output_version(target_id)
            if version is None:
                return None
            task = self.get_task(version["task_id"])
            return f"{task['title']} v{version['version']}"
        raise ValueError(f"target_type must be one of {LINK_TARGETS}")

    def link_note(self, note_id: str, target_type: str, target_id: str,
                  actor: str = "ui") -> dict:
        self._require_note(note_id)
        if target_type not in LINK_TARGETS:
            raise ValueError(f"target_type must be one of {LINK_TARGETS}")
        if target_type == "note" and target_id == note_id:
            raise ValueError("a note cannot link to itself")
        if self._target_title(target_type, target_id) is None:
            raise ValueError(
                f"{target_type} {target_id!r} not found in scope {self.scope_id!r}")
        link_id = new_id()
        with self._db.transaction() as cur:
            clash = cur.execute(
                "SELECT id FROM note_links WHERE note_id = ? AND target_type = ?"
                " AND target_id = ?", (note_id, target_type, target_id)).fetchone()
            if clash is not None:
                raise ConflictError(f"note already linked to {target_type} {target_id}")
            cur.execute(
                "INSERT INTO note_links (id, scope_id, note_id, target_type,"
                " target_id, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (link_id, self.scope_id, note_id, target_type, target_id, now()))
            self._db.audit(cur, "note", note_id, "link", actor,
                           {"target_type": target_type, "target_id": target_id},
                           scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM note_links WHERE id = ?", (link_id,)))

    def unlink_note(self, note_id: str, target_type: str, target_id: str,
                    actor: str = "ui") -> None:
        self._require_note(note_id)
        with self._db.transaction() as cur:
            cur.execute(
                "DELETE FROM note_links WHERE note_id = ? AND scope_id = ?"
                " AND target_type = ? AND target_id = ?",
                (note_id, self.scope_id, target_type, target_id))
            if cur.rowcount != 1:
                raise LookupError(f"no link from note to {target_type} {target_id}")
            self._db.audit(cur, "note", note_id, "unlink", actor,
                           {"target_type": target_type, "target_id": target_id},
                           scope_id=self.scope_id)

    def list_note_links(self, note_id: str) -> list[dict]:
        self._require_note(note_id)
        links = []
        for row in self._db.query(
                "SELECT * FROM note_links WHERE note_id = ? AND scope_id = ?"
                " ORDER BY created_at, rowid", (note_id, self.scope_id)):
            link = dict(row)
            link["target_title"] = self._target_title(link["target_type"],
                                                      link["target_id"])
            links.append(link)
        return links

    def notes_linked_to(self, target_type: str, target_id: str) -> list[dict]:
        if target_type not in LINK_TARGETS:
            raise ValueError(f"target_type must be one of {LINK_TARGETS}")
        return [_note_dict(r) for r in self._db.query(
            f"SELECT {_NOTE_COLUMNS} FROM notes WHERE id IN ("
            "SELECT note_id FROM note_links WHERE scope_id = ?"
            " AND target_type = ? AND target_id = ?)"
            " AND scope_id = ? AND archived_at IS NULL"
            " ORDER BY created_at DESC",
            (self.scope_id, target_type, target_id, self.scope_id))]

    # -- search -----------------------------------------------------------------------

    def search_notes(self, query: str, kinds=None, limit: int = 50,
                     include_archived: bool = False) -> list[dict]:
        kinds = self._check_kinds(kinds)
        tokens = search_tokens(query)
        if not tokens:
            return []
        limit = max(1, min(int(limit), 200))
        filters, params = "", []
        if kinds:
            filters += f" AND n.kind IN ({','.join('?' for _ in kinds)})"
            params.extend(kinds)
        if not include_archived:
            filters += " AND n.archived_at IS NULL"
        if self._fts:
            match = " ".join('"' + t.replace('"', '""') + '"' for t in tokens)
            rows = self._db.query(
                "SELECT n.id, n.kind, n.title, n.entry_date, n.archived_at,"
                " n.created_at, n.updated_at,"
                " snippet(notes_fts, -1, '[', ']', '…', 12) AS snippet"
                " FROM notes_fts JOIN notes n ON n.id = notes_fts.note_id"
                " WHERE notes_fts MATCH ? AND n.scope_id = ?" + filters +
                " ORDER BY bm25(notes_fts), n.created_at DESC LIMIT ?",
                [match, self.scope_id, *params, limit])
            return [dict(r) for r in rows]
        where = " AND ".join(
            "(n.title LIKE ? ESCAPE '\\' OR n.body_md LIKE ? ESCAPE '\\')"
            for _ in tokens)
        like_params = [p for t in tokens for p in (_like_pattern(t),) * 2]
        rows = self._db.query(
            "SELECT n.id, n.kind, n.title, n.body_md, n.entry_date, n.archived_at,"
            " n.created_at, n.updated_at FROM notes n WHERE n.scope_id = ? AND "
            + where + filters + " ORDER BY n.created_at DESC LIMIT ?",
            [self.scope_id, *like_params, *params, limit])
        hits = []
        for row in rows:
            hit = dict(row)
            body = hit.pop("body_md")
            hit["snippet"] = like_snippet(hit["title"], body, tokens)
            hits.append(hit)
        return hits

    def _search_titles(self, table: str, tokens: list[str], limit: int) -> list[dict]:
        where = " AND ".join("title LIKE ? ESCAPE '\\'" for _ in tokens)
        return [dict(r) for r in self._db.query(
            f"SELECT id, title, status FROM {table} WHERE scope_id = ? AND {where}"
            " ORDER BY created_at DESC LIMIT ?",
            [self.scope_id, *(_like_pattern(t) for t in tokens), limit])]

    def search(self, query: str, limit: int = 20) -> dict:
        """Notes by full text, tasks and goals by title, captures by
        title/body/url (cheap LIKE)."""
        tokens = search_tokens(query)
        if not tokens:
            return {"notes": [], "tasks": [], "goals": [], "captures": []}
        limit = max(1, min(int(limit), 100))
        goals = [dict(r) for r in self._db.query(
            "SELECT id, title, outcome_status FROM goals WHERE scope_id = ? AND "
            + " AND ".join("title LIKE ? ESCAPE '\\'" for _ in tokens)
            + " ORDER BY created_at DESC LIMIT ?",
            [self.scope_id, *(_like_pattern(t) for t in tokens), limit])]
        return {"notes": self.search_notes(query, limit=limit),
                "tasks": self._search_titles("tasks", tokens, limit),
                "goals": goals,
                "captures": self.search_captures(query, limit=limit)}
