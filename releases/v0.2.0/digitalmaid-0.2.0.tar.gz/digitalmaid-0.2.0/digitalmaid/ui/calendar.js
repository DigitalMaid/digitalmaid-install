// Calendar: Day / Week / Month / Agenda over GET /api/calendar (stored events plus
// derived read-only items). Times are shown in the browser's zone; new events are
// stored with that IANA zone so recurring wall times survive DST.
import { api } from "./api.js";
import { el, append, pill, empty, field, form, alertBox, pageHeader, moreOptions } from "./views.js";

const VIEWS = [["day", "Day"], ["week", "Week"], ["month", "Month"], ["agenda", "Agenda"]];
const KINDS = ["event", "deadline", "block", "milestone"];
const KIND_LABELS = { task_deadline: "task deadline", job_occurrence: "job due", decision_review: "decision review" };
const STACK_BELOW = 480;
const zone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";

const state = { view: "week", focus: todayKey(), gridHadFocus: false };
let items = [];

// --- date helpers (keys are local YYYY-MM-DD) ----------------------------------------
function pad(n) { return String(n).padStart(2, "0"); }
function keyOf(date) { return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`; }
function todayKey() { return keyOf(new Date()); }
function parseKey(key) { const [y, m, d] = key.split("-").map(Number); return new Date(y, m - 1, d); }
function addDays(key, n) { const d = parseKey(key); d.setDate(d.getDate() + n); return keyOf(d); }
function addMonths(key, n) { const d = parseKey(key); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return keyOf(d); }
function weekStart(key) { const d = parseKey(key); const shift = (d.getDay() + 6) % 7; d.setDate(d.getDate() - shift); return keyOf(d); }
function monthGridStart(key) { const d = parseKey(key); d.setDate(1); return weekStart(keyOf(d)); }
function range(startKey, days) { return Array.from({ length: days }, (_, i) => addDays(startKey, i)); }
function itemDay(item) { return item.all_day && item.local_date ? item.local_date : keyOf(new Date(item.start_utc)); }
function timeLabel(item) {
  if (item.all_day) return "all day";
  const start = new Date(item.start_utc).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return item.end_utc ? `${start}–${new Date(item.end_utc).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : start;
}
function longDate(key) { return parseKey(key).toLocaleDateString([], { weekday: "long", year: "numeric", month: "long", day: "numeric" }); }

function visibleRange() {
  if (state.view === "day") return [state.focus, 1];
  if (state.view === "week") return [weekStart(state.focus), 7];
  if (state.view === "month") return [monthGridStart(state.focus), 42];
  return [state.focus, 30];
}

function periodStep(direction) {
  if (state.view === "day") return addDays(state.focus, direction);
  if (state.view === "week") return addDays(state.focus, 7 * direction);
  if (state.view === "month") return addMonths(state.focus, direction);
  return addDays(state.focus, 30 * direction);
}

function title() {
  const d = parseKey(state.focus);
  if (state.view === "day") return longDate(state.focus);
  if (state.view === "month") return d.toLocaleDateString([], { month: "long", year: "numeric" });
  const [start, days] = visibleRange();
  return `${parseKey(start).toLocaleDateString([], { day: "numeric", month: "short" })} – ${parseKey(addDays(start, days - 1)).toLocaleDateString([], { day: "numeric", month: "short", year: "numeric" })}`;
}

// --- rendering ------------------------------------------------------------------------

export async function renderCalendarPage(container, ctx) {
  const [startKey, days] = visibleRange();
  const from = parseKey(startKey); from.setDate(from.getDate() - 1);
  const to = parseKey(addDays(startKey, days)); to.setDate(to.getDate() + 1);
  const result = await api.calendar(from.toISOString(), to.toISOString());
  items = result.items;
  const byDay = {};
  for (const item of items) (byDay[itemDay(item)] ||= []).push(item);

  const tabs = el("div", { id: "calendar-views", class: "tabs", role: "tablist", "aria-label": "Calendar view" },
    VIEWS.map(([id, label]) => el("button", { class: "tab", type: "button", role: "tab", id: `calendar-tab-${id}`,
      dataset: { view: id }, "aria-selected": String(state.view === id), "aria-controls": "calendar-grid",
      tabindex: state.view === id ? "0" : "-1",
      onclick: () => { state.view = id; rerender(ctx); },
      onkeydown: (e) => {
        const index = VIEWS.findIndex(([v]) => v === id);
        if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
          e.preventDefault();
          const next = VIEWS[(index + (e.key === "ArrowRight" ? 1 : VIEWS.length - 1)) % VIEWS.length][0];
          state.view = next; state.gridHadFocus = false;
          rerender(ctx).then(() => document.getElementById(`calendar-tab-${next}`)?.focus());
        }
      } }, label)));

  const stacked = window.innerWidth < STACK_BELOW;
  const grid = el("div", { id: "calendar-grid", role: "tabpanel", "aria-labelledby": `calendar-tab-${state.view}`,
    dataset: { view: state.view, layout: state.view === "agenda" || stacked ? "stacked" : (state.view === "month" ? "grid" : "grid") },
    class: `calendar-grid is-${state.view}${stacked ? " is-stacked" : ""}`,
    onkeydown: (e) => onGridKey(e, ctx) });
  if (state.view === "agenda") append(grid, [renderAgenda(startKey, days, byDay, ctx)]);
  else append(grid, range(startKey, days).map((key) => dayCell(key, byDay[key] || [], ctx, stacked)));

  const header = pageHeader("calendar", "Calendar",
    `Stored events plus derived items (task deadlines, due job occurrences, decision reviews) shown in ${zone}. Arrow keys move the day, PageUp/PageDown change the period, “t” is today, Enter creates an event on the focused day.`,
    { tools: el("div", { class: "form-actions" },
      el("button", { class: "btn is-small", type: "button", "aria-label": "Previous period", onclick: () => { state.focus = periodStep(-1); rerender(ctx); } }, "‹"),
      el("button", { class: "btn is-small", type: "button", onclick: () => { state.focus = todayKey(); rerender(ctx); } }, "Today"),
      el("button", { class: "btn is-small", type: "button", "aria-label": "Next period", onclick: () => { state.focus = periodStep(1); rerender(ctx); } }, "›"),
      el("button", { class: "btn is-primary is-small", type: "button", id: "new-event-button", dataset: { write: "true" }, onclick: () => openEventDrawer(ctx, null, state.focus) }, "New event")) });
  container.replaceChildren(header,
    el("div", { class: "calendar-toolbar" }, el("h2", { id: "calendar-title", "aria-live": "polite" }, title()), tabs),
    grid);
  ctx.applyReadOnly?.(container);
  if (state.gridHadFocus) grid.querySelector("[data-day][tabindex='0']")?.focus();
  state.gridHadFocus = false;
}

async function rerender(ctx) {
  state.gridHadFocus = document.activeElement?.closest?.("#calendar-grid") !== null && document.activeElement?.closest?.("#calendar-grid") !== undefined;
  await ctx.route();
}

function onGridKey(event, ctx) {
  const vertical = state.view === "week" || state.view === "month" ? 7 : 1;
  const moves = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -vertical, ArrowDown: vertical };
  if (event.key in moves) { event.preventDefault(); state.focus = addDays(state.focus, moves[event.key]); return refocus(ctx); }
  if (event.key === "PageDown" || event.key === "PageUp") { event.preventDefault(); state.focus = periodStep(event.key === "PageDown" ? 1 : -1); return refocus(ctx); }
  if (event.key === "t" || event.key === "T") { if (event.target.matches("input, textarea")) return; event.preventDefault(); state.focus = todayKey(); return refocus(ctx); }
  if (event.key === "Enter" && event.target.matches("[data-day]")) { event.preventDefault(); openEventDrawer(ctx, null, event.target.dataset.day); }
}

function refocus(ctx) {
  state.gridHadFocus = true;
  const [start, days] = visibleRange();
  // Stay inside the rendered range where possible; otherwise re-render for the new period.
  const cell = document.querySelector(`#calendar-grid [data-day="${state.focus}"]`);
  const inRange = state.focus >= start && state.focus < addDays(start, days);
  if (cell && inRange) {
    for (const c of document.querySelectorAll("#calendar-grid [data-day]")) c.tabIndex = c === cell ? 0 : -1;
    cell.focus();
    return;
  }
  return rerender(ctx);
}

function dayCell(key, dayItems, ctx, stacked) {
  const isFocus = key === state.focus;
  const d = parseKey(key);
  const outsideMonth = state.view === "month" && d.getMonth() !== parseKey(state.focus).getMonth();
  if (stacked && state.view === "month" && !dayItems.length && !isFocus) return null;
  return el("div", { class: `calendar-day${isFocus ? " is-focus" : ""}${key === todayKey() ? " is-today" : ""}${outsideMonth ? " is-outside" : ""}`,
    dataset: { day: key }, tabindex: isFocus ? "0" : "-1", role: "group",
    "aria-label": `${longDate(key)}, ${dayItems.length} item${dayItems.length === 1 ? "" : "s"}`,
    onclick: (e) => { if (e.target.closest("[data-item]")) return; state.focus = key; refocus(ctx); },
    ondblclick: (e) => { if (!e.target.closest("[data-item]")) openEventDrawer(ctx, null, key); } },
    el("div", { class: "calendar-day-head" },
      el("span", { class: "calendar-day-num" }, state.view === "month" ? String(d.getDate()) : d.toLocaleDateString([], { weekday: "short", day: "numeric" }))),
    dayItems.length
      ? el("ul", { class: "calendar-items" }, dayItems.map((item) => itemButton(item, ctx)))
      : (state.view !== "month" || stacked ? el("p", { class: "empty" }, "—") : null));
}

function itemButton(item, ctx) {
  const derived = item.source !== "event";
  return el("li", {}, el("button", { class: `calendar-item is-${item.kind}${derived ? " is-derived" : ""}`, type: "button",
    dataset: { item: item.id, source: item.source, kind: item.kind },
    title: derived ? `${KIND_LABELS[item.kind] || item.kind} (read-only, opens its source)` : item.title,
    onclick: () => openItem(item, ctx) },
    el("span", { class: "calendar-item-time" }, timeLabel(item)),
    el("span", { class: "calendar-item-title" }, item.title),
    derived ? el("span", { class: "pill is-plain" }, KIND_LABELS[item.kind] || item.kind) : null,
    item.external_source ? el("span", { class: "pill is-plain" }, `owned by ${item.external_source}`) : null));
}

function renderAgenda(startKey, days, byDay, ctx) {
  const keys = range(startKey, days).filter((k) => (byDay[k] || []).length || k === state.focus);
  return el("div", { class: "agenda" }, keys.length ? keys.map((key) => el("section", { class: "agenda-day", dataset: { day: key }, tabindex: key === state.focus ? "0" : "-1",
    "aria-label": longDate(key), onclick: () => { state.focus = key; } },
    el("h3", {}, longDate(key)),
    (byDay[key] || []).length ? el("ul", { class: "calendar-items" }, byDay[key].map((item) => itemButton(item, ctx))) : empty("Nothing scheduled."))) : empty("Nothing in this period."));
}

function openItem(item, ctx) {
  if (item.source === "task") return ctx.openTask(item.linked_id);
  if (item.source === "job") { location.hash = "#/automations"; return; }
  if (item.source === "decision") { location.hash = `#/knowledge/${item.linked_id}`; return; }
  openEventDrawer(ctx, item, itemDay(item));
}

// --- event drawer -----------------------------------------------------------------------

async function openEventDrawer(ctx, item, dayKey) {
  let event = null;
  if (item) {
    try { event = await api.event(item.event_id); } catch (error) { ctx.showGlobal(`Could not load event: ${error.message}`); return; }
  }
  const readOnly = Boolean(event?.external_source);
  const start = event ? new Date(item.start_utc) : null;
  const end = event && item.end_utc ? new Date(item.end_utc) : null;
  const values = {
    title: event?.title || "", kind: event?.kind || "event", date: dayKey,
    start_time: start && !event.all_day ? `${pad(start.getHours())}:${pad(start.getMinutes())}` : "09:00",
    end_time: end && !event.all_day ? `${pad(end.getHours())}:${pad(end.getMinutes())}` : "",
    notes: event?.notes || "", freq: event?.rrule?.freq || "none", until: event?.rrule?.until || "",
  };
  const body = (data) => {
    const startAt = data.all_day ? new Date(parseKey(data.date)) : new Date(`${data.date}T${data.start_time || "09:00"}`);
    const endAt = !data.all_day && data.end_time ? new Date(`${data.date}T${data.end_time}`) : null;
    const rrule = data.freq && data.freq !== "none" ? { freq: data.freq, interval: 1, ...(data.until ? { until: data.until } : {}) } : null;
    return { title: data.title, kind: data.kind, start_utc: startAt.toISOString(), end_utc: endAt ? endAt.toISOString() : null,
      all_day: Boolean(data.all_day), timezone: zone, notes: data.notes || "", rrule };
  };
  const allDay = el("label", { class: "checkbox" }, el("input", { type: "checkbox", name: "all_day", checked: event?.all_day || null }), " All day");
  // Tier 1 (D3): title + when. Kind, end, all-day, repeat and notes wait under More options,
  // which opens itself when an existing event already uses any of them.
  const nonDefault = Boolean(event && (values.kind !== "event" || values.end_time || event.all_day || values.freq !== "none" || values.notes));
  const eventForm = form([
    field("Title", "title", { required: true, value: values.title }),
    el("div", { class: "form-row is-inline" },
      field("Date", "date", { type: "date", required: true, value: values.date }),
      field("Start", "start_time", { type: "time", value: values.start_time })),
    moreOptions([
      el("div", { class: "form-row is-inline" },
        field("Kind", "kind", { options: KINDS, value: values.kind }, "select"),
        field("End", "end_time", { type: "time", value: values.end_time }),
        el("div", { class: "form-row" }, allDay)),
      el("div", { class: "form-row is-inline" },
        field("Repeats", "freq", { options: [{ value: "none", label: "never" }, "daily", "weekly", "monthly"], value: values.freq }, "select"),
        field("Until (date)", "until", { type: "date", value: values.until })),
      field("Notes", "notes", { rows: "2", value: values.notes }, "textarea"),
    ], { open: nonDefault }),
  ], event ? "Save event" : "Create event", async (data) => {
    const payload = body(data);
    if (event) {
      const update = { revision: event.revision, title: payload.title, kind: payload.kind, start_utc: payload.start_utc, end_utc: payload.end_utc, all_day: payload.all_day, notes: payload.notes };
      if (payload.rrule) update.rrule = payload.rrule; else update.clear_rrule = true;
      await api.updateEvent(event.id, update);
    } else await api.createEvent(payload);
    ctx.closeDrawer();
    await ctx.route();
  });
  eventForm.id = "event-form";
  eventForm.querySelector("[name=kind]").value = values.kind;
  eventForm.querySelector("[name=freq]").value = values.freq;
  const actions = [];
  if (event && !readOnly) {
    actions.push(form([], "Archive event", async () => { await api.archiveEvent(event.id, { revision: event.revision }); ctx.closeDrawer(); await ctx.route(); }));
    if (event.rrule) actions.push(form([], `Skip the ${item.occurrence_local_date} occurrence`, async () => {
      await api.addEventException(event.id, { occurrence_local_date: item.occurrence_local_date, kind: "skip" }); ctx.closeDrawer(); await ctx.route(); }));
  }
  const sections = [
    readOnly ? alertBox("info", `Owned by ${event.external_source}; read-only here. Changes must be made at the source (see docs/CALENDAR-SYNC.md).`) : null,
    event ? el("dl", { class: "kv" }, el("dt", {}, "Occurrence"), el("dd", {}, `${longDate(dayKey)} · ${timeLabel(item)}`),
      event.rrule ? [el("dt", {}, "Repeats"), el("dd", {}, `${event.rrule.freq}${event.rrule.until ? ` until ${event.rrule.until}` : ""} · ${event.exceptions.length} exception${event.exceptions.length === 1 ? "" : "s"}`)] : null,
      event.linked_type ? [el("dt", {}, "Linked"), el("dd", {}, `${event.linked_type} ${event.linked_id.slice(0, 8)}…`)] : null) : null,
    readOnly ? null : eventForm,
    ...actions,
  ];
  if (readOnly) eventForm.querySelectorAll("input, select, textarea, button").forEach((n) => { n.disabled = true; });
  if (readOnly) sections.push(eventForm);
  ctx.openDrawer(event ? event.title : `New event on ${longDate(dayKey)}`, el("div", { class: "stack" }, sections), { focus: "#event-form [name=title]", kicker: event ? `Event · ${event.kind}` : "New event" });
}

window.digitalmaidCalendar = {
  goTo(dateKey) { state.focus = dateKey; return window.dispatchEvent(new Event("hashchange")); },
  state,
};
