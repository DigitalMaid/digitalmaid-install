// Thin fetch wrapper over the relative /api. Errors keep the server's body so
// 409 invariant reasons can be shown verbatim, never swallowed.

export class ApiError extends Error {
  constructor(status, body) {
    const reasons = Array.isArray(body?.reasons) ? body.reasons : null;
    const detail = typeof body?.detail === "string"
      ? body.detail
      : Array.isArray(body?.detail)
        ? body.detail.map((d) => `${(d.loc || []).slice(1).join(".")}: ${d.msg}`).join("; ")
        : null;
    super(reasons ? reasons.join("; ") : detail || `HTTP ${status}`);
    this.status = status;
    this.reasons = reasons;
    this.detail = detail;
  }
}

// Every request carries the CSRF marker the server demands on writes; cookies
// are same-site, so a cross-site form post can never carry this header.
async function request(method, path, body) {
  const init = { method, headers: { Accept: "application/json", "X-Requested-With": "digitalmaid" }, credentials: "same-origin" };
  if (body !== undefined) {
    init.headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(body);
  }
  const response = await fetch(`/api${path}`, init);
  let parsed = null;
  const text = await response.text();
  if (text) {
    try { parsed = JSON.parse(text); } catch { parsed = { detail: text }; }
  }
  if (response.status === 401 && path !== "/auth/login") window.dispatchEvent(new CustomEvent("dm:unauthenticated"));
  if (!response.ok) throw new ApiError(response.status, parsed);
  return parsed;
}

// Multipart upload: the browser sets the boundary; only the CSRF marker is added.
async function upload(path, formData) {
  const response = await fetch(`/api${path}`, { method: "POST", headers: { Accept: "application/json", "X-Requested-With": "digitalmaid" }, credentials: "same-origin", body: formData });
  let parsed = null;
  const text = await response.text();
  if (text) { try { parsed = JSON.parse(text); } catch { parsed = { detail: text }; } }
  if (response.status === 401) window.dispatchEvent(new CustomEvent("dm:unauthenticated"));
  if (!response.ok) throw new ApiError(response.status, parsed);
  return parsed;
}

export const api = {
  get: (path) => request("GET", path),

  captures: (status) => request("GET", status ? `/captures?status=${encodeURIComponent(status)}` : "/captures"),
  capture: (captureId) => request("GET", `/captures/${captureId}`),
  createCapture: (body) => request("POST", "/captures", body),
  uploadCapture: (formData) => upload("/captures/upload", formData),
  addCaptureDraft: (captureId, body) => request("POST", `/captures/${captureId}/drafts`, body),
  convertCapture: (captureId, body) => request("POST", `/captures/${captureId}/convert`, body),
  archiveCapture: (captureId, body) => request("POST", `/captures/${captureId}/archive`, body),
  unarchiveCapture: (captureId, body) => request("POST", `/captures/${captureId}/unarchive`, body),
  tokens: () => request("GET", "/tokens"),
  createToken: (body) => request("POST", "/tokens", body),
  revokeToken: (tokenId) => request("POST", `/tokens/${tokenId}/revoke`, null),
  post: (path, body) => request("POST", path, body ?? null),
  put: (path, body) => request("PUT", path, body),

  login: (username, password) => request("POST", "/auth/login", { username, password }),
  logout: () => request("POST", "/auth/logout", null),
  me: () => request("GET", "/auth/me"),
  changePassword: (current_password, new_password) => request("POST", "/auth/password", { current_password, new_password }),
  settings: () => request("GET", "/settings"),
  users: () => request("GET", "/users"),
  createUser: (body) => request("POST", "/users", body),
  setMembership: (userId, role) => request("PUT", `/users/${userId}/membership`, { role }),
  disableUser: (userId) => request("POST", `/users/${userId}/disable`, null),
  calendar: (from, to) => request("GET", `/calendar?${new URLSearchParams({ from, to })}`),
  event: (eventId) => request("GET", `/events/${eventId}`),
  createEvent: (body) => request("POST", "/events", body),
  updateEvent: (eventId, body) => request("PUT", `/events/${eventId}`, body),
  archiveEvent: (eventId, body) => request("POST", `/events/${eventId}/archive`, body),
  addEventException: (eventId, body) => request("POST", `/events/${eventId}/exceptions`, body),

  workspace: () => request("GET", "/workspace"),
  today: () => request("GET", "/today"),
  counts: () => request("GET", "/counts"),
  widgetPreferences: () => request("GET", "/preferences/widgets"),
  saveWidgetPreferences: (widgets) => request("PUT", "/preferences/widgets", { widgets }),

  goals: () => request("GET", "/goals"),
  createGoal: (body) => request("POST", "/goals", body),
  recordGoalOutcome: (goalId, body) => request("POST", `/goals/${goalId}/outcome`, body),
  projects: (goalId) => request("GET", goalId ? `/projects?goal_id=${encodeURIComponent(goalId)}` : "/projects"),
  createProject: (body) => request("POST", "/projects", body),
  projectTasks: (projectId) => request("GET", `/projects/${projectId}/tasks`),
  createTask: (body) => request("POST", "/tasks", body),
  taskDetail: (taskId) => request("GET", `/tasks/${taskId}/detail`),

  assessResource: (taskId, body) => request("POST", `/tasks/${taskId}/resources`, body),
  grantWaiver: (taskId, body) => request("POST", `/tasks/${taskId}/waivers`, body),
  startTask: (taskId) => request("POST", `/tasks/${taskId}/start`, null),
  recordExecution: (taskId, body) => request("POST", `/tasks/${taskId}/executions`, body),
  submitOutput: (taskId, body) => request("POST", `/tasks/${taskId}/outputs`, body),
  recordCheck: (versionId, body) => request("POST", `/output-versions/${versionId}/checks`, body),
  openCorrection: (checkId, body) => request("POST", `/checks/${checkId}/corrections`, body),
  acceptOutput: (versionId) => request("POST", `/output-versions/${versionId}/accept`, null),
  addLearning: (taskId, body) => request("POST", `/tasks/${taskId}/learnings`, body),

  notes: (kind, includeArchived = false) => request("GET", `/notes?${new URLSearchParams({ ...(kind ? { kind } : {}), include_archived: String(includeArchived) })}`),
  note: (noteId) => request("GET", `/notes/${noteId}`),
  createNote: (body) => request("POST", "/notes", body),
  updateNote: (noteId, body) => request("PUT", `/notes/${noteId}`, body),
  archiveNote: (noteId, body) => request("POST", `/notes/${noteId}/archive`, body),
  linkNote: (noteId, body) => request("POST", `/notes/${noteId}/links`, body),
  unlinkNote: (noteId, body) => request("DELETE", `/notes/${noteId}/links`, body),
  decisionOutcome: (noteId, body) => request("POST", `/notes/${noteId}/decision-outcome`, body),
  journalEntry: (entryDate) => request("GET", `/journal/${entryDate}`),
  search: (q, limit = 20) => request("GET", `/search?${new URLSearchParams({ q, limit: String(limit) })}`),

  procedures: () => request("GET", "/procedures"),
  procedure: (procedureId) => request("GET", `/procedures/${procedureId}`),
  createProcedure: (body) => request("POST", "/procedures", body),
  publishProcedureVersion: (procedureId, body) => request("POST", `/procedures/${procedureId}/versions`, body),
  activateProcedure: (procedureId, body) => request("POST", `/procedures/${procedureId}/activate`, body),
  retireProcedure: (procedureId) => request("POST", `/procedures/${procedureId}/retire`, null),
  instantiateProcedure: (procedureId, body) => request("POST", `/procedures/${procedureId}/instantiate`, body),
  proposeLearning: (procedureId, body) => request("POST", `/procedures/${procedureId}/proposals`, body),
  applyProposal: (proposalId, body) => request("POST", `/proposals/${proposalId}/apply`, body),
  rejectProposal: (proposalId, body) => request("POST", `/proposals/${proposalId}/reject`, body),

  reviewInbox: () => request("GET", "/review-inbox"),
  outputs: (accepted) => request("GET", accepted === undefined || accepted === "" ? "/outputs" : `/outputs?accepted=${accepted}`),
  addComment: (versionId, body) => request("POST", `/output-versions/${versionId}/comments`, body),

  agents: () => request("GET", "/agents"),
  workers: () => request("GET", "/workers"),
  jobs: () => request("GET", "/jobs"),
  runJobNow: (jobId, idempotencyKey) => request("POST", `/jobs/${jobId}/run-now`, { idempotency_key: idempotencyKey }),
};
