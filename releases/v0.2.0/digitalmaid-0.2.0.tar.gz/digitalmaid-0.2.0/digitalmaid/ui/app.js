import { api } from "./api.js";
import {
  el, append, pill, phasePill, when, empty, reasonsList, alertBox, field, form, icon, pdccChain, confirmDialog,
  renderToday, renderHiddenWidgets, renderGoals, renderAutomations, renderAgents, runnerLabel,
  executionEvidence, workerStatus, setSession, isReadOnly, currentUser, applyReadOnly,
  pageHeader, techDetails, segmented, moreOptions, PRIORITY_OPTIONS, renderStartHere, startHereKey,
} from "./views.js";
import { renderKnowledgePage, renderProceduresPage, renderReviewPage, renderOutputsPage, renderSettingsPage } from "./pages.js";
import { renderCalendarPage } from "./calendar.js";
import { renderCapturePage, openCapture } from "./capture.js";
import { renderHero, renderBoardHead } from "./hero.js";
import { startSky } from "./sky.js";
import { setupCommands, setCommandScope, recordRecent, openQuickCapture, openHelp } from "./commands.js";

const ROUTES = ["goals", "knowledge", "procedures", "review", "outputs", "automations", "agents", "calendar", "capture", "settings"];
const FIVE_M = ["Man", "Method", "Machine", "Material", "Money"];
const RESOURCE_STATUSES = ["required", "available", "missing", "not_applicable"];
const EXECUTION_STATUSES = ["queued", "running", "succeeded", "failed", "cancelled", "interrupted", "uncertain"];

// The session cookie is HttpOnly, so the page cannot see it. A browser that signed in here
// remembers that; without the hint the login form renders with no request at all (D6).
const SIGNED_IN_KEY = "dm:signed-in";
const DEFAULT_NEXT_ACTION = "Decide the first step";

const view = document.getElementById("view");
const drawer = document.getElementById("drawer");
const backdrop = document.getElementById("backdrop");
const globalAlert = document.getElementById("global-alert");
let lastFocus = null;
let workspaceId = null;

function hasSignedInHint() { return localStorage.getItem(SIGNED_IN_KEY) === "1"; }
function setSignedInHint(on) {
  try { if (on) localStorage.setItem(SIGNED_IN_KEY, "1"); else localStorage.removeItem(SIGNED_IN_KEY); } catch { /* storage unavailable */ }
}

// --- navigation -------------------------------------------------------------------

function currentRoute() {
  const hash = location.hash.replace(/^#\/?/, "");
  for (const name of ROUTES) if (hash === name || hash.startsWith(`${name}/`)) return name;
  return "today";
}

// "#/knowledge/<id>" → "<id>"; nothing else is ever read from the hash.
function routeParam() {
  const parts = location.hash.replace(/^#\/?/, "").split("/");
  return parts.length > 1 && parts[1] ? decodeURIComponent(parts[1]) : null;
}

function setActiveNav(route) {
  for (const link of document.querySelectorAll("[data-route]")) {
    if (link.dataset.route === route) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  }
}

function showGlobal(message, kind = "error", reasons) {
  globalAlert.className = `alert is-${kind}`;
  globalAlert.replaceChildren();
  if (!message) return;
  globalAlert.append(el("div", {}, message));
  if (reasons?.length) globalAlert.append(el("ul", {}, reasons.map((r) => el("li", {}, r))));
}

const pageContext = {
  openTask: (id, options) => openTask(id, options), route: (options) => route(options),
  showGlobal: (...args) => showGlobal(...args), openDrawer, closeDrawer, applyReadOnly,
  currentUser, recordRecent,
};

// Change the hash and resolve once the new page has rendered (route() announces it).
function navigate(hash) {
  if (location.hash === hash) return route();
  return new Promise((resolve) => {
    window.addEventListener("dm:routed", () => resolve(), { once: true });
    location.hash = hash;
  });
}

// Palette "Create" entries and the `n` shortcut open the existing create forms.
async function createIntent(kind) {
  if (kind === "capture") { openQuickCapture(); return; }
  if (kind === "goal") { await navigate("#/goals"); view.querySelector("#new-goal")?.click(); return; }
  if (kind === "task") {
    await navigate("#/goals");
    const button = view.querySelector("[data-new-task]");
    if (button) button.click();
    else showGlobal("Create a goal and a project first; tasks live inside projects.", "info");
    return;
  }
  if (kind === "inbox") { await navigate("#/capture"); return; }
  if (kind === "note") {
    await navigate("#/knowledge");
    const details = view.querySelector("#new-note");
    if (details) { details.open = true; details.querySelector("[name=title]")?.focus(); }
    return;
  }
  if (kind === "journal") {
    await navigate("#/knowledge");
    const tab = view.querySelector("[data-kind-tab='journal']");
    if (tab && tab.getAttribute("aria-selected") !== "true") { tab.click(); await new Promise((r) => window.addEventListener("dm:routed", r, { once: true })); }
    view.querySelector("#todays-entry")?.click();
    return;
  }
  if (kind === "procedure") {
    await navigate("#/procedures");
    const details = view.querySelector("#new-procedure");
    if (details) { details.open = true; details.querySelector("[name=title]")?.focus(); }
    return;
  }
  if (kind === "event") { await navigate("#/calendar"); view.querySelector("#new-event-button")?.click(); }
}

async function runJobFromPalette(job) {
  await navigate("#/automations");
  view.querySelector(`[data-run-now="${job.id}"]`)?.click();
}

// --- session -------------------------------------------------------------------------------

let session = null;

function setSessionState(next) {
  session = next;
  setSession(next);
  const label = document.getElementById("session-label");
  const logout = document.getElementById("logout-button");
  const name = document.getElementById("user-name");
  const avatar = document.getElementById("user-avatar");
  document.body.dataset.signedIn = String(Boolean(next));
  setSignedInHint(Boolean(next));
  if (next) {
    label.textContent = `${next.user.username} · ${next.role || "no membership"}${isReadOnly() ? " (read-only)" : ""}`;
    name.textContent = `Signed in as ${next.user.username}`;
    avatar.replaceChildren(next.user.username.slice(0, 1).toUpperCase());
    logout.hidden = false;
  } else {
    label.textContent = "not signed in";
    name.textContent = "Not signed in";
    avatar.replaceChildren(icon("user"));
    logout.hidden = true;
    document.getElementById("user-menu").open = false;
    for (const badge of document.querySelectorAll(".nav-badge")) badge.hidden = true;
  }
}

// Rail badges (D5): the two inbox counts on every page, hidden at zero. A failed refresh
// leaves the badges as they were; they are a convenience, not a record.
async function refreshCounts() {
  if (!session) return;
  let counts;
  try { counts = await api.counts(); } catch { return; }
  for (const [route, key] of [["capture", "capture_inbox"], ["review", "review_inbox"]]) {
    const badge = document.getElementById(`nav-badge-${route}`);
    const n = counts[key] ?? 0;
    badge.textContent = String(n);
    badge.hidden = n === 0;
    badge.setAttribute("aria-label", `${n} waiting`);
  }
}

async function loadWorkspace() {
  const ws = await api.workspace();
  workspaceId = ws.workspace_id;
  setCommandScope(ws.scope_id);
  document.getElementById("scope-label").textContent = `scope: ${ws.scope_id}`;
  document.getElementById("workspace-label").textContent = `workspace ${ws.workspace_id.slice(0, 8)}…`;
}

function renderLogin(message) {
  const loginForm = form([
    field("Username", "username", { required: true, autocomplete: "username" }),
    field("Password", "password", { type: "password", required: true, autocomplete: "current-password" }),
  ], "Sign in", async (data) => {
    const me = await api.login(data.username, data.password);
    setSessionState(me);
    try { await loadWorkspace(); } catch { /* the label stays as it was */ }
    await route();
  });
  loginForm.id = "login-form";
  document.getElementById("scope-label").textContent = "signed out";
  render(view,
    el("section", { class: "panel login-panel", "aria-labelledby": "login-title" },
      el("div", { class: "wordmark", "aria-hidden": "true" }, el("span", { class: "wordmark-name" }, "DigitalMaid"), el("span", { class: "wordmark-sub" }, "Agentic OS")),
      el("header", { class: "main-header" }, el("div", {}, el("h1", { id: "login-title" }, "Sign in"),
        el("p", {}, "Sign in with the account the workspace owner gave you."))),
      message ? alertBox("info", message) : null, loginForm));
  loginForm.querySelector("[name=username]").focus();
}

async function route(options = {}) {
  const name = currentRoute();
  setActiveNav(name);
  document.body.dataset.route = name;
  document.querySelector(".nav").dataset.open = "false";
  document.getElementById("nav-toggle").setAttribute("aria-expanded", "false");
  showGlobal("");
  if (!session) {
    if (!hasSignedInHint()) { renderLogin(); return; }
    try { setSessionState(await api.me()); } catch { renderLogin(); return; }
  }
  refreshCounts();
  // Re-rendering a page with a focused search box must not throw the caret away.
  const focused = options.keepFocus ? document.querySelector(options.keepFocus) : null;
  const caret = focused && typeof focused.selectionStart === "number" ? focused.selectionStart : null;
  if (!focused) view.replaceChildren(el("p", { class: "empty" }, "Loading…"));
  try {
    if (name === "goals") await renderGoalsPage(routeParam());
    else if (name === "knowledge") await renderKnowledgePage(view, pageContext, routeParam());
    else if (name === "procedures") await renderProceduresPage(view, pageContext, routeParam());
    else if (name === "review") await renderReviewPage(view, pageContext);
    else if (name === "outputs") await renderOutputsPage(view, pageContext);
    else if (name === "automations") await renderAutomationsPage();
    else if (name === "agents") await renderAgentsPage();
    else if (name === "calendar") await renderCalendarPage(view, pageContext);
    else if (name === "capture") await renderCapturePage(view, pageContext, routeParam());
    else if (name === "settings") await renderSettingsPage(view, pageContext);
    else await renderTodayPage();
    applyReadOnly(view);
  } catch (error) {
    if (error.status === 401) { setSessionState(null); renderLogin("Your session ended. Sign in again."); return; }
    view.replaceChildren();
    showGlobal(`Could not load ${name}: ${error.message}`, "error", error.reasons);
  }
  if (options.keepFocus) {
    const again = document.querySelector(options.keepFocus);
    if (again) {
      again.focus();
      if (caret !== null && typeof again.setSelectionRange === "function") again.setSelectionRange(caret, caret);
    }
  }
  window.dispatchEvent(new CustomEvent("dm:routed", { detail: { route: name } }));
}

// --- Today -------------------------------------------------------------------------

async function renderTodayPage() {
  // Journal entry dates feed the 14-day dot row and the job list feeds the Automations
  // node badge; a failure in either must not hide the board.
  const [today, prefs, journalNotes, jobs] = await Promise.all([
    api.today(), api.widgetPreferences(), api.notes("journal").catch(() => []), api.jobs().catch(() => null)]);
  const handlers = {
    journalDates: journalNotes.map((n) => n.entry_date).filter(Boolean),
    onOpenTask: openTask,
    onNewTask: () => createIntent("task"),
    onMoveWidget: async (id, delta) => {
      const order = prefs.widgets.slice();
      const index = order.findIndex((w) => w.id === id);
      const target = index + delta;
      if (target < 0 || target >= order.length) return;
      [order[index], order[target]] = [order[target], order[index]];
      await savePrefs(order);
    },
    onToggleWidget: async (id, visible) => {
      await savePrefs(prefs.widgets.map((w) => (w.id === id ? { ...w, visible } : w)));
    },
    onOpenJournal: async (journal) => {
      try {
        let entry = journal.note_id ? { id: journal.note_id } : null;
        if (!entry) entry = await api.createNote({ kind: "journal", title: `Journal ${journal.entry_date}`, body_md: "", actor: "ui", entry_date: journal.entry_date });
        location.hash = `#/knowledge/${entry.id}`;
      } catch (error) {
        showGlobal(`Could not open today's entry: ${error.message}`, "error", error.reasons);
      }
    },
  };
  async function savePrefs(widgets) {
    try {
      await api.saveWidgetPreferences(widgets);
      await route();
    } catch (error) {
      showGlobal(`Could not save widget preferences: ${error.message}`, "error", error.reasons);
    }
  }
  // Board, not document (DESIGN.md B1/C1): the hero readout replaces the page title; the
  // scope and generation time become a tiny footer meta line.
  render(view,
    renderHero(today, {
      onCapture: openQuickCapture,
      onSearch: () => document.getElementById("global-search")?.focus(),
      onLayout: toggleEditBoard,
      onInfo: openHelp,
      automationsDue: jobs ? jobs.reduce((n, job) => n + (job.next_occurrences?.length || 0), 0) : null,
    }),
    await startHere(),
    renderBoardHead(toggleEditBoard),
    renderHiddenWidgets(prefs, handlers.onToggleWidget),
    renderToday(today, prefs, handlers),
    el("p", { class: "board-foot" }, el("span", { class: "foot-dot", "aria-hidden": "true" }),
      `generated ${when(today.generated_at)} · scope ${document.getElementById("scope-label").textContent.replace(/^scope: /, "")}`));
}

// First-run checklist (D4). The decision is taken once per browser and workspace: a scope
// that already had goals or captures when Today first opened never shows it ("off"); an
// empty one shows it ("active") until all three steps are done or it is dismissed.
async function startHere() {
  const key = startHereKey(workspaceId);
  let state = localStorage.getItem(key);
  if (state === "off") return null;
  let goals, captures;
  try { [goals, captures] = await Promise.all([api.goals(), api.captures()]); } catch { return null; }
  const remember = (value) => { try { localStorage.setItem(key, value); } catch { /* convenience only */ } };
  if (state !== "active") {
    if (goals.length || captures.length) { remember("off"); return null; }
    remember("active");
  }
  const converted = captures.some((c) => c.status === "converted" && c.converted_type === "task");
  if (goals.length && captures.length && converted) { remember("off"); return null; }
  return renderStartHere({ goals, captures }, {
    onNewGoal: () => createIntent("goal"),
    onCapture: openQuickCapture,
    onOpenInbox: (captureId) => { location.hash = captureId ? `#/capture/${captureId}` : "#/capture"; },
    onDismiss: () => { remember("off"); document.getElementById("start-here")?.remove(); },
  });
}

// Header pencil and the hero's layout icon: reveal the move/hide controls while pressed.
function toggleEditBoard() {
  const editing = document.body.dataset.editing !== "true";
  document.body.dataset.editing = String(editing);
  for (const id of ["edit-board", "hero-layout"]) {
    const button = document.getElementById(id);
    if (!button) continue;
    button.setAttribute("aria-pressed", String(editing));
    if (id === "hero-layout") button.dataset.active = String(editing);
  }
}

function setupEditBoard() {
  document.getElementById("edit-board").addEventListener("click", toggleEditBoard);
}

// Narrow screens: the rail becomes a top bar whose list unfolds from a menu button.
function setupNavToggle() {
  const nav = document.querySelector(".nav");
  const button = document.getElementById("nav-toggle");
  button.addEventListener("click", () => {
    const open = nav.dataset.open !== "true";
    nav.dataset.open = String(open);
    button.setAttribute("aria-expanded", String(open));
    if (open) nav.querySelector(".nav-item[aria-current='page'], .nav-item")?.focus();
  });
}

// replaceChildren() stringifies non-Node arguments (a null child becomes the
// text "null"); append() drops null/undefined/false instead.
function render(container, ...children) {
  container.replaceChildren();
  return append(container, children);
}

// --- Goals and projects ------------------------------------------------------------

async function renderGoalsPage(taskId = null) {
  const [goals, projects] = await Promise.all([api.goals(), api.projects()]);
  const projectsByGoal = {};
  for (const project of projects) (projectsByGoal[project.goal_id] ||= []).push(project);
  const taskLists = await Promise.all(projects.map((p) => api.projectTasks(p.id)));
  const tasksByProject = Object.fromEntries(projects.map((p, i) => [p.id, taskLists[i]]));

  const creator = el("div", { class: "stack", id: "creator" });
  const me = currentUser() || "";
  // Two-tier forms (D3): tier 1 is the essential pair; owner, next action, priority and the
  // rest sit under "More options" with defaults, so title + one line is enough to create.
  const handlers = {
    onOpenTask: openTask,
    onNewProject: (goal) => showCreator(creator, `New project under “${goal.title}”`, form([
      field("Title", "title", { required: true }),
      moreOptions([
        field("Owner", "owner", { required: true, value: me }),
        field("Success criteria", "success_criteria", { required: true, value: "All tasks in this project accepted" }),
      ]),
    ], "Create project", async (data) => { await api.createProject({ ...data, goal_id: goal.id }); await route(); })),
    onNewTask: (project) => showCreator(creator, `New task in “${project.title}”`, form([
      field("Title", "title", { required: true }),
      field("What does done look like?", "done", { required: true, placeholder: "One sentence a reviewer can check" }),
      moreOptions([
        el("div", { class: "form-row is-inline" },
          field("Owner", "owner", { required: true, value: me }),
          field("Next action", "next_action", { value: "", placeholder: DEFAULT_NEXT_ACTION })),
        segmented("Priority", "priority", PRIORITY_OPTIONS, "2"),
        field("More acceptance criteria, one per line", "criteria", { rows: "2" }, "textarea"),
        field("Deadline", "deadline", { type: "date" }),
      ]),
    ], "Create task", async (data) => {
      await api.createTask({
        project_id: project.id, title: data.title, owner: data.owner,
        next_action: data.next_action.trim() || DEFAULT_NEXT_ACTION,
        priority: Number.parseInt(data.priority, 10),
        criteria: [data.done, ...(data.criteria || "").split("\n")].map((s) => s.trim()).filter(Boolean),
        deadline: data.deadline || null,
      });
      await route();
    })),
    onDecideGoal: (goal) => showCreator(creator, `Record outcome for “${goal.title}”`, form([
      el("div", { class: "form-row is-inline" },
        field("Achieved?", "achieved", { options: [{ value: "true", label: "Achieved" }, { value: "false", label: "Not achieved" }] }, "select")),
      field("Measured evidence", "evidence", { required: true, rows: "3" }, "textarea"),
      el("p", { class: "meta" }, `Decided by ${currentUser()} (your signed-in account; owner role required).`),
    ], "Record goal outcome", async (data) => {
      await api.recordGoalOutcome(goal.id, { achieved: data.achieved === "true", evidence: data.evidence });
      await route();
    })),
  };

  handlers.onNewGoal = () => showCreator(creator, "New goal", form([
    field("Title", "title", { required: true }),
    field("How will you measure success?", "success_measure", { required: true, placeholder: "A number, a date or a yes/no you can check" }),
    moreOptions([field("Owner", "owner", { required: true, value: me })]),
  ], "Create goal", async (data) => { await api.createGoal(data); await route(); }));

  render(view,
    pageHeader("goals", "Goals and Projects",
      "Delivery progress counts accepted tasks. It never proves a goal's metric — that needs a recorded outcome.",
      { tools: el("button", { id: "new-goal", class: "btn is-primary", type: "button", dataset: { write: "true" }, onclick: handlers.onNewGoal }, "New goal") }),
    creator,
    renderGoals(goals, projectsByGoal, tasksByProject, handlers));
  // "#/goals/<task id>" (the hero's Next strip, palette recents) opens that task once;
  // the hash then drops the id so later re-renders do not reopen the drawer.
  if (taskId) {
    history.replaceState(null, "", "#/goals");
    await openTask(taskId);
  }
}

// --- Automations and agents -----------------------------------------------------------

async function renderAutomationsPage(noticeNode = null) {
  const [jobs, workers] = await Promise.all([api.jobs(), api.workers()]);
  const notice = el("div", { class: "stack", id: "automation-notice" }, noticeNode);
  render(view,
    pageHeader("automations", "Automations",
      "Database-backed occurrences, claimed with a lease and fencing token. “Run now” queues a manual occurrence for the next worker tick (digitalmaid worker --loop or --once); a finished run is an unchecked output, not a completed task."),
    workerStatus(workers),
    notice,
    renderAutomations(jobs, {
      onOpenTask: openTask,
      onRunNow: async (job, key) => {
        try {
          const occurrence = await api.runJobNow(job.id, key);
          await renderAutomationsPage(alertBox("ok", `Manual occurrence ${occurrence.id.slice(0, 8)}… for “${job.purpose}” is due. It runs on the next worker tick.`));
        } catch (error) {
          render(notice, alertBox("error", `Run now refused: ${error.message}`, error.reasons));
        }
      },
    }));
}

async function renderAgentsPage() {
  const agents = await api.agents();
  render(view,
    pageHeader("agents", "Agents",
      "Roster from definitions/agents. A role is not a running worker: only executions with real records count as activity."),
    renderAgents(agents));
}

function showCreator(container, title, formNode) {
  container.replaceChildren(el("section", { class: "panel", "aria-label": title },
    el("div", { class: "panel-header" }, el("h3", {}, title),
      el("button", { class: "btn is-quiet is-small", type: "button", onclick: () => container.replaceChildren() }, "Cancel")),
    formNode));
  applyReadOnly(container);
  container.querySelector("input, select, textarea")?.focus();
}

// Generic drawer for non-task content (calendar events); same focus handling.
function openDrawer(titleText, bodyNode, { focus = null, kicker = "Details" } = {}) {
  lastFocus = document.activeElement;
  drawer.dataset.open = "true";
  backdrop.hidden = false;
  render(drawer,
    el("div", { class: "drawer-header" },
      el("div", {}, el("span", { class: "drawer-kicker" }, kicker), el("h2", { id: "drawer-title", tabindex: "-1" }, titleText)),
      el("button", { class: "btn is-quiet", type: "button", "aria-label": "Close", onclick: closeDrawer }, "Close")),
    el("div", { class: "drawer-body" }, bodyNode));
  applyReadOnly(drawer);
  (focus && drawer.querySelector(focus) || drawer.querySelector("#drawer-title"))?.focus();
}

// --- Task drawer ---------------------------------------------------------------------

async function openTask(taskId, { section = null } = {}) {
  lastFocus = document.activeElement;
  drawer.dataset.open = "true";
  backdrop.hidden = false;
  drawer.replaceChildren(el("p", { class: "empty" }, "Loading task…"));
  await refreshDrawer(taskId);
  // Review Inbox opens the drawer at the relevant form (e.g. the check form).
  const target = section ? drawer.querySelector(`details.action[data-section="${section}"]`) : null;
  if (target) {
    target.open = true;
    target.querySelector("input, select, textarea")?.focus();
    target.scrollIntoView({ block: "start" });
  } else {
    drawer.querySelector("#drawer-title")?.focus();
  }
}

function closeDrawer() {
  drawer.dataset.open = "false";
  backdrop.hidden = true;
  drawer.replaceChildren();
  lastFocus?.focus?.();
}

async function refreshDrawer(taskId, notice) {
  try {
    const detail = await api.taskDetail(taskId);
    recordRecent({ type: "task", id: detail.task.id, title: detail.task.title });
    render(drawer, ...renderTaskDetail(detail, notice));
    applyReadOnly(drawer);
  } catch (error) {
    render(drawer, el("div", { class: "drawer-header" }, el("h2", { id: "drawer-title", tabindex: "-1" }, "Task"),
      el("button", { class: "btn is-quiet", type: "button", onclick: closeDrawer }, "Close")),
      el("div", { class: "drawer-body" }, alertBox("error", `Could not load task: ${error.message}`, error.reasons)));
  }
}

function renderTaskDetail(detail, notice) {
  const { task } = detail;
  const latestVersion = detail.output_versions.at(-1) || null;
  const latestCheck = detail.checks.at(-1) || null;
  const openCorrection = detail.corrections.find((c) => !c.revised_output_version_id) || null;
  const act = (label, promise) => async (data) => {
    await promise(data);
    await refreshDrawer(task.id, `${label} recorded.`);
    // The rest of the page reflects the same records; refresh it quietly.
    route();
  };

  const resourceForm = form([
    el("div", { class: "form-row is-inline" },
      field("Category (5M)", "category", { options: FIVE_M }, "select"),
      field("Status", "status", { options: RESOURCE_STATUSES }, "select")),
    field("Description", "description", { required: true }),
    el("div", { class: "form-row is-inline" },
      field("N/A reason (if not applicable)", "na_reason", {}),
      field("Amount, minor units (Money)", "amount_minor", { type: "number", step: "1" }),
      field("Currency (Money, e.g. EUR)", "currency", { maxlength: "3" })),
  ], "Assess resource", act("Assessment", (data) => api.assessResource(task.id, {
    category: data.category, status: data.status, description: data.description,
    na_reason: data.na_reason || null,
    amount_minor: data.amount_minor === "" ? null : Number.parseInt(data.amount_minor, 10),
    currency: data.currency ? data.currency.toUpperCase() : null,
  })));

  const startButton = el("div", { class: "stack" },
    reasonsList(detail.gate_reasons),
    form([], "Start task (Plan → Do)", act("Start", () => api.startTask(task.id))));

  const executionForm = form([
    el("div", { class: "form-row is-inline" },
      field("Agent id (manual record)", "agent_id", { required: true, value: "manual" }),
      field("Status", "status", { options: EXECUTION_STATUSES }, "select")),
    field("Log", "log", { rows: "2" }, "textarea"),
  ], "Record execution", act("Execution", (data) => api.recordExecution(task.id, { agent_id: data.agent_id, status: data.status, log: data.log || "" })));

  const outputForm = detail.executions.length
    ? form([
      field("Execution", "execution_id", { options: detail.executions.map((e) => ({ value: e.id, label: `${e.status} · ${e.agent_id} · ${when(e.created_at)}` })).reverse() }, "select"),
      field("Content (Markdown)", "content", { required: true }, "textarea"),
    ], `Submit output as version ${(latestVersion?.version || 0) + 1}`, act("Output", (data) => api.submitOutput(task.id, data)))
    : alertBox("info", "Record an execution first; every output version belongs to one execution.");

  const checkForm = latestVersion
    ? form([
      field("Reviewer", "reviewer", { required: true }),
      ...JSON.parse(latestVersion.criteria_snapshot).map((criterion, i) => el("fieldset", {},
        el("legend", {}, criterion),
        el("div", { class: "radio-group" },
          el("label", {}, el("input", { type: "radio", name: `passed_${i}`, value: "true", required: true }), "Pass"),
          el("label", {}, el("input", { type: "radio", name: `passed_${i}`, value: "false" }), "Fail")),
        field("Evidence", `evidence_${i}`, { required: true }))),
    ], `Record check on version ${latestVersion.version}`, act("Check", (data) => api.recordCheck(latestVersion.id, {
      reviewer: data.reviewer,
      results: JSON.parse(latestVersion.criteria_snapshot).map((criterion, i) => ({
        criterion, passed: data[`passed_${i}`] === "true", evidence: data[`evidence_${i}`] || "" })),
    })))
    : alertBox("info", "No output version to check yet.");

  const correctionForm = latestCheck && !latestCheck.passed && task.status === "Correction"
    ? form([
      el("div", { class: "form-row is-inline" }, field("Owner", "owner", { required: true })),
      field("Corrective action", "action", { required: true, rows: "2" }, "textarea"),
    ], "Open correction (→ Do)", act("Correction", (data) => api.openCorrection(latestCheck.id, data)))
    : alertBox("info", task.status === "Correction" ? "Latest check did not fail." : "Corrections open only from a failed check while the task is in Correction.");

  const acceptForm = latestVersion
    ? form([el("p", { class: "meta" }, `Accepted by ${currentUser()} (your signed-in account; owner role required).`)],
      `Accept version ${latestVersion.version} (→ Done)`, act("Acceptance", () => api.acceptOutput(latestVersion.id)))
    : alertBox("info", "Nothing to accept yet.");

  const learningForm = form([field("Learning", "text", { required: true, rows: "2" }, "textarea")],
    "Add learning", act("Learning", (data) => api.addLearning(task.id, data)));

  // Comments live beside a version and never move the PDCC status.
  const commentForm = latestVersion
    ? form([
      field("Comment (Markdown)", "comment_body", { required: true, rows: "2" }, "textarea"),
    ], `Comment on version ${latestVersion.version}`, act("Comment", (data) => api.addComment(latestVersion.id, { author: currentUser(), body_md: data.comment_body })))
    : alertBox("info", "Comments attach to an output version; none exists yet.");
  if (commentForm.tagName === "FORM") commentForm.id = "comment-form";

  const header = el("div", { class: "drawer-header" },
    el("div", {},
      el("span", { class: "drawer-kicker" }, "Task"),
      el("h2", { id: "drawer-title", tabindex: "-1" }, task.title),
      el("div", { class: "meta" }, el("span", { class: "status-word" }, task.status), phasePill(task.status, `PDCC: ${task.status}`), el("span", {}, `owner ${task.owner} · priority ${PRIORITY_OPTIONS.find((p) => p.value === String(task.priority))?.label.toLowerCase() || task.priority}`)),
      pdccChain(task.status)),
    el("button", { class: "btn is-quiet", type: "button", "aria-label": "Close task details", onclick: closeDrawer }, "Close"));
  const body = el("div", { class: "drawer-body" },
    notice ? alertBox("ok", notice) : null,
    drawerSection("Plan", el("dl", { class: "kv" },
      el("dt", {}, "Next action"), el("dd", {}, task.next_action),
      el("dt", {}, "Deadline"), el("dd", {}, task.deadline || "—"),
      el("dt", {}, "Criteria"), el("dd", {}, el("ul", { class: "criteria" }, task.criteria.map((c) => el("li", {}, c)))),
      el("dt", {}, "Spending"), el("dd", {}, detail.can_spend ? "explicitly authorized" : "not authorized (allocation is not permission)"),
      task.procedure_id ? [el("dt", {}, "Procedure"), el("dd", {}, el("a", { href: `#/procedures/${task.procedure_id}` }, `step ${task.step_index + 1} of procedure v${task.procedure_version}`))] : null)),
    detail.dependencies.length ? drawerSection("Depends on", el("ul", { class: "list" }, detail.dependencies.map((d) => el("li", { class: "list-item is-clickable", tabindex: "0", role: "button",
      onclick: () => openTask(d.depends_on_task_id), onkeydown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openTask(d.depends_on_task_id); } } },
      el("div", { class: "list-item-title" }, el("span", {}, d.title), phasePill(d.status)),
      d.status === "Done" ? null : el("div", { class: "meta" }, "waiting: released only by human acceptance"))))) : null,
    drawerSection("5M assessments", detail.resources.length
      ? el("ul", { class: "list" }, FIVE_M.map((cat) => {
        const r = detail.resources.find((x) => x.category === cat);
        return el("li", { class: "list-item" }, el("div", { class: "list-item-title" }, el("strong", {}, cat), r ? pill(r.status) : pill("missing", "not assessed")),
          r ? el("div", { class: "meta" }, r.description, r.na_reason ? ` · N/A: ${r.na_reason}` : "", r.amount_minor !== null && r.amount_minor !== undefined ? ` · ${r.amount_minor} ${r.currency} (minor units)` : "") : null);
      }))
      : empty("Not assessed yet."),
    el("details", { class: "action", dataset: { section: "resource" } }, el("summary", {}, "Assess a resource"), resourceForm)),
    task.status === "Plan" ? drawerSection("Start", startButton) : null,
    drawerSection("Executions", detail.executions.length
      ? el("ul", { class: "list" }, detail.executions.map((e) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" }, el("span", {}, e.agent_id), pill(e.status)),
        el("div", { class: "meta" }, when(e.created_at), ` · ${runnerLabel(e)}`, executionEvidence(e), e.log ? ` · ${e.log}` : ""))))
      : empty("No executions recorded. A finished process is not a checked output."),
    task.status === "Do" ? el("details", { class: "action", dataset: { section: "execution" } }, el("summary", {}, "Record an execution"), executionForm) : null),
    drawerSection("Output versions", detail.output_versions.length
      ? el("ul", { class: "list" }, detail.output_versions.map((v) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" }, el("strong", {}, `Version ${v.version}`), el("span", { class: "meta" }, when(v.created_at))),
        el("pre", { class: "version-content" }, v.content ?? "(blob missing)"),
        techDetails(`sha256 ${v.sha256}`, el("br"), `stored at ${v.blob_path}`))))
      : empty("No output submitted yet."),
    task.status === "Do" ? el("details", { class: "action", dataset: { section: "output" } }, el("summary", {}, "Submit output"), outputForm) : null),
    drawerSection("Checks", detail.checks.length
      ? el("ul", { class: "list" }, detail.checks.map((c) => el("li", { class: "list-item" },
        el("div", { class: "list-item-title" }, el("span", {}, `by ${c.reviewer}`), pill(c.passed ? "pass" : "fail")),
        el("ul", { class: "criteria meta" }, c.results.map((r) => el("li", {}, `${r.passed ? "✓" : "✗"} ${r.criterion} — ${r.evidence}`))))))
      : empty("Unchecked."),
    task.status === "Do" ? el("details", { class: "action", dataset: { section: "check" } }, el("summary", {}, "Record a check"), checkForm) : null),
    drawerSection("Review comments", detail.comments.length
      ? el("ul", { class: "list" }, detail.comments.map((c) => el("li", { class: "list-item" }, c.body_md, el("div", { class: "meta" }, `${c.author} · ${when(c.created_at)} · on version ${detail.output_versions.find((v) => v.id === c.output_version_id)?.version ?? "?"}`))))
      : empty("No comments. Comments never change the PDCC status."),
    el("details", { class: "action", dataset: { section: "comment" } }, el("summary", {}, "Add a comment"), commentForm)),
    drawerSection("Corrections", detail.corrections.length
      ? el("ul", { class: "list" }, detail.corrections.map((c) => el("li", { class: "list-item" },
        el("div", {}, c.action),
        el("div", { class: "meta" }, `owner ${c.owner} · `, c.revised_output_version_id ? "revised in a later version" : "awaiting revised output"))))
      : empty("No corrections."),
    task.status === "Correction" ? el("details", { class: "action", open: true, dataset: { section: "correction" } }, el("summary", {}, "Open a correction"), correctionForm) : null),
    drawerSection("Acceptance", detail.acceptance
      ? el("div", {}, `Accepted by ${detail.acceptance.accepted_by} at ${when(detail.acceptance.created_at)}`)
      : el("div", { class: "stack" }, empty("Not accepted by a human yet."),
        task.status === "Check" ? el("details", { class: "action", open: true, dataset: { section: "accept" } }, el("summary", {}, "Accept the checked version"), acceptForm) : null)),
    drawerSection("Learning", detail.learnings.length
      ? el("ul", { class: "list" }, detail.learnings.map((l) => el("li", { class: "list-item" }, l.text, el("div", { class: "meta" }, when(l.created_at)))))
      : empty("Nothing recorded."),
    el("details", { class: "action", dataset: { section: "learning" } }, el("summary", {}, "Add a learning"), learningForm)),
    detail.notes.length ? drawerSection("Linked notes", el("ul", { class: "list" }, detail.notes.map((n) => el("li", { class: "list-item" },
      el("div", { class: "list-item-title" }, el("a", { href: `#/knowledge/${n.id}`, onclick: closeDrawer }, n.title), pill(n.kind)))))) : null,
    openCorrection ? alertBox("info", "An open correction will be linked to the next output version.") : null);
  return [header, body];
}

function drawerSection(title, ...children) {
  return el("section", { class: "drawer-section" }, el("h4", {}, title), ...children);
}

// --- Global search (combobox + listbox, keyboard first) -------------------------------

function setupGlobalSearch() {
  const input = document.getElementById("global-search");
  const list = document.getElementById("search-results");
  const status = document.getElementById("search-status");
  let items = [];
  let selected = -1;
  let timer = null;

  const close = () => {
    list.hidden = true;
    list.replaceChildren();
    input.setAttribute("aria-expanded", "false");
    input.removeAttribute("aria-activedescendant");
    items = [];
    selected = -1;
  };
  const open = (hit) => {
    close();
    input.value = "";
    if (hit.type === "note") location.hash = `#/knowledge/${hit.id}`;
    else if (hit.type === "task") openTask(hit.id);
    else if (hit.type === "capture") openCapture(hit.id, pageContext);
    else location.hash = "#/goals";
  };
  const select = (index) => {
    selected = index;
    for (const [i, option] of [...list.children].entries()) {
      option.setAttribute("aria-selected", String(i === selected));
      if (i === selected) input.setAttribute("aria-activedescendant", option.id);
    }
    if (selected < 0) input.removeAttribute("aria-activedescendant");
  };
  const show = (result, query) => {
    items = [
      ...result.notes.map((n) => ({ type: "note", id: n.id, label: n.title, meta: `${n.kind}${n.snippet ? ` · ${n.snippet}` : ""}` })),
      ...result.tasks.map((t) => ({ type: "task", id: t.id, label: t.title, meta: `task · ${t.status}` })),
      ...result.goals.map((g) => ({ type: "goal", id: g.id, label: g.title, meta: `goal · ${g.outcome_status}` })),
      ...(result.captures || []).map((c) => ({ type: "capture", id: c.id, label: c.title || c.url || (c.body_text || "").split("\n")[0].slice(0, 80), meta: `capture · ${c.kind} · ${c.status}${c.snippet ? ` · ${c.snippet}` : ""}` })),
    ];
    list.replaceChildren(...(items.length
      ? items.map((hit, i) => el("li", { id: `search-option-${i}`, role: "option", "aria-selected": "false", dataset: { type: hit.type }, onmousedown: (e) => e.preventDefault(), onclick: () => open(hit) },
        el("span", {}, hit.label), el("small", { class: "meta" }, hit.meta)))
      : [el("li", { class: "listbox-empty", role: "presentation" }, `No notes, tasks, goals or captures match “${query}”.`)]));
    list.hidden = false;
    input.setAttribute("aria-expanded", "true");
    selected = -1;
    status.textContent = items.length ? `${items.length} result${items.length === 1 ? "" : "s"}. Use arrow keys, Enter opens, Escape closes.` : "No results.";
  };
  input.addEventListener("input", () => {
    clearTimeout(timer);
    const query = input.value.trim();
    if (!query) { close(); status.textContent = ""; return; }
    timer = setTimeout(async () => {
      try { show(await api.search(query), query); } catch (error) { showGlobal(`Search failed: ${error.message}`); }
    }, 200);
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { close(); return; }
    if (list.hidden || !items.length) return;
    if (event.key === "ArrowDown") { event.preventDefault(); select((selected + 1) % items.length); }
    else if (event.key === "ArrowUp") { event.preventDefault(); select((selected - 1 + items.length) % items.length); }
    else if (event.key === "Enter" && selected >= 0) { event.preventDefault(); open(items[selected]); }
  });
  input.addEventListener("blur", () => setTimeout(() => { if (!list.contains(document.activeElement)) close(); }, 150));
}

// --- boot ----------------------------------------------------------------------------

setupGlobalSearch();
setupEditBoard();
setupNavToggle();
startSky();
setupCommands({
  navigate, create: createIntent, runJob: runJobFromPalette, openTask,
  showGlobal, onCaptured: () => { if (currentRoute() === "today" || currentRoute() === "capture") route(); else refreshCounts(); },
});
window.addEventListener("dm:unauthenticated", () => { if (session) { setSessionState(null); renderLogin("Your session ended. Sign in again."); } });
document.getElementById("logout-button").addEventListener("click", async () => {
  try { await api.logout(); } catch { /* the cookie is gone either way */ }
  setSessionState(null);
  closeDrawer();
  renderLogin("Signed out.");
});
backdrop.addEventListener("click", closeDrawer);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && drawer.dataset.open === "true") closeDrawer();
});
window.addEventListener("hashchange", route);

// Boot: a browser that never signed in here renders the login form without a single
// request; one that did asks who it is, then loads the workspace identity for the rail foot.
if (!hasSignedInHint()) {
  route();
} else {
  api.me().then(async (me) => {
    setSessionState(me);
    await loadWorkspace();
  }).catch(() => { document.getElementById("scope-label").textContent = "signed out"; }).finally(route);
}
