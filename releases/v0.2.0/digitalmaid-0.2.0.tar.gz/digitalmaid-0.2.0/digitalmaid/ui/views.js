// DOM builders and render functions. All record text goes through textContent,
// never innerHTML, so output content and titles cannot inject markup.

// The signed-in session; a viewer role turns every form read-only (see form()).
let currentSession = null;
export function setSession(session) { currentSession = session; }
export function isReadOnly() { return currentSession?.role === "viewer"; }
export function currentUser() { return currentSession?.user?.username || null; }
export const READ_ONLY_REASON = "Read-only: the viewer role cannot make changes.";

// Disables write controls for viewers, stating why (title + note), never hiding them.
export function applyReadOnly(container) {
  if (!isReadOnly() || !container) return;
  for (const button of container.querySelectorAll("button[type=submit], [data-write]")) {
    button.disabled = true;
    button.title = READ_ONLY_REASON;
    button.setAttribute("aria-disabled", "true");
  }
  for (const f of container.querySelectorAll("form.form:not([data-readonly-noted])")) {
    f.dataset.readonlyNoted = "true";
    f.append(el("p", { class: "readonly-note meta" }, READ_ONLY_REASON));
  }
}

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (key === "class") node.className = value;
    else if (key === "dataset") Object.assign(node.dataset, value);
    else if (key.startsWith("on") && typeof value === "function") node.addEventListener(key.slice(2), value);
    else if (key === "text") node.textContent = value;
    else node.setAttribute(key, value === true ? "" : value);
  }
  append(node, children);
  return node;
}

export function append(node, children) {
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

export function pill(status, label) {
  return el("span", { class: "pill", dataset: { status } }, label ?? status);
}

// One phase vocabulary everywhere (DESIGN.md D2): the five words, their plain meanings
// and the hero's colour tokens (mapped in app.css by data-status). Every phase pill
// carries the meaning as title + aria-description; non-phase statuses keep pill().
export const PHASES = ["Plan", "Do", "Check", "Correction", "Done"];
export const PHASE_MEANINGS = {
  Plan: "Not started — waiting on people, method, tools, materials or budget",
  Do: "Someone is working on it",
  Check: "Finished; waiting for a human to check it",
  Correction: "Failed its check; being fixed",
  Done: "Checked and accepted by a human",
};

export function phasePill(phase, label) {
  if (!PHASE_MEANINGS[phase]) return pill(phase, label);
  const meaning = PHASE_MEANINGS[phase];
  return el("span", { class: "pill", dataset: { status: phase, phase }, title: meaning, "aria-description": meaning }, label ?? phase);
}

// Plain-language page lead (D1): one sentence, then the original explanation folded into a
// closed "How this works" whose open state is remembered per page.
export const LEADS = {
  goals: "Goals are the results you want; projects deliver them; tasks are the work.",
  knowledge: "Notes, research, decisions and your daily journal — nothing is ever deleted.",
  procedures: "Step-by-step procedures you can run; each run becomes a chain of tasks.",
  review: "Work that needs a human decision from you.",
  outputs: "Every finished piece of work, with its check and acceptance status.",
  automations: "Scheduled work that runs on its own and lands in your Review Inbox.",
  agents: "The AI roles that do work here, and whether each one is ready.",
  calendar: "Your events plus deadlines, scheduled runs and decision reviews.",
  capture: "Drop anything here now; shape it into a task, note or goal later.",
  settings: "People, roles, tokens, backups and what this workspace is connected to.",
};

export function howDetails(route, ...children) {
  const key = `dm:how:${route}`;
  const details = el("details", { class: "how", open: localStorage.getItem(key) === "1" || null },
    el("summary", {}, icon("info"), el("span", {}, "How this works")),
    el("div", { class: "how-body" }, children));
  const remember = (open) => {
    try { localStorage.setItem(key, open ? "1" : "0"); } catch { /* remembering is a convenience */ }
  };
  // `toggle` is dispatched asynchronously; write on the click too so a navigation right after
  // the click (or a reload) never loses the choice.
  details.querySelector("summary").addEventListener("click", () => remember(!details.open));
  details.addEventListener("toggle", () => remember(details.open));
  return details;
}

// Page header: title, the D1 lead, the folded explanation, optional meta after the lead,
// and the page's tools on the right.
export function pageHeader(route, title, how, { meta = null, tools = null } = {}) {
  return el("header", { class: "main-header" },
    el("div", {}, el("h1", {}, title), el("p", {}, LEADS[route]), meta, howDetails(route, how)),
    tools);
}

// Hashes, fencing tokens, schedule versions, misfire policies (D6): present on the record,
// never on the first line.
export function techDetails(...children) {
  return el("details", { class: "tech" }, el("summary", {}, "Technical details"), el("div", { class: "tech-body mono" }, children));
}

// Thin-stroke 16px icon from the symbol sheet in index.html.
export function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "icon");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#i-${name}`);
  svg.append(use);
  return svg;
}

// Small uppercase tracked caption (the signature label style).
export function label(text, attrs = {}) {
  return el("span", { ...attrs, class: `label${attrs.class ? ` ${attrs.class}` : ""}` }, text);
}

// Big number + caption: the numeral face, accent when the number asks for action.
export function bigNumber(value, caption, { action = false } = {}) {
  return el("div", { class: "big-number" },
    el("div", { class: `num${action ? " is-action" : ""}`, "aria-hidden": "true" }, String(value)),
    el("span", { class: "visually-hidden" }, `${value} — ${caption}`),
    el("span", { class: "caption", "aria-hidden": "true" }, caption));
}

// Dot row: one dot per day, filled when done, today ringed in accent.
export function dotRow(days) {
  return el("ul", { class: "dot-row", "aria-label": `Last ${days.length} days` }, days.map((d) => el("li", {
    class: `dot${d.today ? " is-today" : ""}`, dataset: { on: String(Boolean(d.on)), day: d.key },
    title: `${d.key}: ${d.on ? "written" : "not written"}`,
  }, el("span", { class: "visually-hidden" }, `${d.key}: ${d.on ? "written" : "not written"}`))));
}

const PDCC = ["Plan", "Do", "Check", "Correction"];

// Plan → Do → Check → Correction as a chain of nodes; the current one ringed.
// Done means every node has been passed; Correction loops back to Do, so both stay lit.
export function pdccChain(status) {
  const index = PDCC.indexOf(status);
  return el("ol", { class: "pdcc-chain", "aria-label": `PDCC status: ${status}` }, PDCC.map((step, i) => {
    const done = status === "Done" || i < index || (status === "Correction" && step !== "Correction");
    return el("li", { class: "pdcc-node", dataset: { done: String(done) }, "aria-current": step === status ? "step" : null },
      el("span", { class: "node", "aria-hidden": "true" }), el("span", {}, step));
  }));
}

// In-page confirmation (replaces window.confirm). Resolves true only on an explicit
// confirm; Esc, Cancel and the backdrop resolve false. Focus is trapped by the native
// modal dialog and returns to the opener when it closes.
export function confirmDialog({ title = "Confirm", message = "", confirmLabel = "Confirm", cancelLabel = "Cancel" } = {}) {
  const dialog = document.getElementById("confirm-dialog");
  const opener = document.activeElement;
  dialog.querySelector("#confirm-title").textContent = title;
  dialog.querySelector("#confirm-message").textContent = message;
  const ok = dialog.querySelector("#confirm-ok");
  const cancel = dialog.querySelector("#confirm-cancel");
  ok.textContent = confirmLabel;
  cancel.textContent = cancelLabel;
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      ok.removeEventListener("click", onOk);
      cancel.removeEventListener("click", onCancel);
      dialog.removeEventListener("cancel", onNativeCancel);
      dialog.removeEventListener("keydown", onKey);
      dialog.removeEventListener("click", onBackdrop);
      if (dialog.open) dialog.close();
      opener?.focus?.();
      resolve(value);
    };
    const onOk = () => finish(true);
    const onCancel = () => finish(false);
    const onNativeCancel = (e) => { e.preventDefault(); finish(false); };
    const onKey = (e) => {
      if (e.key === "Enter" && e.target !== cancel) { e.preventDefault(); finish(true); }
    };
    const onBackdrop = (e) => { if (e.target === dialog) finish(false); };
    ok.addEventListener("click", onOk);
    cancel.addEventListener("click", onCancel);
    dialog.addEventListener("cancel", onNativeCancel);
    dialog.addEventListener("keydown", onKey);
    dialog.addEventListener("click", onBackdrop);
    dialog.showModal();
    ok.focus();
  });
}

export function when(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
}

export function empty(text) {
  return el("p", { class: "empty" }, text);
}

// Ghost pill (DESIGN.md B2): hairline border, 10px uppercase tracked. A link when
// given an href, otherwise a button.
export function pillButton(text, { href = null, onclick = null, class: extra = "", ...attrs } = {}) {
  const cls = `pill-btn${extra ? ` ${extra}` : ""}`;
  if (href) return el("a", { ...attrs, class: cls, href, onclick }, text);
  return el("button", { ...attrs, class: cls, type: "button", onclick }, text);
}

// Empty state that teaches (C6): a thin icon, one sentence on what lives here, and the
// area's own create action as a ghost pill. Never an illustration.
export function emptyState(iconName, sentence, actionLabel = null, action = null, attrs = {}) {
  // A link never writes; a button runs the area's create action, so viewers see it disabled.
  const target = typeof action === "string" ? { href: action } : action ? { onclick: action, dataset: { write: "true", ...(attrs.dataset || {}) } } : null;
  return el("div", { class: "empty-state" }, icon(iconName), el("p", {}, sentence),
    actionLabel && target ? pillButton(actionLabel, target) : null);
}

export function reasonsList(reasons) {
  if (!reasons?.length) return null;
  return el("ul", { class: "reasons" }, reasons.map((r) => el("li", {}, r)));
}

// Today's quiet gate line (Observatory): the 5M reasons collapse into "k of 5 readiness checks
// not assessed · money needs a waiver · waiting on: …"; the full list stays in the task drawer.
// The complete reasons ride along as the title.
export function gateSummary(reasons) {
  if (!reasons?.length) return null;
  const assess = /^(\w+) not assessed$/, waiver = /^(\w+) missing without waiver$/;
  const notAssessed = reasons.filter((r) => assess.test(r)).length;
  const waivers = reasons.filter((r) => waiver.test(r)).map((r) => r.match(waiver)[1].toLowerCase());
  const other = reasons.filter((r) => !assess.test(r) && !waiver.test(r));
  const parts = [];
  if (notAssessed) parts.push([el("em", {}, `${notAssessed} of 5`), ` readiness check${notAssessed === 1 ? "" : "s"} not assessed`]);
  for (const w of waivers) parts.push(`${w} needs a waiver`);
  parts.push(...other);
  const line = el("span", {});
  parts.forEach((part, i) => { if (i) line.append(" · "); append(line, [part]); });
  return el("div", { class: "gate-line", title: reasons.join("\n") }, line);
}

// The Correction counterpart: one rose-dot line naming the failed criteria.
export function failedLine(criteria) {
  if (!criteria?.length) return null;
  return el("div", { class: "gate-line is-error", title: criteria.join("\n") },
    el("span", {}, el("em", {}, criteria.length === 1 ? "Failed" : `${criteria.length} failed`), ": ", criteria.join(" · ")));
}

export function alertBox(kind, message, reasons) {
  const box = el("div", { class: `alert is-${kind}`, role: kind === "error" ? "alert" : "status" });
  if (message) box.append(el("div", {}, message));
  if (reasons?.length) box.append(el("ul", {}, reasons.map((r) => el("li", {}, r))));
  return box;
}

// CSSOM assignment rather than a style attribute: the CSP forbids inline styles.
function bar(pct) {
  const span = el("span");
  span.style.width = `${pct}%`;
  return span;
}

export function progress(done, total) {
  const pct = total ? Math.round((done / total) * 100) : 0;
  return el("div", { class: "progress", role: "group", "aria-label": `Delivery progress ${done} of ${total} tasks done` },
    el("div", { class: "progress-bar", "aria-hidden": "true" }, bar(pct)),
    el("span", { class: "progress-label" }, `${done}/${total}`));
}

// --- Today -------------------------------------------------------------------

export const WIDGET_TITLES = {
  needs_attention: "Needs attention",
  in_progress: "In progress",
  achieved: "Achieved",
  review_inbox: "Review inbox",
  journal: "Journal",
  capture_inbox: "Inbox",
};

function widgetTitle(id, today) {
  if (id === "review_inbox") return `Review inbox (${today.review_inbox_count ?? 0})`;
  if (id === "capture_inbox") return `Inbox (${today.capture_inbox_count ?? 0})`;
  return WIDGET_TITLES[id] || id;
}

const LIVE_STATES = new Set(["running", "queued"]);

function taskItem(task, onOpen, extra, { live = false } = {}) {
  return el("li", { class: `list-item is-clickable${live ? " is-live" : ""}`, tabindex: "0", role: "button", dataset: { status: task.status, live: String(live) },
    onclick: () => onOpen(task.id),
    onkeydown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onOpen(task.id); } } },
    el("div", { class: "list-item-title" }, el("strong", {}, task.title), phasePill(task.status)),
    el("div", { class: "meta" }, task.project_title ? `${task.project_title} · ` : "", task.owner),
    extra);
}

// First-run checklist (D4): three steps, hollow → filled as the objects appear. Shown only on
// a scope that had neither goals nor captures when this browser first opened Today; a
// Dismiss hides it for good (localStorage, keyed by workspace id).
const START_STEPS = [
  { id: "goal", text: "Write your first goal", action: "New goal" },
  { id: "capture", text: "Capture something on your mind", action: "Quick capture" },
  { id: "task", text: "Turn a capture into a task", action: "Open Capture Inbox" },
];

export function startHereKey(workspaceId) { return `dm:starthere:${workspaceId || "default"}`; }

export function renderStartHere({ goals, captures }, { onNewGoal, onCapture, onOpenInbox, onDismiss }) {
  const firstCapture = captures.find((c) => c.status === "inbox" || c.status === "drafting") || captures[0] || null;
  const done = {
    goal: goals.length > 0,
    capture: captures.length > 0,
    task: captures.some((c) => c.status === "converted" && c.converted_type === "task"),
  };
  const actions = {
    goal: () => onNewGoal(),
    capture: () => onCapture(),
    task: () => onOpenInbox(firstCapture ? firstCapture.id : null),
  };
  return el("section", { id: "start-here", class: "widget start-here", "aria-labelledby": "start-here-title" },
    el("div", { class: "widget-header" },
      el("div", { class: "widget-title" }, icon("today"), el("h2", { id: "start-here-title" }, "Start here")),
      el("span", { class: "widget-meta" }, `${Object.values(done).filter(Boolean).length} of 3`),
      pillButton("Dismiss", { class: "start-dismiss", dataset: { dismiss: "true" }, onclick: onDismiss, "aria-label": "Dismiss the Start here checklist" })),
    el("ol", { class: "start-steps" }, START_STEPS.map((step, index) => el("li", { class: "start-step", dataset: { step: step.id, done: String(done[step.id]) } },
      el("span", { class: "start-node", "aria-hidden": "true" }, String(index + 1)),
      el("span", { class: "start-text" }, step.text, el("span", { class: "visually-hidden" }, done[step.id] ? " — done" : " — not yet")),
      done[step.id] ? null : pillButton(step.action, { onclick: actions[step.id], ...(step.id === "task" ? {} : { dataset: { write: "true" } }) })))));
}

const WIDGET_ICONS = {
  needs_attention: "review", in_progress: "automations", achieved: "goals",
  review_inbox: "review", journal: "knowledge", capture_inbox: "capture",
};

function localKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

// The last `count` local days ending today, marked from a set of journal entry dates.
export function journalDays(writtenDates, count = 14, now = new Date()) {
  const written = new Set(writtenDates || []);
  const todayKey = localKey(now);
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (count - 1 - i));
    const key = localKey(d);
    return { key, on: written.has(key), today: key === todayKey };
  });
}

export function renderToday(today, prefs, { onOpenTask, onMoveWidget, onToggleWidget, onOpenJournal, onNewTask = null, journalDates = null }) {
  const attention = today.needs_attention;
  const decisions = attention.decision_reviews_due || [];
  const newTask = onNewTask || "#/goals";
  const bodies = {
    needs_attention: () => {
      const total = attention.in_correction.length + attention.awaiting_acceptance.length
        + attention.blocked_in_plan.filter((t) => t.reasons.length).length + decisions.length;
      if (!total) return emptyState("review", "Corrections, checked work waiting for acceptance, gate-blocked plans and due decision reviews gather here.", "New task", newTask);
      return el("div", { class: "stack" },
        section("In Correction", attention.in_correction, (t) => taskItem(t, onOpenTask, failedLine(t.failed_criteria))),
        section("Checked, awaiting human acceptance", attention.awaiting_acceptance, (t) => taskItem(t, onOpenTask,
          t.latest_version ? el("div", { class: "meta" }, `version ${t.latest_version.version} passed its check`) : null)),
        section("Blocked in Plan", attention.blocked_in_plan.filter((t) => t.reasons.length), (t) => taskItem(t, onOpenTask, gateSummary(t.reasons))),
        section("Decision reviews due", decisions, (n) => el("li", { class: "list-item", dataset: { status: "required" } },
          el("div", { class: "list-item-title" }, el("a", { href: `#/knowledge/${n.id}` }, n.title), pill("required", n.reason)),
          el("div", { class: "meta" }, `chosen ${n.decision.chosen} · review date ${n.decision.review_date}`))));
    },
    review_inbox: () => {
      const count = today.review_inbox_count ?? 0;
      const number = bigNumber(count, count === 1 ? "item waiting for a human" : "items waiting for a human", { action: count > 0 });
      number.append(
        el("p", { class: "meta" }, count ? "Checks, revisions or decision reviews due." : "Nothing waiting for review."),
        pillButton("Open Review Inbox", { href: "#/review" }));
      return number;
    },
    capture_inbox: () => {
      const count = today.capture_inbox_count ?? 0;
      const number = bigNumber(count, count === 1 ? "capture to draft or convert" : "captures to draft or convert", { action: count > 0 });
      number.append(
        el("p", { class: "meta" }, count ? "Raw material waiting in the Capture Inbox." : "Nothing waiting in the Capture Inbox."),
        pillButton("Open Capture Inbox", { href: "#/capture" }));
      return number;
    },
    journal: () => {
      const j = today.journal_today || {};
      const days = journalDays(journalDates || (j.written && j.entry_date ? [j.entry_date] : []));
      const writtenCount = days.filter((d) => d.on).length;
      return el("div", { class: "stack" },
        dotRow(days),
        el("div", { class: "meta" }, `${writtenCount} of ${days.length} days written · `, j.written ? `today's entry (${j.entry_date}) is written.` : `no entry for ${j.entry_date} yet.`),
        pillButton(j.written ? "Open today's entry" : "Write today's entry", { onclick: () => onOpenJournal(j), dataset: { write: "true" } }));
    },
    in_progress: () => {
      if (!today.in_progress.length) return emptyState("do", "Tasks in Do live here with their latest execution; a finished process is not a checked output.", "New task", newTask);
      return el("ul", { class: "list" }, today.in_progress.map((t) => taskItem(t, onOpenTask,
        t.latest_execution
          ? el("div", { class: "meta" }, "latest execution ", pill(t.latest_execution.status), ` by ${t.latest_execution.agent_id} · ${runnerLabel(t.latest_execution)}`)
          : el("div", { class: "meta" }, "no execution recorded yet"),
        { live: LIVE_STATES.has(t.latest_execution?.status) })));
    },
    achieved: () => {
      const { done_tasks, decided_goals } = today.achieved;
      if (!done_tasks.length && !decided_goals.length) return emptyState("goals", "Accepted tasks and decided goals land here once a human has said so.", "New goal", "#/goals");
      return el("div", { class: "stack" },
        section("Recently accepted tasks", done_tasks, (t) => taskItem(t, onOpenTask, el("div", { class: "meta" }, `accepted ${when(t.updated_at)}`))),
        section("Decided goals", decided_goals, (g) => el("li", { class: "list-item", dataset: { status: g.outcome_status } },
          el("div", { class: "list-item-title" }, el("strong", {}, g.title), pill(g.outcome_status, g.outcome_status.replace("_", " "))),
          g.outcome ? el("div", { class: "meta" }, `decided by ${g.outcome.decided_by}: ${g.outcome.evidence}`) : null)));
    },
  };

  const metas = {
    needs_attention: () => {
      const n = attention.in_correction.length + attention.awaiting_acceptance.length
        + attention.blocked_in_plan.filter((t) => t.reasons.length).length + decisions.length;
      return n ? `${n} item${n === 1 ? "" : "s"}` : "clear";
    },
    in_progress: () => `${today.in_progress.length} in Do`,
    achieved: () => `${today.achieved.done_tasks.length} accepted · ${today.achieved.decided_goals.length} decided`,
    review_inbox: () => "human gate",
    journal: () => `today's entry ${today.journal_today?.written ? "written" : "not yet"} · 14 days`,
    capture_inbox: () => "raw material",
  };

  // Board, not document (B1/B2): widgets sit on the page with no box; the row hairlines
  // come from the grid, the title is the 18px uppercase display signature.
  const widgets = prefs.widgets;
  return el("div", { class: "grid board", id: "widgets" }, widgets.map((w, index) => {
    const body = bodies[w.id];
    return el("section", { class: "widget", dataset: { widget: w.id, hidden: String(!w.visible) }, "aria-labelledby": `widget-${w.id}` },
      el("div", { class: "widget-header" },
        el("div", { class: "widget-title" }, icon(WIDGET_ICONS[w.id] || "today"), el("h2", { id: `widget-${w.id}` }, widgetTitle(w.id, today))),
        el("span", { class: "widget-meta" }, metas[w.id] ? metas[w.id]() : ""),
        el("div", { class: "panel-tools", role: "group", "aria-label": `Arrange ${WIDGET_TITLES[w.id]}` },
          el("button", { class: "btn is-quiet btn-icon", type: "button", "aria-label": "Move widget earlier", disabled: index === 0, onclick: () => onMoveWidget(w.id, -1) }, "↑"),
          el("button", { class: "btn is-quiet btn-icon", type: "button", "aria-label": "Move widget later", disabled: index === widgets.length - 1, onclick: () => onMoveWidget(w.id, 1) }, "↓"),
          el("button", { class: "btn is-quiet btn-icon", type: "button", "aria-label": "Hide widget", onclick: () => onToggleWidget(w.id, false) }, "×"))),
      body ? body() : empty("Unknown widget"));
  }));
}

// Only visible while the board is being edited (header pencil); see app.css.
export function renderHiddenWidgets(prefs, onToggleWidget) {
  const hidden = prefs.widgets.filter((w) => !w.visible);
  if (!hidden.length) return null;
  return el("div", { class: "hidden-widgets", id: "hidden-widgets" }, label("Hidden widgets"),
    hidden.map((w) => el("button", { class: "btn is-small", type: "button", onclick: () => onToggleWidget(w.id, true) }, `Show ${WIDGET_TITLES[w.id]}`)));
}

function section(title, items, render) {
  if (!items.length) return null;
  return el("div", {}, el("h4", {}, title), el("ul", { class: "list" }, items.map(render)));
}

// --- Goals and projects -------------------------------------------------------

// Goal tasks as a dot row (Observatory): one hollow dot per task, filled when Done, gold
// when someone is working on it (Do).
function goalDots(tasks) {
  if (!tasks.length) return null;
  return el("ul", { class: "dot-row", "aria-label": `${tasks.length} tasks` }, tasks.map((task) => el("li", {
    class: `dot${task.status === "Do" ? " is-now" : ""}`, dataset: { on: String(task.status === "Done"), status: task.status },
    title: `${task.title}: ${task.status}`,
  }, el("span", { class: "visually-hidden" }, `${task.title}: ${task.status}`))));
}

export function renderGoals(goals, projectsByGoal, tasksByProject, handlers) {
  if (!goals.length) return emptyState("goals", "Goals hold projects, projects hold tasks; delivery progress counts accepted tasks and never proves a goal's metric.", "New goal", handlers.onNewGoal);
  return el("div", {}, goals.map((goal) => {
    const projects = projectsByGoal[goal.id] || [];
    const goalTasks = projects.flatMap((p) => tasksByProject[p.id] || []);
    const moving = goalTasks.filter((t) => t.status === "Do" || t.status === "Check" || t.status === "Correction").length;
    const done = goalTasks.filter((t) => t.status === "Done").length;
    const summary = goalTasks.length
      ? `${goal.outcome_status === "open" ? `${moving} of ${goalTasks.length} tasks moving` : `${done} of ${goalTasks.length} tasks done`} · ${goal.outcome_status === "open" ? `${done} done` : `decided: ${goal.outcome?.evidence || goal.outcome_status.replace("_", " ")}`}`
      : "no tasks yet";
    // Summary column: status tag, serif title, owner and measure, the task dots, the actions.
    return el("section", { class: "goal", "aria-labelledby": `goal-${goal.id}` },
      el("div", { class: "goal-header" },
        pill(goal.outcome_status, `goal ${goal.outcome_status.replace("_", " ")}`),
        el("h2", { id: `goal-${goal.id}` }, goal.title),
        el("div", { class: "goal-meta" }, "Owner ", el("b", {}, goal.owner), el("br"), "Measure ", el("b", {}, goal.success_measure)),
        goalDots(goalTasks),
        el("div", { class: "goal-meta" }, summary),
        el("div", { class: "form-actions" },
          pillButton("New project", { dataset: { write: "true" }, onclick: () => handlers.onNewProject(goal) }),
          goal.outcome_status === "open"
            ? pillButton("Record outcome", { dataset: { write: "true" }, onclick: () => handlers.onDecideGoal(goal) })
            : null)),
      projects.length
        ? el("div", { class: "projects" }, projects.map((project) => {
          const tasks = tasksByProject[project.id] || [];
          return el("article", { class: "panel project", "aria-labelledby": `project-${project.id}` },
            el("div", { class: "project-head" },
              el("h3", { id: `project-${project.id}` }, project.title),
              progress(project.progress.done, project.progress.total)),
            el("div", { class: "meta" }, `${project.owner} · ${project.success_criteria}`),
            tasks.length
              ? el("div", { class: "stack" }, tasks.map((task) => el("button", { class: "task-row", type: "button", dataset: { status: task.status }, onclick: () => handlers.onOpenTask(task.id) },
                el("span", {}, task.title, el("small", {}, `next: ${task.next_action}`)), phasePill(task.status))))
              : emptyState("plan", "Tasks start in Plan and pass the 5M gate before Do.", "New task", () => handlers.onNewTask(project), { dataset: { newTask: project.id } }),
            tasks.length ? el("div", {}, pillButton("New task", { dataset: { write: "true", newTask: project.id }, onclick: () => handlers.onNewTask(project) })) : null);
        }))
        : emptyState("goals", "A project turns this goal into deliverable work with its own success criteria.", "New project", () => handlers.onNewProject(goal)));
  }));
}

// --- Automations and agents -----------------------------------------------------

// Executions by the fixture are labelled as such; nothing here may read as a live AI agent.
// For live executions the label is the provider/model the response reported — never the
// policy's requested model, and never what the model said about itself.
export function runnerLabel(policyOrExecution) {
  const kind = policyOrExecution?.kind || policyOrExecution?.provider || policyOrExecution?.model;
  if (kind === "fixture") return "fixture runner (deterministic test fixture, no model)";
  if (policyOrExecution?.kind === "live") return `live model policy: ${policyOrExecution.provider} / ${policyOrExecution.model}`;
  if (policyOrExecution?.provider) {
    const response = `${policyOrExecution.provider} / ${policyOrExecution.model}`;
    // OpenRouter answers with the upstream provider name ("Anthropic"); keep the
    // requested policy provider visible so the two are never confused.
    return policyOrExecution.policy_provider ? `policy: ${policyOrExecution.policy_provider} → response: ${response}` : response;
  }
  if ((policyOrExecution?.log || "").startsWith("live runner")) return "live run — no provider response recorded";
  return "manual record";
}

// Tokens and cost as the provider reported them; absent fields stay absent.
export function executionEvidence(execution) {
  const parts = [];
  if (execution?.usage_json) {
    try {
      const usage = JSON.parse(execution.usage_json);
      if (Number.isInteger(usage.total_tokens)) {
        const detail = Number.isInteger(usage.prompt_tokens) && Number.isInteger(usage.completion_tokens)
          ? ` (${usage.prompt_tokens} prompt + ${usage.completion_tokens} completion)` : "";
        parts.push(`${usage.total_tokens} tokens${detail}`);
      }
    } catch { /* unreadable usage is simply not shown */ }
  }
  if (Number.isInteger(execution?.cost_minor)) parts.push(`cost ${execution.cost_minor} ${execution.cost_currency || ""} (minor units)`.replace("  ", " "));
  if (execution?.provider_response_id) parts.push(`response ${execution.provider_response_id}`);
  return parts.length ? ` · ${parts.join(" · ")}` : "";
}

// Full-width hairline banner (D6): paused with the start command, or active with its age.
export function workerStatus(workers) {
  const alive = (workers || []).filter((w) => w.alive).sort((a, b) => a.age_seconds - b.age_seconds);
  const latest = (workers || [])[0];
  const isAlive = alive.length > 0;
  const body = isAlive
    ? [el("span", { class: "banner-dot", "aria-hidden": "true" }),
      el("span", { class: "banner-text" }, `Worker active · last seen ${alive[0].age_seconds} s ago`),
      el("span", { class: "banner-hint" }, alive[0].worker_id, alive[0].current_occurrence_id ? " · running an occurrence" : "")]
    : [el("span", { class: "banner-dot", "aria-hidden": "true" }),
      el("span", { class: "banner-text" }, "Automations are paused — no worker is running."),
      el("span", { class: "banner-hint" }, "Start one with ", el("code", { class: "mono" }, "digitalmaid worker --loop"),
        latest ? ` · last worker ${latest.worker_id} seen ${latest.age_seconds} s ago (${latest.status})` : "")];
  return el("p", { id: "worker-status", class: `worker-banner${isAlive ? " is-live" : ""}`, role: "status", dataset: { alive: String(isAlive) } }, body);
}

function scheduleText(job) {
  const spec = job.schedule_spec;
  if (job.schedule_kind === "once") return `once at ${when(spec.at)}`;
  if (job.schedule_kind === "interval") return `every ${spec.every_seconds} s from ${when(spec.start)}`;
  const dow = spec.dow ? ` on weekdays ${spec.dow.join(",")} (Mon=0)` : " daily";
  return `${String(spec.hour).padStart(2, "0")}:${String(spec.minute).padStart(2, "0")} ${job.timezone}${dow}`;
}

// One node on the run rail; the leased (claimed, running) node is ringed in accent.
function occurrenceItem(o, onOpenTask) {
  return el("li", { class: `list-item${o.state === "leased" ? " is-live" : ""}`, dataset: { occurrence: o.id, state: o.state, status: o.state } },
    el("div", { class: "list-item-title" },
      el("span", {}, `${o.kind} · ${when(o.occurrence_utc)}`), pill(o.state)),
    el("div", { class: "meta" },
      o.worker_id ? `worker ${o.worker_id} · ` : "",
      o.execution ? ["execution ", pill(o.execution.status), ` · ${runnerLabel(o.execution)}`, executionEvidence(o.execution)] : "no execution"),
    o.task ? el("button", { class: "btn is-small", type: "button", onclick: () => onOpenTask(o.task.id) }, `Open task: ${o.task.title}`, " ", phasePill(o.task.status)) : null,
    o.blocked_reasons.length ? reasonsList(o.blocked_reasons.map((r) => `blocked: ${r}`)) : null,
    techDetails(`occurrence ${o.id} · fencing token ${o.fencing_token} · state ${o.state}`));
}

function spendText(job) {
  const auth = job.task_template?.spend_authorization;
  if (!auth || auth.amount_minor === null || auth.amount_minor === undefined) return "no spend authorized";
  return `spend authorized: ${auth.amount_minor} ${auth.currency || ""} (minor units)${auth.authorized_by ? ` by ${auth.authorized_by}` : ""}`;
}

export function renderAutomations(jobs, { onOpenTask, onRunNow }) {
  if (!jobs.length) return emptyState("automations", "Scheduled jobs the worker claims with a lease and fencing token live here; none is defined in this scope yet, so nothing runs unattended.", "Open Agents", "#/agents");
  return el("div", { class: "stack" }, jobs.map((job) => {
    const agentName = job.agent ? job.agent.name : `${job.agent_id} (definition missing)`;
    // Ghost button (D6): the solid accent lives only inside the confirmation, which names
    // the spend authorization and the agent that will do the work.
    const runButton = el("button", { class: "btn is-small", type: "button", dataset: { runNow: job.id, write: "true" } }, "Run now");
    // One idempotency key per rendered button: a double click reuses it, so the
    // server returns the same occurrence instead of creating a second one.
    const key = `ui-${crypto.randomUUID()}`;
    runButton.addEventListener("click", async () => {
      const confirmed = await confirmDialog({
        title: `Run “${job.purpose}” now?`,
        message: `Agent: ${agentName}.\n${spendText(job)[0].toUpperCase()}${spendText(job).slice(1)}.\n\nA manual occurrence is queued for the next worker tick; the result lands in your Review Inbox as unchecked work.`,
        confirmLabel: "Queue the run",
      });
      if (!confirmed) return;
      runButton.disabled = true;
      try { await onRunNow(job, key); } finally { runButton.disabled = false; }
    });
    const history = job.occurrences.filter((o) => o.status !== "due");
    return el("section", { class: "panel", "aria-labelledby": `job-${job.id}` },
      el("div", { class: "panel-header" },
        el("div", {}, el("h2", { id: `job-${job.id}` }, job.purpose),
          el("div", { class: "meta" }, scheduleText(job), job.enabled ? "" : " · disabled")),
        el("div", { class: "form-actions" }, pill(job.enabled ? "available" : "missing", job.enabled ? "enabled" : "paused"), runButton)),
      el("dl", { class: "kv" },
        el("dt", {}, "Agent"), el("dd", {}, job.agent ? `${job.agent.name} — ${runnerLabel(job.agent.model_policy)}` : agentName),
        el("dt", {}, "Project"), el("dd", {}, job.project ? job.project.title : job.project_id),
        el("dt", {}, "Task template"), el("dd", {}, `${job.task_template.title} · owner ${job.task_template.owner} · ${job.task_template.criteria.length} criteria`),
        el("dt", {}, "Spending"), el("dd", {}, spendText(job))),
      techDetails(`job ${job.id} · misfire: ${job.misfire_policy} · schedule v${job.schedule_version} · ${job.schedule_kind} ${JSON.stringify(job.schedule_spec)} · ${job.timezone}`),
      el("h4", {}, "Next occurrences"),
      job.next_occurrences.length
        ? el("ul", { class: "list rail" }, job.next_occurrences.map((o) => occurrenceItem(o, onOpenTask)))
        : empty("Nothing due or planned yet; the worker plans occurrences on its next tick."),
      el("h4", {}, "Run history"),
      history.length ? el("ul", { class: "list rail" }, history.map((o) => occurrenceItem(o, onOpenTask))) : empty("No runs yet."));
  }));
}

function agentPill(agent) {
  if (agent.model_policy.kind === "fixture") return pill("not_applicable", "test fixture");
  const configured = agent.runner_status?.configured === true;
  return pill(configured ? "available" : "required", configured ? "live, configured" : "live, unconfigured");
}

export function renderAgents(agents) {
  if (!agents.length) return emptyState("agents", "Agent roles are portable JSON definitions under definitions/agents; a role is not a running worker.", "Open Settings", "#/settings");
  return el("div", { class: "grid" }, agents.map((agent) => el("section", { class: "panel", "aria-labelledby": `agent-${agent.id}` },
    el("div", { class: "panel-header" }, el("h2", { id: `agent-${agent.id}` }, agent.name), agentPill(agent)),
    el("p", {}, agent.responsibility),
    el("dl", { class: "kv" },
      el("dt", {}, "Runs as"), el("dd", {}, runnerLabel(agent.model_policy),
        agent.runner_status?.problems?.length ? reasonsList(agent.runner_status.problems.map((p) => `not configured: ${p}`)) : null),
      el("dt", {}, "Allowed actions"), el("dd", {}, el("ul", { class: "criteria" }, agent.allowed_actions.map((a) => el("li", {}, a)))),
      el("dt", {}, "Reports to"), el("dd", {}, agent.reports_to || "—"),
      el("dt", {}, "Limitations"), el("dd", {}, (agent.limitations || []).length ? el("ul", { class: "criteria" }, agent.limitations.map((l) => el("li", {}, l))) : "—"),
      el("dt", {}, "Definition"), el("dd", { class: "mono" }, agent.definition_path)))));
}

// --- Forms ----------------------------------------------------------------------

let fieldCounter = 0;

export function field(label, name, attrs = {}, tag = "input") {
  const { options, value, ...rest } = attrs;
  const id = `f-${name}-${++fieldCounter}`;
  const input = el(tag, { id, name, ...rest });
  for (const opt of options || []) {
    input.append(el("option", { value: opt.value ?? opt }, opt.label ?? opt));
  }
  // A textarea's initial text is its content, not a value attribute; a select needs its
  // options before its value can be chosen.
  if (value !== undefined && value !== null) input.value = String(value);
  // Required fields carry a small accent dot (D3); the text itself stays the label.
  return el("div", { class: "form-row" }, el("label", { for: id, class: rest.required ? "is-required" : null }, label), input);
}

// Three-way segmented control (D3) — one radio per option, the checked one is the value.
// Priority uses it as Low / Normal / High → 3 / 2 / 1, so the API still receives an integer.
export function segmented(labelText, name, options, value) {
  const id = `f-${name}-${++fieldCounter}`;
  return el("div", { class: "form-row" }, el("span", { class: "label-text", id }, labelText),
    el("div", { class: "segmented", role: "radiogroup", "aria-labelledby": id }, options.map((opt) =>
      el("label", { class: "segment" },
        el("input", { type: "radio", name, value: opt.value, checked: opt.value === value || null }),
        el("span", {}, opt.label)))));
}

export const PRIORITY_OPTIONS = [{ value: "3", label: "Low" }, { value: "2", label: "Normal" }, { value: "1", label: "High" }];

// Tier 2 of a form (D3): closed by default, open when something in it is already non-default.
export function moreOptions(fields, { open = false } = {}) {
  return el("details", { class: "more", open: open || null }, el("summary", {}, "More options"), el("div", { class: "more-body" }, fields));
}

// Required fields that are visible, enabled and still empty; radio groups count as one.
function missingRequired(node) {
  const missing = [];
  const seenRadio = new Set();
  for (const input of node.querySelectorAll("[required]")) {
    if (input.disabled || input.closest("[hidden]")) continue;
    if (input.type === "radio") {
      if (seenRadio.has(input.name)) continue;
      seenRadio.add(input.name);
      if (node.querySelector(`input[type=radio][name="${input.name}"]:checked`)) continue;
    } else if (input.value.trim()) continue;
    const label = input.id ? node.querySelector(`label[for="${input.id}"]`) : input.closest("fieldset")?.querySelector("legend");
    missing.push((label?.textContent || input.name).trim());
  }
  return missing;
}

export function form(fields, submitLabel, onSubmit, { inline = false } = {}) {
  const alert = el("div", { class: "alert is-error", role: "alert" });
  const node = el("form", { class: "form", novalidate: true },
    inline ? el("div", { class: "form-row is-inline" }, fields) : fields,
    alert,
    el("div", { class: "form-actions" }, el("button", { class: "btn is-primary", type: "submit" }, submitLabel)));
  const button = node.querySelector("button[type=submit]");
  // The primary stays disabled until every required field is filled and says why (D3);
  // the viewer's read-only reason wins over it.
  const refresh = () => {
    if (isReadOnly()) return;
    const missing = missingRequired(node);
    button.disabled = missing.length > 0;
    button.title = missing.length ? `Fill in: ${missing.join(", ")}` : "";
    button.dataset.missing = String(missing.length);
  };
  node.addEventListener("input", refresh);
  node.addEventListener("change", refresh);
  node.addEventListener("submit", async (event) => {
    event.preventDefault();
    alert.replaceChildren();
    if (isReadOnly()) { alert.replaceChildren(el("div", {}, READ_ONLY_REASON)); return; }
    button.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(node).entries());
      await onSubmit(data, node);
    } catch (error) {
      alert.replaceChildren(el("div", {}, error.reasons ? "Refused by the server:" : error.message));
      if (error.reasons) alert.append(el("ul", {}, error.reasons.map((r) => el("li", {}, r))));
    } finally {
      button.disabled = isReadOnly();
      refresh();
    }
  });
  applyReadOnly(node);
  refresh();
  return node;
}
