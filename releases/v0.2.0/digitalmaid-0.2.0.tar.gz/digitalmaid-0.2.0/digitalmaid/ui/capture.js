// Stage H: Capture Inbox. Quick-capture bar (text or URL → link, Ctrl/Cmd+Enter),
// file drop zone with the server's allow-list, grouped list, and a drawer with the
// original, draft versions, "Convert to…" and archive/unarchive. textContent only.

import { api } from "./api.js";
import { el, append, pill, when, empty, emptyState, alertBox, field, form, isReadOnly, currentUser, pageHeader, segmented, PRIORITY_OPTIONS } from "./views.js";

const GROUPS = [["inbox", "Inbox"], ["drafting", "Drafting"], ["converted", "Converted"], ["archived", "Archived"]];
const TARGETS = ["task", "note", "journal", "decision", "event", "goal"];
const URL_RE = /^https?:\/\/\S+$/i;

function render(container, ...children) {
  container.replaceChildren();
  return append(container, children);
}

function humanSize(bytes) {
  if (bytes >= 1024 * 1024) return `${Math.round(bytes / (1024 * 1024))} MB`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${bytes} bytes`;
}

function captureLabel(c) {
  if (c.title) return c.title;
  if (c.kind === "link") return c.url.replace(/^https?:\/\//, "");
  if (c.body_text) return c.body_text.split("\n")[0].slice(0, 120);
  return `${c.kind} capture`;
}

function captureRow(c, onOpen) {
  return el("li", {}, el("button", { class: "task-row", type: "button", dataset: { captureRow: c.id, kind: c.kind }, onclick: () => onOpen(c.id) },
    el("span", {}, captureLabel(c), el("small", {}, `${c.kind} · ${c.source} · by ${c.captured_by} · ${when(c.captured_at)}`,
      c.converted_type ? ` · → ${c.converted_type}` : "", c.mime ? ` · ${c.mime}, ${humanSize(c.size_bytes)}` : "")),
    pill(c.status === "converted" ? "available" : c.status === "archived" ? "not_applicable" : c.status === "drafting" ? "required" : "Plan", c.status)));
}

let uploadInfo = null;

export async function renderCapturePage(view, ctx, captureId) {
  const [captures, archived, settings] = await Promise.all([api.captures(), api.captures("archived"), api.settings()]);
  uploadInfo = settings.capture;
  const all = [...captures, ...archived];
  const open = (id) => openCapture(id, ctx);

  // Quick capture: a pasted URL is detected as a link before submit.
  const kindHint = el("span", { id: "quick-capture-kind", class: "meta", role: "status", "aria-live": "polite" }, "text");
  const textField = field("Capture text, or paste a URL (Ctrl/Cmd+Enter submits)", "text", { required: true, rows: "2", placeholder: "Idea, note, https://…" }, "textarea");
  const textarea = textField.querySelector("textarea");
  const detect = () => { kindHint.textContent = URL_RE.test(textarea.value.trim()) ? "link (URL detected)" : "text"; };
  textarea.addEventListener("input", detect);
  const quick = form([textField, kindHint], "Capture", async (data) => {
    const value = data.text.trim();
    if (!value) throw new Error("Nothing to capture.");
    const body = URL_RE.test(value) ? { kind: "link", url: value } : { kind: "text", body_text: value };
    await api.createCapture(body);
    await ctx.route();
  });
  quick.id = "quick-capture";
  textarea.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); quick.requestSubmit(); } });

  // File drop zone + input. The allow-list and cap come from the server.
  const uploadStatus = el("div", { id: "upload-status", class: "meta", role: "status", "aria-live": "polite" });
  const fileInput = el("input", { id: "capture-file", type: "file", accept: uploadInfo.allowed_types.join(","), disabled: isReadOnly() || null, "aria-describedby": "upload-rules" });
  const upload = async (file) => {
    if (!file) return;
    render(uploadStatus, `Uploading ${file.name} (${humanSize(file.size)})…`);
    try {
      if (!uploadInfo.allowed_types.includes(file.type)) throw new Error(`Type ${file.type || "unknown"} is not allowed.`);
      if (file.size > uploadInfo.max_bytes) throw new Error(`File is larger than ${humanSize(uploadInfo.max_bytes)}.`);
      const body = new FormData();
      body.append("file", file, file.name);
      await api.uploadCapture(body);
      render(uploadStatus, `Stored ${file.name}.`);
      await ctx.route();
    } catch (error) {
      render(uploadStatus, alertBox("error", `Upload refused: ${error.message}`, error.reasons));
    }
  };
  fileInput.addEventListener("change", () => upload(fileInput.files[0]));
  const dropZone = el("div", { class: "drop-zone", id: "drop-zone", dataset: { active: "false" } },
    el("label", { for: "capture-file" }, "Drop a file here or choose one"), fileInput,
    el("p", { id: "upload-rules", class: "meta" }, `Allowed: ${uploadInfo.allowed_types.join(", ")} · max ${humanSize(uploadInfo.max_bytes)} · originals are stored once and never changed · audio becomes a transcript whose text you or Hermes supply (transcription: external).`),
    uploadStatus);
  for (const evt of ["dragenter", "dragover"]) dropZone.addEventListener(evt, (e) => { e.preventDefault(); if (!isReadOnly()) dropZone.dataset.active = "true"; });
  for (const evt of ["dragleave", "drop"]) dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.dataset.active = "false"; });
  dropZone.addEventListener("drop", (e) => { if (!isReadOnly()) upload(e.dataTransfer?.files?.[0]); });

  const groups = GROUPS.map(([status, label]) => {
    const items = all.filter((c) => c.status === status);
    return el("section", { class: "panel", id: `capture-group-${status}`, "aria-labelledby": `capture-group-${status}-title` },
      el("h2", { id: `capture-group-${status}-title` }, `${label} (${items.length})`),
      items.length ? el("ul", { class: "list" }, items.map((c) => captureRow(c, open)))
        : status === "inbox" ? emptyState("capture", "Raw text, links, files and transcripts land here unchanged; capture is the entry point for everything.", "Capture", () => textarea.focus())
          : empty(`No ${label.toLowerCase()} captures.`));
  });

  render(view,
    pageHeader("capture", "Capture Inbox",
      "Raw text, links, files and transcripts land here unchanged. Write a draft, then convert it into a task, note, journal entry, decision, event or goal — through the same gates as everything else. Nothing is deleted; archive is reversible."),
    el("div", { class: "grid" }, el("section", { class: "panel", "aria-label": "Quick capture" }, quick), dropZone),
    el("div", { class: "grid" }, groups));
  if (captureId) await openCapture(captureId, ctx);
}

export async function openCapture(captureId, ctx, notice = null) {
  let c;
  try { c = await api.capture(captureId); } catch (error) {
    ctx.openDrawer("Capture", alertBox("error", `Could not load capture: ${error.message}`, error.reasons));
    return;
  }
  const refresh = async (text) => { await openCapture(captureId, ctx, text); ctx.route(); };
  const writable = c.status === "inbox" || c.status === "drafting";
  const info = uploadInfo || (await api.settings()).capture;

  const original = el("section", { class: "drawer-section" }, el("h4", {}, "Original (immutable)"),
    el("dl", { class: "kv" },
      el("dt", {}, "Kind"), el("dd", {}, c.kind),
      el("dt", {}, "Source"), el("dd", {}, `${c.source} · captured by ${c.captured_by} · ${when(c.captured_at)}`),
      c.url ? [el("dt", {}, "Link"), el("dd", {}, el("a", { href: c.url, target: "_blank", rel: "noopener noreferrer" }, c.url))] : null,
      c.original_url ? [
        el("dt", {}, "File"), el("dd", {}, `${c.title || "original"} · ${c.mime} · ${c.size_bytes} bytes`),
        el("dt", {}, "sha256"), el("dd", { class: "mono" }, c.original_sha256),
        el("dt", {}, "Download"), el("dd", {}, el("a", { href: c.original_url, download: `original`, class: "btn is-small" }, "Download original")),
        c.mime.startsWith("image/") ? [el("dt", {}, "Preview"), el("dd", {}, el("img", { class: "capture-preview", src: `${c.original_url}?inline=1`, alt: `Preview of ${c.title || "the uploaded image"}` }))] : null,
      ] : null,
      c.kind === "transcript" ? [el("dt", {}, "Transcription"), el("dd", {}, `external — ${c.body_text ? "text supplied" : "no text yet; a human or Hermes supplies it (the app never transcribes)"}`)] : null),
    c.body_text ? el("pre", { class: "version-content" }, c.body_text) : null);

  const drafts = el("section", { class: "drawer-section" }, el("h4", {}, "Draft versions"),
    c.drafts.length ? el("ul", { class: "list" }, c.drafts.slice().reverse().map((d) => el("li", { class: "list-item" },
      el("div", { class: "list-item-title" }, el("strong", {}, `version ${d.version}`), el("span", { class: "meta" }, `${d.created_by} · ${when(d.created_at)}`)),
      el("pre", { class: "version-content" }, d.body_md)))) : empty("No draft yet. The latest draft is what gets converted; without one, the original text is used."),
    writable ? (() => {
      const f = form([field("Draft (Markdown)", "body_md", { required: true, rows: "4", value: c.drafts.at(-1)?.body_md || "" }, "textarea")],
        `Save draft as version ${c.drafts.length + 1}`, async (data) => { await api.addCaptureDraft(c.id, { body_md: data.body_md }); await refresh(`Draft version ${c.drafts.length + 1} saved.`); });
      f.id = "draft-form";
      return f;
    })() : null);

  const convert = writable ? await convertForm(c, ctx, refresh) : (c.converted_type
    ? el("div", { class: "stack" }, alertBox("ok", `Converted to ${c.converted_type}.`),
      ...c.links.map((l) => el("button", { class: "btn is-small", type: "button", dataset: { convertedLink: l.target_id }, onclick: () => openTarget(l, ctx) }, `Open ${l.target_type.replace("_", " ")}: ${l.target_title ?? l.target_id}`)))
    : alertBox("info", "Archived captures are read-only. Unarchive to work on it."));

  const revision = c.revision;
  const archiveTools = el("div", { class: "form-actions" },
    c.status !== "archived"
      ? el("button", { id: "capture-archive", class: "btn is-small", type: "button", dataset: { write: "true" }, onclick: async () => { try { await api.archiveCapture(c.id, { revision }); await refresh("Archived. Nothing is deleted; unarchive any time."); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, "Archive")
      : el("button", { id: "capture-unarchive", class: "btn is-small is-primary", type: "button", dataset: { write: "true" }, onclick: async () => { try { await api.unarchiveCapture(c.id, { revision }); await refresh("Restored."); } catch (error) { ctx.showGlobal(error.message, "error", error.reasons); } } }, "Unarchive"));

  const body = el("div", { id: "capture-detail", class: "stack", dataset: { status: c.status } },
    notice ? alertBox("ok", notice) : null,
    el("div", { class: "meta" }, pill(c.status === "converted" ? "available" : c.status === "archived" ? "not_applicable" : "required", c.status), ` · revision ${c.revision}`, c.converted_type ? ` · converted to ${c.converted_type}` : ""),
    original, drafts,
    el("section", { class: "drawer-section" }, el("h4", {}, "Convert to…"), convert),
    el("section", { class: "drawer-section" }, el("h4", {}, "Archive"), archiveTools));
  ctx.openDrawer(captureLabel(c), body, { kicker: `Capture · ${c.status}` });
  void info;
}

function openTarget(link, ctx) {
  if (link.target_type === "task") ctx.openTask(link.target_id);
  else if (link.target_type === "note") { ctx.closeDrawer(); location.hash = `#/knowledge/${link.target_id}`; }
  else if (link.target_type === "event") { ctx.closeDrawer(); location.hash = "#/calendar"; }
  else { ctx.closeDrawer(); location.hash = "#/goals"; }
}

async function convertForm(c, ctx, refresh) {
  const targetField = field("Target", "target", { options: TARGETS }, "select");
  const targetSelect = targetField.querySelector("select");
  const specific = el("div", { class: "stack", id: "convert-fields" });
  const projects = await api.projects();
  const todayIso = new Date().toISOString().slice(0, 10);
  const build = () => {
    const t = targetSelect.value;
    const rows = [field("Title (defaults to the capture title or first line of the draft)", "title", {})];
    if (t === "task") rows.push(
      el("div", { class: "form-row is-inline" },
        field("Project", "project_id", { options: projects.map((p) => ({ value: p.id, label: p.title })) }, "select"),
        field("Owner", "owner", { value: currentUser() || "" })),
      segmented("Priority", "priority", PRIORITY_OPTIONS, "2"),
      field("Next action", "next_action", {}),
      field("Acceptance criteria, one per line (required)", "criteria", { rows: "2" }, "textarea"));
    else if (t === "note") rows.push(field("Kind", "kind", { options: ["note", "research"] }, "select"));
    else if (t === "journal") rows.push(field("Entry date", "entry_date", { type: "date", value: todayIso, required: true }));
    else if (t === "decision") rows.push(
      field("Options, one per line", "options", { rows: "2", required: true }, "textarea"),
      el("div", { class: "form-row is-inline" },
        field("Chosen option", "chosen", { required: true }),
        field("Confidence (1–5)", "confidence", { type: "number", min: "1", max: "5", value: "3", required: true }),
        field("Review date", "review_date", { type: "date", required: true })),
      field("Reasoning", "reasoning", { required: true }), field("Expected result", "expected_result", { required: true }));
    else if (t === "event") rows.push(
      el("div", { class: "form-row is-inline" },
        field("Start (local)", "start", { type: "datetime-local", required: true }),
        field("End (local)", "end", { type: "datetime-local" }),
        field("Kind", "kind", { options: ["event", "deadline", "block", "milestone"] }, "select")));
    else rows.push(field("Success measure (required)", "success_measure", { required: true }), field("Owner", "owner", { value: currentUser() || "" }));
    render(specific, rows);
  };
  targetSelect.addEventListener("change", build);
  build();
  const node = form([targetField, specific], "Convert", async (data) => {
    const t = data.target;
    const payload = {};
    if (data.title) payload.title = data.title;
    if (t === "task") {
      payload.project_id = data.project_id;
      payload.criteria = (data.criteria || "").split("\n").map((s) => s.trim()).filter(Boolean);
      if (data.owner) payload.owner = data.owner;
      if (data.next_action) payload.next_action = data.next_action;
      if (data.priority) payload.priority = Number.parseInt(data.priority, 10);
    } else if (t === "note") payload.kind = data.kind;
    else if (t === "journal") payload.entry_date = data.entry_date;
    else if (t === "decision") payload.decision = {
      options: data.options.split("\n").map((s) => s.trim()).filter(Boolean), chosen: data.chosen,
      reasoning: data.reasoning, expected_result: data.expected_result,
      confidence: Number.parseInt(data.confidence, 10), review_date: data.review_date };
    else if (t === "event") {
      payload.start_utc = data.start ? new Date(data.start).toISOString() : "";
      if (data.end) payload.end_utc = new Date(data.end).toISOString();
      payload.kind = data.kind;
      payload.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    } else { payload.success_measure = data.success_measure; if (data.owner) payload.owner = data.owner; }
    await api.convertCapture(c.id, { target: t, payload });
    await refresh(`Converted to ${t}.`);
  });
  node.id = "convert-form";
  return node;
}
