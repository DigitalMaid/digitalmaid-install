// Observatory sky (docs/DESIGN.md, "Observatory" 2026-09-09): a fixed, full-viewport canvas
// behind everything holding a very faint starfield. Decoration only — the canvas is
// aria-hidden, ignores pointer events and carries no information. Stars twinkle on their
// own slow sines; with prefers-reduced-motion they are drawn once and hold still, and the
// loop pauses while the tab is hidden.

const DENSITY = 6500;         // one star per this many CSS px²
const INK = "235,230,218";    // most stars are the page ink…
const GOLD = "212,175,90";    // …a few are gold or sky-blue
const SKY = "143,184,230";

function makeStars(width, height) {
  const count = Math.round((width * height) / DENSITY);
  return Array.from({ length: count }, () => {
    const pick = Math.random();
    return {
      x: Math.random() * width, y: Math.random() * height,
      r: 0.3 + Math.random() * 0.9, a: 0.08 + Math.random() * 0.3,
      phase: Math.random() * Math.PI * 2, tempo: 0.2 + Math.random() * 0.6,
      colour: pick < 0.85 ? INK : pick < 0.925 ? GOLD : SKY,
    };
  });
}

export function startSky(canvas = document.getElementById("sky")) {
  const ctx = canvas?.getContext?.("2d");
  if (!ctx) return null;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let stars = [], width = 0, height = 0;
  const fit = () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
    stars = makeStars(width, height);
  };
  const draw = (t) => {
    ctx.clearRect(0, 0, width, height);
    for (const s of stars) {
      const twinkle = reduced ? 1 : 0.6 + 0.4 * Math.sin(s.phase + t * 0.001 * s.tempo);
      ctx.globalAlpha = s.a * twinkle;
      ctx.fillStyle = `rgb(${s.colour})`;
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  };
  const tick = (now) => {
    if (!document.hidden) draw(now);
    if (!reduced) requestAnimationFrame(tick);
  };
  window.addEventListener("resize", () => { fit(); if (reduced) draw(0); });
  fit();
  requestAnimationFrame(tick);
  return canvas;
}
