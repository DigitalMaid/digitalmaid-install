"""Calendar events with recurrence, exceptions and derived read-only items.

A recurring event stores one anchor instant plus the IANA zone it was
created in; occurrences are generated on the *local wall clock* of that zone,
so a 09:00 weekly block stays at 09:00 across a DST transition (the UTC
instant shifts). A wall time that does not exist on a transition day is
shifted forward past the gap; an ambiguous one takes its first instant —
the same policies as scheduling.py.

Task deadlines, due job occurrences and decision review dates are *derived*
from their own tables at read time; they are never copied into ``events``.
Rows carrying ``external_source`` are owned by that source (ADR-002): every
write here refuses them with ``ConflictError("owned by <source>")``.
"""

import json
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from digitalmaid.db import new_id, now
from digitalmaid.errors import ConflictError
from digitalmaid.scheduling import UTC, parse_utc, utc_iso

EVENT_KINDS = ("event", "deadline", "block", "milestone")
DERIVED_KINDS = ("task_deadline", "job_occurrence", "decision_review")
LINKED_TYPES = ("goal", "project", "task", "job")
FREQUENCIES = ("daily", "weekly", "monthly")
EXCEPTION_KINDS = ("skip", "move")
_MAX_OCCURRENCES = 5_000
_EVENT_COLUMNS = ("id, scope_id, title, kind, start_utc, end_utc, all_day, timezone,"
                  " rrule_json, notes, linked_type, linked_id, external_source,"
                  " external_id, archived_at, created_at, updated_at, revision")
_UPDATABLE = ("title", "kind", "start_utc", "end_utc", "all_day", "timezone", "rrule",
              "notes", "linked_type", "linked_id")


def _check_zone(name) -> str:
    try:
        ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise ValueError(f"unknown IANA timezone {name!r}") from None
    return name


def _check_date(value, what: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{what} must be an ISO date string")
    try:
        return date.fromisoformat(value).isoformat()
    except ValueError:
        raise ValueError(f"{what} must be an ISO date (YYYY-MM-DD), got {value!r}") from None


def check_rrule(rrule) -> dict | None:
    """Normalise ``{freq, interval, byweekday[], until}``; None means no rule."""
    if rrule is None:
        return None
    if not isinstance(rrule, dict):
        raise ValueError("rrule must be an object")
    unknown = set(rrule) - {"freq", "interval", "byweekday", "until"}
    if unknown:
        raise ValueError(f"rrule has unknown keys {sorted(unknown)}")
    freq = rrule.get("freq")
    if freq not in FREQUENCIES:
        raise ValueError(f"rrule.freq must be one of {FREQUENCIES}")
    interval = rrule.get("interval", 1)
    if type(interval) is not int or not 1 <= interval <= 366:
        raise ValueError("rrule.interval must be an int between 1 and 366")
    byweekday = rrule.get("byweekday")
    if byweekday is not None:
        if freq != "weekly":
            raise ValueError("rrule.byweekday is only valid with freq 'weekly'")
        if (not isinstance(byweekday, list) or not byweekday
                or any(type(d) is not int or not 0 <= d <= 6 for d in byweekday)):
            raise ValueError("rrule.byweekday must be a non-empty list of ints 0-6 (Mon=0)")
        byweekday = sorted(set(byweekday))
    until = rrule.get("until")
    if until is not None:
        until = _check_date(until, "rrule.until")
    return {"freq": freq, "interval": interval, "byweekday": byweekday, "until": until}


def _add_months(day: date, months: int) -> date | None:
    """Same day-of-month ``months`` later, or None when that month is shorter."""
    month_index = day.month - 1 + months
    year, month = day.year + month_index // 12, month_index % 12 + 1
    try:
        return day.replace(year=year, month=month)
    except ValueError:
        return None


def occurrence_dates(start: date, rule: dict, stop: date):
    """Local dates on which the rule fires, ascending, up to ``stop`` inclusive."""
    if rule["until"] is not None:
        stop = min(stop, date.fromisoformat(rule["until"]))
    yielded = 0
    if rule["freq"] == "daily":
        day = start
        while day <= stop and yielded < _MAX_OCCURRENCES:
            yield day
            yielded += 1
            day += timedelta(days=rule["interval"])
    elif rule["freq"] == "weekly":
        weekdays = rule["byweekday"] or [start.weekday()]
        week_zero = start - timedelta(days=start.weekday())
        day = start
        while day <= stop and yielded < _MAX_OCCURRENCES:
            weeks = (day - week_zero).days // 7
            if day.weekday() in weekdays and weeks % rule["interval"] == 0:
                yield day
                yielded += 1
            day += timedelta(days=1)
    else:
        k = 0
        while yielded < _MAX_OCCURRENCES:
            day = _add_months(start, k * rule["interval"])
            k += 1
            if day is None:
                if _add_months(start.replace(day=1), (k - 1) * rule["interval"]) > stop:
                    break
                continue
            if day > stop:
                break
            yield day
            yielded += 1


def _event_dict(row) -> dict:
    event = dict(row)
    event["all_day"] = bool(event["all_day"])
    event["rrule"] = json.loads(event.pop("rrule_json")) if event["rrule_json"] else None
    return event


class Calendar:
    """Mixin; expects ``self._db``, ``self.scope_id`` and the other stores."""

    # -- validation ------------------------------------------------------------------

    def _check_event_fields(self, fields: dict) -> dict:
        title = fields.get("title")
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must be a non-empty string")
        if fields.get("kind") not in EVENT_KINDS:
            raise ValueError(f"kind must be one of {EVENT_KINDS}")
        start = utc_iso(parse_utc(fields.get("start_utc")))
        end = fields.get("end_utc")
        end = None if end is None else utc_iso(parse_utc(end))
        if end is not None and end < start:
            raise ValueError("end_utc must not be before start_utc")
        all_day = fields.get("all_day", False)
        if not isinstance(all_day, bool):
            raise ValueError("all_day must be a bool")
        zone = _check_zone(fields.get("timezone"))
        rule = check_rrule(fields.get("rrule"))
        notes = fields.get("notes") or ""
        if not isinstance(notes, str):
            raise ValueError("notes must be a string")
        linked_type, linked_id = fields.get("linked_type"), fields.get("linked_id")
        if (linked_type is None) != (linked_id is None):
            raise ValueError("linked_type and linked_id go together")
        if linked_type is not None:
            if linked_type not in LINKED_TYPES:
                raise ValueError(f"linked_type must be one of {LINKED_TYPES}")
            getter = {"goal": self.get_goal, "project": self.get_project,
                      "task": self.get_task, "job": self.get_job}[linked_type]
            if getter(linked_id) is None:
                raise ValueError(f"{linked_type} {linked_id!r} not found in scope"
                                 f" {self.scope_id!r}")
        return {"title": title.strip(), "kind": fields["kind"], "start_utc": start,
                "end_utc": end, "all_day": all_day, "timezone": zone, "rrule": rule,
                "notes": notes, "linked_type": linked_type, "linked_id": linked_id}

    # -- writes --------------------------------------------------------------------------

    def create_event(self, title: str, kind: str, start_utc: str, *, timezone: str,
                     actor: str, end_utc: str | None = None, all_day: bool = False,
                     rrule: dict | None = None, notes: str = "",
                     linked_type: str | None = None, linked_id: str | None = None,
                     external_source: str | None = None,
                     external_id: str | None = None) -> dict:
        clean = self._check_event_fields({
            "title": title, "kind": kind, "start_utc": start_utc, "end_utc": end_utc,
            "all_day": all_day, "timezone": timezone, "rrule": rrule, "notes": notes,
            "linked_type": linked_type, "linked_id": linked_id})
        if external_source is not None and (
                not isinstance(external_source, str) or not external_source.strip()):
            raise ValueError("external_source must be a non-empty string or None")
        if (external_id is None) != (external_source is None):
            raise ValueError("external_source and external_id go together")
        if not isinstance(actor, str) or not actor.strip():
            raise ValueError("actor must be a non-empty string")
        event_id, stamp = new_id(), now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO events (id, scope_id, title, kind, start_utc, end_utc, all_day,"
                " timezone, rrule_json, notes, linked_type, linked_id, external_source,"
                " external_id, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (event_id, self.scope_id, clean["title"], clean["kind"], clean["start_utc"],
                 clean["end_utc"], int(clean["all_day"]), clean["timezone"],
                 json.dumps(clean["rrule"], sort_keys=True) if clean["rrule"] else None,
                 clean["notes"], clean["linked_type"], clean["linked_id"], external_source,
                 external_id, stamp, stamp))
            self._db.audit(cur, "event", event_id, "create", actor,
                           {"kind": clean["kind"], "external_source": external_source},
                           scope_id=self.scope_id)
        return self.get_event(event_id)

    def _require_event(self, event_id: str) -> dict:
        event = self.get_event(event_id)
        if event is None:
            raise LookupError(f"event {event_id!r} not found in scope {self.scope_id!r}")
        return event

    @staticmethod
    def _require_owned_here(event: dict) -> None:
        if event["external_source"]:
            raise ConflictError(f"event {event['id']!r} is owned by"
                                f" {event['external_source']}; edit it at the source")

    def update_event(self, event_id: str, expected_revision: int, fields: dict,
                     actor: str) -> dict:
        event = self._require_event(event_id)
        self._require_owned_here(event)
        if event["archived_at"]:
            raise ConflictError("archived events are read-only")
        if not isinstance(fields, dict) or not fields:
            raise ValueError("fields must be a non-empty object")
        bad = set(fields) - set(_UPDATABLE)
        if bad:
            raise ValueError(f"cannot update {sorted(bad)}")
        clean = self._check_event_fields({**event, **fields})
        columns = {k: v for k, v in clean.items() if k != "rrule"}
        columns["all_day"] = int(columns["all_day"])
        columns["rrule_json"] = (json.dumps(clean["rrule"], sort_keys=True)
                                 if clean["rrule"] else None)
        self._db.update_with_revision(
            "events", event_id, self.scope_id, expected_revision, columns, actor=actor,
            action="update", details={"fields": sorted(fields)}, entity_type="event")
        return self.get_event(event_id)

    def archive_event(self, event_id: str, expected_revision: int, actor: str) -> dict:
        event = self._require_event(event_id)
        self._require_owned_here(event)
        if event["revision"] != expected_revision:
            raise ConflictError(f"event {event_id!r} not at revision {expected_revision}")
        if event["archived_at"]:
            raise ConflictError("event already archived")
        self._db.update_with_revision(
            "events", event_id, self.scope_id, expected_revision, {"archived_at": now()},
            actor=actor, action="archive", entity_type="event")
        return self.get_event(event_id)

    def add_event_exception(self, event_id: str, occurrence_local_date: str, kind: str,
                            actor: str, new_start_utc: str | None = None,
                            new_end_utc: str | None = None) -> dict:
        event = self._require_event(event_id)
        self._require_owned_here(event)
        if kind not in EXCEPTION_KINDS:
            raise ValueError(f"exception kind must be one of {EXCEPTION_KINDS}")
        local_date = _check_date(occurrence_local_date, "occurrence_local_date")
        if kind == "move":
            if new_start_utc is None:
                raise ValueError("a 'move' exception needs new_start_utc")
            new_start_utc = utc_iso(parse_utc(new_start_utc))
            new_end_utc = None if new_end_utc is None else utc_iso(parse_utc(new_end_utc))
            if new_end_utc is not None and new_end_utc < new_start_utc:
                raise ValueError("new_end_utc must not be before new_start_utc")
        elif new_start_utc is not None or new_end_utc is not None:
            raise ValueError("a 'skip' exception carries no new times")
        if date.fromisoformat(local_date) not in set(self._local_dates(
                event, date.fromisoformat(local_date))):
            raise ValueError(f"{local_date} is not an occurrence of this event")
        exception_id = new_id()
        with self._db.transaction() as cur:
            existing = cur.execute(
                "SELECT id FROM event_exceptions WHERE event_id = ?"
                " AND occurrence_local_date = ?", (event_id, local_date)).fetchone()
            if existing:
                raise ConflictError(f"an exception for {local_date} already exists")
            cur.execute(
                "INSERT INTO event_exceptions (id, scope_id, event_id, occurrence_local_date,"
                " kind, new_start_utc, new_end_utc, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (exception_id, self.scope_id, event_id, local_date, kind, new_start_utc,
                 new_end_utc, now()))
            self._db.audit(cur, "event", event_id, f"exception:{kind}", actor,
                           {"occurrence_local_date": local_date}, scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM event_exceptions WHERE id = ?", (exception_id,)))

    # -- reads ------------------------------------------------------------------------------

    def get_event(self, event_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_EVENT_COLUMNS} FROM events WHERE id = ? AND scope_id = ?",
            (event_id, self.scope_id))
        return None if row is None else _event_dict(row)

    def list_events(self, include_archived: bool = False) -> list[dict]:
        sql = f"SELECT {_EVENT_COLUMNS} FROM events WHERE scope_id = ?"
        if not include_archived:
            sql += " AND archived_at IS NULL"
        return [_event_dict(r) for r in self._db.query(sql + " ORDER BY start_utc, id",
                                                        (self.scope_id,))]

    def list_event_exceptions(self, event_id: str) -> list[dict]:
        return [dict(r) for r in self._db.query(
            "SELECT * FROM event_exceptions WHERE event_id = ? AND scope_id = ?"
            " ORDER BY occurrence_local_date", (event_id, self.scope_id))]

    def _local_dates(self, event: dict, stop: date) -> list[date]:
        tz = ZoneInfo(event["timezone"])
        start_local = parse_utc(event["start_utc"]).astimezone(tz)
        if not event["rrule"]:
            return [start_local.date()] if start_local.date() <= stop else []
        return list(occurrence_dates(start_local.date(), event["rrule"], stop))

    def _event_occurrences(self, event: dict, range_start: datetime,
                           range_end: datetime) -> list[dict]:
        tz = ZoneInfo(event["timezone"])
        start = parse_utc(event["start_utc"])
        end = parse_utc(event["end_utc"]) if event["end_utc"] else None
        duration = (end - start) if end else None
        exceptions = {e["occurrence_local_date"]: e
                      for e in self.list_event_exceptions(event["id"])}
        base = {"event_id": event["id"], "source": "event", "kind": event["kind"],
                "title": event["title"], "all_day": event["all_day"],
                "timezone": event["timezone"], "linked_type": event["linked_type"],
                "linked_id": event["linked_id"], "external_source": event["external_source"],
                "read_only": event["external_source"] is not None, "notes": event["notes"],
                "revision": event["revision"], "recurring": event["rrule"] is not None}
        out = []
        start_local = start.astimezone(tz)
        stop = range_end.astimezone(tz).date() + timedelta(days=1)
        for day in self._local_dates(event, stop):
            local = datetime(day.year, day.month, day.day, start_local.hour,
                             start_local.minute, start_local.second, tzinfo=tz, fold=0)
            instant = local.astimezone(UTC)
            occurrence_end = instant + duration if duration is not None else None
            exception = exceptions.get(day.isoformat())
            label = None
            if exception is not None:
                if exception["kind"] == "skip":
                    continue
                instant = parse_utc(exception["new_start_utc"])
                occurrence_end = (parse_utc(exception["new_end_utc"])
                                  if exception["new_end_utc"] else None)
                label = "move"
            last = occurrence_end or instant
            if instant >= range_end or last < range_start:
                continue
            out.append({**base, "id": f"{event['id']}:{day.isoformat()}",
                        "occurrence_local_date": day.isoformat(),
                        "start_utc": utc_iso(instant),
                        "end_utc": utc_iso(occurrence_end) if occurrence_end else None,
                        "exception": label})
        return out

    def _derived_items(self, range_start: datetime, range_end: datetime) -> list[dict]:
        first, last = range_start.date().isoformat(), range_end.date().isoformat()
        items = []
        for task in self.list_tasks():
            deadline = task.get("deadline")
            if not deadline or task["status"] == "Done" or not first <= deadline <= last:
                continue
            items.append(self._derived("task", "task_deadline", f"Deadline: {task['title']}",
                                       deadline, "task", task["id"],
                                       {"status": task["status"]}))
        for note in self._db.query(
                "SELECT id, title, json_extract(decision_json, '$.review_date') AS review_date"
                " FROM notes WHERE scope_id = ? AND kind = 'decision' AND archived_at IS NULL"
                " AND outcome IS NULL", (self.scope_id,)):
            if note["review_date"] and first <= note["review_date"] <= last:
                items.append(self._derived("decision", "decision_review",
                                           f"Decision review: {note['title']}",
                                           note["review_date"], "note", note["id"], {}))
        for row in self._db.query(
                "SELECT o.id, o.occurrence_utc, o.kind, o.job_id, j.purpose"
                " FROM job_occurrences o JOIN automation_jobs j ON j.id = o.job_id"
                " WHERE o.scope_id = ? AND o.status = 'due' AND o.occurrence_utc >= ?"
                " AND o.occurrence_utc < ? ORDER BY o.occurrence_utc",
                (self.scope_id, utc_iso(range_start), utc_iso(range_end))):
            items.append({"id": f"job:{row['id']}", "event_id": None, "source": "job",
                          "kind": "job_occurrence", "title": f"{row['purpose']} (due)",
                          "start_utc": row["occurrence_utc"], "end_utc": None,
                          "all_day": False, "timezone": "UTC", "linked_type": "job",
                          "linked_id": row["job_id"], "external_source": None,
                          "read_only": True, "notes": "", "exception": None,
                          "occurrence_id": row["id"], "occurrence_kind": row["kind"]})
        return items

    @staticmethod
    def _derived(source, kind, title, day, linked_type, linked_id, extra) -> dict:
        start = datetime.combine(date.fromisoformat(day), datetime.min.time(), tzinfo=UTC)
        return {"id": f"{source}:{linked_id}", "event_id": None, "source": source, "kind": kind,
                "title": title, "start_utc": utc_iso(start), "end_utc": None, "all_day": True,
                "timezone": "UTC", "linked_type": linked_type, "linked_id": linked_id,
                "external_source": None, "read_only": True, "notes": "", "exception": None,
                "local_date": day, **extra}

    def expand_events(self, range_start_utc, range_end_utc,
                      include_derived: bool = True) -> list[dict]:
        """Concrete occurrences in [start, end): stored events plus derived items."""
        range_start, range_end = parse_utc(range_start_utc), parse_utc(range_end_utc)
        if range_end <= range_start:
            raise ValueError("range end must be after range start")
        if range_end - range_start > timedelta(days=400):
            raise ValueError("range may span at most 400 days")
        items = []
        for event in self.list_events():
            items.extend(self._event_occurrences(event, range_start, range_end))
        if include_derived:
            items.extend(self._derived_items(range_start, range_end))
        items.sort(key=lambda o: (o["start_utc"], o["title"]))
        return items
