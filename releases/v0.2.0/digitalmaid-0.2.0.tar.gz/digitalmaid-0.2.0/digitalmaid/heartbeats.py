"""Worker liveness: one row per worker id, refreshed on every tick and while
an execution runs, so the UI can say "alive Ns ago" or "no worker running".
A heartbeat is observed state, not authority: the lease on the occurrence
is what decides who may complete it."""

from datetime import datetime, timedelta, timezone

from digitalmaid.scheduling import parse_utc, utc_iso

UTC = timezone.utc


class Heartbeats:
    """Mixin; expects ``self._db`` and ``self.scope_id``."""

    def heartbeat(self, worker_id: str, current_occurrence_id: str | None,
                  stale_after_seconds: int, now_utc: datetime | None = None) -> dict:
        if not isinstance(worker_id, str) or not worker_id.strip():
            raise ValueError("worker_id must be a non-empty string")
        if type(stale_after_seconds) is not int or stale_after_seconds < 1:
            raise ValueError("stale_after_seconds must be a positive int")
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        seen = utc_iso(now_utc)
        expires = utc_iso(now_utc + timedelta(seconds=stale_after_seconds))
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO worker_heartbeats (worker_id, scope_id, status,"
                " started_at_utc, last_seen_utc, expires_at_utc,"
                " current_occurrence_id) VALUES (?, ?, 'running', ?, ?, ?, ?)"
                " ON CONFLICT(worker_id) DO UPDATE SET status = 'running',"
                " scope_id = excluded.scope_id, last_seen_utc = excluded.last_seen_utc,"
                " expires_at_utc = excluded.expires_at_utc,"
                " current_occurrence_id = excluded.current_occurrence_id",
                (worker_id, self.scope_id, seen, seen, expires, current_occurrence_id))
        return self._worker(worker_id, now_utc)

    def stop_heartbeat(self, worker_id: str, now_utc: datetime | None = None) -> dict | None:
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        with self._db.transaction() as cur:
            cur.execute(
                "UPDATE worker_heartbeats SET status = 'stopped', last_seen_utc = ?,"
                " current_occurrence_id = NULL WHERE worker_id = ? AND scope_id = ?",
                (utc_iso(now_utc), worker_id, self.scope_id))
        return self._worker(worker_id, now_utc)

    def _worker(self, worker_id: str, now_utc: datetime) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM worker_heartbeats WHERE worker_id = ? AND scope_id = ?",
            (worker_id, self.scope_id))
        return None if row is None else self._worker_dict(row, now_utc)

    @staticmethod
    def _worker_dict(row, now_utc: datetime) -> dict:
        worker = dict(row)
        age = (now_utc - parse_utc(worker["last_seen_utc"])).total_seconds()
        worker["age_seconds"] = max(0, int(age))
        worker["alive"] = (worker["status"] == "running"
                           and worker["expires_at_utc"] > utc_iso(now_utc))
        return worker

    def list_workers(self, now_utc: datetime | None = None) -> list[dict]:
        now_utc = parse_utc(now_utc or datetime.now(UTC))
        return [self._worker_dict(r, now_utc) for r in self._db.query(
            "SELECT * FROM worker_heartbeats WHERE scope_id = ?"
            " ORDER BY last_seen_utc DESC, worker_id", (self.scope_id,))]
