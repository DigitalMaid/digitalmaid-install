"""Workspace root: identity manifest and the transactional file outbox.

The outbox protocol (ADR-002): write the blob to a ``.staging`` sibling,
fsync it, atomically rename it into place, fsync the directory, and only
then commit the database row that references it. A crash leaves either a
``.staging`` file or a final blob without a referencing row; both are
reported by ``orphaned_blobs`` and never deleted or overwritten silently.
"""

import hashlib
import json
import os
import re
import uuid
from pathlib import Path

from digitalmaid.db import now

MANIFEST_NAME = "workspace.json"
STAGING_SUFFIX = ".staging"
_OPAQUE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")


def check_opaque_id(value: str, what: str) -> str:
    """Reject anything that could act as a path component other than a name."""
    if not isinstance(value, str) or not _OPAQUE_ID.match(value):
        raise ValueError(f"{what} must match {_OPAQUE_ID.pattern}, got"
                         f" {value!r}")
    return value


def _fsync_dir(directory: Path) -> None:
    fd = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_atomic(path: Path, data: bytes) -> None:
    """Stage → fsync → rename → fsync(dir). Refuses to overwrite ``path``."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"refusing to overwrite immutable {path}")
    staged = path.with_name(path.name + STAGING_SUFFIX)
    with open(staged, "xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.rename(staged, path)
    _fsync_dir(path.parent)


def load_or_create_manifest(root: Path, schema_version: int) -> dict:
    path = Path(root) / MANIFEST_NAME
    if path.exists():
        manifest = json.loads(path.read_text(encoding="utf-8"))
        uuid.UUID(manifest["workspace_id"])
        return manifest
    manifest = {
        "workspace_id": str(uuid.uuid4()),
        "schema_version": int(schema_version),
        "created_at": now(),
    }
    write_atomic(path, (json.dumps(manifest, indent=2, sort_keys=True)
                        + "\n").encode("utf-8"))
    return manifest


def read_manifest(root: Path) -> dict:
    path = Path(root) / MANIFEST_NAME
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def update_manifest(root: Path, **fields) -> dict:
    """Rewrite workspace.json atomically with ``fields`` merged in (no secrets)."""
    path = Path(root) / MANIFEST_NAME
    manifest = {**read_manifest(root), **fields}
    staged = path.with_name(path.name + STAGING_SUFFIX)
    data = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
    with open(staged, "wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(staged, path)
    _fsync_dir(path.parent)
    return manifest


class Outbox:
    """Blob writer rooted at ``<root>/outputs``; paths are id-derived only."""

    def __init__(self, root: Path):
        self.root = Path(root)

    def output_blob_path(self, scope_id: str, output_id: str,
                         version: int) -> str:
        check_opaque_id(scope_id, "scope_id")
        check_opaque_id(output_id, "output_id")
        if type(version) is not int or version < 1:
            raise ValueError("version must be a positive int")
        return f"outputs/{scope_id}/{output_id}/{version}/content.md"

    def stage_output(self, scope_id: str, output_id: str, version: int,
                     content: str) -> tuple[str, str]:
        """Write the blob durably; returns (relative_path, sha256).

        The caller commits the database row afterwards. If that commit
        fails the blob stays behind as an orphan for recovery.
        """
        relative = self.output_blob_path(scope_id, output_id, version)
        data = content.encode("utf-8")
        write_atomic(self.root / relative, data)
        return relative, hashlib.sha256(data).hexdigest()

    def read_output(self, relative_path: str) -> str | None:
        target = self._contained(relative_path, "outputs")
        if target is None or not target.is_file():
            return None
        return target.read_text(encoding="utf-8")

    def capture_blob_path(self, scope_id: str, capture_id: str, extension: str) -> str:
        check_opaque_id(scope_id, "scope_id")
        check_opaque_id(capture_id, "capture_id")
        if not re.fullmatch(r"[a-z0-9]{1,8}", extension or ""):
            raise ValueError(f"extension must come from the allow-list, got {extension!r}")
        return f"captures/{scope_id}/{capture_id}/original.{extension}"

    def stage_capture_original(self, scope_id: str, capture_id: str, extension: str,
                               data: bytes) -> tuple[str, str]:
        """Write a capture original durably; returns (relative_path, sha256).

        Same protocol as ``stage_output``: the file lands before the row that
        references it is committed, and an existing file is never overwritten.
        """
        relative = self.capture_blob_path(scope_id, capture_id, extension)
        write_atomic(self.root / relative, data)
        return relative, hashlib.sha256(data).hexdigest()

    def read_capture_original(self, relative_path: str) -> bytes | None:
        target = self._contained(relative_path, "captures")
        if target is None or not target.is_file():
            return None
        return target.read_bytes()

    def _contained(self, relative_path: str, subdir: str) -> Path | None:
        """Resolve a stored relative path under ``<root>/<subdir>``, refusing
        absolute paths, ``..`` segments, symlinks and anything resolving outside."""
        if not isinstance(relative_path, str) or not relative_path:
            return None
        allowed_root = (self.root / subdir).resolve()
        candidate = Path(relative_path)
        if candidate.is_absolute() or ".." in candidate.parts:
            return None
        target = self.root / candidate
        if target.is_symlink():
            return None
        try:
            target.resolve().relative_to(allowed_root)
        except ValueError:
            return None
        return target

    def orphaned_blobs(self, scope_id: str, referenced: set[str]) -> list[str]:
        """Files under this scope's outputs dir not referenced by the DB."""
        check_opaque_id(scope_id, "scope_id")
        scope_dir = self.root / "outputs" / scope_id
        if not scope_dir.is_dir():
            return []
        orphans = []
        for path in sorted(scope_dir.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(self.root).as_posix()
            if relative not in referenced:
                orphans.append(relative)
        return orphans
