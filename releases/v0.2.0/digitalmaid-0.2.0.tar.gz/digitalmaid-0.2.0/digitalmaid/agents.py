"""Portable agent role definitions: ``<root>/definitions/agents/<id>.json``.

The files are authoritative for their text (ADR-002). The package ships a
few built-in roles that are copied into a fresh root once; existing files
are never overwritten.
"""

import json
from pathlib import Path

from digitalmaid.workspace import check_opaque_id, write_atomic

AGENT_DEFINITIONS_DIR = Path("definitions") / "agents"
BUILTIN_DIR = Path(__file__).parent / "definitions" / "agents"
MODEL_POLICY_KINDS = ("fixture", "live")
_REQUIRED = ("id", "name", "responsibility", "allowed_actions", "model_policy")


def validate_definition(data, expected_id: str | None = None) -> dict:
    if not isinstance(data, dict):
        raise ValueError("agent definition must be an object")
    missing = [k for k in _REQUIRED if k not in data]
    if missing:
        raise ValueError(f"agent definition missing {missing}")
    check_opaque_id(data["id"], "agent id")
    if expected_id is not None and data["id"] != expected_id:
        raise ValueError(
            f"agent definition id {data['id']!r} does not match file name"
            f" {expected_id!r}")
    for name in ("name", "responsibility"):
        if not isinstance(data[name], str) or not data[name].strip():
            raise ValueError(f"agent {name} must be a non-empty string")
    actions = data["allowed_actions"]
    if not isinstance(actions, list) or any(
            not isinstance(a, str) or not a.strip() for a in actions):
        raise ValueError("allowed_actions must be a list of strings")
    policy = data["model_policy"]
    if not isinstance(policy, dict) or policy.get("kind") not in MODEL_POLICY_KINDS:
        raise ValueError(f"model_policy.kind must be one of {MODEL_POLICY_KINDS}")
    return data


def ensure_builtin_definitions(root: Path) -> list[str]:
    """Copy packaged role files the root lacks; returns the ids written."""
    target = Path(root) / AGENT_DEFINITIONS_DIR
    written = []
    for source in sorted(BUILTIN_DIR.glob("*.json")):
        destination = target / source.name
        if destination.exists():
            continue
        validate_definition(json.loads(source.read_text(encoding="utf-8")),
                            source.stem)
        write_atomic(destination, source.read_bytes())
        written.append(source.stem)
    return written


class Agents:
    """Mixin; expects ``self.root``."""

    def list_agents(self) -> list[dict]:
        directory = self.root / AGENT_DEFINITIONS_DIR
        if not directory.is_dir():
            return []
        agents = []
        for path in sorted(directory.glob("*.json")):
            if path.is_symlink():
                raise ValueError(f"refusing symlinked definition {path.name}")
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path.name}: invalid JSON: {exc}") from exc
            agents.append({**validate_definition(data, path.stem),
                           "definition_path": (AGENT_DEFINITIONS_DIR / path.name).as_posix()})
        return agents

    def get_agent(self, agent_id: str) -> dict | None:
        return next((a for a in self.list_agents() if a["id"] == agent_id), None)
