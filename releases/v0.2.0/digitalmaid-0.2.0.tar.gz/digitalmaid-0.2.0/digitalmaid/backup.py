"""Consistent backup and verified restore of one workspace root (ADR-007).

``create_backup`` copies the live database with SQLite's online backup API
into a temporary file (never a raw copy of a live DB/WAL), then writes one
``tar.gz`` holding that copy, the immutable ``outputs/`` and ``captures/``
blobs, the canonical ``definitions/`` and ``knowledge/`` files, ``workspace.json`` and a
``MANIFEST.json`` with a sha256 per file, the schema version and the app
version. ``restore_backup`` only ever targets an empty root, re-hashes every
file before trusting it, refuses a manifest newer than this app understands
and then applies pending migrations by opening the database.
"""

import hashlib
import io
import json
import sqlite3
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from digitalmaid import __version__
from digitalmaid.db import MIGRATIONS, SCHEMA_VERSION, Database
from digitalmaid.workspace import MANIFEST_NAME, read_manifest, update_manifest

MANIFEST_MEMBER = "MANIFEST.json"
DB_MEMBER = "state/state.sqlite"
_COPIED_DIRS = ("outputs", "definitions", "knowledge", "attachments", "captures")


class BackupError(Exception):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_member(name: str) -> None:
    parts = Path(name).parts
    if not parts or Path(name).is_absolute() or ".." in parts or name.startswith("/"):
        raise BackupError(f"unsafe path in archive: {name!r}")


def pending_migrations(root) -> list[dict]:
    """Migrations not yet journaled in ``root``; opens nothing for writing."""
    db_path = Path(root) / "state" / "state.sqlite"
    applied: set[int] = set()
    if db_path.is_file():
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type = 'table'"
                                  " AND name = 'schema_migrations'").fetchone()
            if exists:
                applied = {r[0] for r in conn.execute("SELECT version FROM schema_migrations")}
        finally:
            conn.close()
    return [{"version": version, "summary": _summary(script)}
            for version, script in enumerate(MIGRATIONS, start=1) if version not in applied]


def _summary(script: str) -> str:
    lines = [l.strip() for l in script.strip().splitlines()]
    tables = [l.split()[2] for l in lines if l.startswith("CREATE TABLE")]
    alters = sorted({l.split()[2] for l in lines if l.startswith("ALTER TABLE")})
    parts = []
    if tables:
        parts.append("creates " + ", ".join(tables))
    if alters:
        parts.append("alters " + ", ".join(alters))
    return "; ".join(parts) or "index/data changes"


def create_backup(root, out_path) -> dict:
    root, out_path = Path(root), Path(out_path)
    db_path = root / "state" / "state.sqlite"
    if not db_path.is_file() or not (root / MANIFEST_NAME).is_file():
        raise BackupError(f"{root} is not a DigitalMaid workspace root")
    if out_path.exists():
        raise BackupError(f"refusing to overwrite {out_path}")
    workspace = read_manifest(root)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="dm-backup-") as tmp:
        snapshot = Path(tmp) / "state.sqlite"
        source = sqlite3.connect(db_path)
        try:
            target = sqlite3.connect(snapshot)
            try:
                source.backup(target)
            finally:
                target.close()
        finally:
            source.close()
        files = [{"path": DB_MEMBER, "sha256": _sha256(snapshot), "size": snapshot.stat().st_size,
                  "source": snapshot}]
        files.append({"path": MANIFEST_NAME, "sha256": _sha256(root / MANIFEST_NAME),
                      "size": (root / MANIFEST_NAME).stat().st_size,
                      "source": root / MANIFEST_NAME})
        for name in _COPIED_DIRS:
            directory = root / name
            if not directory.is_dir():
                continue
            for path in sorted(p for p in directory.rglob("*") if p.is_file()
                               and not p.is_symlink()):
                relative = path.relative_to(root).as_posix()
                files.append({"path": relative, "sha256": _sha256(path),
                              "size": path.stat().st_size, "source": path})
        manifest = {
            "format": "digitalmaid-backup/1",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "app_version": __version__,
            "schema_version": SCHEMA_VERSION,
            "workspace_id": workspace.get("workspace_id"),
            "files": [{k: f[k] for k in ("path", "sha256", "size")} for f in files],
        }
        manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
        staging = out_path.with_name(out_path.name + ".staging")
        with tarfile.open(staging, "w:gz") as tar:
            info = tarfile.TarInfo(MANIFEST_MEMBER)
            info.size = len(manifest_bytes)
            info.mtime = int(datetime.now(timezone.utc).timestamp())
            tar.addfile(info, io.BytesIO(manifest_bytes))
            for entry in files:
                tar.add(entry["source"], arcname=entry["path"], recursive=False)
        staging.replace(out_path)
    update_manifest(root, last_backup_at=manifest["created_at"],
                    last_backup_path=str(out_path))
    return manifest


def _read_manifest_member(tar: tarfile.TarFile) -> dict:
    try:
        member = tar.getmember(MANIFEST_MEMBER)
    except KeyError:
        raise BackupError("archive has no MANIFEST.json") from None
    manifest = json.loads(tar.extractfile(member).read())
    if not isinstance(manifest.get("files"), list) or "schema_version" not in manifest:
        raise BackupError("MANIFEST.json is incomplete")
    return manifest


def verify_backup(archive) -> dict:
    """Re-hash every member against the manifest without extracting to disk."""
    archive = Path(archive)
    if not archive.is_file():
        raise BackupError(f"{archive} does not exist")
    with tarfile.open(archive) as tar:
        manifest = _read_manifest_member(tar)
        members = {m.name: m for m in tar.getmembers()}
        for name in members:
            _safe_member(name)
        for entry in manifest["files"]:
            member = members.get(entry["path"])
            if member is None or not member.isfile():
                raise BackupError(f"missing file in archive: {entry['path']}")
            digest = hashlib.sha256()
            with tar.extractfile(member) as handle:
                for chunk in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(chunk)
            if digest.hexdigest() != entry["sha256"]:
                raise BackupError(f"sha256 mismatch for {entry['path']}")
        extra = set(members) - {e["path"] for e in manifest["files"]} - {MANIFEST_MEMBER}
        extra = {n for n in extra if members[n].isfile()}
        if extra:
            raise BackupError(f"archive contains files not in the manifest: {sorted(extra)}")
    return manifest


def restore_backup(archive, new_root) -> dict:
    """Extract into an empty root after verification, then migrate."""
    new_root = Path(new_root)
    if new_root.exists() and any(new_root.iterdir()):
        raise BackupError(f"restore target {new_root} is not empty")
    manifest = verify_backup(archive)
    if int(manifest["schema_version"]) > SCHEMA_VERSION:
        raise BackupError(
            f"backup schema_version {manifest['schema_version']} is newer than this app"
            f" supports ({SCHEMA_VERSION}); upgrade DigitalMaid first")
    new_root.mkdir(parents=True, exist_ok=True)
    wanted = {e["path"] for e in manifest["files"]}
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if member.name in wanted and member.isfile():
                tar.extract(member, path=new_root, filter="data")
    to_apply = pending_migrations(new_root)
    Database(new_root).close()  # applies pending migrations, journaled
    for path in manifest["files"]:
        if _sha256(new_root / path["path"]) != path["sha256"] and path["path"] != DB_MEMBER:
            raise BackupError(f"post-restore hash mismatch for {path['path']}")
    return {"root": str(new_root), "schema_version": SCHEMA_VERSION,
            "backup_schema_version": manifest["schema_version"],
            "applied_migrations": [m["version"] for m in to_apply],
            "files": len(manifest["files"])}
