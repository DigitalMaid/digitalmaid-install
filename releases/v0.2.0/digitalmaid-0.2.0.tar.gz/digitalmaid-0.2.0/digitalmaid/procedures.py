"""Versioned procedures (SOPs), instantiation into dependent tasks, and
learning proposals that only a human can turn into a new version.

A procedure version is immutable once published: its canonical JSON hash is
stored with it and publishing version n+1 never touches version n.
"""

import hashlib
import json

from digitalmaid.db import new_id, now
from digitalmaid.errors import InvariantError

PROCEDURE_STATUSES = ("draft", "active", "retired")
PROPOSAL_STATUSES = ("open", "applied", "rejected")
STEP_FIELDS = ("title", "instruction_md", "expected_evidence", "role")
HUMAN_ROLE = "human"

_PROCEDURE_COLUMNS = ("id, scope_id, title, purpose, status, current_version,"
                      " created_at, updated_at, revision")


def canonical_hash(steps: list[dict], inputs: list[str], outputs: list[str]) -> str:
    payload = json.dumps({"steps": steps, "inputs": inputs, "outputs": outputs},
                         sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _clean_names(values, name: str) -> list[str]:
    if values is None:
        return []
    if not isinstance(values, list) or any(
            not isinstance(v, str) or not v.strip() for v in values):
        raise ValueError(f"{name} must be a list of non-empty strings")
    return [v.strip() for v in values]


def _version_dict(row) -> dict:
    version = dict(row)
    version["steps"] = json.loads(version.pop("steps_json"))
    version["inputs"] = json.loads(version.pop("inputs_json"))
    version["outputs"] = json.loads(version.pop("outputs_json"))
    return version


class Procedures:
    """Mixin; expects ``self._db``, ``self.scope_id``, Tasks and Agents."""

    # -- validation -------------------------------------------------------------

    def _clean_steps(self, steps) -> list[dict]:
        if not isinstance(steps, list) or not steps:
            raise ValueError("steps must be a non-empty list")
        agent_ids = {a["id"] for a in self.list_agents()}
        cleaned = []
        for index, step in enumerate(steps):
            if not isinstance(step, dict) or set(step) != set(STEP_FIELDS):
                raise ValueError(
                    f"step {index} must have exactly the fields {STEP_FIELDS}")
            for field in ("title", "expected_evidence", "role"):
                if not isinstance(step[field], str) or not step[field].strip():
                    raise ValueError(f"step {index}: {field} must be a non-empty string")
            if not isinstance(step["instruction_md"], str):
                raise ValueError(f"step {index}: instruction_md must be a string")
            role = step["role"].strip()
            if role != HUMAN_ROLE and role not in agent_ids:
                raise ValueError(
                    f"step {index}: role must be 'human' or a defined agent id,"
                    f" got {role!r}")
            cleaned.append({"title": step["title"].strip(),
                            "instruction_md": step["instruction_md"],
                            "expected_evidence": step["expected_evidence"].strip(),
                            "role": role})
        return cleaned

    @staticmethod
    def _clean_text(value, name: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be a non-empty string")
        return value.strip()

    # -- procedures and versions ----------------------------------------------------

    def create_procedure(self, title: str, purpose: str, created_by: str,
                         steps: list[dict], inputs=None, outputs=None,
                         changelog: str = "initial version") -> dict:
        title = self._clean_text(title, "title")
        purpose = self._clean_text(purpose, "purpose")
        created_by = self._clean_text(created_by, "created_by")
        procedure_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO procedures (id, scope_id, title, purpose, status,"
                " current_version, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, 'draft', 1, ?, ?)",
                (procedure_id, self.scope_id, title, purpose, stamp, stamp))
            self._db.audit(cur, "procedure", procedure_id, "create", created_by,
                           scope_id=self.scope_id)
            self._publish(cur, procedure_id, None, 1, steps, inputs, outputs,
                          changelog, created_by)
        return self.get_procedure(procedure_id)

    def _publish(self, cur, procedure_id: str, expected_revision: int | None,
                 version: int, steps, inputs, outputs, changelog: str,
                 created_by: str) -> dict:
        """Insert an immutable version row; ``expected_revision`` None means
        the procedure row was just inserted with this version."""
        cleaned_steps = self._clean_steps(steps)
        cleaned_inputs = _clean_names(inputs, "inputs")
        cleaned_outputs = _clean_names(outputs, "outputs")
        changelog = self._clean_text(changelog, "changelog")
        created_by = self._clean_text(created_by, "created_by")
        version_id = new_id()
        cur.execute(
            "INSERT INTO procedure_versions (id, scope_id, procedure_id, version,"
            " steps_json, inputs_json, outputs_json, changelog, created_by,"
            " created_at, sha256) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (version_id, self.scope_id, procedure_id, version,
             json.dumps(cleaned_steps), json.dumps(cleaned_inputs),
             json.dumps(cleaned_outputs), changelog, created_by, now(),
             canonical_hash(cleaned_steps, cleaned_inputs, cleaned_outputs)))
        if expected_revision is None:
            self._db.audit(cur, "procedure", procedure_id, f"publish:{version}",
                           created_by, {"version_id": version_id},
                           scope_id=self.scope_id)
        else:
            self._db.update_with_revision(
                "procedures", procedure_id, self.scope_id, expected_revision,
                {"current_version": version}, actor=created_by,
                action=f"publish:{version}", details={"version_id": version_id},
                cur=cur, entity_type="procedure")
        return _version_dict(cur.execute(
            "SELECT * FROM procedure_versions WHERE id = ?", (version_id,)).fetchone())

    def publish_procedure_version(self, procedure_id: str, expected_revision: int,
                                  steps, inputs, outputs, changelog: str,
                                  created_by: str) -> dict:
        procedure = self._require_procedure(procedure_id)
        if procedure["status"] == "retired":
            raise InvariantError("retired procedures cannot publish new versions")
        with self._db.transaction() as cur:
            self._publish(cur, procedure_id, expected_revision,
                          procedure["current_version"] + 1, steps, inputs,
                          outputs, changelog, created_by)
        return self.get_procedure(procedure_id)

    def get_procedure(self, procedure_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_PROCEDURE_COLUMNS} FROM procedures"
            " WHERE id = ? AND scope_id = ?", (procedure_id, self.scope_id))
        return None if row is None else dict(row)

    def _require_procedure(self, procedure_id: str) -> dict:
        procedure = self.get_procedure(procedure_id)
        if procedure is None:
            raise LookupError(
                f"procedure {procedure_id!r} not found in scope {self.scope_id!r}")
        return procedure

    def list_procedures(self) -> list[dict]:
        return [dict(r) for r in self._db.query(
            f"SELECT {_PROCEDURE_COLUMNS} FROM procedures WHERE scope_id = ?"
            " ORDER BY created_at, rowid", (self.scope_id,))]

    def get_procedure_version(self, procedure_id: str, version: int) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM procedure_versions WHERE procedure_id = ?"
            " AND version = ? AND scope_id = ?",
            (procedure_id, version, self.scope_id))
        return None if row is None else _version_dict(row)

    def list_procedure_versions(self, procedure_id: str) -> list[dict]:
        self._require_procedure(procedure_id)
        return [_version_dict(r) for r in self._db.query(
            "SELECT * FROM procedure_versions WHERE procedure_id = ?"
            " AND scope_id = ? ORDER BY version", (procedure_id, self.scope_id))]

    def _set_procedure_status(self, procedure_id: str, status: str,
                              allowed_from: tuple[str, ...], actor: str) -> dict:
        procedure = self._require_procedure(procedure_id)
        if procedure["status"] not in allowed_from:
            raise InvariantError(
                f"procedure is {procedure['status']}; cannot move to {status}")
        self._db.update_with_revision(
            "procedures", procedure_id, self.scope_id, procedure["revision"],
            {"status": status}, actor=actor, action=f"status:{status}",
            entity_type="procedure")
        return self.get_procedure(procedure_id)

    def activate_procedure(self, procedure_id: str, actor: str) -> dict:
        return self._set_procedure_status(procedure_id, "active", ("draft",), actor)

    def retire_procedure(self, procedure_id: str, actor: str) -> dict:
        return self._set_procedure_status(procedure_id, "retired",
                                          ("draft", "active"), actor)

    def procedure_detail(self, procedure_id: str) -> dict:
        procedure = self._require_procedure(procedure_id)
        versions = self.list_procedure_versions(procedure_id)
        current = next((v for v in versions
                        if v["version"] == procedure["current_version"]), None)
        return {**procedure, "current": current, "versions": versions,
                "proposals": self.list_learning_proposals(procedure_id),
                "instantiations": self._instantiations(procedure_id)}

    def _instantiations(self, procedure_id: str) -> list[dict]:
        return [dict(r) for r in self._db.query(
            "SELECT t.project_id, p.title AS project_title, t.procedure_version,"
            " COUNT(*) AS steps, SUM(t.status = 'Done') AS done,"
            " MIN(t.created_at) AS created_at"
            " FROM tasks t JOIN projects p ON p.id = t.project_id"
            " WHERE t.procedure_id = ? AND t.scope_id = ?"
            " GROUP BY t.project_id, t.procedure_version, t.created_at"
            " ORDER BY MIN(t.created_at) DESC", (procedure_id, self.scope_id))]

    # -- instantiate ---------------------------------------------------------------

    def instantiate_procedure(self, procedure_id: str, version: int,
                              project_id: str, owner: str,
                              actor: str | None = None) -> list[dict]:
        """One Plan task per step, each depending on the previous step."""
        procedure = self._require_procedure(procedure_id)
        owner = self._clean_text(owner, "owner")
        if procedure["status"] == "retired":
            raise InvariantError("procedure is retired and cannot be instantiated")
        definition = self.get_procedure_version(procedure_id, version)
        if definition is None:
            raise LookupError(
                f"procedure {procedure_id!r} has no version {version}")
        tasks = []
        with self._db.transaction() as cur:
            for index, step in enumerate(definition["steps"]):
                task = self.create_task(
                    project_id, step["title"], owner, step["instruction_md"],
                    [step["expected_evidence"]], 2,
                    procedure=(procedure_id, version, index), cur=cur)
                if tasks:
                    self.add_task_dependency(task["id"], tasks[-1]["id"],
                                             actor or owner, cur=cur)
                tasks.append(task)
            self._db.audit(cur, "procedure", procedure_id, "instantiate",
                           actor or owner,
                           {"version": version, "project_id": project_id,
                            "task_ids": [t["id"] for t in tasks]},
                           scope_id=self.scope_id)
        return tasks

    # -- learning proposals -----------------------------------------------------------

    def propose_learning(self, procedure_id: str, text: str, from_task_id: str,
                         actor: str) -> dict:
        self._require_procedure(procedure_id)
        text = self._clean_text(text, "text")
        actor = self._clean_text(actor, "actor")
        task = self.get_task(from_task_id)
        if task is None or task["procedure_id"] != procedure_id:
            raise ValueError(
                f"task {from_task_id!r} did not come from procedure {procedure_id!r}")
        proposal_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO learning_proposals (id, scope_id, procedure_id, text,"
                " from_task_id, proposed_by, status, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, 'open', ?, ?)",
                (proposal_id, self.scope_id, procedure_id, text, from_task_id,
                 actor, stamp, stamp))
            self._db.audit(cur, "learning_proposal", proposal_id, "propose", actor,
                           {"procedure_id": procedure_id, "from_task_id": from_task_id},
                           scope_id=self.scope_id)
        return self.get_learning_proposal(proposal_id)

    def get_learning_proposal(self, proposal_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM learning_proposals WHERE id = ? AND scope_id = ?",
            (proposal_id, self.scope_id))
        return None if row is None else dict(row)

    def _require_proposal(self, proposal_id: str) -> dict:
        proposal = self.get_learning_proposal(proposal_id)
        if proposal is None:
            raise LookupError(
                f"proposal {proposal_id!r} not found in scope {self.scope_id!r}")
        if proposal["status"] != "open":
            raise InvariantError(f"proposal is already {proposal['status']}")
        return proposal

    def list_learning_proposals(self, procedure_id: str) -> list[dict]:
        self._require_procedure(procedure_id)
        return [dict(r) for r in self._db.query(
            "SELECT * FROM learning_proposals WHERE procedure_id = ?"
            " AND scope_id = ? ORDER BY created_at, rowid",
            (procedure_id, self.scope_id))]

    def apply_learning_proposal(self, proposal_id: str, actor: str, steps, inputs,
                                outputs, changelog: str,
                                expected_revision: int) -> dict:
        """A human publishes a new version whose changelog cites the proposal."""
        actor = self._clean_text(actor, "actor")
        if actor in {a["id"] for a in self.list_agents()}:
            raise ValueError("applying a proposal is a human act; actor is an agent role")
        proposal = self._require_proposal(proposal_id)
        if not isinstance(changelog, str) or proposal_id not in changelog:
            raise ValueError("changelog must reference the proposal id")
        procedure = self._require_procedure(proposal["procedure_id"])
        if procedure["status"] == "retired":
            raise InvariantError("retired procedures cannot publish new versions")
        new_version = procedure["current_version"] + 1
        with self._db.transaction() as cur:
            self._publish(cur, procedure["id"], expected_revision, new_version,
                          steps, inputs, outputs, changelog, actor)
            self._db.update_with_revision(
                "learning_proposals", proposal_id, self.scope_id,
                proposal["revision"],
                {"status": "applied", "decided_by": actor,
                 "applied_version": new_version},
                actor=actor, action="apply",
                details={"applied_version": new_version}, cur=cur,
                entity_type="learning_proposal")
        applied = self.get_learning_proposal(proposal_id)
        applied["applied_by"] = applied["decided_by"]
        return applied

    def reject_learning_proposal(self, proposal_id: str, actor: str) -> dict:
        actor = self._clean_text(actor, "actor")
        proposal = self._require_proposal(proposal_id)
        self._db.update_with_revision(
            "learning_proposals", proposal_id, self.scope_id, proposal["revision"],
            {"status": "rejected", "decided_by": actor}, actor=actor,
            action="reject", entity_type="learning_proposal")
        return self.get_learning_proposal(proposal_id)
