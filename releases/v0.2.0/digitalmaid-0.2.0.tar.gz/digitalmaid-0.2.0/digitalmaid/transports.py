"""Provider transports (ADR-008): the only code that talks to a model API.

``OpenAICompatibleTransport`` speaks the OpenAI chat-completions JSON shape,
which OpenRouter and OpenAI both accept, over stdlib ``urllib``. The
credential is referenced by the *name* of an environment variable and read
at call time only: it is never stored on the object, logged, persisted or
echoed in an error. Provider, model, usage and cost in the result come from
the response body — evidence of the actual invocation — never from prompt
text or from what the model says about itself.
"""

import json
import os
import re
import socket
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from decimal import ROUND_CEILING, Decimal

from digitalmaid.errors import ConfigurationError

_MAX_ERROR_BODY = 2000
_BEARER = re.compile(r"Bearer\s+\S+")
_USAGE_KEYS = ("prompt_tokens", "completion_tokens", "total_tokens")


class TransportError(Exception):
    """The provider answered non-2xx, timed out, or returned an unusable body."""

    def __init__(self, status: int | None, safe_message: str):
        self.status = status
        self.safe_message = safe_message
        super().__init__(safe_message)


@dataclass(frozen=True)
class TransportResult:
    text: str
    provider: str | None
    model: str | None
    usage: dict = field(default_factory=dict)
    cost_minor: int | None = None
    currency: str | None = None
    raw_id: str | None = None


def credential_env_name(credential_ref: str | None) -> str | None:
    """Accept ``NAME`` or the older ``env:NAME`` spelling; return ``NAME``."""
    if not isinstance(credential_ref, str) or not credential_ref.strip():
        return None
    name = credential_ref.strip()
    return name[4:] if name.startswith("env:") else name


def redact(text: str, secret: str | None) -> str:
    text = _BEARER.sub("Bearer [redacted]", text)
    if secret:
        text = text.replace(secret, "[redacted]")
    return text


def _cost_minor(cost) -> int | None:
    """Currency minor units, rounded up so a real cost never reads as free."""
    if cost is None:
        return None
    try:
        amount = Decimal(str(cost)) * 100
    except (ArithmeticError, ValueError):
        return None
    return int(amount.quantize(Decimal(1), rounding=ROUND_CEILING))


class OpenAICompatibleTransport:
    def __init__(self, base_url: str, credential_ref: str, timeout_seconds: float,
                 extra_body: dict | None = None):
        parsed = urllib.parse.urlparse(base_url or "")
        if parsed.scheme not in ("https", "http") or not parsed.hostname:
            raise ValueError("base_url must be an http(s) URL")
        name = credential_env_name(credential_ref)
        if name is None:
            raise ValueError("credential_ref must name an environment variable")
        if not isinstance(timeout_seconds, (int, float)) or timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        self.base_url = base_url.rstrip("/")
        self.host = parsed.hostname
        self.credential_ref = name
        self.timeout_seconds = timeout_seconds
        self.extra_body = dict(extra_body or {})

    def __repr__(self) -> str:
        return (f"OpenAICompatibleTransport(base_url={self.base_url!r},"
                f" credential_ref={self.credential_ref!r},"
                f" timeout_seconds={self.timeout_seconds!r})")

    def _secret(self) -> str:
        value = os.environ.get(self.credential_ref)
        if not value:
            raise ConfigurationError(
                f"credential environment variable {self.credential_ref} is not set")
        return value

    def complete(self, model: str, messages: list[dict], max_tokens: int) -> TransportResult:
        if not isinstance(model, str) or not model.strip():
            raise ValueError("model must be a non-empty string")
        if type(max_tokens) is not int or max_tokens < 1:
            raise ValueError("max_tokens must be a positive int")
        secret = self._secret()
        payload = {**self.extra_body, "model": model, "messages": messages,
                   "max_tokens": max_tokens}
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions", method="POST",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {secret}",
                     "Content-Type": "application/json",
                     "Accept": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                status = getattr(response, "status", 200)
                raw = response.read()
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read(_MAX_ERROR_BODY).decode("utf-8", "replace")
            except Exception:  # body unreadable; the status is still evidence
                body = ""
            raise TransportError(exc.code, redact(
                f"HTTP {exc.code} from {self.host}: {body[:_MAX_ERROR_BODY]}", secret)) from None
        except (socket.timeout, TimeoutError):
            raise TransportError(None, f"request to {self.host} timed out after"
                                       f" {self.timeout_seconds} s") from None
        except urllib.error.URLError as exc:
            raise TransportError(None, redact(
                f"could not reach {self.host}: {exc.reason}", secret)) from None
        except OSError as exc:
            raise TransportError(None, redact(
                f"network error talking to {self.host}: {exc}", secret)) from None
        return self._parse(raw, status, secret)

    def _parse(self, raw: bytes, status: int, secret: str) -> TransportResult:
        try:
            body = json.loads(raw.decode("utf-8"))
            choice = body["choices"][0]
            text = choice["message"]["content"]
            if not isinstance(text, str):
                raise TypeError("content is not text")
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise TransportError(status, redact(
                f"malformed response from {self.host}: {exc}", secret)) from None
        usage_in = body.get("usage") if isinstance(body.get("usage"), dict) else {}
        usage = {k: usage_in[k] for k in _USAGE_KEYS
                 if isinstance(usage_in.get(k), int)}
        cost_minor = _cost_minor(usage_in.get("cost"))
        provider = body.get("provider") if isinstance(body.get("provider"), str) else None
        model = body.get("model") if isinstance(body.get("model"), str) else None
        raw_id = body.get("id") if isinstance(body.get("id"), str) else None
        return TransportResult(text=text, provider=provider or self.host, model=model,
                               usage=usage, cost_minor=cost_minor,
                               currency="USD" if cost_minor is not None else None,
                               raw_id=raw_id)
