"""Domain exceptions."""


class ConflictError(Exception):
    """A write found a different revision than the caller expected."""


class InvariantError(Exception):
    """A state transition would violate a PDCC/5M invariant.

    ``reasons`` lists every specific violation so callers can show all of
    them at once instead of discovering them one by one.
    """

    def __init__(self, reasons):
        if isinstance(reasons, str):
            reasons = [reasons]
        self.reasons = list(reasons)
        super().__init__("; ".join(self.reasons))


class ConfigurationError(Exception):
    """A live adapter cannot run because credentials or permissions are absent."""
