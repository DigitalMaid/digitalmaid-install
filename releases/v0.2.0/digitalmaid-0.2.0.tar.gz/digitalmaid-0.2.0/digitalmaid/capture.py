"""Capture Inbox: a raw original plus drafts a human turns into something.

A capture keeps what arrived (text, a link, an uploaded file or a transcript)
exactly as it arrived. Originals are immutable blobs written once under
``captures/<scope>/<capture_id>/original.<ext>`` with the outbox protocol;
the extension comes from the MIME allow-list, never from the client's file
name, which is kept only as display ``title``. Drafts are append-only
versions; converting creates the target through the ordinary Store methods
(so every gate still applies) and links the capture to it. Nothing is
deleted: archiving is reversible.

The application never transcribes audio. A transcript's ``body_text`` is
whatever a human or Hermes supplied (docs/HERMES-INTEGRATION.md).
"""

from urllib.parse import urlsplit

from digitalmaid.db import new_id, now
from digitalmaid.errors import ConflictError, InvariantError
from digitalmaid.knowledge import like_snippet, search_tokens
from digitalmaid.workspace import read_manifest

CAPTURE_KINDS = ("text", "link", "file", "transcript")
CAPTURE_SOURCES = ("ui", "api", "email", "hermes", "import")
CAPTURE_STATUSES = ("inbox", "drafting", "converted", "archived")
CONVERT_TARGETS = ("task", "note", "journal", "decision", "event", "goal")
OPEN_STATUSES = ("inbox", "drafting")
# MIME type → file extension. The extension is the only thing derived from
# client input that touches a path, and only through this table.
ALLOWED_UPLOAD_TYPES = {
    "text/plain": "txt",
    "text/markdown": "md",
    "application/pdf": "pdf",
    "image/png": "png",
    "image/jpeg": "jpg",
    "audio/ogg": "ogg",
    "audio/mpeg": "mp3",
    "application/json": "json",
}
AUDIO_TYPES = ("audio/ogg", "audio/mpeg")
INLINE_TYPES = ("image/png", "image/jpeg", "application/pdf")
DEFAULT_CAPTURE_MAX_BYTES = 25 * 1024 * 1024
_TITLE_MAX = 120
_CAPTURE_COLUMNS = ("id, scope_id, kind, title, body_text, url, original_path,"
                    " original_sha256, mime, size_bytes, source, captured_by,"
                    " captured_at, status, converted_type, converted_id,"
                    " created_at, updated_at, revision")


def capture_extension(mime) -> str:
    if mime not in ALLOWED_UPLOAD_TYPES:
        raise ValueError(
            f"unsupported upload type {mime!r}; allowed: {', '.join(sorted(ALLOWED_UPLOAD_TYPES))}")
    return ALLOWED_UPLOAD_TYPES[mime]


def check_capture_url(url) -> str:
    if not isinstance(url, str) or not url.strip():
        raise ValueError("url must be a non-empty string")
    url = url.strip()
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise ValueError("url must be an absolute http:// or https:// address")
    return url


def _optional_text(value, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{name} must be a string")
    return value


def _like_pattern(token: str) -> str:
    escaped = token.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


class Captures:
    """Mixin; expects ``self._db``, ``self._outbox``, ``self.root``, ``self.scope_id``
    and the goals/tasks/knowledge/calendar mixins for conversion."""

    # -- create / read ------------------------------------------------------------------

    @property
    def capture_max_bytes(self) -> int:
        value = read_manifest(self.root).get("capture_max_bytes", DEFAULT_CAPTURE_MAX_BYTES)
        return int(value) if type(value) is int and value > 0 else DEFAULT_CAPTURE_MAX_BYTES

    def create_capture(self, kind: str, captured_by: str, *, title: str | None = None,
                       body_text: str | None = None, url: str | None = None,
                       source: str = "ui") -> dict:
        if kind not in CAPTURE_KINDS:
            raise ValueError(f"kind must be one of {CAPTURE_KINDS}, got {kind!r}")
        if source not in CAPTURE_SOURCES:
            raise ValueError(f"source must be one of {CAPTURE_SOURCES}, got {source!r}")
        if not isinstance(captured_by, str) or not captured_by.strip():
            raise ValueError("captured_by required")
        title = _optional_text(title, "title")
        body_text = _optional_text(body_text, "body_text")
        if title is not None:
            title = title.strip() or None
        if kind == "text" and (body_text is None or not body_text.strip()):
            raise ValueError("text captures need body_text")
        if kind == "link":
            url = check_capture_url(url)
        elif url is not None:
            raise ValueError("url only applies to link captures")
        capture_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO captures (id, scope_id, kind, title, body_text, url, source,"
                " captured_by, captured_at, status, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'inbox', ?, ?)",
                (capture_id, self.scope_id, kind, title, body_text, url, source,
                 captured_by, stamp, stamp, stamp))
            self._db.audit(cur, "capture", capture_id, "create", captured_by,
                           {"kind": kind, "source": source}, scope_id=self.scope_id)
        return self.get_capture(capture_id)

    def get_capture(self, capture_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_CAPTURE_COLUMNS} FROM captures WHERE id = ? AND scope_id = ?",
            (capture_id, self.scope_id))
        return None if row is None else dict(row)

    def _require_capture(self, capture_id: str) -> dict:
        capture = self.get_capture(capture_id)
        if capture is None:
            raise LookupError(f"capture {capture_id!r} not found in scope {self.scope_id!r}")
        return capture

    def list_captures(self, status: str | None = None,
                      include_archived: bool = False) -> list[dict]:
        sql = f"SELECT {_CAPTURE_COLUMNS} FROM captures WHERE scope_id = ?"
        params: list = [self.scope_id]
        if status is not None:
            if status not in CAPTURE_STATUSES:
                raise ValueError(f"status must be one of {CAPTURE_STATUSES}, got {status!r}")
            sql += " AND status = ?"
            params.append(status)
        elif not include_archived:
            sql += " AND status != 'archived'"
        return [dict(r) for r in self._db.query(
            sql + " ORDER BY captured_at DESC, rowid DESC", params)]

    def capture_detail(self, capture_id: str) -> dict:
        capture = self._require_capture(capture_id)
        return {**capture, "drafts": self.list_capture_drafts(capture_id),
                "links": self.list_capture_links(capture_id)}

    def count_open_captures(self) -> int:
        return int(self._db.query_one(
            "SELECT COUNT(*) AS n FROM captures WHERE scope_id = ?"
            " AND status IN ('inbox', 'drafting')", (self.scope_id,))["n"])

    # -- originals ----------------------------------------------------------------------

    def attach_original(self, capture_id: str, data: bytes, mime, actor: str,
                        filename: str | None = None) -> dict:
        """Store the one and only original of a file/transcript capture.

        ``filename`` is display text: it becomes ``title`` when the capture has
        none and is never used to build the path.
        """
        capture = self._require_capture(capture_id)
        extension = capture_extension(mime)
        if not isinstance(data, (bytes, bytearray)) or len(data) == 0:
            raise ValueError("upload is empty")
        limit = self.capture_max_bytes
        if len(data) > limit:
            raise ValueError(f"upload of {len(data)} bytes exceeds capture_max_bytes {limit}")
        if capture["kind"] == "transcript" and mime not in AUDIO_TYPES:
            raise ValueError("a transcript's original must be audio (audio/ogg or audio/mpeg)")
        if capture["kind"] == "file" and mime in AUDIO_TYPES:
            raise ValueError("audio uploads are transcript captures, not files")
        if capture["kind"] not in ("file", "transcript"):
            raise ValueError(f"{capture['kind']} captures do not carry an original")
        if capture["status"] not in OPEN_STATUSES:
            raise InvariantError(f"cannot attach to a {capture['status']} capture")
        if capture["original_path"] is not None:
            raise ConflictError("this capture already has its original; originals are immutable")
        if not isinstance(actor, str) or not actor.strip():
            raise ValueError("actor required")
        fields = {"mime": mime, "size_bytes": len(data)}
        if capture["title"] is None and isinstance(filename, str) and filename.strip():
            fields["title"] = filename.strip()[:_TITLE_MAX]
        with self._db.transaction() as cur:
            # Re-check under the write lock, then blob first, row second: a
            # crash between the two leaves an unreferenced file, never a row
            # pointing at nothing.
            current = cur.execute(
                "SELECT original_path FROM captures WHERE id = ? AND scope_id = ?",
                (capture_id, self.scope_id)).fetchone()
            if current["original_path"] is not None:
                raise ConflictError("this capture already has its original; originals are immutable")
            relative, digest = self._outbox.stage_capture_original(
                self.scope_id, capture_id, extension, bytes(data))
            fields.update({"original_path": relative, "original_sha256": digest})
            self._db.update_with_revision(
                "captures", capture_id, self.scope_id, capture["revision"], fields,
                actor=actor, action="attach_original",
                details={"mime": mime, "size_bytes": len(data), "sha256": digest},
                cur=cur, entity_type="capture")
        return self.get_capture(capture_id)

    def read_original(self, capture_id: str) -> bytes | None:
        capture = self.get_capture(capture_id)
        if capture is None or capture["original_path"] is None:
            return None
        return self._outbox.read_capture_original(capture["original_path"])

    # -- drafts -------------------------------------------------------------------------

    def _require_open(self, capture: dict) -> None:
        if capture["status"] == "archived":
            raise InvariantError("archived captures are read-only; unarchive first")
        if capture["status"] == "converted":
            raise InvariantError(
                f"capture already converted to {capture['converted_type']}"
                f" {capture['converted_id']}")

    def add_capture_draft(self, capture_id: str, body_md: str, created_by: str) -> dict:
        capture = self._require_capture(capture_id)
        if not isinstance(body_md, str) or not body_md.strip():
            raise ValueError("body_md must be a non-empty string")
        if not isinstance(created_by, str) or not created_by.strip():
            raise ValueError("created_by required")
        self._require_open(capture)
        draft_id = new_id()
        with self._db.transaction() as cur:
            latest = cur.execute(
                "SELECT COALESCE(MAX(version), 0) AS v FROM capture_drafts WHERE capture_id = ?",
                (capture_id,)).fetchone()["v"]
            version = int(latest) + 1
            cur.execute(
                "INSERT INTO capture_drafts (id, scope_id, capture_id, version, body_md,"
                " created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (draft_id, self.scope_id, capture_id, version, body_md, created_by, now()))
            fields = {"status": "drafting"} if capture["status"] == "inbox" else None
            if fields:
                self._db.update_with_revision(
                    "captures", capture_id, self.scope_id, capture["revision"], fields,
                    actor=created_by, action=f"draft:{version}", cur=cur, entity_type="capture")
            else:
                self._db.audit(cur, "capture", capture_id, f"draft:{version}", created_by,
                               {"draft_id": draft_id}, scope_id=self.scope_id)
        return dict(self._db.query_one("SELECT * FROM capture_drafts WHERE id = ?", (draft_id,)))

    def list_capture_drafts(self, capture_id: str) -> list[dict]:
        self._require_capture(capture_id)
        return [dict(r) for r in self._db.query(
            "SELECT * FROM capture_drafts WHERE capture_id = ? AND scope_id = ? ORDER BY version",
            (capture_id, self.scope_id))]

    def list_capture_links(self, capture_id: str) -> list[dict]:
        links = []
        for row in self._db.query(
                "SELECT * FROM capture_links WHERE capture_id = ? AND scope_id = ?"
                " ORDER BY created_at, rowid", (capture_id, self.scope_id)):
            link = dict(row)
            link["target_title"] = self._capture_target_title(link["target_type"], link["target_id"])
            links.append(link)
        return links

    def _capture_target_title(self, target_type: str, target_id: str) -> str | None:
        if target_type == "event":
            event = self.get_event(target_id)
            return event and event["title"]
        return self._target_title(target_type, target_id)

    # -- conversion ---------------------------------------------------------------------

    def _capture_content(self, capture: dict) -> tuple[str, str]:
        """(title, body) a target is built from: latest draft, else the original text."""
        drafts = self.list_capture_drafts(capture["id"])
        if drafts:
            body = drafts[-1]["body_md"]
        elif capture["body_text"]:
            body = capture["body_text"]
        elif capture["url"]:
            body = capture["url"]
        else:
            body = capture["title"] or ""
        first_line = next((line.strip() for line in body.splitlines() if line.strip()), "")
        title = capture["title"] or first_line[:_TITLE_MAX] or f"Capture {capture['id'][:8]}"
        if capture["url"] and capture["url"] not in body:
            body = f"{body}\n\n{capture['url']}".strip()
        return title, body

    def convert_capture(self, capture_id: str, target: str, payload, actor: str) -> dict:
        """Create ``target`` from the capture through the ordinary Store methods.

        The target's own validation and gates apply unchanged; a refused
        target leaves the capture as it was. Converting twice is a conflict.
        """
        if target not in CONVERT_TARGETS:
            raise ValueError(f"target must be one of {CONVERT_TARGETS}, got {target!r}")
        if payload is None:
            payload = {}
        if not isinstance(payload, dict):
            raise ValueError("payload must be an object")
        if not isinstance(actor, str) or not actor.strip():
            raise ValueError("actor required")
        capture = self._require_capture(capture_id)
        if capture["status"] == "converted":
            raise ConflictError(
                f"capture already converted to {capture['converted_type']}"
                f" {capture['converted_id']}")
        self._require_open(capture)
        default_title, body = self._capture_content(capture)
        title = payload.get("title") or default_title
        owner = payload.get("owner") or actor
        link_type = target
        if target == "task":
            if not payload.get("project_id"):
                raise ValueError("task conversion needs project_id")
            if not payload.get("criteria"):
                raise ValueError("task conversion needs criteria: at least one acceptance criterion")
            created = self.create_task(
                payload["project_id"], title, owner,
                payload.get("next_action") or "Review the captured material and plan the work",
                payload["criteria"], payload.get("priority", 2),
                deadline=payload.get("deadline"))
        elif target == "note":
            kind = payload.get("kind", "note")
            if kind not in ("note", "research"):
                raise ValueError("note conversion kind must be 'note' or 'research'")
            created = self.create_note(kind, title, body, actor)
            link_type = "note"
        elif target == "journal":
            if not payload.get("entry_date"):
                raise ValueError("journal conversion needs entry_date (YYYY-MM-DD)")
            created = self.create_note("journal", title, body, actor,
                                       entry_date=payload["entry_date"])
            link_type = "note"
        elif target == "decision":
            if not isinstance(payload.get("decision"), dict):
                raise ValueError("decision conversion needs the structured decision record")
            created = self.create_note("decision", title, body, actor,
                                       decision=payload["decision"])
            link_type = "note"
        elif target == "event":
            if not payload.get("start_utc"):
                raise ValueError("event conversion needs start_utc")
            created = self.create_event(
                title, payload.get("kind", "event"), payload["start_utc"],
                timezone=payload.get("timezone", "UTC"), actor=actor,
                end_utc=payload.get("end_utc"), all_day=bool(payload.get("all_day", False)),
                notes=body)
        else:
            if not payload.get("success_measure"):
                raise ValueError("goal conversion needs success_measure")
            created = self.create_goal(title, owner, payload["success_measure"])
        with self._db.transaction() as cur:
            try:
                self._db.update_with_revision(
                    "captures", capture_id, self.scope_id, capture["revision"],
                    {"status": "converted", "converted_type": target,
                     "converted_id": created["id"]},
                    actor=actor, action=f"convert:{target}",
                    details={"target_id": created["id"]}, cur=cur, entity_type="capture")
            except ConflictError as exc:
                raise ConflictError(
                    f"{exc}; a {target} {created['id']} was created before the conflict"
                    " was detected and remains") from exc
            cur.execute(
                "INSERT INTO capture_links (id, scope_id, capture_id, target_type, target_id,"
                " created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (new_id(), self.scope_id, capture_id, link_type, created["id"], now()))
        return self.get_capture(capture_id)

    # -- archive ------------------------------------------------------------------------

    def archive_capture(self, capture_id: str, expected_revision: int, actor: str) -> dict:
        capture = self._require_capture(capture_id)
        if capture["revision"] != expected_revision:
            raise ConflictError(f"captures {capture_id!r} not at revision {expected_revision}")
        if capture["status"] == "archived":
            raise InvariantError("capture is already archived")
        self._db.update_with_revision(
            "captures", capture_id, self.scope_id, expected_revision, {"status": "archived"},
            actor=actor, action="archive", details={"from": capture["status"]},
            entity_type="capture")
        return self.get_capture(capture_id)

    def unarchive_capture(self, capture_id: str, expected_revision: int, actor: str) -> dict:
        capture = self._require_capture(capture_id)
        if capture["revision"] != expected_revision:
            raise ConflictError(f"captures {capture_id!r} not at revision {expected_revision}")
        if capture["status"] != "archived":
            raise InvariantError("capture is not archived")
        if capture["converted_id"]:
            status = "converted"
        elif self.list_capture_drafts(capture_id):
            status = "drafting"
        else:
            status = "inbox"
        self._db.update_with_revision(
            "captures", capture_id, self.scope_id, expected_revision, {"status": status},
            actor=actor, action="unarchive", details={"to": status}, entity_type="capture")
        return self.get_capture(capture_id)

    # -- search -------------------------------------------------------------------------

    def search_captures(self, query: str, limit: int = 20) -> list[dict]:
        tokens = search_tokens(query)
        if not tokens:
            return []
        where = " AND ".join(
            "(COALESCE(title, '') LIKE ? ESCAPE '\\' OR COALESCE(body_text, '') LIKE ? ESCAPE '\\'"
            " OR COALESCE(url, '') LIKE ? ESCAPE '\\')" for _ in tokens)
        params = [p for t in tokens for p in (_like_pattern(t),) * 3]
        hits = []
        for row in self._db.query(
                f"SELECT {_CAPTURE_COLUMNS} FROM captures WHERE scope_id = ?"
                f" AND status != 'archived' AND {where}"
                " ORDER BY captured_at DESC LIMIT ?", [self.scope_id, *params, limit]):
            hit = dict(row)
            hit["snippet"] = like_snippet(
                hit["title"] or "", " ".join(filter(None, (hit["body_text"], hit["url"]))), tokens)
            hits.append(hit)
        return hits
