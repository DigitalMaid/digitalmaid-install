"""Executions and immutable output versions (the Do phase's evidence)."""

import json

from digitalmaid.db import new_id, now
from digitalmaid.errors import InvariantError

EXECUTION_STATUSES = ("queued", "running", "succeeded", "failed",
                      "cancelled", "interrupted", "uncertain")


class Outputs:
    """Mixin; expects ``self._db``, ``self.scope_id`` and the Tasks mixin."""

    def record_execution(self, task_id: str, agent_id: str, status: str,
                         model: str | None = None,
                         provider: str | None = None, log: str = "") -> dict:
        if status not in EXECUTION_STATUSES:
            raise ValueError(
                f"status must be one of {EXECUTION_STATUSES}, got {status!r}")
        if not agent_id or not agent_id.strip():
            raise ValueError("agent_id required")
        task = self._require_task(task_id)
        if task["status"] != "Do":
            raise InvariantError(
                f"executions only run while task is in Do (now"
                f" {task['status']})")
        execution_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO executions (id, scope_id, task_id, agent_id,"
                " status, model, provider, log, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (execution_id, self.scope_id, task_id, agent_id, status,
                 model, provider, log, stamp, stamp))
            self._db.audit(cur, "execution", execution_id, f"status:{status}",
                           agent_id, {"task_id": task_id, "model": model,
                                      "provider": provider},
                           scope_id=self.scope_id)
        return self.get_execution(execution_id)

    def get_execution(self, execution_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM executions WHERE id = ? AND scope_id = ?",
            (execution_id, self.scope_id))
        return None if row is None else self._execution_dict(row)

    def _execution_dict(self, row) -> dict:
        """Execution row plus the *requested* policy provider/model.

        ``provider``/``model`` are what the response reported (for OpenRouter
        that is the upstream provider, e.g. "Anthropic"); ``policy_provider``/
        ``policy_model`` come from the role definition so the two are never
        confused. Manual records and fixture roles carry None.
        """
        execution = dict(row)
        policy = None
        agent = self.get_agent(execution["agent_id"]) if hasattr(self, "get_agent") else None
        if agent and agent["model_policy"].get("kind") == "live":
            policy = agent["model_policy"]
        execution["policy_provider"] = policy.get("provider") if policy else None
        execution["policy_model"] = policy.get("model") if policy else None
        return execution

    def update_execution_status(self, execution_id: str, status: str,
                                log_append: str = "") -> dict:
        """Move an execution to ``status`` (revision-checked, audited)."""
        return self.record_execution_evidence(execution_id, status,
                                              log_append=log_append)

    def record_execution_evidence(self, execution_id: str, status: str,
                                  model: str | None = None,
                                  provider: str | None = None,
                                  usage: dict | None = None,
                                  cost_minor: int | None = None,
                                  cost_currency: str | None = None,
                                  provider_response_id: str | None = None,
                                  log_append: str = "") -> dict:
        """Finish an execution with what the provider response proved.

        ``model``/``provider``/``usage``/cost come from the response body of
        the actual invocation (ADR-008), never from prompt text or from what
        the model says about itself.
        """
        if status not in EXECUTION_STATUSES:
            raise ValueError(
                f"status must be one of {EXECUTION_STATUSES}, got {status!r}")
        if cost_minor is not None and type(cost_minor) is not int:
            raise ValueError("cost_minor must be an int in minor units")
        if usage is not None and not isinstance(usage, dict):
            raise ValueError("usage must be an object")
        execution = self.get_execution(execution_id)
        if execution is None:
            raise LookupError(
                f"execution {execution_id!r} not found in scope {self.scope_id!r}")
        log = execution["log"]
        if log_append:
            log = f"{log}\n{log_append}" if log else log_append
        fields = {"status": status, "log": log}
        if model is not None:
            fields["model"] = model
        if provider is not None:
            fields["provider"] = provider
        if usage is not None:
            fields["usage_json"] = json.dumps(usage, sort_keys=True)
        if cost_minor is not None:
            fields["cost_minor"] = cost_minor
            fields["cost_currency"] = cost_currency
        if provider_response_id is not None:
            fields["provider_response_id"] = provider_response_id
        self._db.update_with_revision(
            "executions", execution_id, self.scope_id, execution["revision"],
            fields, actor=execution["agent_id"], action=f"status:{status}",
            details={"from": execution["status"], "model": model,
                     "provider": provider, "cost_minor": cost_minor,
                     "provider_response_id": provider_response_id},
            entity_type="execution")
        return self.get_execution(execution_id)

    def list_executions(self, task_id: str) -> list[dict]:
        self._require_task(task_id)
        return [self._execution_dict(r) for r in self._db.query(
            "SELECT * FROM executions WHERE task_id = ? AND scope_id = ?"
            " ORDER BY created_at, rowid", (task_id, self.scope_id))]

    def submit_output(self, task_id: str, execution_id: str,
                      content: str) -> dict:
        """Create OutputVersion n+1 for the task's single Output.

        Never changes task status: a produced output is unchecked output.
        If an open Correction exists for the task, the new version is
        recorded as its revision.
        """
        if not isinstance(content, str):
            raise ValueError("content must be a string")
        task = self._require_task(task_id)
        execution = self.get_execution(execution_id)
        if execution is None or execution["task_id"] != task_id:
            raise ValueError(
                f"execution {execution_id!r} does not belong to task"
                f" {task_id!r} in scope {self.scope_id!r}")
        if task["status"] != "Do":
            raise InvariantError(
                f"outputs can only be submitted while task is in Do (now"
                f" {task['status']})")
        stamp = now()
        version_id = new_id()
        with self._db.transaction() as cur:
            output = cur.execute(
                "SELECT id, latest_version, revision FROM outputs"
                " WHERE task_id = ? AND scope_id = ?",
                (task_id, self.scope_id)).fetchone()
            if output is None:
                output_id = new_id()
                cur.execute(
                    "INSERT INTO outputs (id, scope_id, task_id,"
                    " latest_version, created_at, updated_at)"
                    " VALUES (?, ?, ?, 0, ?, ?)",
                    (output_id, self.scope_id, task_id, stamp, stamp))
                self._db.audit(cur, "output", output_id, "create",
                               execution["agent_id"], {"task_id": task_id},
                               scope_id=self.scope_id)
                number, revision = 1, 1
            else:
                output_id = output["id"]
                number, revision = output["latest_version"] + 1, output["revision"]
            # Blob first, row second: the write lock held by this
            # transaction serialises version numbering, and a crash here
            # leaves an unreferenced blob for orphaned_blobs(), never a row
            # pointing at missing content.
            blob_path, digest = self._outbox.stage_output(
                self.scope_id, output_id, number, content)
            cur.execute(
                "INSERT INTO output_versions (id, scope_id, output_id,"
                " execution_id, version, blob_path, sha256,"
                " criteria_snapshot, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (version_id, self.scope_id, output_id, execution_id, number,
                 blob_path, digest, json.dumps(task["criteria"]), stamp))
            self._db.update_with_revision(
                "outputs", output_id, self.scope_id, revision,
                {"latest_version": number}, actor=execution["agent_id"],
                action="new_version", details={"version": number},
                cur=cur, entity_type="output")
            self._db.audit(cur, "output_version", version_id, "create",
                           execution["agent_id"],
                           {"task_id": task_id, "version": number},
                           scope_id=self.scope_id)
            self._link_open_correction(cur, task_id, version_id,
                                       execution["agent_id"])
        return self.get_output_version(version_id)

    def _link_open_correction(self, cur, task_id: str, version_id: str,
                              actor: str) -> None:
        correction = cur.execute(
            "SELECT id, revision FROM corrections WHERE task_id = ?"
            " AND scope_id = ? AND revised_output_version_id IS NULL",
            (task_id, self.scope_id)).fetchone()
        if correction is None:
            return
        self._db.update_with_revision(
            "corrections", correction["id"], self.scope_id,
            correction["revision"],
            {"revised_output_version_id": version_id}, actor=actor,
            action="revise", details={"output_version_id": version_id},
            cur=cur, entity_type="correction")

    def get_output(self, task_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM outputs WHERE task_id = ? AND scope_id = ?",
            (task_id, self.scope_id))
        return None if row is None else dict(row)

    def _version_dict(self, row) -> dict:
        version = dict(row)
        version["content"] = self._outbox.read_output(version["blob_path"])
        return version

    def get_output_version(self, version_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT v.*, o.task_id FROM output_versions v"
            " JOIN outputs o ON o.id = v.output_id"
            " WHERE v.id = ? AND v.scope_id = ?",
            (version_id, self.scope_id))
        return None if row is None else self._version_dict(row)

    def list_output_versions(self, task_id: str) -> list[dict]:
        self._require_task(task_id)
        return [self._version_dict(r) for r in self._db.query(
            "SELECT v.*, o.task_id FROM output_versions v"
            " JOIN outputs o ON o.id = v.output_id"
            " WHERE o.task_id = ? AND v.scope_id = ? ORDER BY v.version",
            (task_id, self.scope_id))]

    def orphaned_blobs(self) -> list[str]:
        """Blob files in this scope's outputs dir that no version references."""
        referenced = {r["blob_path"] for r in self._db.query(
            "SELECT blob_path FROM output_versions WHERE scope_id = ?",
            (self.scope_id,))}
        return self._outbox.orphaned_blobs(self.scope_id, referenced)
