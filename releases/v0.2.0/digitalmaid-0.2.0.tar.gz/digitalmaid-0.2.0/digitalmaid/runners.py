"""Runners turn a claimed occurrence into task records (ADR-008).

``FixtureRunner`` is a deterministic test fixture: no model, no network, and
output content that is a pure function of its inputs. ``LiveLLMRunner``
calls a real provider through an injected transport and refuses to run
until credentials, permissions and a cost cap are configured.
``run_bounded`` is the only way subprocesses are started: fixed argv, no
shell, own process group, killed as a group on timeout.
"""

import hashlib
import json
import os
import signal
import subprocess
from dataclasses import dataclass, field

from digitalmaid.errors import ConfigurationError, InvariantError
from digitalmaid.transports import (OpenAICompatibleTransport, TransportError,
                                    credential_env_name, redact)

FIXTURE_ACTIONS = ("create_task", "assess_resource", "start_task",
                   "record_execution", "submit_output")
LIVE_REQUIRED_PERMISSIONS = ("create_task", "record_execution", "submit_output")


@dataclass
class RunResult:
    status: str                      # succeeded | blocked | failed
    task_id: str | None = None
    execution_id: str | None = None
    reasons: list[str] = field(default_factory=list)


def fixture_content(template: dict, occurrence_utc: str, version: int,
                    correction_action: str | None = None) -> str:
    """Deterministic Markdown; identical inputs give identical bytes."""
    inputs = {"template": template, "occurrence_utc": occurrence_utc,
              "version": version, "correction_action": correction_action}
    digest = hashlib.sha256(
        json.dumps(inputs, sort_keys=True).encode("utf-8")).hexdigest()
    lines = [f"# {template['title']}", "",
             f"Fixture runner output, version {version}, for occurrence"
             f" {occurrence_utc}. Produced by a deterministic test fixture,"
             " not by a model.", "", "Criteria addressed:"]
    lines += [f"- {criterion}" for criterion in template["criteria"]]
    if correction_action:
        lines += ["", f"Revision addressing correction: {correction_action}"]
    lines += ["", f"inputs sha256: {digest}", ""]
    return "\n".join(lines)


class FixtureRunner:
    model = "fixture"
    provider = "fixture"

    def run_occurrence(self, store, job: dict, occurrence: dict,
                       agent: dict) -> RunResult:
        template = job["task_template"]
        forbidden = [a for a in FIXTURE_ACTIONS if a not in agent["allowed_actions"]]
        if forbidden:
            return RunResult("blocked", reasons=[
                f"agent {agent['id']!r} may not {a}" for a in forbidden])
        task = store.create_task(
            job["project_id"], f"{template['title']} ({occurrence['occurrence_utc'][:10]})",
            template["owner"], template["next_action"], template["criteria"],
            template["priority"], deadline=template.get("deadline"))
        for category, entry in template.get("resources", {}).items():
            store.assess_resource(task["id"], category, entry["description"],
                                  entry["status"], na_reason=entry.get("na_reason"),
                                  amount_minor=entry.get("amount_minor"),
                                  currency=entry.get("currency"))
        try:
            store.start_task(task["id"])
        except InvariantError as exc:
            return RunResult("blocked", task_id=task["id"], reasons=exc.reasons)
        execution_id = self._produce(store, task["id"], agent["id"], template,
                                     occurrence["occurrence_utc"], 1)
        return RunResult("succeeded", task_id=task["id"], execution_id=execution_id)

    def revise(self, store, job: dict, task: dict, occurrence: dict,
               correction: dict, agent: dict) -> str:
        version = store.get_output(task["id"])["latest_version"] + 1
        return self._produce(store, task["id"], agent["id"], job["task_template"],
                             occurrence["occurrence_utc"], version,
                             correction_action=correction["action"])

    def _produce(self, store, task_id, agent_id, template, occurrence_utc,
                 version, correction_action=None) -> str:
        execution = store.record_execution(
            task_id, agent_id, "running", model=self.model, provider=self.provider,
            log="fixture runner: deterministic test fixture, no model called")
        content = fixture_content(template, occurrence_utc, version,
                                  correction_action=correction_action)
        store.submit_output(task_id, execution["id"], content)
        store.update_execution_status(execution["id"], "succeeded",
                                      log_append=f"submitted version {version}")
        return execution["id"]


def build_messages(agent: dict, task: dict, template: dict,
                   correction_action: str | None = None,
                   previous_content: str | None = None) -> list[dict]:
    """System prompt from the role definition; user prompt from the task."""
    system = [f"You are {agent['name']}.", agent["responsibility"], "",
              "Allowed actions: " + ", ".join(agent["allowed_actions"]) + ".",
              "Limitations: " + ("; ".join(agent.get("limitations") or []) or "none listed") + ".",
              "Return only the deliverable, in Markdown. A human checks it"
              " against the numbered criteria; you cannot check or accept it."]
    user = [f"Task: {task['title']}", f"Next action: {task['next_action']}", "",
            "Acceptance criteria:"]
    user += [f"{i}. {c}" for i, c in enumerate(task["criteria"], start=1)]
    inputs = template.get("inputs") or {}
    if inputs:
        user += ["", "Inputs:"] + [f"- {k}: {inputs[k]}" for k in sorted(inputs)]
    if correction_action is not None:
        user += ["", f"Correction requested by the reviewer: {correction_action}",
                 "", "Previous version:", "---", (previous_content or "").rstrip(),
                 "---", "", "Produce the complete revised deliverable."]
    return [{"role": "system", "content": "\n".join(system)},
            {"role": "user", "content": "\n".join(user)}]


class LiveLLMRunner:
    """Real provider execution behind the Execution record (ADR-008).

    ``config`` is the agent definition's ``model_policy`` plus the
    ``permissions`` granted to the role. ``credential_ref`` names an
    environment variable; the secret is read by the transport at call time
    and never stored here. Money gate: ``max_cost_minor`` is required, a
    spend intent is recorded before every paid call, and the call happens
    only if the task carries an explicit spend authorization covering the
    cap. Provider/model/usage/cost on the Execution come from the response.
    Like the fixture, this runner never checks or accepts output.
    """

    def __init__(self, config: dict | None = None, transport=None):
        self.config = dict(config or {})
        self.transport = transport

    def problems(self) -> list[str]:
        """Everything that stops this runner from running; empty means ready."""
        config, missing = self.config, []
        env_name = credential_env_name(config.get("credential_ref"))
        if env_name is None:
            missing.append("credential_ref (no credential configured)")
        elif not os.environ.get(env_name):
            missing.append(f"credential environment variable {env_name} is not set")
        granted = set(config.get("permissions") or [])
        lacking = [p for p in LIVE_REQUIRED_PERMISSIONS if p not in granted]
        if lacking:
            missing.append(f"permission(s) {lacking} not granted")
        for key in ("base_url", "model"):
            if not isinstance(config.get(key), str) or not config[key].strip():
                missing.append(f"{key} missing")
        cap = config.get("max_cost_minor")
        if type(cap) is not int or cap < 0:
            missing.append("max_cost_minor missing (required per live execution)")
        if self.transport is None:
            missing.append("no provider transport configured")
        return missing

    def prepare(self) -> None:
        missing = self.problems()
        if missing:
            raise ConfigurationError(
                "live LLM runner refused: " + "; ".join(missing))

    # -- gates ------------------------------------------------------------------

    def _money_gate(self, store, task_id: str) -> list[str]:
        cap, currency = self.config["max_cost_minor"], self._currency()
        if not store.can_spend(task_id):
            return ["Money: no explicit spend authorization on this task"
                    " (allocation is not permission)"]
        authorized = store.spend_authorized_minor(task_id, currency)
        if authorized < cap:
            return [f"Money: authorized {authorized} {currency} is below"
                    f" max_cost_minor {cap} {currency}"]
        return []

    def _currency(self) -> str:
        return self.config.get("currency") or "USD"

    # -- Plan / Do ------------------------------------------------------------------

    def run_occurrence(self, store, job: dict, occurrence: dict,
                       agent: dict) -> RunResult:
        self.prepare()
        template = job["task_template"]
        forbidden = [a for a in FIXTURE_ACTIONS if a not in agent["allowed_actions"]]
        if forbidden:
            return RunResult("blocked", reasons=[
                f"agent {agent['id']!r} may not {a}" for a in forbidden])
        task = store.create_task(
            job["project_id"], f"{template['title']} ({occurrence['occurrence_utc'][:10]})",
            template["owner"], template["next_action"], template["criteria"],
            template["priority"], deadline=template.get("deadline"))
        for category, entry in template.get("resources", {}).items():
            store.assess_resource(task["id"], category, entry["description"],
                                  entry["status"], na_reason=entry.get("na_reason"),
                                  amount_minor=entry.get("amount_minor"),
                                  currency=entry.get("currency"))
        authorization = template.get("spend_authorization")
        if isinstance(authorization, dict):
            store.authorize_spend(task["id"], authorization["amount_minor"],
                                  authorization["currency"],
                                  authorization["authorized_by"])
        gate = self._money_gate(store, task["id"])
        if gate:
            return RunResult("blocked", task_id=task["id"], reasons=gate)
        try:
            task = store.start_task(task["id"])
        except InvariantError as exc:
            return RunResult("blocked", task_id=task["id"], reasons=exc.reasons)
        execution_id, status, reasons = self._produce(store, task, agent, template, 1)
        return RunResult(status, task_id=task["id"], execution_id=execution_id,
                         reasons=reasons)

    def revise(self, store, job: dict, task: dict, occurrence: dict,
               correction: dict, agent: dict) -> str:
        self.prepare()
        gate = self._money_gate(store, task["id"])
        if gate:
            raise InvariantError(gate)
        versions = store.list_output_versions(task["id"])
        previous = versions[-1]["content"] if versions else ""
        execution_id, status, reasons = self._produce(
            store, task, agent, job["task_template"], len(versions) + 1,
            correction_action=correction["action"], previous_content=previous)
        if status == "failed":
            raise RunFailed(execution_id, reasons)
        return execution_id

    def _produce(self, store, task: dict, agent: dict, template: dict,
                 version: int, correction_action: str | None = None,
                 previous_content: str | None = None) -> tuple[str, str, list[str]]:
        config = self.config
        cap, currency = config["max_cost_minor"], self._currency()
        execution = store.record_execution(
            task["id"], agent["id"], "running",
            log=f"live runner: requesting policy model {config['model']!r} from"
                f" {config['base_url']} (max_cost_minor {cap} {currency});"
                " provider/model/usage below come from the response")
        store.record_spend_intent(task["id"], execution["id"], cap, currency)
        messages = build_messages(agent, task, template, correction_action,
                                  previous_content)
        try:
            result = self.transport.complete(
                config["model"], messages, int(config.get("max_tokens") or 1024))
        except (TransportError, ConfigurationError, TimeoutError, OSError) as exc:
            secret = os.environ.get(credential_env_name(config.get("credential_ref")) or "")
            reason = redact(f"{type(exc).__name__}: {exc}", secret or None)
            store.update_execution_status(execution["id"], "failed",
                                          log_append=f"failed: {reason}")
            return execution["id"], "failed", [reason]
        store.submit_output(task["id"], execution["id"], result.text)
        store.record_execution_evidence(
            execution["id"], "succeeded", model=result.model,
            provider=result.provider, usage=result.usage,
            cost_minor=result.cost_minor, cost_currency=result.currency,
            provider_response_id=result.raw_id,
            log_append=f"submitted version {version}")
        reasons = []
        if result.cost_minor is not None and result.cost_minor > cap:
            reason = f"cost cap exceeded: {result.cost_minor} > {cap}"
            store.add_learning(task["id"],
                               f"Live execution {execution['id'][:8]}: {reason}"
                               f" ({result.currency or currency}); output kept"
                               " for review, not retried.")
            reasons.append(reason)
        return execution["id"], "succeeded", reasons


class RunFailed(Exception):
    """A revision's execution failed; the Execution row carries the reason."""

    def __init__(self, execution_id: str, reasons: list[str]):
        self.execution_id = execution_id
        self.reasons = list(reasons)
        super().__init__("; ".join(self.reasons))


def default_transport(config: dict):
    extra = {"usage": {"include": True}} if config.get("provider") == "openrouter" else None
    return OpenAICompatibleTransport(config["base_url"], config["credential_ref"],
                                     config.get("timeout_seconds") or 120,
                                     extra_body=extra)


def runner_status(agent: dict) -> dict:
    """Configured or not, from ``prepare()`` alone: no network is contacted."""
    kind = agent["model_policy"]["kind"]
    if kind == "fixture":
        return {"kind": "fixture", "configured": True, "problems": []}
    problems = build_live_runner(agent).problems()
    return {"kind": kind, "configured": not problems, "problems": problems}


def build_live_runner(agent: dict, transport_factory=None,
                      overrides: dict | None = None) -> LiveLLMRunner:
    """Runner for a live-policy role: policy + granted actions + transport.

    Constructing the transport opens no connection; the credential is only
    read when a call is made.
    """
    config = {**agent["model_policy"], "permissions": list(agent["allowed_actions"]),
              **(overrides or {})}
    transport = None
    if config.get("base_url") and credential_env_name(config.get("credential_ref")):
        try:
            transport = (transport_factory or default_transport)(config)
        except ValueError:
            transport = None
    return LiveLLMRunner(config, transport)


def run_bounded(argv: list[str], timeout_seconds: float, cwd=None,
                env: dict | None = None) -> dict:
    """Run a fixed argv in its own process group; kill the group on timeout."""
    if (not isinstance(argv, list) or not argv
            or any(not isinstance(a, str) or not a for a in argv)):
        raise ValueError("argv must be a non-empty list of non-empty strings")
    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive")
    process = subprocess.Popen(
        argv, cwd=cwd, env=env, shell=False, start_new_session=True,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        _kill_group(process)
        stdout, stderr = process.communicate()
    status = "interrupted" if timed_out else (
        "succeeded" if process.returncode == 0 else "failed")
    return {"status": status, "returncode": process.returncode,
            "timed_out": timed_out,
            "stdout": stdout.decode("utf-8", "replace"),
            "stderr": stderr.decode("utf-8", "replace")}


def _kill_group(process) -> None:
    try:
        pgid = os.getpgid(process.pid)
    except ProcessLookupError:
        return
    for sig, grace in ((signal.SIGTERM, 1.0), (signal.SIGKILL, None)):
        try:
            os.killpg(pgid, sig)
        except ProcessLookupError:
            return
        if grace is None:
            return
        try:
            process.wait(timeout=grace)
            return
        except subprocess.TimeoutExpired:
            continue
