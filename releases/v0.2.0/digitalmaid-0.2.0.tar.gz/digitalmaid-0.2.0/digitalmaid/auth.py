"""Users, per-scope memberships, opaque sessions and a login rate limiter.

Passwords are hashed with ``hashlib.scrypt`` and a per-user random salt
(stdlib only). Users and sessions are workspace-wide; the *role* a session
carries is looked up per scope through ``memberships``, so authentication
never implies authorization in a scope (ADR-006).
"""

import hashlib
import hmac
import re
import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

from digitalmaid.db import new_id, now
from digitalmaid.errors import ConflictError, InvariantError

ROLES = ("owner", "member", "viewer")
_USERNAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
MIN_PASSWORD_LENGTH = 8
DEFAULT_SESSION_TTL = 14 * 24 * 3600
_SCRYPT = {"n": 2 ** 14, "r": 8, "p": 1, "dklen": 32}
_USER_COLUMNS = "id, username, created_at, disabled_at"
_TOKEN_COLUMNS = "id, user_id, name, created_at, last_used_at, revoked_at"
TOKEN_PREFIX = "dmt_"


def hash_password(password: str, salt: bytes) -> str:
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, **_SCRYPT).hex()


def check_username(username) -> str:
    if not isinstance(username, str) or not _USERNAME.match(username):
        raise ValueError("username must be 1-64 letters, digits, '.', '_' or '-'")
    return username


def check_password(password) -> str:
    if not isinstance(password, str) or len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"password must be at least {MIN_PASSWORD_LENGTH} characters")
    return password


class LoginRateLimiter:
    """``limit`` failures per username inside ``window_seconds`` blocks logins."""

    def __init__(self, limit: int = 10, window_seconds: int = 900, clock=time.monotonic):
        self.limit, self.window, self.clock = limit, window_seconds, clock
        self._failures: dict[str, deque] = defaultdict(deque)

    def _prune(self, username: str) -> deque:
        failures = self._failures[username]
        cutoff = self.clock() - self.window
        while failures and failures[0] <= cutoff:
            failures.popleft()
        return failures

    def allowed(self, username: str) -> bool:
        return len(self._prune(username)) < self.limit

    def record_failure(self, username: str) -> None:
        self._prune(username).append(self.clock())

    def reset(self, username: str) -> None:
        self._failures.pop(username, None)


class Auth:
    """Mixin; expects ``self._db`` and ``self.scope_id``."""

    # -- users ---------------------------------------------------------------------------

    def create_user(self, username: str, password: str, actor: str) -> dict:
        check_username(username)
        check_password(password)
        salt = secrets.token_bytes(16)
        user_id = new_id()
        with self._db.transaction() as cur:
            if cur.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone():
                raise ConflictError(f"username {username!r} already exists")
            cur.execute(
                "INSERT INTO users (id, username, password_hash, salt, created_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (user_id, username, hash_password(password, salt), salt.hex(), now()))
            self._db.audit(cur, "user", user_id, "create", actor, {"username": username})
        return self.get_user(user_id)

    def _user_dict(self, row) -> dict:
        user = dict(row)
        user["memberships"] = [
            {"scope_id": m["scope_id"], "role": m["role"]} for m in self._db.query(
                "SELECT scope_id, role FROM memberships WHERE user_id = ? ORDER BY scope_id",
                (user["id"],))]
        return user

    def get_user(self, user_id: str) -> dict | None:
        row = self._db.query_one(f"SELECT {_USER_COLUMNS} FROM users WHERE id = ?", (user_id,))
        return None if row is None else self._user_dict(row)

    def get_user_by_username(self, username: str) -> dict | None:
        row = self._db.query_one(f"SELECT {_USER_COLUMNS} FROM users WHERE username = ?",
                                 (username,))
        return None if row is None else self._user_dict(row)

    def list_users(self) -> list[dict]:
        return [self._user_dict(r) for r in self._db.query(
            f"SELECT {_USER_COLUMNS} FROM users ORDER BY created_at, username")]

    def disable_user(self, user_id: str, actor: str) -> dict:
        user = self.get_user(user_id)
        if user is None:
            raise LookupError(f"user {user_id!r} not found")
        if user["disabled_at"]:
            raise ConflictError("user already disabled")
        if (self.role_for(user_id, self.scope_id) == "owner"
                and self.count_owners() <= 1):
            raise InvariantError(
                f"cannot disable the last enabled owner of scope {self.scope_id!r}")
        with self._db.transaction() as cur:
            cur.execute("UPDATE users SET disabled_at = ? WHERE id = ?", (now(), user_id))
            cur.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
            self._db.audit(cur, "user", user_id, "disable", actor)
        return self.get_user(user_id)

    # -- memberships -----------------------------------------------------------------------

    def set_membership(self, user_id: str, scope_id: str, role: str, actor: str) -> dict:
        if role not in ROLES:
            raise ValueError(f"role must be one of {ROLES}")
        if self.get_user(user_id) is None:
            raise LookupError(f"user {user_id!r} not found")
        if (role != "owner" and self.role_for(user_id, scope_id) == "owner"
                and self._count_owners_in(scope_id) <= 1):
            raise InvariantError(
                f"cannot change the role of the last enabled owner of scope {scope_id!r};"
                " add another owner first")
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO memberships (id, user_id, scope_id, role, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (user_id, scope_id)"
                " DO UPDATE SET role = excluded.role, updated_at = excluded.updated_at",
                (new_id(), user_id, scope_id, role, stamp, stamp))
            self._db.audit(cur, "user", user_id, f"membership:{role}", actor,
                           {"scope_id": scope_id}, scope_id=scope_id)
        return {"user_id": user_id, "scope_id": scope_id, "role": role}

    def role_for(self, user_id: str, scope_id: str) -> str | None:
        row = self._db.query_one(
            "SELECT role FROM memberships WHERE user_id = ? AND scope_id = ?",
            (user_id, scope_id))
        return None if row is None else row["role"]

    def count_owners(self, any_scope: bool = False) -> int:
        return self._count_owners_in(None if any_scope else self.scope_id)

    def _count_owners_in(self, scope_id: str | None) -> int:
        sql = ("SELECT COUNT(DISTINCT m.user_id) AS n FROM memberships m JOIN users u"
               " ON u.id = m.user_id WHERE m.role = 'owner' AND u.disabled_at IS NULL")
        params: tuple = ()
        if scope_id is not None:
            sql += " AND m.scope_id = ?"
            params = (scope_id,)
        return int(self._db.query_one(sql, params)["n"])

    def change_password(self, user_id: str, current_password: str, new_password: str,
                        keep_session_id: str | None = None) -> None:
        """Verify the current password, store the new hash, revoke every other session."""
        user = self.get_user(user_id)
        if user is None:
            raise LookupError(f"user {user_id!r} not found")
        if self.authenticate(user["username"], current_password) is None:
            raise PermissionError("current password is incorrect")
        new_password = check_password(new_password)
        salt = secrets.token_bytes(16)
        with self._db.transaction() as cur:
            cur.execute("UPDATE users SET password_hash = ?, salt = ? WHERE id = ?",
                        (hash_password(new_password, salt), salt.hex(), user_id))
            if keep_session_id:
                cur.execute("DELETE FROM sessions WHERE user_id = ? AND id != ?", (user_id, keep_session_id))
            else:
                cur.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
            self._db.audit(cur, "user", user_id, "password:change", user["username"])

    # -- authentication and sessions ------------------------------------------------------

    def authenticate(self, username: str, password: str) -> dict | None:
        """The enabled user matching both, else None (constant-time compare)."""
        if not isinstance(username, str) or not isinstance(password, str):
            return None
        row = self._db.query_one(
            "SELECT id, password_hash, salt, disabled_at FROM users WHERE username = ?",
            (username,))
        if row is None:
            # Burn the same work as a real comparison so timing does not leak names.
            hash_password(password, b"\0" * 16)
            return None
        computed = hash_password(password, bytes.fromhex(row["salt"]))
        if not hmac.compare_digest(computed, row["password_hash"]) or row["disabled_at"]:
            return None
        return self.get_user(row["id"])

    def create_session(self, user_id: str, ttl_seconds: int = DEFAULT_SESSION_TTL) -> dict:
        if self.get_user(user_id) is None:
            raise LookupError(f"user {user_id!r} not found")
        created = datetime.now(timezone.utc)
        session = {"id": secrets.token_urlsafe(32), "user_id": user_id,
                   "created_at": created.isoformat(),
                   "expires_at": (created + timedelta(seconds=ttl_seconds)).isoformat(),
                   "last_seen_at": created.isoformat()}
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO sessions (id, user_id, created_at, expires_at, last_seen_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (session["id"], user_id, session["created_at"], session["expires_at"],
                 session["last_seen_at"]))
        return session

    def resolve_session(self, session_id: str) -> dict | None:
        """``{user, role}`` for a live session of an enabled user, else None."""
        if not isinstance(session_id, str) or not session_id:
            return None
        row = self._db.query_one(
            "SELECT s.id, s.user_id, s.expires_at, u.disabled_at FROM sessions s"
            " JOIN users u ON u.id = s.user_id WHERE s.id = ?", (session_id,))
        if row is None or row["disabled_at"]:
            return None
        if datetime.fromisoformat(row["expires_at"]) <= datetime.now(timezone.utc):
            self.delete_session(session_id)
            return None
        with self._db.transaction() as cur:
            cur.execute("UPDATE sessions SET last_seen_at = ? WHERE id = ?",
                        (now(), session_id))
        return {"user": self.get_user(row["user_id"]),
                "role": self.role_for(row["user_id"], self.scope_id)}

    def delete_session(self, session_id: str) -> None:
        with self._db.transaction() as cur:
            cur.execute("DELETE FROM sessions WHERE id = ?", (session_id,))

    # -- API tokens (Hermes seam) -----------------------------------------------------------
    #
    # A token is ``dmt_<token id>_<secret>``. The id is the row key so one scrypt
    # verifies a request; only the scrypt hash of the secret is stored, so a
    # leaked database does not leak usable tokens. The value is returned once.

    def create_api_token(self, user_id: str, name: str, actor: str) -> dict:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("token name must be a non-empty string")
        if self.get_user(user_id) is None:
            raise LookupError(f"user {user_id!r} not found")
        token_id = secrets.token_hex(8)
        secret = secrets.token_urlsafe(32)
        salt = secrets.token_bytes(16)
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO api_tokens (id, user_id, name, token_hash, created_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (token_id, user_id, name.strip(), f"{salt.hex()}${hash_password(secret, salt)}",
                 now()))
            self._db.audit(cur, "api_token", token_id, "create", actor,
                           {"user_id": user_id, "name": name.strip()})
        return {**self._api_token_dict(self._db.query_one(
            f"SELECT {_TOKEN_COLUMNS} FROM api_tokens WHERE id = ?", (token_id,))),
                "token": f"{TOKEN_PREFIX}{token_id}_{secret}"}

    def _api_token_dict(self, row) -> dict:
        token = dict(row)
        user = self.get_user(token["user_id"])
        token["username"] = user["username"] if user else None
        return token

    def list_api_tokens(self) -> list[dict]:
        return [self._api_token_dict(r) for r in self._db.query(
            f"SELECT {_TOKEN_COLUMNS} FROM api_tokens ORDER BY created_at, id")]

    def revoke_api_token(self, token_id: str, actor: str) -> dict:
        row = self._db.query_one(f"SELECT {_TOKEN_COLUMNS} FROM api_tokens WHERE id = ?",
                                 (token_id,))
        if row is None:
            raise LookupError(f"api token {token_id!r} not found")
        if row["revoked_at"]:
            raise ConflictError("token already revoked")
        with self._db.transaction() as cur:
            cur.execute("UPDATE api_tokens SET revoked_at = ? WHERE id = ?", (now(), token_id))
            self._db.audit(cur, "api_token", token_id, "revoke", actor)
        return self._api_token_dict(self._db.query_one(
            f"SELECT {_TOKEN_COLUMNS} FROM api_tokens WHERE id = ?", (token_id,)))

    def resolve_api_token(self, value) -> dict | None:
        """``{user, role, token_id}`` for a live token of an enabled user, else None."""
        if not isinstance(value, str) or not value.startswith(TOKEN_PREFIX):
            return None
        parts = value[len(TOKEN_PREFIX):].split("_", 1)
        if len(parts) != 2 or not parts[0] or not parts[1]:
            return None
        token_id, secret = parts
        row = self._db.query_one(
            "SELECT t.id, t.user_id, t.token_hash, t.revoked_at, u.disabled_at FROM api_tokens t"
            " JOIN users u ON u.id = t.user_id WHERE t.id = ?", (token_id,))
        if row is None or row["revoked_at"] or row["disabled_at"]:
            hash_password(secret, b"\0" * 16)
            return None
        salt_hex, _, stored = row["token_hash"].partition("$")
        computed = hash_password(secret, bytes.fromhex(salt_hex))
        if not hmac.compare_digest(computed, stored):
            return None
        with self._db.transaction() as cur:
            cur.execute("UPDATE api_tokens SET last_used_at = ? WHERE id = ?", (now(), token_id))
        return {"user": self.get_user(row["user_id"]),
                "role": self.role_for(row["user_id"], self.scope_id), "token_id": token_id}

    def audit_trail_global(self, entity_type: str, entity_id: str) -> list[dict]:
        """Audit rows for workspace-wide entities (users) regardless of scope."""
        return [dict(r) for r in self._db.query(
            "SELECT id, entity_type, entity_id, action, actor, at, details FROM audit_events"
            " WHERE entity_type = ? AND entity_id = ? ORDER BY at, rowid",
            (entity_type, entity_id))]
