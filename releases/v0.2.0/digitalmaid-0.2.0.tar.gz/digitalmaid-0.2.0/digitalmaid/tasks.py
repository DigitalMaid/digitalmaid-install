"""Tasks, 5M resource assessments, waivers, spend authorization, Plan→Do."""

import json
import re

from digitalmaid.db import new_id, now
from digitalmaid.errors import ConflictError, InvariantError

FIVE_M = ("Man", "Method", "Machine", "Material", "Money")
RESOURCE_STATUSES = ("required", "available", "missing", "not_applicable")
TASK_STATUSES = ("Plan", "Do", "Check", "Correction", "Done")
_CURRENCY = re.compile(r"^[A-Z]{3}$")

_TASK_COLUMNS = ("id, scope_id, project_id, title, owner, next_action,"
                 " criteria, priority, deadline, status, procedure_id,"
                 " procedure_version, step_index, created_at, updated_at,"
                 " revision")


def _clean_criteria(criteria) -> list[str]:
    if not isinstance(criteria, list) or not criteria:
        raise ValueError("criteria must be a non-empty list of strings")
    cleaned = []
    for item in criteria:
        if not isinstance(item, str) or not item.strip():
            raise ValueError("every criterion must be a non-empty string")
        cleaned.append(item.strip())
    return cleaned


def _check_money(amount_minor, currency) -> None:
    if type(amount_minor) is not int:
        raise ValueError("amount_minor must be an int in minor units")
    if not isinstance(currency, str) or not _CURRENCY.match(currency):
        raise ValueError("currency must be a 3-letter uppercase code")


def _task_dict(row) -> dict:
    task = dict(row)
    task["criteria"] = json.loads(task["criteria"])
    return task


class Tasks:
    """Mixin; expects ``self._db`` (Database) and ``self.scope_id``."""

    # -- tasks --------------------------------------------------------------

    def create_task(self, project_id: str, title: str, owner: str,
                    next_action: str, criteria: list[str], priority: int,
                    deadline: str | None = None,
                    procedure: tuple[str, int, int] | None = None,
                    cur=None) -> dict:
        """Create a task in Plan. ``procedure`` = (procedure_id, version,
        step_index) when the task is one step of an instantiated SOP."""
        if cur is None:
            with self._db.transaction() as own:
                return self.create_task(project_id, title, owner, next_action,
                                        criteria, priority, deadline, procedure,
                                        cur=own)
        cleaned = _clean_criteria(criteria)
        for name, value in (("title", title), ("owner", owner),
                            ("next_action", next_action)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        if type(priority) is not int:
            raise ValueError("priority must be an int")
        task_id = new_id()
        stamp = now()
        procedure_id, procedure_version, step_index = procedure or (None, None, None)
        project = cur.execute(
            "SELECT id FROM projects WHERE id = ? AND scope_id = ?",
            (project_id, self.scope_id)).fetchone()
        if project is None:
            raise ValueError(
                f"project {project_id!r} not found in scope"
                f" {self.scope_id!r}")
        cur.execute(
            "INSERT INTO tasks (id, scope_id, project_id, title, owner,"
            " next_action, criteria, priority, deadline, status,"
            " procedure_id, procedure_version, step_index,"
            " created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Plan', ?, ?, ?, ?, ?)",
            (task_id, self.scope_id, project_id, title, owner,
             next_action, json.dumps(cleaned), priority, deadline,
             procedure_id, procedure_version, step_index, stamp, stamp))
        self._db.audit(cur, "task", task_id, "create", owner,
                       {"status": "Plan", "procedure_id": procedure_id,
                        "procedure_version": procedure_version,
                        "step_index": step_index}, scope_id=self.scope_id)
        row = cur.execute(
            f"SELECT {_TASK_COLUMNS} FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return _task_dict(row)

    def get_task(self, task_id: str) -> dict | None:
        row = self._db.query_one(
            f"SELECT {_TASK_COLUMNS} FROM tasks WHERE id = ? AND scope_id = ?",
            (task_id, self.scope_id))
        return None if row is None else _task_dict(row)

    def list_tasks(self, project_id: str | None = None,
                   status: str | None = None) -> list[dict]:
        sql = f"SELECT {_TASK_COLUMNS} FROM tasks WHERE scope_id = ?"
        params: list = [self.scope_id]
        if project_id is not None:
            sql += " AND project_id = ?"
            params.append(project_id)
        if status is not None:
            if status not in TASK_STATUSES:
                raise ValueError(f"unknown task status {status!r}")
            sql += " AND status = ?"
            params.append(status)
        rows = self._db.query(sql + " ORDER BY created_at, id", params)
        return [_task_dict(r) for r in rows]

    def _require_task(self, task_id: str) -> dict:
        task = self.get_task(task_id)
        if task is None:
            raise LookupError(
                f"task {task_id!r} not found in scope {self.scope_id!r}")
        return task

    def _set_task_status(self, task: dict, status: str, actor: str,
                         cur, **details) -> None:
        if status not in TASK_STATUSES:
            raise ValueError(f"unknown task status {status!r}")
        self._db.update_with_revision(
            "tasks", task["id"], self.scope_id, task["revision"],
            {"status": status}, actor=actor, action=f"status:{status}",
            details={"from": task["status"], "to": status, **details},
            cur=cur, entity_type="task")

    # -- 5M -----------------------------------------------------------------

    def assess_resource(self, task_id: str, category: str, description: str,
                        status: str, na_reason: str | None = None,
                        amount_minor: int | None = None,
                        currency: str | None = None) -> dict:
        if category not in FIVE_M:
            raise ValueError(f"category must be one of {FIVE_M}, got"
                             f" {category!r}")
        if status not in RESOURCE_STATUSES:
            raise ValueError(f"status must be one of {RESOURCE_STATUSES}")
        if status == "not_applicable" and not (na_reason and na_reason.strip()):
            raise ValueError("not_applicable requires na_reason")
        if category == "Money" and status != "not_applicable":
            _check_money(amount_minor, currency)
        elif amount_minor is not None or currency is not None:
            raise ValueError("amount_minor/currency only apply to Money")
        task = self._require_task(task_id)
        stamp = now()
        record_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "DELETE FROM resource_assessments"
                " WHERE task_id = ? AND scope_id = ? AND category = ?",
                (task_id, self.scope_id, category))
            cur.execute(
                "INSERT INTO resource_assessments (id, scope_id, task_id,"
                " category, description, status, na_reason, amount_minor,"
                " currency, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (record_id, self.scope_id, task_id, category, description,
                 status, na_reason, amount_minor, currency, stamp, stamp))
            self._db.audit(cur, "resource_assessment", record_id, "assess",
                           task["owner"], {"task_id": task_id,
                                           "category": category,
                                           "status": status},
                           scope_id=self.scope_id)
        return self._resource(record_id)

    def _resource(self, record_id: str) -> dict:
        return dict(self._db.query_one(
            "SELECT * FROM resource_assessments WHERE id = ? AND scope_id = ?",
            (record_id, self.scope_id)))

    def list_resources(self, task_id: str) -> list[dict]:
        self._require_task(task_id)
        return [dict(r) for r in self._db.query(
            "SELECT * FROM resource_assessments"
            " WHERE task_id = ? AND scope_id = ? ORDER BY category",
            (task_id, self.scope_id))]

    def grant_waiver(self, task_id: str, category: str, reason: str,
                     granted_by: str) -> dict:
        if category not in FIVE_M:
            raise ValueError(f"category must be one of {FIVE_M}")
        if not reason or not reason.strip():
            raise ValueError("waiver reason required")
        self._require_task(task_id)
        waiver_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO waivers (id, scope_id, task_id, category, reason,"
                " granted_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (waiver_id, self.scope_id, task_id, category, reason,
                 granted_by, now()))
            self._db.audit(cur, "waiver", waiver_id, "grant", granted_by,
                           {"task_id": task_id, "category": category},
                           scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM waivers WHERE id = ?", (waiver_id,)))

    # -- dependencies ---------------------------------------------------------

    def add_task_dependency(self, task_id: str, depends_on_task_id: str,
                            actor: str, cur=None) -> dict:
        """``task_id`` cannot start until ``depends_on_task_id`` is Done.

        Both tasks must be in this scope; self-references and anything that
        would close a cycle are refused before the insert.
        """
        if cur is None:
            with self._db.transaction() as own:
                return self.add_task_dependency(task_id, depends_on_task_id,
                                                actor, cur=own)
        if task_id == depends_on_task_id:
            raise ValueError("a task cannot depend on itself")
        for name, value in (("task", task_id), ("dependency", depends_on_task_id)):
            if cur.execute("SELECT 1 FROM tasks WHERE id = ? AND scope_id = ?",
                           (value, self.scope_id)).fetchone() is None:
                raise ValueError(
                    f"{name} {value!r} not found in scope {self.scope_id!r}")
        if task_id in self._upstream_ids(depends_on_task_id, cur):
            raise ValueError("dependency would create a cycle")
        if cur.execute(
                "SELECT 1 FROM task_dependencies WHERE task_id = ?"
                " AND depends_on_task_id = ?",
                (task_id, depends_on_task_id)).fetchone():
            raise ConflictError("dependency already recorded")
        dependency_id = new_id()
        cur.execute(
            "INSERT INTO task_dependencies (id, scope_id, task_id,"
            " depends_on_task_id, created_at) VALUES (?, ?, ?, ?, ?)",
            (dependency_id, self.scope_id, task_id, depends_on_task_id, now()))
        self._db.audit(cur, "task", task_id, "depends_on", actor,
                       {"depends_on_task_id": depends_on_task_id},
                       scope_id=self.scope_id)
        return dict(cur.execute("SELECT * FROM task_dependencies WHERE id = ?",
                                (dependency_id,)).fetchone())

    def _upstream_ids(self, task_id: str, cur) -> set[str]:
        """Every task ``task_id`` transitively depends on."""
        seen, frontier = set(), [task_id]
        while frontier:
            current = frontier.pop()
            for row in cur.execute(
                    "SELECT depends_on_task_id FROM task_dependencies"
                    " WHERE task_id = ? AND scope_id = ?",
                    (current, self.scope_id)).fetchall():
                upstream = row["depends_on_task_id"]
                if upstream not in seen:
                    seen.add(upstream)
                    frontier.append(upstream)
        return seen

    def list_task_dependencies(self, task_id: str) -> list[dict]:
        """Direct dependencies with the upstream task's title and status."""
        self._require_task(task_id)
        return [dict(r) for r in self._db.query(
            "SELECT d.id, d.task_id, d.depends_on_task_id, d.created_at,"
            " t.title, t.status FROM task_dependencies d"
            " JOIN tasks t ON t.id = d.depends_on_task_id"
            " WHERE d.task_id = ? AND d.scope_id = ?"
            " ORDER BY d.created_at, d.rowid", (task_id, self.scope_id))]

    # -- Plan → Do ----------------------------------------------------------

    def start_gate_reasons(self, task_id: str) -> list[str]:
        """Every reason the task cannot leave Plan; empty means ready."""
        task = self._require_task(task_id)
        reasons = []
        if task["status"] != "Plan":
            reasons.append(f"task is in {task['status']}, not Plan")
        for field in ("owner", "next_action"):
            if not task[field].strip():
                reasons.append(f"{field} missing")
        if not task["criteria"]:
            reasons.append("criteria missing")
        assessed = {r["category"]: r for r in self.list_resources(task_id)}
        waived = {r["category"] for r in self._db.query(
            "SELECT category FROM waivers WHERE task_id = ? AND scope_id = ?",
            (task_id, self.scope_id))}
        for category in FIVE_M:
            assessment = assessed.get(category)
            if assessment is None:
                reasons.append(f"{category} not assessed")
            elif assessment["status"] == "missing" and category not in waived:
                reasons.append(f"{category} missing without waiver")
        for dependency in self.list_task_dependencies(task_id):
            if dependency["status"] != "Done":
                reasons.append(f"waiting on: {dependency['title']}")
        return reasons

    def start_task(self, task_id: str) -> dict:
        task = self._require_task(task_id)
        reasons = self.start_gate_reasons(task_id)
        if reasons:
            raise InvariantError(reasons)
        with self._db.transaction() as cur:
            self._set_task_status(task, "Do", task["owner"], cur)
        return self.get_task(task_id)

    # -- Money: allocation vs spending ----------------------------------------

    def authorize_spend(self, task_id: str, amount_minor: int, currency: str,
                        authorized_by: str) -> dict:
        _check_money(amount_minor, currency)
        if not authorized_by or not authorized_by.strip():
            raise ValueError("authorized_by required")
        self._require_task(task_id)
        auth_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO spend_authorizations (id, scope_id, task_id,"
                " amount_minor, currency, authorized_by, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (auth_id, self.scope_id, task_id, amount_minor, currency,
                 authorized_by, now()))
            self._db.audit(cur, "spend_authorization", auth_id, "authorize",
                           authorized_by, {"task_id": task_id,
                                           "amount_minor": amount_minor,
                                           "currency": currency},
                           scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM spend_authorizations WHERE id = ?", (auth_id,)))

    # -- learnings and delivery progress ---------------------------------------

    def add_learning(self, task_id: str, text: str) -> dict:
        if not isinstance(text, str) or not text.strip():
            raise ValueError("learning text must be a non-empty string")
        task = self._require_task(task_id)
        learning_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO learnings (id, scope_id, task_id, text,"
                " created_at) VALUES (?, ?, ?, ?, ?)",
                (learning_id, self.scope_id, task_id, text, now()))
            self._db.audit(cur, "learning", learning_id, "create",
                           task["owner"], {"task_id": task_id},
                           scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM learnings WHERE id = ?", (learning_id,)))

    def list_learnings(self, task_id: str) -> list[dict]:
        self._require_task(task_id)
        return [dict(r) for r in self._db.query(
            "SELECT * FROM learnings WHERE task_id = ? AND scope_id = ?"
            " ORDER BY created_at, rowid", (task_id, self.scope_id))]

    def project_progress(self, project_id: str) -> dict:
        """Delivery progress only; says nothing about the goal metric."""
        if self.get_project(project_id) is None:
            raise LookupError(
                f"project {project_id!r} not found in scope {self.scope_id!r}")
        row = self._db.query_one(
            "SELECT COUNT(*) AS total,"
            " COALESCE(SUM(status = 'Done'), 0) AS done"
            " FROM tasks WHERE project_id = ? AND scope_id = ?",
            (project_id, self.scope_id))
        return {"done": row["done"], "total": row["total"]}

    def can_spend(self, task_id: str) -> bool:
        """True only with an explicit authorization; allocation never counts."""
        self._require_task(task_id)
        row = self._db.query_one(
            "SELECT 1 FROM spend_authorizations"
            " WHERE task_id = ? AND scope_id = ? LIMIT 1",
            (task_id, self.scope_id))
        return row is not None

    def spend_authorized_minor(self, task_id: str, currency: str) -> int:
        """Sum of explicit authorizations in ``currency`` (minor units)."""
        self._require_task(task_id)
        row = self._db.query_one(
            "SELECT COALESCE(SUM(amount_minor), 0) AS total"
            " FROM spend_authorizations"
            " WHERE task_id = ? AND scope_id = ? AND currency = ?",
            (task_id, self.scope_id, currency))
        return int(row["total"])

    def record_spend_intent(self, task_id: str, execution_id: str,
                            amount_minor: int, currency: str) -> dict:
        """The cap a live execution may cost, written before the paid call."""
        _check_money(amount_minor, currency)
        task = self._require_task(task_id)
        execution = self._db.query_one(
            "SELECT id, agent_id FROM executions WHERE id = ? AND task_id = ?"
            " AND scope_id = ?", (execution_id, task_id, self.scope_id))
        if execution is None:
            raise ValueError(
                f"execution {execution_id!r} does not belong to task {task_id!r}")
        intent_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO spend_intents (id, scope_id, task_id, execution_id,"
                " amount_minor, currency, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (intent_id, self.scope_id, task_id, execution_id, amount_minor,
                 currency, now()))
            self._db.audit(cur, "spend_intent", intent_id, "record",
                           execution["agent_id"],
                           {"task_id": task_id, "execution_id": execution_id,
                            "amount_minor": amount_minor, "currency": currency,
                            "task_owner": task["owner"]},
                           scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM spend_intents WHERE id = ?", (intent_id,)))

    def list_spend_intents(self, task_id: str) -> list[dict]:
        self._require_task(task_id)
        return [dict(r) for r in self._db.query(
            "SELECT * FROM spend_intents WHERE task_id = ? AND scope_id = ?"
            " ORDER BY created_at, rowid", (task_id, self.scope_id))]
