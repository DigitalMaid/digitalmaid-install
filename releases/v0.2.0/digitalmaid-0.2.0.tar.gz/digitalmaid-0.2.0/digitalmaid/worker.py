"""Worker: plan → claim → run → complete, then revision passes.

``tick`` does one pass. ``run_loop`` repeats it until a stop event is set
(the CLI sets it on SIGTERM/SIGINT). While a runner executes in a
background thread the main thread renews the occurrence lease and the
worker heartbeat, so a crashed worker's lease expires and a live one is
never stolen. The worker never decides that work is done: it leaves tasks
in Do with an unchecked output version for a human reviewer.
"""

import os
import socket
import threading
from datetime import datetime, timedelta, timezone

from digitalmaid.errors import ConfigurationError, ConflictError, InvariantError
from digitalmaid.runners import FixtureRunner, RunFailed, RunResult, build_live_runner

UTC = timezone.utc


def default_worker_id() -> str:
    return f"{socket.gethostname()}-{os.getpid()}"


class Worker:
    def __init__(self, store, worker_id: str | None = None,
                 lease_seconds: int = 300,
                 horizon: timedelta = timedelta(days=1),
                 live_config: dict | None = None, transport_factory=None,
                 interval_seconds: int = 15):
        if type(lease_seconds) is not int or lease_seconds < 1:
            raise ValueError("lease_seconds must be a positive int")
        if type(interval_seconds) is not int or interval_seconds < 1:
            raise ValueError("interval_seconds must be a positive int")
        self.store = store
        self.worker_id = worker_id or default_worker_id()
        self.lease_seconds = lease_seconds
        self.horizon = horizon
        self.live_config = live_config or {}
        self.transport_factory = transport_factory
        self.interval_seconds = interval_seconds
        # Renew well inside the lease; a heartbeat is stale once two renewal
        # periods or two idle intervals have passed without one.
        self.renew_every = max(1.0, lease_seconds / 3)
        self.stale_after_seconds = int(max(2 * interval_seconds, 2 * self.renew_every) + 5)

    def runner_for(self, agent: dict):
        if agent["model_policy"]["kind"] == "fixture":
            return FixtureRunner()
        return build_live_runner(agent, transport_factory=self.transport_factory,
                                 overrides=self.live_config)

    # -- one pass --------------------------------------------------------------------

    def tick(self, now_utc: datetime | None = None) -> dict:
        store = self.store
        now_utc = now_utc or datetime.now(UTC)
        summary = {"worker_id": self.worker_id, "planned": 0, "claimed": 0,
                   "succeeded": 0, "blocked": 0, "failed": 0, "lost": 0,
                   "revised": 0, "revision_blocked": 0, "occurrences": []}
        self._beat(None)
        summary["planned"] = store.plan_occurrences(now_utc, self.horizon)
        for occurrence in store.list_due_occurrences(now_utc):
            token = store.claim_occurrence(occurrence["id"], self.worker_id,
                                           self.lease_seconds, now_utc=now_utc)
            if token is None:
                continue
            summary["claimed"] += 1
            self._beat(occurrence["id"])
            result = self._run_leased(occurrence, token)
            try:
                done = store.complete_occurrence(
                    occurrence["id"], token, result.status, task_id=result.task_id,
                    execution_id=result.execution_id, blocked_reasons=result.reasons,
                    actor=f"worker:{self.worker_id}")
            except ConflictError:
                # The lease was lost mid-run; whoever holds it now owns the outcome.
                summary["lost"] += 1
                continue
            finally:
                self._beat(None)
            summary[result.status] += 1
            summary["occurrences"].append({
                "id": done["id"], "status": done["status"],
                "fencing_token": done["fencing_token"], "task_id": done["task_id"]})
        summary["revised"], summary["revision_blocked"] = self._revision_pass()
        return summary

    def _beat(self, occurrence_id: str | None) -> None:
        self.store.heartbeat(self.worker_id, occurrence_id, self.stale_after_seconds)

    def stop(self) -> None:
        """Mark this worker stopped so the UI stops reporting it as alive."""
        self.store.stop_heartbeat(self.worker_id)

    def _run_leased(self, occurrence: dict, token: int) -> RunResult:
        """Run in a thread; renew lease + heartbeat from here until it ends."""
        box: dict = {}

        def target():
            try:
                box["result"] = self._run(occurrence)
            except BaseException as exc:  # surfaces below as a failed occurrence
                box["error"] = exc

        thread = threading.Thread(target=target, name=f"run-{occurrence['id'][:8]}",
                                  daemon=True)
        thread.start()
        while True:
            thread.join(timeout=self.renew_every)
            if not thread.is_alive():
                break
            try:
                self.store.renew_lease(occurrence["id"], token, self.lease_seconds)
                self._beat(occurrence["id"])
            except ConflictError:
                pass  # completion will detect the lost lease
        if "error" in box:
            return RunResult("failed", reasons=[
                f"runner crashed: {type(box['error']).__name__}: {box['error']}"])
        return box["result"]

    def _run(self, occurrence: dict) -> RunResult:
        store = self.store
        job = store.get_job(occurrence["job_id"])
        agent = store.get_agent(job["agent_id"])
        if agent is None:
            return RunResult("failed", reasons=[
                f"agent definition {job['agent_id']!r} not found"])
        try:
            return self.runner_for(agent).run_occurrence(store, job, occurrence, agent)
        except ConfigurationError as exc:
            return RunResult("failed", reasons=[str(exc)])

    def _revision_pass(self) -> tuple[int, int]:
        """Produce the revised version for every open Correction on a job task.

        One attempt per correction: if the latest execution after the
        correction opened already failed, a human decides what happens next;
        the worker never retries a paid call on its own.
        """
        store = self.store
        revised = blocked = 0
        for task in store.list_tasks(status="Do"):
            occurrence = store.occurrence_for_task(task["id"])
            if occurrence is None:
                continue
            correction = next((c for c in store.list_corrections(task["id"])
                               if c["revised_output_version_id"] is None), None)
            if correction is None:
                continue
            executions = store.list_executions(task["id"])
            if executions and executions[-1]["status"] == "failed" \
                    and executions[-1]["created_at"] >= correction["created_at"]:
                blocked += 1
                continue
            job = store.get_job(occurrence["job_id"])
            agent = store.get_agent(job["agent_id"])
            if agent is None:
                continue
            try:
                self.runner_for(agent).revise(store, job, task, occurrence,
                                              correction, agent)
                revised += 1
            except (ConfigurationError, InvariantError, RunFailed):
                blocked += 1
        return revised, blocked

    # -- the loop --------------------------------------------------------------------

    def run_loop(self, stop_event: threading.Event | None = None,
                 on_tick=None, max_ticks: int | None = None) -> int:
        """Tick, sleep ``interval_seconds``, repeat until ``stop_event`` is set.

        Returns the number of ticks. Always marks the heartbeat stopped on
        exit; a tick in progress finishes first so no lease outlives the
        process while an occurrence is half-recorded.
        """
        stop = stop_event or threading.Event()
        ticks = 0
        try:
            while not stop.is_set():
                summary = self.tick()
                ticks += 1
                if on_tick is not None:
                    on_tick(summary)
                if max_ticks is not None and ticks >= max_ticks:
                    break
                stop.wait(self.interval_seconds)
        finally:
            self.stop()
        return ticks
