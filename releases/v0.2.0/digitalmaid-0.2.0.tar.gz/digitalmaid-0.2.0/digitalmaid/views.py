"""Read-side aggregates for the UI (Today, task detail) and widget preferences.

Everything here is derived from the authoritative records; nothing is
computed that the records do not already prove. A task in Do with a
succeeded execution is still "in progress" until a check and a human
acceptance say otherwise.
"""

import json
from datetime import UTC, date, datetime, timedelta

from digitalmaid.db import new_id, now

TODAY_WIDGETS = ("needs_attention", "in_progress", "achieved", "review_inbox",
                 "journal", "capture_inbox")
RECENT_LIMIT = 10
# A Check-phase item or an inbox capture counts as "overdue" after this long.
OVERDUE_AFTER = timedelta(hours=24)
# Execution end states that leave the Do phase stuck without an output.
STUCK_EXECUTIONS = ("failed", "interrupted", "uncertain", "cancelled")


def _parse_stamp(value: str) -> datetime:
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return stamp if stamp.tzinfo else stamp.replace(tzinfo=UTC)


def _age_text(then: str, now_utc: datetime) -> str:
    delta = now_utc - _parse_stamp(then)
    days = delta.days
    if days >= 1:
        return f"{days} day{'s' if days != 1 else ''}"
    hours = max(1, int(delta.total_seconds() // 3600))
    return f"{hours} hour{'s' if hours != 1 else ''}"


def _capture_label(capture: dict) -> str:
    if capture.get("title"):
        return capture["title"]
    if capture.get("url"):
        return capture["url"]
    if capture.get("body_text"):
        return capture["body_text"].split("\n", 1)[0][:120]
    return f"{capture['kind']} capture"


def _clean_widgets(widgets, allowed: tuple[str, ...]) -> list[dict]:
    if not isinstance(widgets, list) or not widgets:
        raise ValueError("widgets must be a non-empty list")
    seen = []
    for item in widgets:
        if not isinstance(item, dict) or item.get("id") not in allowed:
            raise ValueError(f"unknown widget {item!r}; allowed {allowed}")
        if item["id"] in seen:
            raise ValueError(f"widget {item['id']!r} listed twice")
        if not isinstance(item.get("visible"), bool):
            raise ValueError(f"visible must be a bool for {item['id']!r}")
        seen.append(item["id"])
    missing = [w for w in allowed if w not in seen]
    if missing:
        raise ValueError(f"widgets missing {missing}")
    return [{"id": w["id"], "visible": w["visible"]} for w in widgets]


class Views:
    """Mixin; expects the Tasks, Outputs and Checks mixins."""

    def task_detail(self, task_id: str) -> dict:
        task = self._require_task(task_id)
        versions = self.list_output_versions(task_id)
        return {
            "task": task,
            "gate_reasons": (self.start_gate_reasons(task_id)
                             if task["status"] == "Plan" else []),
            "dependencies": self.list_task_dependencies(task_id),
            "resources": self.list_resources(task_id),
            "can_spend": self.can_spend(task_id),
            "executions": self.list_executions(task_id),
            "output_versions": versions,
            "checks": self.list_checks(task_id),
            "corrections": self.list_corrections(task_id),
            "acceptance": next(
                (a for a in (self.get_acceptance(v["id"]) for v in versions)
                 if a is not None), None),
            "learnings": self.list_learnings(task_id),
            "comments": [c for v in versions
                         for c in self.list_review_comments(v["id"])],
            "notes": self.notes_linked_to("task", task_id),
        }

    def _latest_execution(self, task_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM executions WHERE task_id = ? AND scope_id = ?"
            " ORDER BY created_at DESC, rowid DESC LIMIT 1",
            (task_id, self.scope_id))
        return None if row is None else self._execution_dict(row)

    def _latest_failed_check(self, task_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT c.id FROM checks c"
            " JOIN output_versions v ON v.id = c.output_version_id"
            " JOIN outputs o ON o.id = v.output_id"
            " WHERE o.task_id = ? AND c.scope_id = ? AND c.passed = 0"
            " ORDER BY c.created_at DESC, c.rowid DESC LIMIT 1",
            (task_id, self.scope_id))
        return None if row is None else self.get_check(row["id"])

    def _with_project(self, task: dict, projects: dict) -> dict:
        project = projects.get(task["project_id"])
        return {**task, "project_title": project["title"] if project else None}

    def pdcc_counts(self) -> dict:
        """Open tasks per PDCC phase in this scope (Done is not open)."""
        rows = self._db.query(
            "SELECT status, COUNT(*) AS n FROM tasks WHERE scope_id = ?"
            " GROUP BY status", (self.scope_id,))
        by_status = {r["status"]: r["n"] for r in rows}
        return {phase.lower(): int(by_status.get(phase, 0))
                for phase in ("Plan", "Do", "Check", "Correction")}

    def next_action(self, now_utc: datetime | None = None) -> dict | None:
        """The single most important thing to do now, or None.

        Priority (DESIGN.md C1): overdue Check > blocked Do > oldest Correction
        > inbox capture older than 24 h > next scheduled automation. ``phase``
        names the hero node the action belongs to.
        """
        moment = now_utc or datetime.now(UTC)
        cutoff = moment - OVERDUE_AFTER
        # 1. Check phase waiting on a human for more than a day: an unchecked latest
        #    version, or a passed check still waiting for acceptance.
        inbox = self.review_inbox()
        overdue = []
        for item in inbox["awaiting_check"]:
            version = item["latest_version"]
            if _parse_stamp(version["created_at"]) <= cutoff:
                overdue.append((version["created_at"], item, version, None))
        for task in self.list_tasks(status="Check"):
            if _parse_stamp(task["updated_at"]) <= cutoff:
                overdue.append((task["updated_at"], task, None, "acceptance"))
        if overdue:
            stamp, task, version, kind = min(overdue, key=lambda o: o[0])
            if kind == "acceptance":
                reason = (f"checked and passed; waiting {_age_text(stamp, moment)}"
                          f" for human acceptance")
            else:
                reason = (f"version {version['version']} has waited"
                          f" {_age_text(stamp, moment)} for a check")
            return {"label": f"Check: {task['title']}", "href": "#/review",
                    "reason": reason, "phase": "check"}
        # 2. Do phase stuck: the latest execution ended without an output.
        for task in self.list_tasks(status="Do"):
            execution = self._latest_execution(task["id"])
            if execution and execution["status"] in STUCK_EXECUTIONS:
                detail = f": {execution['log']}" if execution.get("log") else ""
                return {"label": f"Unblock: {task['title']}",
                        "href": f"#/goals/{task['id']}",
                        "reason": f"latest execution {execution['status']}{detail}",
                        "phase": "do"}
        # 3. Oldest open Correction.
        corrections = sorted(self.list_tasks(status="Correction"),
                             key=lambda t: t["updated_at"])
        if corrections:
            task = corrections[0]
            check = self._latest_failed_check(task["id"])
            failed = [r["criterion"] for r in check["results"] if not r["passed"]] if check else []
            reason = (f"in Correction for {_age_text(task['updated_at'], moment)}"
                      + (f"; failed: {', '.join(failed)}" if failed else ""))
            return {"label": f"Correct: {task['title']}", "href": f"#/goals/{task['id']}",
                    "reason": reason, "phase": "correction"}
        # 4. Raw material waiting in the inbox for more than a day.
        stale = [c for c in self.list_captures()
                 if c["status"] in ("inbox", "drafting")
                 and _parse_stamp(c["captured_at"]) <= cutoff]
        if stale:
            capture = min(stale, key=lambda c: c["captured_at"])
            return {"label": f"Triage: {_capture_label(capture)}",
                    "href": f"#/capture/{capture['id']}",
                    "reason": (f"captured {_age_text(capture['captured_at'], moment)} ago,"
                               f" not yet converted"), "phase": "inbox"}
        # 5. The next due occurrence of any job.
        row = self._db.query_one(
            "SELECT o.occurrence_utc, o.kind, j.purpose FROM job_occurrences o"
            " JOIN automation_jobs j ON j.id = o.job_id"
            " WHERE o.scope_id = ? AND o.status = 'due'"
            " ORDER BY o.occurrence_utc, o.rowid LIMIT 1", (self.scope_id,))
        if row is not None:
            return {"label": f"Run: {row['purpose']}", "href": "#/automations",
                    "reason": f"{row['kind']} occurrence due {row['occurrence_utc'][:16]}Z",
                    "phase": "automations"}
        return None

    def today(self, now_utc: datetime | None = None) -> dict:
        projects = {p["id"]: p for p in self.list_projects()}
        in_correction = []
        for task in self.list_tasks(status="Correction"):
            check = self._latest_failed_check(task["id"])
            in_correction.append({
                **self._with_project(task, projects),
                "failed_check": check,
                "failed_criteria": [r["criterion"] for r in check["results"]
                                    if not r["passed"]] if check else []})
        awaiting_acceptance = []
        for task in self.list_tasks(status="Check"):
            output = self.get_output(task["id"])
            latest = next((v for v in self.list_output_versions(task["id"])
                           if v["version"] == output["latest_version"]), None)
            awaiting_acceptance.append({
                **self._with_project(task, projects),
                "latest_version": latest})
        blocked_in_plan = [
            {**self._with_project(task, projects),
             "reasons": self.start_gate_reasons(task["id"])}
            for task in self.list_tasks(status="Plan")]
        in_progress = [
            {**self._with_project(task, projects),
             "latest_execution": self._latest_execution(task["id"])}
            for task in self.list_tasks(status="Do")]
        done = sorted(self.list_tasks(status="Done"),
                      key=lambda t: t["updated_at"], reverse=True)
        decided_goals = [
            {**goal, "outcome": self.get_goal_outcome(goal["id"])}
            for goal in self.list_goals() if goal["outcome_status"] != "open"]
        decision_reviews_due = [
            {**note, "reason": "decision review due"}
            for note in self.decision_reviews_due()]
        today_iso = date.today().isoformat()
        entry = self.journal_entry(today_iso)
        return {
            "generated_at": now(),
            "review_inbox_count": self.review_inbox()["count"],
            "capture_inbox_count": self.count_open_captures(),
            "pdcc_counts": self.pdcc_counts(),
            "next_action": self.next_action(now_utc),
            "journal_today": {"written": entry is not None,
                              "entry_date": today_iso,
                              "note_id": entry["id"] if entry else None},
            "needs_attention": {
                "in_correction": in_correction,
                "awaiting_acceptance": awaiting_acceptance,
                "blocked_in_plan": blocked_in_plan,
                "decision_reviews_due": decision_reviews_due,
            },
            "in_progress": in_progress,
            "instrument": self.instrument(now_utc),
            "achieved": {
                "done_tasks": [self._with_project(t, projects)
                               for t in done[:RECENT_LIMIT]],
                "decided_goals": decided_goals,
            },
        }

    # -- the Today instrument ---------------------------------------------------------

    def instrument(self, now_utc: datetime | None = None) -> dict:
        """Everything the hero constellation draws, as real state (DESIGN.md Observatory).

        stars: one per open task with its phase and the state that drives its look —
        Plan: unmet 5M gates / ready; Do: latest execution status; Check: hours waiting
        and overdue; Correction: failed criteria count. ``next`` marks the next_action's
        task. core: acceptances (total, last 7 days). rings: enabled automation jobs with
        period and next due instant. Plus captures_open, worker_alive, journal_written.
        """
        moment = now_utc or datetime.now(UTC)
        cutoff = moment - OVERDUE_AFTER
        next_action = self.next_action(now_utc)
        next_href = next_action["href"] if next_action else None
        stars = []
        for task in self.list_tasks():
            phase = task["status"].lower()
            if phase not in ("plan", "do", "check", "correction"):
                continue
            star = {"id": task["id"], "title": task["title"], "phase": phase,
                    "href": f"#/goals/{task['id']}", "priority": task["priority"],
                    "next": next_href == f"#/goals/{task['id']}"}
            if phase == "plan":
                reasons = self.start_gate_reasons(task["id"])
                star["gates_unmet"] = len(reasons)
                star["ready"] = not reasons
            elif phase == "do":
                execution = self._latest_execution(task["id"])
                star["execution"] = execution["status"] if execution else None
            elif phase == "check":
                waited = (moment - _parse_stamp(task["updated_at"])).total_seconds() / 3600
                star["waiting_hours"] = round(max(0.0, waited), 1)
                star["overdue"] = _parse_stamp(task["updated_at"]) <= cutoff
            else:
                check = self._latest_failed_check(task["id"])
                star["failed_criteria"] = (sum(1 for r in check["results"] if not r["passed"])
                                           if check else 0)
            stars.append(star)
        # A Check waiting on a human is also "next" when next_action points at the review inbox.
        if next_action and next_action.get("phase") == "check":
            label = next_action["label"].removeprefix("Check: ")
            for star in stars:
                if star["phase"] == "check" and star["title"] == label:
                    star["next"] = True
                    break
        week_ago = (moment - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")
        row = self._db.query_one(
            "SELECT COUNT(*) AS total,"
            " SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END) AS recent"
            " FROM acceptances WHERE scope_id = ?", (week_ago, self.scope_id))
        core = {"accepted_total": int(row["total"] or 0), "accepted_7d": int(row["recent"] or 0)}
        rings = []
        for job in self.list_jobs():
            if not job["enabled"]:
                continue
            spec, kind = job["schedule_spec"], job["schedule_kind"]
            period = (spec["every_seconds"] if kind == "interval"
                      else 86400 if kind == "cron-lite" else None)
            due = self._db.query_one(
                "SELECT COUNT(*) AS n, MIN(occurrence_utc) AS next_utc FROM job_occurrences"
                " WHERE job_id = ? AND scope_id = ? AND status = 'due'", (job["id"], self.scope_id))
            rings.append({"id": job["id"], "title": job["purpose"], "kind": kind,
                          "period_seconds": period, "due": int(due["n"] or 0),
                          "next_utc": due["next_utc"]})
        workers = self.list_workers(moment)
        return {"stars": stars, "core": core, "rings": rings,
                "captures_open": self.count_open_captures(),
                "worker_alive": any(w["alive"] for w in workers),
                "journal_written": self.journal_entry(date.today().isoformat()) is not None}

    # -- review inbox and outputs -----------------------------------------------------

    def review_inbox(self) -> dict:
        """What a human reviewer has to look at, derived from the records.

        awaiting_check: tasks whose latest output version has no Check;
        awaiting_revision: open Corrections with no revised version yet;
        decision_reviews_due: decisions past their review date without an outcome.
        """
        projects = {p["id"]: p for p in self.list_projects()}
        awaiting_check = []
        for row in self._db.query(
                "SELECT o.task_id, v.id AS version_id FROM outputs o"
                " JOIN output_versions v ON v.output_id = o.id"
                " AND v.version = o.latest_version"
                " WHERE o.scope_id = ? AND NOT EXISTS ("
                "SELECT 1 FROM checks c WHERE c.output_version_id = v.id)"
                " ORDER BY v.created_at DESC", (self.scope_id,)):
            task = self.get_task(row["task_id"])
            awaiting_check.append({
                **self._with_project(task, projects),
                "latest_version": self.get_output_version(row["version_id"])})
        awaiting_revision = []
        for row in self._db.query(
                "SELECT * FROM corrections WHERE scope_id = ?"
                " AND revised_output_version_id IS NULL"
                " ORDER BY created_at DESC", (self.scope_id,)):
            correction = dict(row)
            task = self.get_task(correction["task_id"])
            awaiting_revision.append({**self._with_project(task, projects),
                                      "correction": correction,
                                      "failed_check": self.get_check(correction["check_id"])})
        decisions = [{**n, "reason": "decision review due"}
                     for n in self.decision_reviews_due()]
        return {"awaiting_check": awaiting_check,
                "awaiting_revision": awaiting_revision,
                "decision_reviews_due": decisions,
                "count": len(awaiting_check) + len(awaiting_revision) + len(decisions)}

    def list_all_output_versions(self, accepted: bool | None = None) -> list[dict]:
        """Every output version in the scope, newest first, without blob content."""
        if accepted is not None and not isinstance(accepted, bool):
            raise ValueError("accepted must be a bool")
        sql = ("SELECT v.id, v.output_id, v.execution_id, v.version, v.sha256,"
               " v.blob_path, v.criteria_snapshot, v.created_at, o.task_id,"
               " o.latest_version, t.title AS task_title, t.status AS task_status,"
               " t.project_id, a.id AS acceptance_id"
               " FROM output_versions v JOIN outputs o ON o.id = v.output_id"
               " JOIN tasks t ON t.id = o.task_id"
               " LEFT JOIN acceptances a ON a.output_version_id = v.id"
               " WHERE v.scope_id = ?")
        if accepted is True:
            sql += " AND a.id IS NOT NULL"
        elif accepted is False:
            sql += " AND a.id IS NULL"
        versions = []
        for row in self._db.query(sql + " ORDER BY v.created_at DESC, v.rowid DESC",
                                  (self.scope_id,)):
            version = dict(row)
            acceptance_id = version.pop("acceptance_id")
            latest = version.pop("latest_version")
            check = self._latest_check(version["id"])
            version.update({
                "content": None,
                "superseded": version["version"] != latest,
                "accepted": acceptance_id is not None,
                "acceptance": self.get_acceptance(version["id"]) if acceptance_id else None,
                "check_status": ("unchecked" if check is None
                                 else "pass" if check["passed"] else "fail"),
                "execution": self.get_execution(version["execution_id"]),
            })
            versions.append(version)
        return versions

    # -- review comments --------------------------------------------------------------

    def add_review_comment(self, output_version_id: str, author: str,
                           body_md: str) -> dict:
        """A comment on an immutable version; never touches PDCC status."""
        for name, value in (("author", author), ("body_md", body_md)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        self._require_version(output_version_id)
        comment_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO review_comments (id, scope_id, output_version_id,"
                " author, body_md, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (comment_id, self.scope_id, output_version_id, author.strip(),
                 body_md.strip(), now()))
            self._db.audit(cur, "output_version", output_version_id, "comment",
                           author.strip(), {"comment_id": comment_id},
                           scope_id=self.scope_id)
        return dict(self._db.query_one(
            "SELECT * FROM review_comments WHERE id = ?", (comment_id,)))

    def list_review_comments(self, output_version_id: str) -> list[dict]:
        return [dict(r) for r in self._db.query(
            "SELECT * FROM review_comments WHERE output_version_id = ?"
            " AND scope_id = ? ORDER BY created_at, rowid",
            (output_version_id, self.scope_id))]

    # -- automations -------------------------------------------------------------------

    def job_summary(self, job_id: str) -> dict:
        """Job with its agent, upcoming occurrences and run history."""
        job = self._require_job(job_id)
        occurrences = []
        for occurrence in self.list_occurrences(job_id):
            task = self.get_task(occurrence["task_id"]) if occurrence["task_id"] else None
            execution = (self.get_execution(occurrence["execution_id"])
                         if occurrence["execution_id"] else None)
            occurrences.append({**occurrence, "task": task, "execution": execution})
        pending = [o for o in occurrences if o["status"] == "due"]
        history = [o for o in occurrences if o["status"] != "due"]
        return {**job, "agent": self.get_agent(job["agent_id"]),
                "project": self.get_project(job["project_id"]),
                "next_occurrences": pending,
                "occurrences": sorted(history + pending, key=lambda o: o["occurrence_utc"],
                                      reverse=True)[:RECENT_LIMIT * 2]}

    # -- widget preferences ----------------------------------------------------

    def get_widget_preferences(self, area: str = "today") -> dict:
        row = self._db.query_one(
            "SELECT widgets FROM widget_preferences"
            " WHERE scope_id = ? AND area = ?", (self.scope_id, area))
        if row is None:
            return {"widgets": [{"id": w, "visible": True}
                                for w in TODAY_WIDGETS]}
        # Widgets added after the preference was saved appear at the end, visible.
        saved = [w for w in json.loads(row["widgets"]) if w["id"] in TODAY_WIDGETS]
        known = {w["id"] for w in saved}
        saved.extend({"id": w, "visible": True} for w in TODAY_WIDGETS if w not in known)
        return {"widgets": saved}

    def set_widget_preferences(self, widgets, area: str = "today",
                               actor: str = "ui") -> dict:
        if area != "today":
            raise ValueError(f"unknown preference area {area!r}")
        cleaned = _clean_widgets(widgets, TODAY_WIDGETS)
        stamp = now()
        with self._db.transaction() as cur:
            existing = cur.execute(
                "SELECT id, revision FROM widget_preferences"
                " WHERE scope_id = ? AND area = ?",
                (self.scope_id, area)).fetchone()
            if existing is None:
                pref_id = new_id()
                cur.execute(
                    "INSERT INTO widget_preferences (id, scope_id, area,"
                    " widgets, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, ?)",
                    (pref_id, self.scope_id, area, json.dumps(cleaned),
                     stamp, stamp))
                self._db.audit(cur, "widget_preference", pref_id, "create",
                               actor, {"area": area}, scope_id=self.scope_id)
            else:
                self._db.update_with_revision(
                    "widget_preferences", existing["id"], self.scope_id,
                    existing["revision"], {"widgets": json.dumps(cleaned)},
                    actor=actor, action="update", details={"area": area},
                    cur=cur, entity_type="widget_preference")
        return {"widgets": cleaned}
