"""Check, Correction and human Acceptance against immutable output versions."""

import json

from digitalmaid.db import new_id, now
from digitalmaid.errors import InvariantError


def _clean_results(results, criteria: list[str]) -> list[dict]:
    if not isinstance(results, list):
        raise ValueError("results must be a list")
    seen = {}
    for item in results:
        criterion = item.get("criterion") if isinstance(item, dict) else None
        if criterion not in criteria:
            raise ValueError(f"criterion {criterion!r} is not in the snapshot")
        if criterion in seen:
            raise ValueError(f"criterion {criterion!r} listed twice")
        if not isinstance(item.get("passed"), bool):
            raise ValueError(f"passed must be a bool for {criterion!r}")
        evidence = item.get("evidence")
        if not isinstance(evidence, str) or not evidence.strip():
            raise ValueError(f"evidence required for {criterion!r}")
        seen[criterion] = {"criterion": criterion, "passed": item["passed"],
                           "evidence": evidence}
    missing = [c for c in criteria if c not in seen]
    if missing:
        raise ValueError(f"results missing criteria {missing}")
    return [seen[c] for c in criteria]


class Checks:
    """Mixin; expects ``self._db``, ``self.scope_id``, Tasks and Outputs."""

    def _require_version(self, version_id: str) -> dict:
        version = self.get_output_version(version_id)
        if version is None:
            raise LookupError(
                f"output version {version_id!r} not found in scope"
                f" {self.scope_id!r}")
        return version

    def _latest_check(self, version_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM checks WHERE output_version_id = ? AND scope_id = ?"
            " ORDER BY created_at DESC, rowid DESC LIMIT 1",
            (version_id, self.scope_id))
        return None if row is None else dict(row)

    def record_check(self, output_version_id: str, reviewer: str,
                     results: list[dict]) -> dict:
        if not reviewer or not reviewer.strip():
            raise ValueError("reviewer required")
        version = self._require_version(output_version_id)
        criteria = json.loads(version["criteria_snapshot"])
        cleaned = _clean_results(results, criteria)
        task = self._require_task(version["task_id"])
        reasons = []
        if task["status"] != "Do":
            reasons.append(f"task is in {task['status']}, not Do")
        output = self.get_output(task["id"])
        if version["version"] != output["latest_version"]:
            reasons.append(f"version {version['version']} is superseded by"
                           f" {output['latest_version']}")
        if reasons:
            raise InvariantError(reasons)
        passed = all(r["passed"] for r in cleaned)
        check_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO checks (id, scope_id, output_version_id,"
                " reviewer, passed, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (check_id, self.scope_id, output_version_id, reviewer,
                 int(passed), now()))
            cur.executemany(
                "INSERT INTO check_results (id, check_id, criterion, passed,"
                " evidence) VALUES (?, ?, ?, ?, ?)",
                [(new_id(), check_id, r["criterion"], int(r["passed"]),
                  r["evidence"]) for r in cleaned])
            self._db.audit(cur, "check", check_id,
                           "pass" if passed else "fail", reviewer,
                           {"output_version_id": output_version_id,
                            "failed": [r["criterion"] for r in cleaned
                                       if not r["passed"]]},
                           scope_id=self.scope_id)
            self._set_task_status(task, "Check" if passed else "Correction",
                                  reviewer, cur, check_id=check_id)
        return self.get_check(check_id)

    def get_check(self, check_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM checks WHERE id = ? AND scope_id = ?",
            (check_id, self.scope_id))
        if row is None:
            return None
        check = dict(row)
        check["passed"] = bool(check["passed"])
        check["results"] = [
            {"criterion": r["criterion"], "passed": bool(r["passed"]),
             "evidence": r["evidence"]}
            for r in self._db.query(
                "SELECT criterion, passed, evidence FROM check_results"
                " WHERE check_id = ? ORDER BY rowid", (check_id,))]
        return check

    def open_correction(self, check_id: str, owner: str, action: str) -> dict:
        if not owner.strip() or not action.strip():
            raise ValueError("owner and action required")
        check = self.get_check(check_id)
        if check is None:
            raise LookupError(f"check {check_id!r} not found in scope")
        version = self._require_version(check["output_version_id"])
        task = self._require_task(version["task_id"])
        reasons = []
        if check["passed"]:
            reasons.append("check passed; no correction required")
        if task["status"] != "Correction":
            reasons.append(f"task is in {task['status']}, not Correction")
        if self._db.query_one(
                "SELECT 1 FROM corrections WHERE check_id = ?", (check_id,)):
            reasons.append("correction already opened for this check")
        if reasons:
            raise InvariantError(reasons)
        correction_id = new_id()
        stamp = now()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO corrections (id, scope_id, check_id, task_id,"
                " owner, action, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (correction_id, self.scope_id, check_id, task["id"], owner,
                 action, stamp, stamp))
            self._db.audit(cur, "correction", correction_id, "open", owner,
                           {"check_id": check_id, "task_id": task["id"]},
                           scope_id=self.scope_id)
            self._set_task_status(task, "Do", owner, cur,
                                  correction_id=correction_id)
        return self.get_correction(correction_id)

    def get_correction(self, correction_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM corrections WHERE id = ? AND scope_id = ?",
            (correction_id, self.scope_id))
        return None if row is None else dict(row)

    def list_checks(self, task_id: str) -> list[dict]:
        """All checks on any version of the task's output, oldest first."""
        self._require_task(task_id)
        ids = self._db.query(
            "SELECT c.id FROM checks c"
            " JOIN output_versions v ON v.id = c.output_version_id"
            " JOIN outputs o ON o.id = v.output_id"
            " WHERE o.task_id = ? AND c.scope_id = ?"
            " ORDER BY c.created_at, c.rowid", (task_id, self.scope_id))
        return [self.get_check(r["id"]) for r in ids]

    def list_corrections(self, task_id: str) -> list[dict]:
        self._require_task(task_id)
        return [dict(r) for r in self._db.query(
            "SELECT * FROM corrections WHERE task_id = ? AND scope_id = ?"
            " ORDER BY created_at, rowid", (task_id, self.scope_id))]

    def get_acceptance(self, output_version_id: str) -> dict | None:
        row = self._db.query_one(
            "SELECT * FROM acceptances WHERE output_version_id = ?"
            " AND scope_id = ?", (output_version_id, self.scope_id))
        return None if row is None else dict(row)

    def accept_output(self, output_version_id: str, accepted_by: str) -> dict:
        """Human acceptance: the only way a task reaches Done."""
        if not accepted_by or not accepted_by.strip():
            raise ValueError("accepted_by required")
        version = self._require_version(output_version_id)
        task = self._require_task(version["task_id"])
        output = self.get_output(task["id"])
        latest_check = self._latest_check(output_version_id)
        reasons = []
        if version["version"] != output["latest_version"]:
            reasons.append(f"version {version['version']} is superseded by"
                           f" {output['latest_version']}")
        if latest_check is None:
            reasons.append("version has not been checked")
        elif not latest_check["passed"]:
            reasons.append("latest check on this version failed")
        if task["status"] != "Check":
            reasons.append(f"task is in {task['status']}, not Check")
        if reasons:
            raise InvariantError(reasons)
        acceptance_id = new_id()
        with self._db.transaction() as cur:
            cur.execute(
                "INSERT INTO acceptances (id, scope_id, output_version_id,"
                " accepted_by, created_at) VALUES (?, ?, ?, ?, ?)",
                (acceptance_id, self.scope_id, output_version_id,
                 accepted_by, now()))
            self._db.audit(cur, "output_version", output_version_id, "accept",
                           accepted_by, {"acceptance_id": acceptance_id,
                                         "check_id": latest_check["id"]},
                           scope_id=self.scope_id)
            self._set_task_status(task, "Done", accepted_by, cur,
                                  acceptance_id=acceptance_id)
        return dict(self._db.query_one(
            "SELECT * FROM acceptances WHERE id = ?", (acceptance_id,)))
